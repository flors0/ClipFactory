# ClipFactory 1.1.0 Release Notes

Release date: 2026-09-03

## 1.1.0 changes

- Added channel-driven automatic preset selection. Batch Planner can now use each selected
  channel's stable Core preset and visual-design default without manually pairing them for every
  batch.
- Added five complete visual designs above the existing component profiles. The new
  screenshot-inspired **Creator Stack** uses full-frame video, a compact two-tone header and a
  persistent lower-left ranking stack; Clean Banner, Minimal Overlay, Neon Countdown and the
  text-free Compilation design remain available.
- Expanded the component library to eight Ranking-number, five Caption and five Header profiles.
  Complete designs and individual components can be changed independently.
- Added per-video design editing in Review Queue. A reviewer can switch the complete design,
  number/caption/header components, header background, or open the full visual layout editor and
  re-render from the persisted render plan without discovering, downloading or analyzing clips
  again.
- Added direct Review fields for YouTube title/description and TikTok caption alongside the
  advanced JSON metadata editor.
- Added opt-in-per-edit, locally persisted adaptive Gemini writing memory. ClipFactory stores the
  AI original next to the user's saved correction, scopes one-off preferences to the same channel,
  promotes only field-level patterns repeated in at least three distinct Reviews across channels
  with the same language/platform, and supplies a bounded set of inert examples to later
  `creative-v3` prompts. Multiple edits inside one video cannot masquerade as independent evidence.
  This is prompt adaptation, not opaque model fine-tuning.
- Added a Settings switch, example limit, recurrence threshold, visible memory count and an
  explicit **Forget Learned Writing Preferences** action.
- Persisted the complete preset snapshot and design ID with each Review item and production job so
  later Core-preset edits cannot silently alter an already reviewed video's re-render.
- Added an idempotent database migration for visual designs and editorial feedback; existing
  presets, channels, jobs, reviews, media, logs, assets and credentials remain intact.
- Updated the supported end-user distribution to a Windows one-directory executable package with
  `ClipFactory.exe` as the launch point.
- Added Windows CI verification for the complete locked test suite, the built EXE, a 12-second GUI
  launch, the final ZIP-extracted EXE, packaged migrations, and forbidden private/runtime files.

## 1.1.0 acceptance

- Local suite: 125 passed, 1 skipped on 2026-09-03. The skip is the Qt wheel-event simulation on
  the Linux verification image without `libEGL.so.1`; it remains enabled on Windows.
- Controlled three-job batch: 3/3 outputs reached Review Queue, used 15 distinct marked source
  clips, and each probed as H.264/AAC, 360×640, 30 fps, and exactly 6.000 seconds.
- Controlled editorial re-render: title, header, five captions, and complete design changed; the
  output returned to Review Queue with zero repeated discovery, download, or clip-analysis steps.
- Visual inspection: Creator Stack retained fixed `1..5` rows and cumulative caption/rank coupling
  through playback `5→1`; Neon Countdown visibly changed the complete design while preserving the
  edited copy.

## 1.0.10 changes

- Fixed the production contradiction where a preset using duration enforcement `warn` was allowed
  through selection and rendering, then rejected by the final deterministic `Duration` check.
  The final check now remains visible but non-blocking for `warn`; `block` and `auto_extend`
  remain blocking.
- Made AI trim suggestions preferred windows rather than accidental hard duration caps. When safe
  selected source clips contain enough additional footage, ClipFactory expands around the
  suggested moment and reaches the preset target without looping, duplicating, or inventing
  filler.
- Kept the target distinct from the allowed duration range. A selection inside the configured
  minimum/maximum range is valid even when it falls slightly short of the ideal target.
- Moved blocking duration/clip-count failures ahead of copy generation and FFmpeg rendering and
  added exact selected count, selected duration, allowed range, target, and aggregated rejection
  reasons to the failure.
- Added partial-selection diagnostics. Pools that yield some clips but not enough now report the
  same rights, watermark, history, duplicate, and AI-score rejection counts as total failures.
- Review Queue displays a non-blocking failed check with a warning symbol instead of presenting it
  as a blocking technical failure.
- Restored the source `.gitignore` and safe `.env.example`; generated `.ruff_cache`,
  `.pytest_cache`, bytecode, virtual environments, and user media are excluded from the release.
- Existing `data/`, presets, style profiles, jobs, reviews, logs, assets, and credentials require
  no destructive migration and remain compatible.

## 1.0.9 changes

- Reworked production clip eligibility so one opaque Gemini `usable=false` decision no longer
  empties an otherwise safe candidate pool. Strict AI score gates still run first; when enabled in
  Batch Planner, a visible automatic fallback fills the required ranking from the strongest clips
  above the configured fallback floor.
- Preserved all hard exclusions during fallback: restricted/uncleared rights policies, sensitive
  content, configured watermark and embedded-text rejection, source duration, duplicate media,
  batch exclusions, and used-media history are never silently relaxed.
- Added per-candidate rejection reasons and aggregated failure summaries to Production Queue logs.
  A failed selection now reports whether rights, watermark, history, scores, duration, or another
  concrete gate rejected the pool.
- Invalid AI trim suggestions shorter than the configured minimum now fall back to the safe full
  source window instead of discarding the clip. Similar first-pass captions no longer discard good
  media; project-level copy generation can rewrite them.
- Fixed the Windows Qt `StrEnum`/`QVariant` conversion that could make the Style Profiles dialog
  treat a valid category as absent and show an empty profile list.
- Added direct **Style profile** dropdowns to the right-hand properties panel for Ranking Numbers,
  Ranking Captions, and Header layers, plus **Save as New…** for custom profiles. The full profile
  management dialog remains available.
- Added the complete empty `assets/` tree to the source release, including transition, sound,
  image, font, meme, background, and related folders. No media asset is bundled or enabled.

## 1.0.8 changes

- Ranking videos now use an explicit best-last countdown: AI rank `1` remains the best item and
  the top overlay row, while the final media timeline plays `N → … → 2 → 1`. Clip, rank, caption,
  reveal, and active-number state remain coupled through the same ranked records.
- Preserved the active-rank color behavior. All numbers remain visible; only the currently playing
  rank receives its active color/opacity, previously revealed captions remain visible, and future
  captions remain absent.
- Increased the shipped Ranking-number size from 58 to 88 and Caption size from 48 to 60 at a
  1920-pixel reference height. Font, outline, shadow, blur, glow, and letter spacing now scale with
  output height for consistent layouts at other vertical resolutions.
- Added reusable SQLite-backed style profiles with stable IDs and an idempotent migration:
  seven Ranking-number profiles, four Caption profiles, and four Header profiles.
- Added the built-in Ranking styles **ClipFactory Classic**, **Classic Multicolor**,
  **Podium Pop**, **Violet Neon**, **Golden Glow**, **Electric Cyan**, and **Sunset Heat**.
  Profiles support per-rank active/inactive colors, opacity, outline, shadow, and libass glow.
- Added **Style Profiles…** to the Preset editor. Built-in and custom profiles can be applied,
  captured from the current manual style, duplicated, updated, renamed where custom, deleted where
  custom, and reset where built-in. Manual layer controls remain authoritative and unmatched
  changes are represented as `Custom (unsaved)`.
- Added equivalent reusable profiles for Caption and Header text, including transparent,
  editorial, soft-shadow, and neon variants. Applying a profile changes real renderer inputs,
  not preview-only state.
- Preserved existing custom presets during the v1.0.7 migration. Only untouched shipped core
  typography receives the larger v1.0.8 defaults; customized typography remains unchanged.
- Every render now records the selected style-profile IDs and deterministic style fingerprints.
  This is the data contract for a later opt-in YouTube Analytics experiment system; no unfinished
  Analytics switch, OAuth flow, or automatic style selection is exposed in this release.
- No transition or transition sound was added, downloaded, bundled, selected, or enabled.

## 1.0.7 changes

- Ranking captions now reveal at the configured time for their own clip and remain visible through
  the end of the final timeline. Captions belonging to later clips remain absent until their
  reveal. The same timing upgrade is applied when an existing v1.0.6 render plan is re-rendered.
- Added `captions_persist_after_reveal` to the Ranking preset contract. It defaults to enabled and
  remains editable for custom behavior.
- Removed the shipped semi-transparent black Ranking-caption box. The migration changes only
  Ranking caption layers still carrying the exact v1.0.6 default color, so unrelated user styling
  remains intact.
- Reworked Ranking copy prompts around compact reactions: preferably 2–6 words, never more than
  8, scene-specific, dry/playful, and internet-native without explanatory narration, forced slang,
  stale catchphrases, emojis, hashtags, or repeated joke templates.
- Advanced the default clip/creative prompt versions to `clip-v2` and `creative-v2`. Existing
  installations still using the v1 defaults migrate automatically so old cached clip captions do
  not leak into new jobs; custom version strings remain untouched.
- Rebuilt Review Queue layout allocation. The page title is fixed to its natural height, the main
  table/player split is horizontally draggable, and a second vertical splitter independently
  resizes the player against the scrollable editorial/details pane.
- Review Queue horizontal and vertical splitter sizes persist in the existing non-secret UI
  settings and restore after page or application reopen.

## 1.0.6 changes

- Consolidated the five v1.0.5 factory presets into exactly two editable core presets with stable
  IDs: **Ranking** and **TikTok Core Compilation**. Core presets can be saved directly or reset;
  custom presets can be created, duplicated, renamed, and deleted.
- Added an idempotent v1.0.5 migration. Untouched legacy factory presets map to the new cores,
  user-modified legacy cores are retained as deterministic custom presets, existing custom presets
  survive unchanged, and persisted project/job/review/channel references are updated without
  touching credentials, logs, jobs, or other user data.
- Replaced distributed rank calculations with one best-first ranking timeline. Rank `1` is always
  the top row, rank `N` the bottom row, and clip, caption, reveal time, and visible number come from
  the same ranked item.
- Removed the renderer-side `Top N` header rewrite. The AI header is used as returned after only
  technical whitespace normalization and safe wrapping.
- Made Ranking position, alignment, row spacing, text style, caption width/style/reveal, safe
  margins, and audio-boundary settings persistable and renderer-effective.
- Made **TikTok Core Compilation** text-free by default: no header, captions, ranks, subtitles,
  labels, or ClipFactory watermark. AI clip selection stays enabled while unnecessary AI on-video
  copy generation is skipped.
- Added optional preset-driven transitions and transition audio selected exclusively by Asset
  Library ID. Both shipped cores keep transitions disabled and contain no bundled or preselected
  transition/sound asset. Internal boundary counts are exactly `N - 1`, with no intro/outro
  insertion.
- Rebuilt timing around an explicit final timeline so clip boundaries, overlays, optional
  transitions, sound offsets/trims/fades, original audio, and output duration share one source of
  truth.
- Made the full preset contract/property area and the populated Review Queue details area
  vertically scrollable and responsive without regressing numeric-wheel protection.
- Persisted per-log vertical position and follow-tail state. A reopened log returns to its previous
  position; new lines follow only when the user was already at the bottom.
- Added regression and real-FFmpeg coverage for two-core seeding/migration, rank coupling and
  layout, unmodified AI headers, text-free compilation, transition counts/audio, setting reload,
  scroll containers, wheel protection, and log position restore.

## 1.0.5 changes

- Replaced the blocked public Reddit listing path with a fully automatic Arctic Shift source
  provider. It searches current indexed posts by subreddit/time window and preserves the existing
  discovery → analysis → selection → rendering → review → upload pipeline without asking for local
  files or Share Links.
- Added production filters for original audio, minimum short-edge resolution, completed Reddit
  transcodes, age, score, comments, flair, NSFW state, crossposts, removals, and media-level
  duplicates. Mature ranking data is preferred while younger provisional scores are labelled.
- Added bounded API pagination/retries/pacing, rate-limit diagnostics, a local discovery cache, and
  serialized cache misses so parallel batch jobs do not flood the same free endpoint.
- Added direct `v.redd.it` acquisition: ClipFactory selects the highest suitable video stream and
  highest-bitrate original DASH audio, downloads both from allowlisted hosts, and losslessly muxes
  them with FFmpeg. HLS/yt-dlp remains a bounded fallback.
- Existing persisted `public` provider settings automatically route to the new `archive` provider;
  users do not need to recreate source profiles.
- Multi-video jobs sharing one source now receive disjoint candidate windows from a larger common
  pool, avoiding repeated analysis of the same first candidates in a six-video batch.
- Added a password-masked Gemini API key field and optional Reddit/TikTok app credential fields to
  Settings. Values are stored in the OS credential store; `.env` remains only an optional migration
  fallback. New Gemini jobs can use a newly saved key immediately.
- Installed an application-wide wheel guard: mouse-wheel gestures over numeric fields never alter
  their values and are forwarded to the enclosing scroll page.
- Added job/batch/attempt context to every production log line, a persisted attempt sequence that
  also covers editorial re-renders, clear start/end separators, individual attempt log files, and
  a log-page selector for isolated attempt blocks.
- Added regression tests for archive filtering/ranking/cache, direct Reddit audio/video muxing,
  GUI-managed credential precedence/redaction, per-attempt log routing, and wheel protection.

## 1.0.4 fixes

- Kept the credential-free public Reddit provider working when the normal logged-out subreddit
  page returns HTTP 200 but contains only a client-rendered application shell.
- Follows the public server-rendered HTML feed URL advertised by Reddit's own page and supports
  its `faceplate-partial` cursor pagination without using the OAuth-only JSON API.
- Removed the misleading `raw_json=1` query from the HTML listing URL; that parameter never turns
  an HTML route into JSON.
- Retains hard stops for HTTP 403/429, external redirects, non-Reddit pagination URLs, repeated
  cursors, and the existing low request rate.
- Writes successful fallback diagnostics into the production-job log so an RSS or standard-page
  failure remains visible even when the server-rendered feed recovers discovery.
- Added parser and provider regression tests for an RSS 403 plus empty HTTP-200 page followed by a
  successful server-rendered public feed.

## 1.0.3 fixes

- Added a no-cost Gemini model preflight before Reddit discovery, downloads, or media uploads. A
  missing model now reports the `generateContent` models visible to the configured API key/project.
- Sends media up to 14 MiB inline so ordinary short Reddit clips do not depend on a newly created
  Files API resource becoming visible to `generateContent`.
- Retains the Files API for larger media, but retries transient 404/429/5xx responses with bounded
  backoff and still deletes uploaded files in `finally` cleanup.
- Introduced a fatal provider error boundary so a global 400/401/403/404 is not repeated for every
  candidate in the batch.
- Added verified standard pricing entries for stable `gemini-3.1-flash-lite` and
  `gemini-3.5-flash` alternatives.
- Added regression coverage for model visibility diagnostics, inline media requests, and bounded
  ACTIVE-file 404 retries.

## 1.0.2 fixes

- Fixed all live Gemini structured requests failing with HTTP 400 because the legacy
  `response_schema` path serialized strict Pydantic output as the unsupported protobuf field
  `additional_properties`.
- Moved clip analysis, project copy generation, and final-video review to the SDK's native
  `response_json_schema` path. The wire payload now uses the supported
  `responseJsonSchema.additionalProperties` keyword while returned data still undergoes strict
  Pydantic validation.
- Added a wire-serialization regression test that fails if the legacy `responseSchema` field or
  snake-case `additional_properties` reappears.

## 1.0.1 fixes

- Prevented a pasted Gemini key from becoming an in-memory environment-variable reference when
  Settings validation fails.
- Clarified that the Gemini Settings field accepts only `GEMINI_API_KEY`, while the actual value
  belongs in the local `.env` file.
- Removed the configured environment reference from missing-key exceptions and added
  provider-key-pattern redaction as defense in depth.
- Added startup cleanup for credential patterns already present in rotated logs and persisted
  production/review/upload diagnostics after an in-place update.
- Made **Open Output Folder** work even while the Review Queue is empty.
- Added regression coverage for immutable failed settings assignments, provider-key redaction,
  and empty Review Queue output-folder resolution.

## Delivered

- Complete automatic subreddit-based production workflow with no normal local-clip chooser.
- Twelve-page PySide6 desktop UI and two editable, resettable core presets.
- Arctic Shift Reddit discovery, Reddit OAuth boundary, and deterministic mock source providers.
- Direct Reddit video/original-audio acquisition, yt-dlp fallback, hash/cache reuse, ffprobe metadata, FFmpeg rendering, and deterministic validation.
- Gemini structured Pydantic analysis with cache, usage ledger, current price catalog, preflight estimates, concurrency-safe budgets, and uploaded-file deletion.
- Quality/rights/duplicate/history-aware planning, exact videos-per-channel batches, time-zone schedules, and persisted retries.
- Live rich-text preset editing, dynamic styled placeholders, shared preview/render geometry,
  optional Asset Library transitions/interstitials/audio, subtitles, and audio controls.
- Manual review/player/editor, two explicit approval gates, AI-review override audit, and required re-render after editorial changes.
- OS-keyring OAuth/session storage, official YouTube resumable uploads and processing polling, official TikTok direct/draft uploads and sequential chunking.
- SQLite atomic upload claims, missed-job policies, scheduler-only mode, and optional Windows Task Scheduler registration.
- PyInstaller Windows build configuration, setup/security/live-test documentation, and secret-safe archive procedure.

## Verification

- `ruff format --check .`: passed.
- `ruff check .`: passed.
- `pytest -q`: 113 tests passed; one Qt/EGL-dependent test skipped in the Linux container.
- `python -m compileall -q app tests`: passed.
- Application entry-point/parser and PyInstaller spec syntax: passed.
- Embedded yt-dlp worker entry point: passed (`2026.07.04`).
- Controlled v1.0.10 duration-contract render: a deliberately short Ranking output rendered
  successfully under `warn`, retained H.264/AAC video and audio at 360×640 and 30 fps, and entered
  final review with a visible non-blocking Duration warning. Equivalent `block` and `auto_extend`
  checks remained blocking.
- Controlled v1.0.10 trim-extension render: five 0.6-second AI-preferred windows were expanded
  around their original moments to five 1.3-second windows, reaching exactly 6.500 seconds without
  looping footage. FFprobe confirmed H.264/AAC, 360×640, 30 fps, and audio; extracted frames
  confirmed the unchanged `5 → 4 → 3 → 2 → 1` playback and cumulative captions. The same planner
  contract is separately verified at the production target of exactly 65.000 seconds.
- Controlled v1.0.9 fallback acceptance render: five safe candidates that missed strict AI quality
  gates were selected through the configured fallback and rendered as a complete Ranking. FFprobe
  confirmed H.264/AAC, 360×640, 30 fps, and exactly 5.000 s. A five-frame contact sheet confirmed
  `5 → 4 → 3 → 2 → 1` playback and cumulative captions.
- Controlled v1.0.8 Ranking acceptance render: five marked clips, 360×640 at 30 fps, H.264/AAC,
  exactly 5.000 s. Extracted frames at 0.5-second intervals showed media and active-rank order
  `5, 4, 3, 2, 1`; captions accumulated in the same rows and rank `1` appeared as the finale.
- Rendered and visually inspected all seven shipped Ranking-number profiles in a contact sheet.
  Per-rank palettes, active states, outlines, and the Violet/Gold/Cyan glow paths were visible.
- Controlled text-free Compilation acceptance render: three clips, two internal synthetic
  Asset Library transitions/sounds, 360×640 at 30 fps, H.264/AAC, exactly 3.500 s. Extracted
  clip/transition frames contained no ClipFactory text. Frequency-band checks detected original
  audio in clip regions and the synthetic sound at both boundaries. The synthetic assets are test
  artifacts and are not included in the release.

The FFmpeg render and probe integration tests ran successfully in the Linux build container. The Windows PySide6 GUI and real Gemini/YouTube/TikTok calls were not falsely marked as tested: they require the environment, credentials, accounts, and approvals listed in `LIVE_TEST_CHECKLIST.md`.

## Deliberate technical decisions

- Public YouTube schedules use native `publishAt`; private/unlisted YouTube jobs wait for the local execution time to preserve privacy.
- TikTok future scheduling remains local because this integration does not invent a native future-publish field.
- TikTok draft-only tokens never call the direct-post creator-capability endpoint.
- Unknown AI model pricing blocks paid calls rather than guessing cost.
- Rights status never implies ownership; unknown rights use a manual publication authorization gate.
- FFmpeg is not embedded in the source ZIP or PyInstaller configuration and must be installed/configured explicitly.
