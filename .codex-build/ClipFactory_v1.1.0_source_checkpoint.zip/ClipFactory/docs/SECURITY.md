# ClipFactory Security Model

## Goals

ClipFactory protects API credentials, prevents accidental paid work or publication, confines untrusted media handling, preserves audit state, and makes platform limitations visible. It does not decide whether a user owns publication rights; it provides a mandatory manual decision gate when rights are unknown.

## Trust boundaries

| Boundary | Untrusted input | Control |
|---|---|---|
| Arctic Shift metadata | Indexed Reddit post/video metadata and URLs | Fixed HTTPS API host, redirect validation, bounded client, timeouts/retries/pacing/cache, Pydantic models and candidate filters |
| Media download | Remote URL, DASH manifest and media bytes | Allowlisted Reddit media hosts, HTTPS only, manifest/size limits, explicit stream selection, FFmpeg argument list, timeout/cancel, atomic move, hash cache and ffprobe validation |
| Gemini | Uploaded media and model response | Explicit paid-work confirmation, estimator and budget reservations, structured schema, usage ledger, upload deletion retries |
| Adaptive Review memory | AI copy plus user editorial corrections | Local typed storage, bounded examples, channel/language/platform scoping, inert JSON prompt framing, explicit disable/erase controls |
| FFmpeg | Media and preset values | No shell string, validated numeric models, explicit argument arrays, temporary workspace, atomic final output, deterministic validation |
| YouTube/TikTok | OAuth responses, capabilities, upload sessions, remote statuses | OAuth state, loopback redirect validation, OS keyring, retry policy, secure resumable references, remote ID persistence, status polling |
| User publication action | Review decisions and batch selection | Rights confirmation, technical gate, optional AI gate/explicit override, separate review approval and upload-batch approval |

## Secret handling

- Credentials pasted into Settings are stored through `keyring`; on Windows this uses Windows
  Credential Manager. Secret values are never written to SQLite settings.
- `.env` is an optional compatibility fallback, ignored by source control, and excluded from
  release archives.
- YouTube desktop client JSON is selected at connection time and is never copied into the application tree.
- OAuth access/refresh tokens and resumable upload URLs are stored through `keyring`; SQLite stores only references such as `youtube:<channel-id>`.
- TikTok, Gemini, and optional Reddit OAuth credentials prefer GUI-managed keyring entries;
  named environment variables remain migration fallbacks.
- Settings validation rejects secret-shaped persisted fields and accepts only environment-variable
  names for fallback references.
- Disconnecting a channel deletes its credential-store item and database reference.

## Redaction

The central redactor removes common API key, access token, refresh token, client secret, password, bearer header, and sensitive query-parameter forms. It also removes values of secret-named environment variables. Redaction is applied to:

- stream and rotating-file logs, including formatted tracebacks;
- background-worker traceback messages;
- production and upload job errors before persistence;
- post-upload thumbnail/playlist warnings.
- combined logs and the individual per-production-attempt log files.

Redaction is defense in depth. Provider errors should still avoid embedding response bodies or full signed URLs.

## Paid-call and publication gates

`Generate Batch` requires an explicit dialog before discovery/analyse/render work. Every AI request is pre-estimated and checked against request, job, daily, and monthly limits. A class-wide reservation guard includes concurrently pending estimates so parallel workers cannot each consume the same remaining budget.

Rendered items enter review and cannot upload. Review approval creates an upload job with `blocked_approval`. Only the separate `Approve Upload Batch` action marks selected jobs eligible. Technical failure, required rights review, editorial changes needing re-render, or an un-overridden AI block prevents approval.

## Upload idempotency and recovery

- Due jobs are claimed inside `BEGIN IMMEDIATE`, and the persisted status changes to `uploading` before a worker receives the original operation state.
- A second GUI or scheduler-only process cannot claim the same due row.
- Fresh `uploading` rows are not recovered by another process. An inactive 30-minute lease becomes a recoverable failed job after restart.
- YouTube persists the returned video ID before optional thumbnail/playlist work or status polling.
- YouTube and TikTok resumable details live in keyring and survive an application restart without entering SQLite.
- Remote processing and native-schedule states are polled rather than re-uploaded.

## Filesystem and subprocess safety

- User directories are resolved and filesystem roots are rejected.
- Temporary names are contained under the configured temporary directory.
- Download names use a conservative character allowlist.
- FFmpeg, ffprobe, yt-dlp, and `schtasks` use argument lists with no shell expansion. The only `cmd /c` string is the explicit Windows Task Scheduler registration command for a fixed local project path.
- Media writes use temporary files followed by `os.replace`.
- External processes have bounded execution or cooperative cancellation.
- Pickle, `eval`, dynamic code execution, hidden browser cookies, and browser-upload automation are not used.

## Data retention

- Gemini uploads are deleted immediately after each request with three attempts. Google documents automatic deletion after 48 hours as a provider fallback.
- Local downloads, caches, thumbnails, renders, outputs, database, and logs remain until the user removes them under their retention policy.
- AI-original → user-edited writing pairs remain in the local database until the user chooses
  **Forget Learned Writing Preferences**. They are sent to Gemini only as a bounded prompt context
  when adaptive writing is enabled; they are not used for provider-side fine-tuning by ClipFactory.
- Rotating logs use five 5 MB files by default.
- The source ZIP excludes all runtime data, secrets, tokens, OAuth client files, logs, media, caches, and virtual environments.

## Network limitations

ClipFactory rejects local hostnames, URL user information, unsupported schemes, and literal non-global IP addresses before invoking yt-dlp. A hostname can still change DNS results or redirect after validation; run ClipFactory on a workstation/network where yt-dlp's outbound access is appropriately restricted if server-side request-forgery resistance is a deployment requirement.

Arctic Shift is an independent external index and does not guarantee availability. ClipFactory
uses its documented endpoint with pacing, bounded retries, pagination limits, rate-limit warnings,
and local cache reuse. Discovery failure is reported; it is not treated as a successful empty
result. The default provider does not use browser cookies, proxy rotation, Reddit listing scraping,
or access-control bypasses. Selected media is fetched only from allowlisted public Reddit media
CDN hosts.

## Platform policy limitations

- TikTok requires approved scopes and limits unaudited clients to private visibility. Drafts require an inbox continuation by the user.
- YouTube may restrict uploads from unverified API projects to private visibility.
- ClipFactory does not bypass audits, creator privacy choices, quotas, watermarks, copyright controls, or platform review.
- A technical `rights_status` is not legal advice. Users must review source links, license/permission, privacy, and applicable law before approval.

## Release checklist

Before distributing a ZIP or Windows build:

1. Run lint, formatting, tests, compile checks, and secret scans.
2. Inspect the archive manifest for `.env`, OAuth JSON, SQLite, logs, media, keyring exports, caches, and `.venv`.
3. Build the executable on an isolated Windows runner.
4. Verify signature/hash distribution and malware scanning under the organization's policy.
5. Perform the live checklist using non-production channels and least-privilege scopes.
