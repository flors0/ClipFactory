# ClipFactory Architecture

## End-to-end flow

```mermaid
flowchart TD
    A[Source profiles] --> B[Arctic Shift discovery]
    B --> C[v.redd.it video/audio mux and ffprobe]
    C --> D[Gemini or Mock AI]
    D --> E[Selection and render plan]
    E --> F[FFmpeg render and validation]
    F --> G[Manual review and rights gate]
    G --> H[Upload-batch approval]
    H --> I[Persistent scheduler]
    I --> J[YouTube or TikTok]
```

## Phases represented in the code

| Phase | Main packages | Result |
|---|---|---|
| Foundation | `app/core`, `app/storage`, `app/models`, `app/ui` | Paths, typed settings, WAL/migrations, repositories, state machine, workers, twelve-page shell |
| Presets | `app/presets`, `app/ui/widgets/preset_editor.py` | Two editable/resettable cores, idempotent migrations, persistent style profiles, full contract, live canvas/timeline, rich-text spans, Asset Library IDs |
| Sources | `app/sources` | Arctic Shift index, optional Reddit OAuth and mock provider boundaries, health, cache and filters |
| Acquisition | `app/download`, `app/media` | Direct Reddit DASH video/audio selection and mux, HLS/yt-dlp fallback, cancellation, cache/hash reuse, probing, thumbnails, deterministic checks |
| AI | `app/ai` | Provider protocol, Gemini structured responses, bounded adaptive Review memory, mock provider, cache, ledger, pricing, budget |
| Planning | `app/planning` | Project theme seed, strict quality/rights/duplicate selection, explicit safe quality fallback, rejection diagnostics, history, batch and schedule expansion |
| Rendering | `app/render` | Explicit final timeline, centralized ranked items, optional ASS overlays, audio mix/duck/loudness, Asset Library transitions, subtitles |
| Review | `app/review`, `app/ui/pages/review_queue.py` | Technical/optional AI review, player, edits, re-render, rights and approval gates |
| Accounts | `app/uploads/oauth_manager.py`, channel UI | Multi-channel profiles, OAuth, keyring, capability detection |
| Publication | `app/uploads`, `app/scheduling` | Metadata mapping, resumable uploads, atomic claims, retry/recovery, missed-job handling |
| Orchestration | `app/services/production_service.py` | Persistent status/progress/logs and batch-isolated failure handling |
| Verification and distribution | `tests`, `packaging`, `scripts` | Offline vertical slice, regression suite, PyInstaller configuration, Windows helpers |

## Provider boundaries

- `SourceProvider` allows automatic Arctic Shift discovery, optional OAuth Reddit, and deterministic mock discovery without changing planners or UI. Persisted `public` settings are a compatibility alias for the archive provider.
- `AIAnalysisProvider` returns `ProviderResponse[T]` for clip analysis, project creative data, and final review. Gemini and mock implementations are complete; TwelveLabs is an explicit unsupported extension boundary and cannot silently run.
- `Uploader` separates YouTube and TikTok implementations behind the scheduler.

## Persistent state

SQLite is authoritative for models and job status; files are authoritative for large media. Model payload JSON is retained with indexed status/time columns. Repositories reconstruct Pydantic models at every boundary. Application settings contain no secret values.

Production and publication are deliberately separate state machines. A render may finish and be approved without an active upload. Upload job creation and upload-batch approval are separate transactions.

## Preset migration and render consistency

`PresetManager.ensure_core_presets()` is also the preset migration boundary. It recognizes the
shipped v1.0.5 payloads, consolidates untouched factory rows into the two stable core IDs introduced
in v1.0.6, retains modified factory rows as deterministic custom presets, rewrites stored preset
references, and removes only the legacy factory rows. The v1.0.7 migration additionally removes
only the exact shipped v1.0.6 Ranking-caption background. The v1.0.8 migration upgrades only
untouched core typography and seeds stable style-profile rows; custom presets and styles remain
unchanged. Repeating every operation is idempotent.

Preset bounds are normalized from 0–1. `LayoutEngine` converts them to pixels for both the Qt editor
and ASS overlay renderer, including header padding, rank-row spacing/alignment, and platform safe
zones. `RankingTimelineItem` is the single rank-ordered association of rank, clip, caption, and
final timeline time. AI quality order assigns rank `1` first; `playback_order` independently
projects the same records onto the final timeline, normally `N → 1`. `TimelineSegment` freezes
clip and optional internal transition boundaries. The renderer derives text/audio timing and the
active-number state from those structures instead of recomputing order.
Ranking captions use independent reveal starts and, by default, the final timeline end as their
shared visibility end. Plain persisted Ranking plans receive the current caption and countdown
contracts before an editorial re-render.

Style profiles use their own SQLite repository and stable IDs. Applying a profile copies a typed
render contract into the preset and records the matching ID; manual changes clear that match on
save unless another profile matches exactly. Render plans persist both IDs and SHA-256
fingerprints, so a later Analytics experiment can group results without coupling rendering to
display names. Qt combo boxes store profile categories as stable strings and coerce them back at
the UI boundary, avoiding platform-dependent `StrEnum`/`QVariant` conversion. Ranking Numbers,
Captions, and Header layers also expose their own direct profile dropdown and custom-profile
capture action in the properties panel.

Complete design profiles coordinate layout plus the three component-profile IDs without replacing
the two Core format presets. A channel stores its default Core preset and compatible default design;
Batch Planner resolves both automatically. Each Review item keeps an immutable-at-production preset
snapshot that can be edited independently and re-rendered from its persisted render plan, so no
source discovery, download, or clip analysis is repeated.

Adaptive writing memory stores the AI original and the user's saved replacement as typed local
feedback. Exact-channel examples are immediately eligible; transfer to another channel requires the
same field-level edit signature in multiple distinct Review items and matching language/platform.
The prompt receives only a bounded JSON payload marked as inert examples, never executable
instructions. Users can disable capture per edit or erase the local memory from Settings.

Selection separates explicit hard policy from AI quality ranking. Rights, sensitive-content,
watermark/text preferences, duplicate/history rules, and source duration remain hard gates.
Strict `usable` and score rules run first. If the visible Batch Planner option is enabled and too
few strict candidates remain, only hard-policy-clean candidates above the configured fallback
floor may fill the output. Every final rejection retains typed diagnostic text for the job log.
An invalid undersized AI trim is repaired to the measured media window; first-pass copy similarity
never discards otherwise valid media.

Both shipped cores keep transitions disabled and reference no transition media. Optional visual or
sound transitions can later be selected only through scanned Asset Library IDs. Text-free
compilation plans bypass ASS generation entirely. The source archive includes the complete empty
Asset Library directory tree but no media files or enabled asset references.

Review Queue uses a fixed-height page title, a horizontal table/detail splitter, and a nested
vertical player/editor splitter. Both ratios persist in `UISettings`; the lower editorial pane
remains independently scrollable.

## Concurrency

- Production uses a bounded `ThreadPoolExecutor`; individual jobs fail independently.
- Parallel jobs that share a source reuse one serialized/cached discovery result and receive
  disjoint candidate windows, preventing a multi-video batch from repeatedly analyzing the same
  first candidates.
- AI cost reservations use a process-wide lock and pending-cost accounting.
- The upload scheduler uses bounded worker threads plus database claims for cross-process idempotency.
- Cancellation is cooperative for providers and terminates child processes when required.
