# Acceptance Evidence

This matrix separates implemented behavior, offline evidence, and checks that require external credentials or a Windows host. “Offline verified” never means that a real platform accepted a live upload.

| Acceptance item | Implementation | Evidence/status |
|---|---|---|
| Application starts | `app.main`, lazy GUI imports, `AppContext`, migrations | Module/argument import verified; full Windows GUI smoke test required |
| User enters subreddit URL | Sources UI and `SourceProfileFactory` | Unit tests cover names, `r/name`, old/new/full URLs |
| Automatic provider finds posts | Arctic Shift search, pagination, filters and cache | Mock-transport regression verified; live `sillycats` discovery succeeded on 2026-07-22 |
| Production-ready video candidates detected | Typed filters for completed Reddit video, audio, dimensions, state, profile and duplicates | Regression fixtures plus live 720p/1080p candidates verified |
| Media downloaded automatically | Direct `v.redd.it` video/audio acquisition and lossless FFmpeg mux, with HLS fallback | Generated split-stream integration test and live 720×1280/1080×1920 AAC mux verified |
| Probe reads duration/audio/resolution | ffprobe JSON contract | Generated media integration tests verified |
| Gemini analyses a selected clip | Files upload, structured Pydantic response, deletion | Mock client/schema/usage behavior verified; real key required |
| Analysis cached | Versioned fingerprint/provider/model/prompt cache | Unit tests verified |
| Planner selects clips | Strict thresholds plus opt-in-by-setting safe fallback; hard rights/content/duplicate/history gates remain authoritative | Unit tests and five-clip fallback-to-FFmpeg integration verified |
| Selection failure is actionable | Per-candidate reasons and aggregated Production Queue summary | Watermark, unusable, score, duration, duplicate, history, and rights paths regression verified |
| AI generates header/captions | Creative result and permissions | Mock provider plus render-plan tests verified; real Gemini content quality requires review |
| Channel selects preset/design automatically | Stable channel defaults resolved by `BatchPlanner` | Mapping regression plus three-job/15-source production acceptance verified |
| Exactly two core presets | Idempotent core seeding and v1.0.5 consolidation | Repository/migration regressions verified |
| Existing custom presets survive | Modified legacy cores retained deterministically; custom rows untouched | Repeated-migration regression verified |
| Rank, clip, and caption stay coupled | One `RankingTimelineItem` representation drives number, media, caption, and reveal | Mapping/timeline regression verified |
| Rank `1` is the top row | Normalized ascending layout with fixed row association | Geometry tests and controlled five-clip frame inspection verified |
| Best clip plays last | Rank assignment stays `1..N`; playback projects the same records as `N..1` | Mapping regression and five marked FFmpeg clips verified |
| Active rank remains highlighted | ASS intervals derive active rank from final clip times | Five extracted countdown frames verified |
| Revealed captions accumulate | Each caption starts at its own reveal and ends at final timeline end | Timing/ASS regressions and controlled 1 s/3 s/5 s frame inspection verified |
| Future captions stay hidden | No ASS dialogue exists before the caption's own reveal start | Timing and ASS event regressions verified |
| Caption box is transparent | v1.0.7 core default plus exact-value v1.0.6 migration | Preset/migration regression and controlled frame inspection verified |
| Typography is larger and responsive | Reference-height scaling covers font, outline, shadow, blur, glow, and spacing | Model/ASS regressions plus 360×640 and 1080×1920 math verified |
| Style profiles persist | Dedicated typed SQLite repository with stable IDs and idempotent core seeding | 18-profile seeding, CRUD, apply, reset, and preset round-trip regressions verified |
| Style profiles are selectable per layer | Direct properties-panel dropdown for Ranking Numbers, Captions, and Header; full management dialog retained | UI source/enum-boundary regression verified; Windows interaction smoke test required |
| Complete designs coordinate component styles | Five design profiles combine layout, visibility, and component IDs without duplicating Core presets | Seeding/apply/custom-capture regressions and Creator/Neon frame inspection verified |
| Review design and copy can be revised | Per-video preset snapshot plus direct/advanced Review controls | Persistence regression and successful cached Neon re-render verified |
| Re-render does not repeat acquisition | Persisted render plan, selected clips, Review copy, and preset snapshot | Zero new discovery/download/clip-analysis steps across controlled re-render |
| Gemini learns from saved edits | Typed AI-original → user-preferred local memory, bounded prompt JSON | Exact-channel and three-distinct-Review transfer regressions verified |
| One video cannot over-train global style | Cross-channel signatures count distinct Review IDs and require matching language/platform | Five-edits-in-one-Review isolation regression verified |
| Asset folders exist in release | Nine managed empty directories retained with placeholders; scan creates/reconciles runtime rows | ZIP manifest and filesystem-tree regression verified |
| Reference Ranking styles render | Eight per-rank/outline/glow profiles feed the ASS renderer | Creator Stack and legacy style visual inspections verified |
| Future Analytics can identify styles | Render metadata stores profile IDs and deterministic fingerprints | Metadata regression verified; automatic Analytics selection intentionally not implemented |
| Captions request short meme reactions | `clip-v2` and `creative-v3` require 2–6-word natural reactions and prohibit explanatory templates | Prompt/adaptive-context regression verified; real Gemini style still requires manual review |
| AI header is not rewritten | Render plan uses normalized AI text without a `Top N` template | Exact-string regression verified |
| Compilation has no text overlays | Core capabilities disable copy plus renderer omits the ASS path | ASS regression and controlled three-clip frame inspection verified |
| Optional transitions are internal only | Final timeline inserts an Asset Library transition only between clips | `N - 1` plan/render/audio integration verified; no assets ship enabled |
| Preset renders vertical video | FFmpeg renderer and ASS overlay | Integration tests render/probe deterministic video |
| Video enters Review Queue | Production service and repository | Offline vertical slice verified |
| User can play video in tool | Qt Multimedia player, pause, seek, folder action | Implemented; Windows GUI smoke test required |
| Numeric wheel cannot change settings | Application-wide `NumericWheelGuard` | Event-filter regression implemented; Windows/EGL GUI smoke test required |
| Attempts have separate log blocks | Context-tagged logging and per-attempt files/view selector | File-routing/redaction regression verified |
| Log position is restored | Per-log scroll/follow-tail state persisted in UI settings | State regression verified; Windows widget smoke test required |
| API key entered in tool | Settings credential editor backed by OS keyring | In-memory credential-priority/redaction regression verified; Windows Credential Manager smoke test required |
| Upload metadata editable | Platform-specific Pydantic validation | Model/mapping tests verified; Windows UI smoke test required |
| User confirms upload | Separate review and upload-batch gates | Repository/service tests verified |
| UploadJob scheduled | Persistent queue, time zone, native/local execution semantics | Unit tests verified |
| Job executes at time | Local scheduler, missed-job policy, optional Windows task | Scheduler unit tests verified; Windows timing test required |
| Remote status and ID saved | YouTube/TikTok uploaders and polling | Mock status tests verified; live test requires OAuth and platform approval |

## Preset editor acceptance

| Required demonstration | Implementation | Remaining validation |
|---|---|---|
| Edit text directly | Double-click `QGraphicsTextItem` editor | Windows GUI smoke test |
| Select individual words/ranges | Native QTextCursor selection | Windows GUI smoke test |
| Open color wheel | QColorDialog with alpha and recent platform colors | Windows GUI smoke test |
| Change word color | Selection char format → persisted rich spans | Model tests plus Windows GUI smoke test |
| Move and resize text | Drag, resize handle, numeric property editor, snap | Windows GUI smoke test |
| Save preset | Validated SQLite repository; core save/reset and custom lifecycle | Serialization, reload, migration, and lifecycle tests |
| Apply/manage style profiles | Direct per-layer dropdown plus dedicated dialog for apply, capture, duplicate, update, rename/delete custom, and reset core | Model/UI composition and Windows QVariant-boundary regressions; Windows interaction smoke test required |
| Preview updates | Canvas reload and timeline visibility | Windows GUI smoke test |
| Final layout matches | Shared normalized `LayoutEngine` | Geometry/render tests; visual Windows sample inspection recommended |
| Entire editor is reachable | Scrollable contract and property panes, wrapped rows | Source/UI composition regression; Windows DPI smoke test required |
| Populated Review Queue is reachable | Scrollable responsive detail pane and button grids | Source/UI composition regression; Windows DPI smoke test required |
| Review panes resize both ways | Horizontal table/player splitter plus vertical player/details splitter with persisted sizes | Source/settings regression; Windows drag/DPI smoke test required |

## Verified command set

```text
uv run ruff format --check .
uv run ruff check .
uv run pytest -q
uv run python -m compileall -q app tests
```

The release report must include the exact output and date rather than copying this matrix without rerunning it.
