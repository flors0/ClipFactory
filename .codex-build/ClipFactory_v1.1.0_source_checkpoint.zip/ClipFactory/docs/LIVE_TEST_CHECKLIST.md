# Live and Windows Validation Checklist

Use disposable/non-production accounts and private visibility for the first run. Record IDs and timestamps without recording access tokens.

## Windows desktop

- [ ] Install FFmpeg/ffprobe and verify both executables.
- [ ] Run `uv sync --group dev --frozen`.
- [ ] Start with `uv run python -m app.main`.
- [ ] Confirm all twelve navigation pages open without a Qt plugin error.
- [ ] Confirm exactly **Ranking** and **TikTok Core Compilation** are marked as core presets.
- [ ] Edit/save/reset a core preset; duplicate it; rename/delete the custom copy; restart and
  confirm every saved field reloads.
- [ ] Open **Style Profiles…** and apply each of the seven Ranking-number profiles. Confirm active
  coloring, per-rank palettes, outline/glow, larger size, and preview refresh. Create, duplicate,
  update, rename, delete, and reload one custom Ranking, Caption, and Header profile.
- [ ] Select the Ranking Numbers, Ranking Captions, and Header layers individually. Confirm the
  right-hand **Style profile** dropdown is populated, applies a profile immediately to the preview,
  shows `Custom (unsaved)` after manual styling, and **Save as New…** persists a custom entry.
- [ ] Resize the window and use Windows DPI scaling; confirm every preset contract/property field
  and every fully populated Review Queue detail/action remains reachable by scrolling.
- [ ] Confirm the Review Queue title uses only one compact row. Drag the table/player divider
  horizontally and the player/details divider vertically, switch pages or restart, and confirm
  both sizes restore.
- [ ] Scroll every preset number field; its value must not change while the page scrolls.
- [ ] Confirm both core presets initially have transitions disabled and no selected transition or
  sound. Then manually add test media to `assets/transitions` and `assets/sounds`, scan the Asset
  Library, select the entries, and inspect metadata/thumbnails.
- [ ] Render a five-clip Ranking and confirm rows read `1` through `5` from top to bottom, media
  plays `5 → 4 → 3 → 2 → 1`, the active color follows that same order, each caption follows its
  matching clip, previously revealed captions remain visible, future captions remain hidden, no
  black Caption box appears, and the AI header is not prefixed with `Top 5`.
- [ ] Render the default Compilation and confirm it contains original media/audio but no header,
  captions, rank numbers, subtitles, labels, watermark, or transition.
- [ ] Close/reopen and confirm profiles, presets, jobs, schedules, and settings persist.
- [ ] Build with `scripts/build_windows.ps1`; repeat the start and preset checks from `dist\ClipFactory`.

## Automatic Reddit discovery and media

- [ ] Keep the default `archive` source provider, create a source using a subreddit URL, and use
  **Test Discovery**.
- [ ] Confirm Source Health identifies `reddit_archive_arctic_shift` and candidates retain their
  Reddit post links.
- [ ] Generate one private test project with Mock AI but real automatic discovery/download.
- [ ] Raise strict AI score thresholds until fewer than the required clips pass. Confirm the
  enabled automatic quality fallback fills only from candidates above its floor and logs the
  fallback IDs. Disable it and confirm a failed job reports an aggregated rejection summary.
- [ ] Keep watermark/sensitive/rights rejection enabled for a deliberately blocked candidate and
  confirm fallback never selects that clip.
- [ ] Confirm the output has both video and original audio, ffprobe metadata is correct, a retry
  reports a cache hit, and no local source chooser appears.
- [ ] Create a multi-video batch and confirm attempt logs show different assigned candidate windows.
- [ ] Review the source rights link and do not approve content without authorization.

## Gemini

- [ ] Paste the key only into **Settings → Gemini API key**, save, close/reopen the page, and confirm
  the status remains `ready` without creating `.env`.
- [ ] Use a restricted key and low request/job/daily/monthly budgets.
- [ ] Generate one short, authorized test using Gemini.
- [ ] Confirm each Ranking caption is a short scene-specific reaction rather than an explanatory
  sentence. Record awkward or repetitive outputs for the next prompt-tuning iteration.
- [ ] Confirm Pydantic analysis/creative results, usage ledger tokens/cost, and cache hit on retry.
- [ ] Confirm Gemini Files list no longer contains the uploaded test file after completion.
- [ ] Induce a budget failure and confirm no API request is sent.

## YouTube

- [ ] Use a test channel and a desktop OAuth client JSON stored outside the project.
- [ ] Connect OAuth; restart ClipFactory; refresh channel capabilities.
- [ ] Approve a private upload only after both gates.
- [ ] Interrupt one resumable transfer, restart, explicitly retry, and confirm the same remote upload is resumed or polled rather than duplicated.
- [ ] Confirm video ID persistence, processing polling, requested metadata, and final private visibility.
- [ ] Test a future public schedule only after API-project audit/visibility restrictions are understood.

## TikTok

- [ ] Register the exact loopback redirect and request only required scopes.
- [ ] Test `video.upload` alone; confirm capability UI shows draft available and direct post unavailable.
- [ ] Deliver a draft and complete/reject it from the TikTok inbox as appropriate.
- [ ] Test direct post only with approved `video.publish`; confirm privacy/capability choices match creator info.
- [ ] Use a file larger than 64 MiB in a private test and verify sequential ranges and final processing status.
- [ ] Confirm unaudited-client visibility restrictions before describing any result as public.

## Scheduler and recovery

- [ ] Schedule two local jobs several minutes apart; close the GUI and keep scheduler-only mode running.
- [ ] Start a second scheduler-only process and confirm only one process claims each job.
- [ ] Exercise each missed-job choice; confirm overdue jobs are not all dispatched simultaneously.
- [ ] Inspect and optionally register the Windows logon task; verify the scheduler starts after sign-in.

## Security/release

- [ ] Scroll over every numeric control in Settings and Batch Planner; its value must remain
  unchanged while the surrounding page scrolls.
- [ ] Generate, fail, and retry one production job; confirm **Logs** shows separate Attempt 1 and
  Attempt 2 blocks with job and batch IDs.
- [ ] Scroll partway through two different logs, switch away/restart the application, and confirm
  each log returns to its own position. Append lines while reading above the tail and confirm the
  view does not jump; repeat at the bottom and confirm follow-tail remains active.
- [ ] Search logs/database/archive for the test key/token substrings; no matches are permitted.
- [ ] Disconnect both channels and verify their keyring entries are removed.
- [ ] Inspect the ZIP manifest for `.env`, OAuth JSON, database, logs, media, cache, `.venv`, and resumable URLs.
- [ ] Hash and malware-scan the final Windows distribution under the organization's release policy.
