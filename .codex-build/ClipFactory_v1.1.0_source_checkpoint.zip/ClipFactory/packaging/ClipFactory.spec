# -*- mode: python ; coding: utf-8 -*-

from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_submodules


project_root = Path.cwd()
hidden_imports = (
    collect_submodules("keyring.backends")
    + collect_submodules("yt_dlp")
    + [
        "PySide6.QtMultimedia",
        "PySide6.QtMultimediaWidgets",
        "googleapiclient.discovery_cache",
    ]
)
data_files = [
    (
        str(project_root / "config" / "defaults" / "ai_pricing.json"),
        "config/defaults",
    ),
    (
        str(project_root / "app" / "storage" / "migrations"),
        "app/storage/migrations",
    ),
] + collect_data_files("certifi")

analysis = Analysis(
    [str(project_root / "app" / "main.py")],
    pathex=[str(project_root)],
    binaries=[],
    datas=data_files,
    hiddenimports=hidden_imports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["pytest", "ruff"],
    noarchive=False,
    optimize=1,
)
pyz = PYZ(analysis.pure)

executable = EXE(
    pyz,
    analysis.scripts,
    [],
    exclude_binaries=True,
    name="ClipFactory",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
)

distribution = COLLECT(
    executable,
    analysis.binaries,
    analysis.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="ClipFactory",
)
