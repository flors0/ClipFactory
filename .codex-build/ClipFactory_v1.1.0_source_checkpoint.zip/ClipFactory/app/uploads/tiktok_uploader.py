"""Official TikTok Content Posting API uploader with capability detection."""

from __future__ import annotations

import json
import math
import time
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from threading import Event

import httpx

from app.core.exceptions import CancelledError, UploadError
from app.media.media_probe import MediaProbe
from app.models.channel_models import ChannelProfile
from app.models.upload_models import (
    TikTokCapabilities,
    TikTokMetadata,
    UploadJob,
    UploadResult,
    UploadStatus,
)
from app.uploads.metadata_mapping import tiktok_post_info
from app.uploads.oauth_manager import OAuthManager
from app.uploads.uploader import Uploader


class TikTokUploader(Uploader):
    platform = "tiktok"
    base_url = "https://open.tiktokapis.com"
    MEGABYTE = 1_000_000
    MINIMUM_CHUNK_SIZE = 5 * MEGABYTE
    PREFERRED_CHUNK_SIZE = 32 * MEGABYTE
    MAXIMUM_CHUNK_SIZE = 64 * MEGABYTE
    MAXIMUM_FINAL_CHUNK_SIZE = 128 * MEGABYTE
    MAXIMUM_CHUNK_COUNT = 1000

    def __init__(
        self,
        oauth: OAuthManager,
        probe: MediaProbe,
        *,
        retry_count: int = 5,
        status_timeout_seconds: float = 900,
        client: httpx.Client | None = None,
    ):
        self.oauth = oauth
        self.probe = probe
        self.retry_count = retry_count
        self.status_timeout_seconds = status_timeout_seconds
        self.client = client or httpx.Client(timeout=60)

    def capabilities(self, channel_id: str) -> TikTokCapabilities:
        token = self.oauth.tiktok_token(channel_id, self.client)
        scopes = self._scope_values(token.scope)
        if "video.publish" not in scopes:
            return TikTokCapabilities(
                creator_username=token.open_id,
                creator_nickname="TikTok account",
                privacy_level_options=[],
                comments_allowed=False,
                duet_allowed=False,
                stitch_allowed=False,
                max_video_duration_seconds=0,
                direct_post_available=False,
                draft_upload_available="video.upload" in scopes,
            )
        data = self._post_json(
            "/v2/post/publish/creator_info/query/",
            token.access_token,
            {},
        ).get("data", {})
        return TikTokCapabilities(
            creator_username=str(data.get("creator_username", "")),
            creator_nickname=str(data.get("creator_nickname", "")),
            privacy_level_options=list(data.get("privacy_level_options", [])),
            comments_allowed=not bool(data.get("comment_disabled", True)),
            duet_allowed=not bool(data.get("duet_disabled", True)),
            stitch_allowed=not bool(data.get("stitch_disabled", True)),
            max_video_duration_seconds=int(data.get("max_video_post_duration_sec", 0)),
            direct_post_available="video.publish" in scopes,
            draft_upload_available="video.upload" in scopes,
        )

    def upload(
        self,
        job: UploadJob,
        channel: ChannelProfile,
        *,
        cancel_event: Event | None = None,
        progress_callback: Callable[[int, str], None] | None = None,
        state_callback: Callable[[UploadJob], None] | None = None,
    ) -> UploadResult:
        cancel_event = cancel_event or Event()
        progress_callback = progress_callback or (lambda _value, _message: None)
        state_callback = state_callback or (lambda _job: None)
        if not job.batch_approved or job.status not in {
            UploadStatus.QUEUED,
            UploadStatus.SCHEDULED,
            UploadStatus.FAILED,
            UploadStatus.PROCESSING,
        }:
            raise UploadError("TikTok upload requires an explicitly approved queued job.")
        if job.remote_id and job.status in {UploadStatus.PUBLISHED, UploadStatus.DRAFT}:
            return UploadResult(remote_id=job.remote_id, status=job.status)
        path = Path(job.file_path).resolve()
        if not path.is_file() or path.stat().st_size <= 0:
            raise UploadError("TikTok upload file is missing or empty.")
        metadata = TikTokMetadata.model_validate(job.metadata)
        token = self.oauth.tiktok_token(channel.id, self.client)
        scopes = self._scope_values(token.scope)
        session_reference = job.resumable_uri_reference
        session: dict[str, object] = {}
        if session_reference:
            if session_reference.startswith("tiktok:"):
                session = {"publish_id": session_reference.split(":", 1)[1]}
            else:
                raw_session = self.oauth.secure_value(session_reference)
                if raw_session:
                    try:
                        session = json.loads(raw_session)
                    except (TypeError, json.JSONDecodeError):
                        session = {}
            existing_publish_id = str(session.get("publish_id", ""))
            existing = (
                self._status_once(existing_publish_id, token.access_token)
                if existing_publish_id
                else {}
            )
            existing_status = str(existing.get("status", ""))
            if existing_status == "PUBLISH_COMPLETE":
                public_ids = (
                    existing.get("publicaly_available_post_id")
                    or existing.get("publicly_available_post_id")
                    or []
                )
                self.oauth.delete_secure_value(session_reference)
                job.resumable_uri_reference = None
                state_callback(job)
                return UploadResult(
                    remote_id=str(public_ids[0]) if public_ids else existing_publish_id,
                    status=UploadStatus.PUBLISHED,
                    published_at=datetime.now(UTC),
                    details={"publish_id": existing_publish_id, "resumed_status_check": True},
                )
            if existing_status == "SEND_TO_USER_INBOX":
                self.oauth.delete_secure_value(session_reference)
                job.resumable_uri_reference = None
                state_callback(job)
                return UploadResult(
                    remote_id=existing_publish_id,
                    status=UploadStatus.DRAFT,
                    details={"publish_id": existing_publish_id, "draft_delivered": True},
                )
            if existing_status == "FAILED":
                self.oauth.delete_secure_value(session_reference)
                job.resumable_uri_reference = None
                session_reference = None
                session = {}
                state_callback(job)
            elif existing_status and not session.get("upload_url"):
                return UploadResult(
                    remote_id=existing_publish_id,
                    status=UploadStatus.PROCESSING,
                    details={
                        "publish_id": existing_publish_id,
                        "processing_status": existing_status,
                    },
                )
        info = self.probe.probe(path)
        if metadata.mode == "direct_post":
            capabilities = self.capabilities(channel.id)
            if (
                capabilities.max_video_duration_seconds
                and info.duration_seconds > capabilities.max_video_duration_seconds
            ):
                raise UploadError(
                    "Video exceeds the connected TikTok creator's current duration capability."
                )
            if metadata.privacy_level not in capabilities.privacy_level_options:
                raise UploadError(
                    "Selected TikTok privacy level is not available for this creator."
                )
            if metadata.comments_enabled and not capabilities.comments_allowed:
                raise UploadError("Comments are disabled by the connected TikTok creator settings.")
            if metadata.duet_enabled and not capabilities.duet_allowed:
                raise UploadError("Duet is not available for the connected TikTok creator.")
            if metadata.stitch_enabled and not capabilities.stitch_allowed:
                raise UploadError("Stitch is not available for the connected TikTok creator.")
            if not capabilities.direct_post_available:
                raise UploadError("Connected TikTok authorization lacks the video.publish scope.")
        elif "video.upload" not in scopes:
            raise UploadError("Connected TikTok authorization lacks the video.upload scope.")
        size = path.stat().st_size
        if not session:
            chunk_size, chunks = self._chunk_plan(size)
            source_info = {
                "source": "FILE_UPLOAD",
                "video_size": size,
                "chunk_size": chunk_size,
                "total_chunk_count": chunks,
            }
            endpoint = (
                "/v2/post/publish/video/init/"
                if metadata.mode == "direct_post"
                else "/v2/post/publish/inbox/video/init/"
            )
            body: dict[str, object] = {"source_info": source_info}
            if metadata.mode == "direct_post":
                body["post_info"] = tiktok_post_info(metadata)
            init = self._post_json(endpoint, token.access_token, body, cancel_event=cancel_event)
            data = init.get("data", {})
            upload_url = data.get("upload_url")
            publish_id = data.get("publish_id")
            if not upload_url or not publish_id:
                raise UploadError(
                    "TikTok upload initialization returned no upload URL or publish ID."
                )
            session_reference = f"tiktok-upload:{job.id}"
            session = {
                "publish_id": str(publish_id),
                "upload_url": str(upload_url),
                "chunk_size": chunk_size,
                "total_chunk_count": chunks,
                "total_size": size,
                "next_byte": 0,
                "next_chunk_index": 0,
            }
            self.oauth.store_secure_value(session_reference, json.dumps(session))
            job.resumable_uri_reference = session_reference
            job.status = UploadStatus.UPLOADING
            state_callback(job)
        publish_id = str(session.get("publish_id", ""))
        upload_url = str(session.get("upload_url", ""))
        chunk_size = int(session.get("chunk_size", 0))
        total_chunk_count = int(
            session.get(
                "total_chunk_count",
                max(1, size // chunk_size) if chunk_size > 0 and size > chunk_size else 1,
            )
        )
        next_byte = int(session.get("next_byte", 0))
        next_chunk_index = int(
            session.get(
                "next_chunk_index",
                next_byte // chunk_size if chunk_size > 0 else 0,
            )
        )
        if not publish_id or not upload_url or chunk_size <= 0:
            raise UploadError(
                "Persisted TikTok upload session is incomplete; retry initialization."
            )
        self._upload_chunks(
            path,
            upload_url,
            chunk_size,
            total_chunk_count,
            size,
            next_byte,
            next_chunk_index,
            session,
            session_reference,
            cancel_event,
            progress_callback,
            job,
            state_callback,
        )
        progress_callback(100, "TikTok media transfer completed")
        final = self._poll_status(str(publish_id), token.access_token, cancel_event)
        status_name = str(final.get("status", ""))
        if status_name == "FAILED":
            raise UploadError(
                f"TikTok processing failed: {final.get('fail_reason', 'unknown reason')}"
            )
        public_ids = (
            final.get("publicaly_available_post_id")
            or final.get("publicly_available_post_id")
            or []
        )
        remote_id = str(public_ids[0]) if public_ids else str(publish_id)
        published = status_name == "PUBLISH_COMPLETE" and metadata.mode == "direct_post"
        draft_delivered = status_name == "SEND_TO_USER_INBOX" and metadata.mode != "direct_post"
        if published or draft_delivered:
            self.oauth.delete_secure_value(session_reference)
            job.resumable_uri_reference = None
            state_callback(job)
        return UploadResult(
            remote_id=remote_id,
            status=(
                UploadStatus.PUBLISHED
                if published
                else UploadStatus.DRAFT
                if draft_delivered
                else UploadStatus.PROCESSING
            ),
            published_at=datetime.now(UTC) if published else None,
            details={"publish_id": publish_id, "processing_status": status_name},
        )

    def _upload_chunks(
        self,
        path: Path,
        upload_url: str,
        chunk_size: int,
        total_chunk_count: int,
        total_size: int,
        start_offset: int,
        start_chunk_index: int,
        session: dict[str, object],
        session_reference: str,
        cancel_event: Event,
        progress_callback: Callable[[int, str], None],
        job: UploadJob,
        state_callback: Callable[[UploadJob], None],
    ) -> None:
        with path.open("rb") as stream:
            start = max(0, min(start_offset, total_size))
            chunk_index = max(0, start_chunk_index)
            if not 1 <= total_chunk_count <= self.MAXIMUM_CHUNK_COUNT:
                raise UploadError("Persisted TikTok upload chunk count is invalid.")
            expected_start = min(chunk_index * chunk_size, total_size)
            if start != expected_start:
                raise UploadError("Persisted TikTok upload offset is not on a chunk boundary.")
            stream.seek(start)
            while start < total_size:
                if cancel_event.is_set():
                    raise CancelledError("TikTok upload was cancelled.")
                if chunk_index >= total_chunk_count:
                    raise UploadError("Persisted TikTok upload chunk index is invalid.")
                payload_size = (
                    total_size - start if chunk_index == total_chunk_count - 1 else chunk_size
                )
                payload = stream.read(payload_size)
                if len(payload) != payload_size:
                    raise UploadError("TikTok upload file changed during media transfer.")
                end = start + len(payload) - 1
                response = None
                for attempt in range(self.retry_count + 1):
                    try:
                        response = self.client.put(
                            upload_url,
                            content=payload,
                            headers={
                                "Content-Type": "video/mp4",
                                "Content-Length": str(len(payload)),
                                "Content-Range": f"bytes {start}-{end}/{total_size}",
                            },
                        )
                    except httpx.RequestError as error:
                        if attempt >= self.retry_count:
                            raise UploadError(
                                "TikTok media transfer failed after network retries."
                            ) from error
                        if cancel_event.wait(min(2**attempt, 30)):
                            raise CancelledError(
                                "TikTok upload was cancelled during retry backoff."
                            ) from error
                        continue
                    if (
                        response.status_code not in {429, 500, 502, 503, 504}
                        or attempt >= self.retry_count
                    ):
                        break
                    if cancel_event.wait(self._retry_delay(response, attempt)):
                        raise CancelledError("TikTok upload was cancelled during retry backoff.")
                assert response is not None
                if response.status_code not in {200, 201, 206}:
                    raise UploadError(
                        f"TikTok media transfer failed with HTTP {response.status_code}."
                    )
                start = end + 1
                chunk_index += 1
                session["next_byte"] = start
                session["next_chunk_index"] = chunk_index
                self.oauth.store_secure_value(session_reference, json.dumps(session))
                job.progress = int(start / total_size * 100)
                progress_callback(job.progress, "Uploading to TikTok")
                state_callback(job)

    def _poll_status(
        self, publish_id: str, access_token: str, cancel_event: Event
    ) -> dict[str, object]:
        started = time.monotonic()
        while True:
            if cancel_event.wait(3):
                raise CancelledError("TikTok status polling was cancelled.")
            response = self._post_json(
                "/v2/post/publish/status/fetch/",
                access_token,
                {"publish_id": publish_id},
                cancel_event=cancel_event,
            )
            data = response.get("data", {})
            status = str(data.get("status", ""))
            if status in {"PUBLISH_COMPLETE", "SEND_TO_USER_INBOX", "FAILED"}:
                return data
            if time.monotonic() - started > self.status_timeout_seconds:
                return data

    def _post_json(
        self,
        path: str,
        access_token: str,
        payload: dict[str, object],
        *,
        cancel_event: Event | None = None,
    ) -> dict[str, object]:
        response = None
        for attempt in range(self.retry_count + 1):
            try:
                response = self.client.post(
                    f"{self.base_url}{path}",
                    json=payload,
                    headers={
                        "Authorization": f"Bearer {access_token}",
                        "Content-Type": "application/json; charset=UTF-8",
                    },
                )
            except httpx.RequestError as error:
                if attempt >= self.retry_count:
                    raise UploadError("TikTok API request failed after network retries.") from error
                delay = min(2**attempt, 30)
                if cancel_event and cancel_event.wait(delay):
                    raise CancelledError("TikTok API retry was cancelled.") from error
                if not cancel_event:
                    time.sleep(delay)
                continue
            if response.status_code not in {429, 500, 502, 503, 504} or attempt >= self.retry_count:
                break
            delay = self._retry_delay(response, attempt)
            if cancel_event and cancel_event.wait(delay):
                raise CancelledError("TikTok API retry was cancelled.")
            if not cancel_event:
                time.sleep(delay)
        assert response is not None
        try:
            body = response.json()
        except ValueError as error:
            raise UploadError("TikTok returned a non-JSON response.") from error
        error_data = body.get("error", {}) if isinstance(body, dict) else {}
        error_code = error_data.get("code") if isinstance(error_data, dict) else None
        if response.status_code >= 400 or error_code not in {None, "ok"}:
            raise UploadError(f"TikTok API request failed: {error_code or response.status_code}")
        return body

    def _status_once(self, publish_id: str, access_token: str) -> dict[str, object]:
        return self._post_json(
            "/v2/post/publish/status/fetch/",
            access_token,
            {"publish_id": publish_id},
        ).get("data", {})

    @classmethod
    def _chunk_plan(cls, total_size: int) -> tuple[int, int]:
        """Return TikTok-compliant chunk size/count with the remainder in the final chunk."""
        if total_size <= 0:
            raise UploadError("TikTok upload file is empty.")
        if total_size <= cls.MAXIMUM_CHUNK_SIZE:
            return total_size, 1
        required_for_limit = math.ceil(total_size / cls.MAXIMUM_CHUNK_COUNT)
        chunk_size = max(
            cls.PREFERRED_CHUNK_SIZE,
            cls.MINIMUM_CHUNK_SIZE,
            math.ceil(required_for_limit / cls.MEGABYTE) * cls.MEGABYTE,
        )
        if chunk_size > cls.MAXIMUM_CHUNK_SIZE:
            raise UploadError("Video exceeds TikTok's supported chunked upload size.")
        total_chunk_count = total_size // chunk_size
        final_chunk_size = total_size - chunk_size * (total_chunk_count - 1)
        if not 1 <= total_chunk_count <= cls.MAXIMUM_CHUNK_COUNT:
            raise UploadError("Video requires an unsupported number of TikTok upload chunks.")
        if final_chunk_size > cls.MAXIMUM_FINAL_CHUNK_SIZE:
            raise UploadError("TikTok's final upload chunk would exceed 128 MB.")
        return chunk_size, total_chunk_count

    @staticmethod
    def _scope_values(raw_scope: str) -> set[str]:
        return {value.strip() for value in raw_scope.replace(" ", ",").split(",") if value.strip()}

    @staticmethod
    def _retry_delay(response: httpx.Response, attempt: int) -> float:
        try:
            retry_after = float(response.headers.get("Retry-After", ""))
        except ValueError:
            retry_after = 0
        return min(60, max(retry_after, 2**attempt))
