"""Uploader interface and shared retry contract."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from threading import Event

from app.models.channel_models import ChannelProfile
from app.models.upload_models import UploadJob, UploadResult


class Uploader(ABC):
    platform: str

    @abstractmethod
    def upload(
        self,
        job: UploadJob,
        channel: ChannelProfile,
        *,
        cancel_event: Event | None = None,
        progress_callback: Callable[[int, str], None] | None = None,
        state_callback: Callable[[UploadJob], None] | None = None,
    ) -> UploadResult:
        """Upload one explicitly approved job and return its remote state."""
