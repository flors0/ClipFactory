"""Create and activate upload jobs only after both review and batch approval."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from app.models.channel_models import ChannelProfile
from app.models.render_models import ProductionStatus
from app.models.review_models import ReviewItem, ReviewStatus
from app.models.schedule_models import MissedJobPolicy
from app.models.upload_models import UploadJob, UploadStatus, YouTubeMetadata
from app.storage.repositories.job_repository import ProductionJobRepository, UploadJobRepository


class UploadQueue:
    def __init__(self, repository: UploadJobRepository, production_jobs: ProductionJobRepository):
        self.repository = repository
        self.production_jobs = production_jobs

    def create_from_review(self, item: ReviewItem, channel: ChannelProfile) -> UploadJob:
        if item.status != ReviewStatus.APPROVED:
            raise ValueError("A review item must be approved before an upload job can be created.")
        if item.channel_id and item.channel_id != channel.id:
            raise ValueError("Review item and target channel do not match.")
        if item.platform != channel.platform:
            raise ValueError("Review platform and channel platform do not match.")
        if item.scheduled_at is None or item.scheduled_at.tzinfo is None:
            raise ValueError("An upload job requires a timezone-aware schedule.")
        existing = next(
            (job for job in self.repository.list() if job.review_item_id == item.id),
            None,
        )
        if existing:
            return existing
        now = datetime.now(UTC)
        youtube_native_schedule = False
        if channel.platform == "youtube":
            youtube_metadata = YouTubeMetadata.model_validate(item.upload_metadata)
            youtube_native_schedule = youtube_metadata.privacy_status == "public"
        execution_at = (
            now if channel.platform == "youtube" and youtube_native_schedule else item.scheduled_at
        )
        production = self.production_jobs.get(item.production_job_id)
        return self.repository.save(
            UploadJob(
                production_job_id=item.production_job_id,
                batch_id=production.batch_id if production else None,
                review_item_id=item.id,
                channel_id=channel.id,
                platform=channel.platform,
                file_path=item.video_path,
                scheduled_at=item.scheduled_at,
                execution_at=execution_at,
                status=UploadStatus.BLOCKED_APPROVAL,
                metadata=item.upload_metadata,
                batch_approved=False,
                log_messages=[
                    "Created after manual video approval; awaiting upload-batch approval."
                ],
            )
        )

    def approve_upload_batch(self, identifiers: list[str]) -> list[UploadJob]:
        if not identifiers:
            raise ValueError("Upload batch approval requires at least one job.")
        jobs: list[UploadJob] = []
        for identifier in identifiers:
            job = self.repository.get(identifier)
            if not job:
                raise KeyError(f"Upload job does not exist: {identifier}")
            if job.status != UploadStatus.BLOCKED_APPROVAL:
                raise ValueError(f"Upload job is not awaiting batch approval: {identifier}")
            jobs.append(job)
        approved: list[UploadJob] = []
        with self.repository.database.transaction(immediate=True):
            for job in jobs:
                job.batch_approved = True
                execution_at = job.execution_at or job.scheduled_at
                job.status = (
                    UploadStatus.SCHEDULED
                    if execution_at > datetime.now(UTC)
                    else UploadStatus.QUEUED
                )
                job.log_messages.append("Upload batch explicitly approved by the user.")
                self.repository.save(job)
                production = self.production_jobs.get(job.production_job_id)
                if production:
                    production.status = ProductionStatus.QUEUED_FOR_UPLOAD
                    production.current_step = "Queued for approved upload"
                    self.production_jobs.save(production)
                approved.append(job)
        return approved

    def pause(self, identifier: str) -> UploadJob:
        job = self._required(identifier)
        if job.status not in {UploadStatus.QUEUED, UploadStatus.SCHEDULED, UploadStatus.FAILED}:
            raise ValueError("Only inactive queued jobs can be paused.")
        job.status = UploadStatus.PAUSED
        job.log_messages.append("Upload job paused by the user.")
        return self.repository.save(job)

    def resume(self, identifier: str) -> UploadJob:
        job = self._required(identifier)
        if job.status != UploadStatus.PAUSED:
            raise ValueError("Upload job is not paused.")
        execution_at = job.execution_at or job.scheduled_at
        job.status = (
            UploadStatus.SCHEDULED if execution_at > datetime.now(UTC) else UploadStatus.QUEUED
        )
        job.log_messages.append("Upload job resumed by the user.")
        return self.repository.save(job)

    def retry(self, identifier: str) -> UploadJob:
        job = self._required(identifier)
        if job.status != UploadStatus.FAILED or not job.batch_approved:
            raise ValueError("Only failed, approved uploads can be retried.")
        job.retry_count += 1
        job.last_error = None
        job.status = UploadStatus.QUEUED
        job.log_messages.append(f"Retry {job.retry_count} queued by the user.")
        return self.repository.save(job)

    def resolve_missed(
        self,
        identifiers: list[str],
        policy: MissedJobPolicy,
        *,
        now: datetime | None = None,
    ) -> list[UploadJob]:
        if policy == MissedJobPolicy.ASK:
            raise ValueError("Choose a concrete catch-up action.")
        now = now or datetime.now(UTC)
        selected = [self._required(identifier) for identifier in identifiers]
        selected = [job for job in selected if job.status == UploadStatus.PAUSED]
        if not selected:
            raise ValueError("Select one or more paused missed upload jobs.")
        selected.sort(key=lambda job: job.execution_at or job.scheduled_at)
        changed: list[UploadJob] = []
        if policy == MissedJobPolicy.SKIP:
            for job in selected:
                job.status = UploadStatus.CANCELLED
                job.last_error = "Skipped by the user's missed-job decision."
                job.log_messages.append(job.last_error)
                changed.append(self.repository.save(job))
            return changed
        if policy == MissedJobPolicy.UPLOAD_IMMEDIATELY:
            for index, job in enumerate(selected):
                job.execution_at = now + timedelta(minutes=index * 10)
                job.status = UploadStatus.QUEUED if index == 0 else UploadStatus.SCHEDULED
                job.last_error = None
                job.log_messages.append("Missed upload was explicitly staggered from now.")
                changed.append(self.repository.save(job))
            return changed
        first = selected[0].execution_at or selected[0].scheduled_at
        shift = now + timedelta(minutes=1) - first
        batch_ids = {job.batch_id for job in selected if job.batch_id}
        selected_ids = {job.id for job in selected}
        related = [
            job
            for job in self.repository.list()
            if ((job.batch_id and job.batch_id in batch_ids) or job.id in selected_ids)
            and job.status in {UploadStatus.PAUSED, UploadStatus.QUEUED, UploadStatus.SCHEDULED}
            and (job.execution_at or job.scheduled_at) >= first
        ]
        for job in related:
            job.execution_at = (job.execution_at or job.scheduled_at) + shift
            job.scheduled_at += shift
            job.status = UploadStatus.SCHEDULED
            job.last_error = None
            job.log_messages.append("Remaining batch schedule was explicitly shifted forward.")
            changed.append(self.repository.save(job))
        return changed

    def _required(self, identifier: str) -> UploadJob:
        job = self.repository.get(identifier)
        if not job:
            raise KeyError(f"Upload job does not exist: {identifier}")
        return job
