"""Pure, testable mapping from validated metadata to official API resources."""

from __future__ import annotations

from datetime import UTC, datetime

from app.models.upload_models import TikTokMetadata, YouTubeMetadata


def youtube_insert_body(
    metadata: YouTubeMetadata, scheduled_at: datetime | None = None
) -> dict[str, object]:
    description = metadata.description
    hashtags = [f"#{value.lstrip('#')}" for value in metadata.hashtags if value.strip()]
    if hashtags:
        hashtag_line = " ".join(dict.fromkeys(hashtags))
        description = f"{description.rstrip()}\n\n{hashtag_line}".strip()
    snippet: dict[str, object] = {
        "title": metadata.title,
        "description": description[:5000],
        "tags": metadata.tags,
        "categoryId": metadata.category_id,
        "defaultLanguage": metadata.default_language,
        "defaultAudioLanguage": metadata.language,
    }
    status: dict[str, object] = {
        "privacyStatus": metadata.privacy_status,
        "embeddable": metadata.embeddable,
        "license": metadata.license,
        "selfDeclaredMadeForKids": metadata.made_for_kids,
    }
    if scheduled_at:
        if scheduled_at.tzinfo is None:
            raise ValueError("YouTube scheduled publish time must include a timezone.")
        if scheduled_at <= datetime.now(UTC):
            raise ValueError("YouTube native publish time must be in the future.")
        status["privacyStatus"] = "private"
        status["publishAt"] = scheduled_at.astimezone(UTC).isoformat().replace("+00:00", "Z")
    body: dict[str, object] = {"snippet": snippet, "status": status}
    if metadata.recording_date:
        body["recordingDetails"] = {"recordingDate": metadata.recording_date}
    return body


def tiktok_post_info(metadata: TikTokMetadata) -> dict[str, object]:
    title = " ".join(
        [
            metadata.caption.strip(),
            *[f"#{value.lstrip('#')}" for value in metadata.hashtags if value.strip()],
        ]
    ).strip()
    if len(title) > 2200:
        raise ValueError("Combined TikTok caption and hashtags exceed 2200 characters.")
    value: dict[str, object] = {
        "title": title,
        "privacy_level": metadata.privacy_level,
        "disable_comment": not metadata.comments_enabled,
        "disable_duet": not metadata.duet_enabled,
        "disable_stitch": not metadata.stitch_enabled,
    }
    if metadata.cover_timestamp_ms is not None:
        value["video_cover_timestamp_ms"] = metadata.cover_timestamp_ms
    return value
