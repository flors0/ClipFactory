"""Official YouTube Data API resumable uploader."""

from __future__ import annotations

import random
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from threading import Event

import httplib2
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload

from app.core.exceptions import CancelledError, UploadError
from app.core.logging import redact_text
from app.models.channel_models import ChannelProfile
from app.models.upload_models import UploadJob, UploadResult, UploadStatus, YouTubeMetadata
from app.uploads.metadata_mapping import youtube_insert_body
from app.uploads.oauth_manager import OAuthManager
from app.uploads.uploader import Uploader


class YouTubeUploader(Uploader):
    platform = "youtube"
    RETRIABLE_STATUS_CODES = {500, 502, 503, 504}

    def __init__(self, oauth: OAuthManager, retry_count: int = 5):
        self.oauth = oauth
        self.retry_count = retry_count

    def capabilities(self, channel_id: str) -> dict[str, str]:
        credentials = self.oauth.youtube_credentials(channel_id)
        service = build("youtube", "v3", credentials=credentials, cache_discovery=False)
        response = service.channels().list(part="snippet,contentDetails", mine=True).execute()
        items = response.get("items", []) if isinstance(response, dict) else []
        if not items:
            raise UploadError("YouTube returned no channel for the connected account.")
        item = items[0]
        return {
            "channel_id": str(item.get("id", "")),
            "title": str(item.get("snippet", {}).get("title", "")),
            "uploads_playlist_id": str(
                item.get("contentDetails", {}).get("relatedPlaylists", {}).get("uploads", "")
            ),
        }

    def upload(
        self,
        job: UploadJob,
        channel: ChannelProfile,
        *,
        cancel_event: Event | None = None,
        progress_callback: Callable[[int, str], None] | None = None,
        state_callback: Callable[[UploadJob], None] | None = None,
    ) -> UploadResult:
        cancel_event = cancel_event or Event()
        progress_callback = progress_callback or (lambda _value, _message: None)
        state_callback = state_callback or (lambda _job: None)
        if not job.batch_approved or job.status not in {
            UploadStatus.QUEUED,
            UploadStatus.SCHEDULED,
            UploadStatus.FAILED,
            UploadStatus.PROCESSING,
        }:
            raise UploadError("YouTube upload requires an explicitly approved queued job.")
        metadata = YouTubeMetadata.model_validate(job.metadata)
        if job.remote_id:
            if job.status == UploadStatus.PUBLISHED:
                return UploadResult(remote_id=job.remote_id, status=job.status)
            credentials = self.oauth.youtube_credentials(channel.id)
            service = build("youtube", "v3", credentials=credentials, cache_discovery=False)
            return self._remote_result(service, job, metadata)
        path = Path(job.file_path).resolve()
        if not path.is_file() or path.stat().st_size <= 0:
            raise UploadError("YouTube upload file is missing or empty.")
        credentials = self.oauth.youtube_credentials(channel.id)
        service = build("youtube", "v3", credentials=credentials, cache_discovery=False)
        native_schedule = (
            job.scheduled_at
            if metadata.privacy_status == "public" and job.scheduled_at > datetime.now(UTC)
            else None
        )
        body = youtube_insert_body(metadata, native_schedule)
        media = MediaFileUpload(
            str(path), chunksize=8 * 1024 * 1024, resumable=True, mimetype="video/mp4"
        )
        request = service.videos().insert(
            part="snippet,status,recordingDetails",
            body=body,
            media_body=media,
            notifySubscribers=metadata.notify_subscribers,
        )
        if job.resumable_uri_reference:
            reference = job.resumable_uri_reference
            if reference.startswith(("http://", "https://")):
                # Migrate an early-development database value to the OS credential store.
                resumable_uri = reference
                reference = f"youtube-upload:{job.id}"
                self.oauth.store_secure_value(reference, resumable_uri)
                job.resumable_uri_reference = reference
                state_callback(job)
            else:
                resumable_uri = self.oauth.secure_value(reference)
            if resumable_uri:
                request.resumable_uri = resumable_uri
            else:
                job.resumable_uri_reference = None
                state_callback(job)
        response = None
        retries = 0
        job.status = UploadStatus.UPLOADING
        state_callback(job)
        while response is None:
            if cancel_event.is_set():
                raise CancelledError("YouTube upload was cancelled.")
            try:
                status, response = request.next_chunk()
                if getattr(request, "resumable_uri", None):
                    reference = job.resumable_uri_reference or f"youtube-upload:{job.id}"
                    self.oauth.store_secure_value(reference, str(request.resumable_uri))
                    job.resumable_uri_reference = reference
                    state_callback(job)
                if status:
                    job.progress = max(job.progress, int(status.progress() * 100))
                    progress_callback(job.progress, "Uploading to YouTube")
                    state_callback(job)
                retries = 0
            except HttpError as error:
                if (
                    error.resp.status not in self.RETRIABLE_STATUS_CODES
                    or retries >= self.retry_count
                ):
                    raise UploadError(
                        f"YouTube API upload failed with HTTP {error.resp.status}."
                    ) from error
                retries += 1
                self._backoff(retries, cancel_event)
            except (OSError, httplib2.HttpLib2Error) as error:
                if retries >= self.retry_count:
                    raise UploadError("YouTube upload failed after network retries.") from error
                retries += 1
                self._backoff(retries, cancel_event)
        video_id = response.get("id") if isinstance(response, dict) else None
        if not video_id:
            raise UploadError("YouTube upload returned no video identifier.")
        session_reference = job.resumable_uri_reference
        job.remote_id = str(video_id)
        job.status = UploadStatus.PROCESSING
        job.published_at = None
        job.progress = 99
        job.resumable_uri_reference = None
        state_callback(job)
        self.oauth.delete_secure_value(session_reference)
        warnings: list[str] = []
        if metadata.thumbnail_path:
            thumbnail = Path(metadata.thumbnail_path).resolve()
            if thumbnail.is_file():
                try:
                    service.thumbnails().set(videoId=video_id, media_body=str(thumbnail)).execute()
                except Exception as error:
                    warnings.append(
                        redact_text(f"Thumbnail upload failed after the video was created: {error}")
                    )
        if metadata.playlist_id:
            try:
                service.playlistItems().insert(
                    part="snippet",
                    body={
                        "snippet": {
                            "playlistId": metadata.playlist_id,
                            "resourceId": {"kind": "youtube#video", "videoId": video_id},
                        }
                    },
                ).execute()
            except Exception as error:
                warnings.append(
                    redact_text(f"Playlist assignment failed after the video was created: {error}")
                )
        job.log_messages.extend(warnings)
        remote_result = self._remote_result(service, job, metadata)
        job.status = remote_result.status
        job.published_at = remote_result.published_at
        job.progress = 99 if remote_result.status == UploadStatus.PROCESSING else 100
        state_callback(job)
        progress_callback(job.progress, "YouTube media transfer completed")
        details = dict(remote_result.details)
        details.update(
            {
                "native_schedule": bool(native_schedule),
                "caption_certification_note": "Stored for review only; videos.insert exposes no verified writable caption-certification field.",
                "warnings": warnings,
            }
        )
        return UploadResult(
            remote_id=str(video_id),
            status=remote_result.status,
            published_at=remote_result.published_at,
            details=details,
        )

    @staticmethod
    def _remote_result(service, job: UploadJob, metadata: YouTubeMetadata) -> UploadResult:
        response = (
            service.videos().list(part="status,processingDetails", id=job.remote_id).execute()
        )
        items = response.get("items", []) if isinstance(response, dict) else []
        if not items:
            raise UploadError("YouTube no longer returns the uploaded video.")
        item = items[0]
        status_data = item.get("status", {})
        processing_data = item.get("processingDetails", {})
        upload_status = str(status_data.get("uploadStatus", "")).lower()
        processing_status = str(processing_data.get("processingStatus", "")).lower()
        privacy = str(status_data.get("privacyStatus", ""))
        publish_at = status_data.get("publishAt")
        if upload_status in {"deleted", "failed", "rejected"} or processing_status in {
            "failed",
            "terminated",
        }:
            reason = (
                status_data.get("failureReason")
                or status_data.get("rejectionReason")
                or processing_data.get("processingFailureReason")
                or "unspecified platform reason"
            )
            raise UploadError(f"YouTube processing did not succeed: {redact_text(reason)}")
        succeeded = upload_status == "processed" or processing_status == "succeeded"
        if succeeded:
            remotely_scheduled = metadata.privacy_status == "public" and privacy == "private"
            final_status = UploadStatus.SCHEDULED if remotely_scheduled else UploadStatus.PUBLISHED
            return UploadResult(
                remote_id=str(job.remote_id),
                status=final_status,
                published_at=datetime.now(UTC) if final_status == UploadStatus.PUBLISHED else None,
                details={
                    "privacy_status": privacy,
                    "publish_at": publish_at,
                    "upload_status": upload_status,
                    "processing_status": processing_status,
                },
            )
        return UploadResult(
            remote_id=str(job.remote_id),
            status=UploadStatus.PROCESSING,
            details={
                "privacy_status": privacy,
                "publish_at": publish_at,
                "upload_status": upload_status,
                "processing_status": processing_status,
            },
        )

    @staticmethod
    def _backoff(attempt: int, cancel_event: Event) -> None:
        delay = min(60, (2**attempt) + random.random())
        if cancel_event.wait(delay):
            raise CancelledError("YouTube upload was cancelled during retry backoff.")
