"""OAuth flows with OS-keyring token storage and reference-only SQLite rows."""

from __future__ import annotations

import json
import secrets
import threading
import webbrowser
from datetime import UTC, datetime, timedelta
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse

import httpx
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from pydantic import BaseModel

from app.core.credentials import (
    TIKTOK_CLIENT_KEY,
    TIKTOK_CLIENT_SECRET,
    TIKTOK_REDIRECT_URI,
    TIKTOK_SCOPES,
    CredentialStore,
    KeyringCredentialStore,
    resolve_credential,
)
from app.core.credentials import (
    InMemoryCredentialStore as InMemoryCredentialStore,
)
from app.core.exceptions import OAuthError
from app.storage.database import Database


class TikTokToken(BaseModel):
    access_token: str
    refresh_token: str
    open_id: str = ""
    scope: str = ""
    expires_at: datetime
    refresh_expires_at: datetime | None = None


class OAuthManager:
    YOUTUBE_SCOPES = [
        "https://www.googleapis.com/auth/youtube.upload",
        "https://www.googleapis.com/auth/youtube",
    ]
    TIKTOK_CONTENT_SCOPES = {"video.publish", "video.upload"}

    def __init__(self, database: Database, credential_store: CredentialStore | None = None):
        self.database = database
        self.credential_store = credential_store or KeyringCredentialStore()
        self._pending_tiktok_states: dict[str, str] = {}

    def connect_youtube(self, channel_id: str, client_secrets_file: Path) -> Credentials:
        path = client_secrets_file.expanduser().resolve()
        if not path.is_file():
            raise OAuthError("YouTube OAuth client-secrets file does not exist.")
        try:
            flow = InstalledAppFlow.from_client_secrets_file(str(path), self.YOUTUBE_SCOPES)
            credentials = flow.run_local_server(host="127.0.0.1", port=0, open_browser=True)
        except Exception as error:
            raise OAuthError(f"YouTube OAuth authorization failed: {error}") from error
        reference = f"youtube:{channel_id}"
        self.credential_store.set(reference, credentials.to_json())
        self._save_reference(channel_id, "youtube", reference)
        return credentials

    def youtube_credentials(self, channel_id: str) -> Credentials:
        reference = self._reference(channel_id, "youtube")
        raw = self.credential_store.get(reference)
        if not raw:
            raise OAuthError("YouTube credentials are not available in the OS credential store.")
        credentials = Credentials.from_authorized_user_info(json.loads(raw), self.YOUTUBE_SCOPES)
        if credentials.expired and credentials.refresh_token:
            try:
                credentials.refresh(Request())
            except Exception as error:
                raise OAuthError(f"YouTube token refresh failed: {error}") from error
            self.credential_store.set(reference, credentials.to_json())
        if not credentials.valid:
            raise OAuthError("YouTube authorization is invalid; reconnect the channel.")
        return credentials

    def tiktok_authorization_url(self, channel_id: str) -> tuple[str, str]:
        client_key = resolve_credential(
            self.credential_store, TIKTOK_CLIENT_KEY, "TIKTOK_CLIENT_KEY"
        )
        redirect_uri = resolve_credential(
            self.credential_store, TIKTOK_REDIRECT_URI, "TIKTOK_REDIRECT_URI"
        )
        if not client_key or not redirect_uri:
            raise OAuthError("TIKTOK_CLIENT_KEY and TIKTOK_REDIRECT_URI are required.")
        requested_scopes = {
            value.strip()
            for value in (
                resolve_credential(self.credential_store, TIKTOK_SCOPES, "TIKTOK_SCOPES")
                or "video.publish,video.upload"
            ).split(",")
            if value.strip()
        }
        if not requested_scopes or not requested_scopes <= self.TIKTOK_CONTENT_SCOPES:
            raise OAuthError("TIKTOK_SCOPES must contain video.publish, video.upload, or both.")
        state = secrets.token_urlsafe(32)
        self._pending_tiktok_states[channel_id] = state
        query = urlencode(
            {
                "client_key": client_key,
                "scope": ",".join(sorted(requested_scopes)),
                "response_type": "code",
                "redirect_uri": redirect_uri,
                "state": state,
            }
        )
        return f"https://www.tiktok.com/v2/auth/authorize/?{query}", state

    def exchange_tiktok_code(
        self, channel_id: str, code: str, state: str, client: httpx.Client | None = None
    ) -> TikTokToken:
        expected = self._pending_tiktok_states.pop(channel_id, None)
        if not expected or not secrets.compare_digest(expected, state):
            raise OAuthError("TikTok OAuth state validation failed.")
        client_key = resolve_credential(
            self.credential_store, TIKTOK_CLIENT_KEY, "TIKTOK_CLIENT_KEY"
        )
        client_secret = resolve_credential(
            self.credential_store, TIKTOK_CLIENT_SECRET, "TIKTOK_CLIENT_SECRET"
        )
        redirect_uri = resolve_credential(
            self.credential_store, TIKTOK_REDIRECT_URI, "TIKTOK_REDIRECT_URI"
        )
        if not all((client_key, client_secret, redirect_uri)):
            raise OAuthError("TikTok OAuth app credentials are incomplete in Settings.")
        response = (client or httpx.Client(timeout=30)).post(
            "https://open.tiktokapis.com/v2/oauth/token/",
            data={
                "client_key": client_key,
                "client_secret": client_secret,
                "code": code,
                "grant_type": "authorization_code",
                "redirect_uri": redirect_uri,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        if response.status_code >= 400:
            raise OAuthError(f"TikTok token exchange failed with HTTP {response.status_code}.")
        token = self._parse_tiktok_token(response.json())
        reference = f"tiktok:{channel_id}"
        self.credential_store.set(reference, token.model_dump_json())
        self._save_reference(channel_id, "tiktok", reference)
        return token

    def connect_tiktok_interactive(
        self, channel_id: str, timeout_seconds: float = 300
    ) -> TikTokToken:
        redirect_uri = resolve_credential(
            self.credential_store, TIKTOK_REDIRECT_URI, "TIKTOK_REDIRECT_URI"
        )
        if not redirect_uri:
            raise OAuthError("TIKTOK_REDIRECT_URI is required.")
        parsed = urlparse(redirect_uri)
        if (
            parsed.scheme != "http"
            or parsed.hostname not in {"127.0.0.1", "localhost"}
            or not parsed.port
        ):
            raise OAuthError(
                "Interactive desktop TikTok OAuth requires a loopback HTTP redirect URI with an explicit port."
            )
        authorization_url, state = self.tiktok_authorization_url(channel_id)
        result: dict[str, str] = {}
        completed = threading.Event()

        class CallbackHandler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:
                query = parse_qs(urlparse(self.path).query)
                result["code"] = query.get("code", [""])[0]
                result["state"] = query.get("state", [""])[0]
                result["error"] = query.get("error", [""])[0]
                body = b"ClipFactory received the TikTok authorization response. You can close this tab."
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                completed.set()

            def log_message(self, _format: str, *_args: object) -> None:
                return

        server = HTTPServer((parsed.hostname, parsed.port), CallbackHandler)
        server.timeout = 0.5
        webbrowser.open(authorization_url)
        try:
            deadline = datetime.now(UTC) + timedelta(seconds=timeout_seconds)
            while not completed.is_set() and datetime.now(UTC) < deadline:
                server.handle_request()
        finally:
            server.server_close()
        if not completed.is_set():
            self._pending_tiktok_states.pop(channel_id, None)
            raise OAuthError("TikTok OAuth timed out before the loopback callback arrived.")
        if result.get("error"):
            raise OAuthError(f"TikTok authorization was denied: {result['error']}")
        if not result.get("code"):
            raise OAuthError("TikTok callback did not include an authorization code.")
        return self.exchange_tiktok_code(channel_id, result["code"], result.get("state", state))

    def tiktok_token(self, channel_id: str, client: httpx.Client | None = None) -> TikTokToken:
        reference = self._reference(channel_id, "tiktok")
        raw = self.credential_store.get(reference)
        if not raw:
            raise OAuthError("TikTok credentials are not available in the OS credential store.")
        token = TikTokToken.model_validate_json(raw)
        if token.expires_at <= datetime.now(UTC) + timedelta(minutes=2):
            token = self._refresh_tiktok(token, client or httpx.Client(timeout=30))
            self.credential_store.set(reference, token.model_dump_json())
        return token

    def disconnect(self, channel_id: str) -> None:
        row = self.database.fetchone(
            "SELECT credential_reference FROM oauth_references WHERE channel_id = ?", (channel_id,)
        )
        if row:
            self.credential_store.delete(row["credential_reference"])
            self.database.execute(
                "DELETE FROM oauth_references WHERE channel_id = ?", (channel_id,)
            )

    def store_secure_value(self, reference: str, value: str) -> None:
        """Store transient upload capabilities beside OAuth tokens, never in SQLite."""
        if not reference or not value:
            raise OAuthError("A secure credential reference and value are required.")
        self.credential_store.set(reference, value)

    def secure_value(self, reference: str) -> str | None:
        return self.credential_store.get(reference)

    def delete_secure_value(self, reference: str | None) -> None:
        if reference:
            self.credential_store.delete(reference)

    def _refresh_tiktok(self, token: TikTokToken, client: httpx.Client) -> TikTokToken:
        client_key = resolve_credential(
            self.credential_store, TIKTOK_CLIENT_KEY, "TIKTOK_CLIENT_KEY"
        )
        client_secret = resolve_credential(
            self.credential_store, TIKTOK_CLIENT_SECRET, "TIKTOK_CLIENT_SECRET"
        )
        if not client_key or not client_secret:
            raise OAuthError("TikTok client credentials are required to refresh access.")
        response = client.post(
            "https://open.tiktokapis.com/v2/oauth/token/",
            data={
                "client_key": client_key,
                "client_secret": client_secret,
                "grant_type": "refresh_token",
                "refresh_token": token.refresh_token,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        if response.status_code >= 400:
            raise OAuthError("TikTok token refresh failed; reconnect the channel.")
        return self._parse_tiktok_token(response.json())

    @staticmethod
    def _parse_tiktok_token(data: dict[str, object]) -> TikTokToken:
        now = datetime.now(UTC)
        if not data.get("access_token") or not data.get("refresh_token"):
            raise OAuthError("TikTok response did not contain complete tokens.")
        return TikTokToken(
            access_token=str(data["access_token"]),
            refresh_token=str(data["refresh_token"]),
            open_id=str(data.get("open_id", "")),
            scope=str(data.get("scope", "")),
            expires_at=now + timedelta(seconds=int(data.get("expires_in", 0))),
            refresh_expires_at=now + timedelta(seconds=int(data["refresh_expires_in"]))
            if data.get("refresh_expires_in")
            else None,
        )

    def _save_reference(self, channel_id: str, provider: str, reference: str) -> None:
        self.database.execute(
            "INSERT INTO oauth_references(channel_id, provider, credential_reference, updated_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(channel_id) DO UPDATE SET provider=excluded.provider, credential_reference=excluded.credential_reference, updated_at=excluded.updated_at",
            (channel_id, provider, reference, datetime.now(UTC).isoformat()),
        )

    def _reference(self, channel_id: str, provider: str) -> str:
        row = self.database.fetchone(
            "SELECT provider, credential_reference FROM oauth_references WHERE channel_id = ?",
            (channel_id,),
        )
        if not row or row["provider"] != provider:
            raise OAuthError(f"No {provider} OAuth reference exists for this channel.")
        return str(row["credential_reference"])
