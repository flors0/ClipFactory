"""Source profile and discovery contracts."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Literal

from pydantic import Field, field_validator

from app.models.base import EntityModel, StrictModel


class RightsMode(StrEnum):
    STRICT = "strict"
    MANUAL_REVIEW = "manual_review"
    IGNORE = "ignore"


class MediaType(StrEnum):
    VIDEO = "video"
    GIF = "gif"
    IMAGE = "image"
    GALLERY = "gallery"
    EXTERNAL = "external"
    UNKNOWN = "unknown"


class SourceProfile(EntityModel):
    name: str = Field(min_length=1, max_length=120)
    platform: Literal["reddit"] = "reddit"
    community: str = Field(min_length=1, max_length=100)
    source_url: str
    sort: Literal["new", "hot", "top"] = "top"
    time_filter: Literal["hour", "day", "week", "month", "year", "all"] = "week"
    candidate_limit: int = Field(50, ge=1, le=200)
    min_score: int = Field(0, ge=0)
    min_comment_count: int = Field(0, ge=0)
    max_post_age_hours: int = Field(168, ge=1)
    require_video: bool = True
    allow_gifs: bool = True
    allow_nsfw: bool = False
    allow_crossposts: bool = True
    allowed_flairs: list[str] = Field(default_factory=list)
    blocked_flairs: list[str] = Field(default_factory=list)
    language: str = "en"
    theme_hint: str | None = None
    rights_mode: RightsMode = RightsMode.MANUAL_REVIEW

    @field_validator("community")
    @classmethod
    def normalize_community(cls, value: str) -> str:
        value = value.strip().strip("/")
        if value.lower().startswith("r/"):
            value = value[2:]
        if not value or any(
            character not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"
            for character in value
        ):
            raise ValueError("Community contains unsupported characters.")
        return value


class SourceCandidate(StrictModel):
    post_id: str
    title: str
    post_url: str
    community: str
    published_at: datetime
    score: int | None = None
    comment_count: int | None = None
    flair: str | None = None
    nsfw: bool = False
    is_crosspost: bool = False
    crosspost_parent_id: str | None = None
    media_type: MediaType = MediaType.UNKNOWN
    thumbnail_url: str | None = None
    media_url: str | None = None
    author: str | None = None
    rights_status: Literal["unknown", "cleared", "restricted"] = "unknown"
    source_fingerprint: str
    raw_metadata: dict[str, object] = Field(default_factory=dict)


class SourceHealth(StrictModel):
    provider: str
    reachable: bool
    checked_at: datetime
    candidate_count: int = 0
    cache_hit: bool = False
    message: str = ""


class DiscoveryResult(StrictModel):
    profile_id: str
    community_description: str | None = None
    candidates: list[SourceCandidate] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    health: SourceHealth
