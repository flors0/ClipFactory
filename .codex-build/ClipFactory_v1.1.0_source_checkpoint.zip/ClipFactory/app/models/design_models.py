"""Coordinated visual design profiles for a complete video format."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from app.models.base import EntityModel
from app.models.preset_models import Rect


class DesignProfile(EntityModel):
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=500)
    core: bool = False
    video_format: Literal["ranking", "compilation"] = "ranking"
    ranking_numbers_profile_id: str | None = None
    captions_profile_id: str | None = None
    header_profile_id: str | None = None
    layer_bounds: dict[str, Rect] = Field(default_factory=dict)
    hidden_layers: dict[str, bool] = Field(default_factory=dict)
    header_enabled: bool | None = None
    ranking_enabled: bool | None = None
    ranking_spacing: float | None = Field(default=None, ge=0, le=0.2)
    ranking_vertical_alignment: Literal["top", "center", "bottom"] | None = None
