"""Validated application data contracts."""
