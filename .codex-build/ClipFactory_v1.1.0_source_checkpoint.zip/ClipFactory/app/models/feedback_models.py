"""Persistent user editorial corrections used as adaptive Gemini context."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field

from app.models.base import EntityModel


class EditorialFieldKind(StrEnum):
    HEADER = "header"
    RANKING_CAPTION = "ranking_caption"
    UPLOAD_TITLE = "upload_title"
    UPLOAD_DESCRIPTION = "upload_description"
    TIKTOK_CAPTION = "tiktok_caption"


class AIEditFeedback(EntityModel):
    review_item_id: str
    production_job_id: str
    project_id: str
    channel_id: str | None = None
    preset_id: str
    platform: str
    language: str = "en"
    theme: str = ""
    field_kind: EditorialFieldKind
    field_key: str
    original_text: str
    edited_text: str
    edit_signature: str = ""
    context: dict[str, object] = Field(default_factory=dict)
