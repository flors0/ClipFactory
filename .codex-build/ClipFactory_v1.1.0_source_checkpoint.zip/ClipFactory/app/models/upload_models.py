"""Platform metadata and upload job contracts."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Literal

from pydantic import Field, field_validator

from app.models.base import EntityModel, StrictModel


class UploadStatus(StrEnum):
    DRAFT = "draft"
    BLOCKED_APPROVAL = "blocked_approval"
    QUEUED = "queued"
    PAUSED = "paused"
    UPLOADING = "uploading"
    PROCESSING = "processing"
    SCHEDULED = "scheduled"
    PUBLISHED = "published"
    FAILED = "failed"
    CANCELLED = "cancelled"


class YouTubeMetadata(StrictModel):
    title: str = Field(min_length=1, max_length=100)
    description: str = Field("", max_length=5000)
    tags: list[str] = Field(default_factory=list)
    category_id: str = "22"
    language: str = "en"
    default_language: str = "en"
    privacy_status: str = "private"
    made_for_kids: bool = False
    embeddable: bool = True
    license: str = "youtube"
    notify_subscribers: bool = False
    recording_date: str | None = None
    playlist_id: str | None = None
    caption_certification: str | None = None
    thumbnail_path: str | None = None
    hashtags: list[str] = Field(default_factory=list)

    @field_validator("tags")
    @classmethod
    def validate_total_tag_length(cls, values: list[str]) -> list[str]:
        if sum(len(value) for value in values) > 450:
            raise ValueError("YouTube tags exceed the safe total length.")
        return values


class TikTokMetadata(StrictModel):
    caption: str = Field("", max_length=2200)
    hashtags: list[str] = Field(default_factory=list)
    privacy_level: str = "SELF_ONLY"
    comments_enabled: bool = True
    duet_enabled: bool = False
    stitch_enabled: bool = False
    cover_timestamp_ms: int | None = Field(default=None, ge=0)
    mode: Literal["direct_post", "draft_upload"] = "direct_post"


class TikTokCapabilities(StrictModel):
    creator_username: str
    creator_nickname: str
    privacy_level_options: list[str]
    comments_allowed: bool
    duet_allowed: bool
    stitch_allowed: bool
    max_video_duration_seconds: int
    direct_post_available: bool
    draft_upload_available: bool = True


class UploadJob(EntityModel):
    production_job_id: str
    batch_id: str | None = None
    review_item_id: str
    channel_id: str
    platform: str
    file_path: str
    scheduled_at: datetime
    execution_at: datetime | None = None
    status: UploadStatus = UploadStatus.BLOCKED_APPROVAL
    metadata: dict[str, object] = Field(default_factory=dict)
    batch_approved: bool = False
    progress: int = Field(0, ge=0, le=100)
    retry_count: int = Field(0, ge=0)
    last_error: str | None = None
    remote_id: str | None = None
    resumable_uri_reference: str | None = None
    published_at: datetime | None = None
    log_messages: list[str] = Field(default_factory=list)

    def model_post_init(self, __context: object) -> None:
        if self.execution_at is None:
            self.execution_at = self.scheduled_at


class UploadResult(StrictModel):
    remote_id: str
    status: UploadStatus
    published_at: datetime | None = None
    details: dict[str, object] = Field(default_factory=dict)
