"""Render job and plan contracts."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Literal

from pydantic import Field

from app.models.base import EntityModel, StrictModel
from app.models.project_models import SelectedClip


class ProductionStatus(StrEnum):
    PLANNED = "planned"
    DISCOVERING = "discovering"
    DOWNLOADING = "downloading"
    PROBING = "probing"
    ANALYZING = "analyzing"
    SELECTING = "selecting"
    GENERATING_COPY = "generating_copy"
    RENDERING = "rendering"
    VALIDATING = "validating"
    AWAITING_REVIEW = "awaiting_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    QUEUED_FOR_UPLOAD = "queued_for_upload"
    UPLOADING = "uploading"
    SCHEDULED = "scheduled"
    PUBLISHED = "published"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TimedText(StrictModel):
    text: str
    start_seconds: float = Field(ge=0)
    end_seconds: float = Field(gt=0)
    layer_id: str
    clip_id: str | None = None
    rank: int | None = Field(default=None, ge=1)
    rich_text_override: dict[str, object] | None = None


class TimedAudioAsset(StrictModel):
    path: str
    start_seconds: float = Field(ge=0)
    duration_seconds: float | None = Field(default=None, gt=0)
    source_start_seconds: float = Field(0, ge=0)
    fade_in_seconds: float = Field(0, ge=0)
    fade_out_seconds: float = Field(0, ge=0)
    volume: float = Field(1, ge=0, le=2)


class TimelineSegment(StrictModel):
    kind: Literal["clip", "transition", "interstitial"]
    start_seconds: float = Field(ge=0)
    end_seconds: float = Field(gt=0)
    path: str
    source_start_seconds: float = Field(0, ge=0)
    clip_id: str | None = None
    rank: int | None = Field(default=None, ge=1)

    @property
    def duration_seconds(self) -> float:
        return self.end_seconds - self.start_seconds


class RankingTimelineItem(StrictModel):
    rank: int = Field(ge=1)
    clip_id: str
    caption: str
    clip_start_seconds: float = Field(ge=0)
    clip_end_seconds: float = Field(gt=0)
    caption_start_seconds: float = Field(ge=0)
    caption_end_seconds: float = Field(gt=0)


class TimedVisualAsset(StrictModel):
    path: str
    x: int
    y: int
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    start_seconds: float = Field(ge=0)
    end_seconds: float = Field(gt=0)
    opacity: float = Field(1, ge=0, le=1)
    rotation_degrees: float = Field(0, ge=-180, le=180)


class RenderPlan(StrictModel):
    project_id: str
    job_id: str
    preset_id: str
    output_path: str
    clips: list[SelectedClip]
    header_text: str
    captions: list[TimedText]
    width: int
    height: int
    fps: int
    target_duration_seconds: float
    background_path: str | None = None
    music_path: str | None = None
    transition_path: str | None = None
    interstitial_path: str | None = None
    subtitle_path: str | None = None
    font_directory: str | None = None
    audio_overlays: list[TimedAudioAsset] = Field(default_factory=list)
    visual_overlays: list[TimedVisualAsset] = Field(default_factory=list)
    timeline: list[TimelineSegment] = Field(default_factory=list)
    ranking_items: list[RankingTimelineItem] = Field(default_factory=list)
    transition_count: int = Field(0, ge=0)
    text_overlays_enabled: bool = True
    metadata: dict[str, object] = Field(default_factory=dict)


class ProductionJob(EntityModel):
    project_id: str
    batch_id: str | None = None
    status: ProductionStatus = ProductionStatus.PLANNED
    progress: int = Field(0, ge=0, le=100)
    current_step: str = "Planned"
    retry_count: int = Field(0, ge=0)
    attempt_count: int = Field(0, ge=0)
    last_error: str | None = None
    preset_id: str
    design_profile_id: str | None = None
    channel_id: str | None = None
    scheduled_at: datetime | None = None
    output_path: str | None = None
    estimated_ai_cost_usd: float = Field(0, ge=0)
    actual_ai_cost_usd: float = Field(0, ge=0)
    log_messages: list[str] = Field(default_factory=list)
    render_plan_payload: dict[str, object] | None = None
    use_mock_ai: bool = False
    use_mock_source: bool = False
    production_options: dict[str, object] = Field(default_factory=dict)
