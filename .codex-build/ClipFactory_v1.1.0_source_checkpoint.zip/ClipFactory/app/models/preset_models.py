"""Complete visual and technical preset contracts."""

from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import Field, model_validator

from app.models.ai_models import AIFieldPermissions
from app.models.base import EntityModel, StrictModel


class DurationEnforcement(StrEnum):
    WARN = "warn"
    BLOCK = "block"
    AUTO_EXTEND = "auto_extend"


class ElementType(StrEnum):
    VIDEO = "video"
    BACKGROUND = "background"
    IMAGE = "image"
    MEME = "meme"
    HEADER = "header"
    RICH_TEXT = "rich_text"
    RANKING_NUMBER = "ranking_number"
    DYNAMIC_CAPTION = "dynamic_caption"
    SUBTITLE = "subtitle"
    INTERSTITIAL = "interstitial"
    AUDIO = "audio"
    MUSIC = "music"
    SOUND_EFFECT = "sound_effect"
    SHAPE = "shape"


class Color(StrictModel):
    red: int = Field(255, ge=0, le=255)
    green: int = Field(255, ge=0, le=255)
    blue: int = Field(255, ge=0, le=255)
    alpha: int = Field(255, ge=0, le=255)

    @classmethod
    def from_hex(cls, value: str) -> Color:
        cleaned = value.lstrip("#")
        if len(cleaned) not in {6, 8}:
            raise ValueError("Color must use RRGGBB or RRGGBBAA format.")
        if len(cleaned) == 6:
            cleaned += "FF"
        parts = [int(cleaned[index : index + 2], 16) for index in range(0, 8, 2)]
        return cls(red=parts[0], green=parts[1], blue=parts[2], alpha=parts[3])

    def to_hex(self, include_alpha: bool = True) -> str:
        base = f"#{self.red:02X}{self.green:02X}{self.blue:02X}"
        return f"{base}{self.alpha:02X}" if include_alpha else base


class TextStyle(StrictModel):
    font_family: str = "Arial"
    fallback_font: str = "DejaVu Sans"
    font_size: float = Field(64, gt=0)
    minimum_font_size: float = Field(28, gt=0)
    scale_with_canvas: bool = True
    reference_height: int = Field(1920, ge=240, le=7680)
    bold: bool = True
    italic: bool = False
    underline: bool = False
    foreground: Color = Field(default_factory=Color)
    outline: Color = Field(default_factory=lambda: Color(red=0, green=0, blue=0))
    outline_width: float = Field(3, ge=0)
    shadow_enabled: bool = True
    shadow_color: Color = Field(default_factory=lambda: Color(red=0, green=0, blue=0, alpha=180))
    shadow_distance: float = Field(2, ge=0, le=50)
    shadow_blur: float = Field(0, ge=0, le=50)
    glow_enabled: bool = False
    glow_color: Color | None = None
    glow_radius: float = Field(0, ge=0, le=50)
    glow_intensity: float = Field(0.65, ge=0, le=1)
    background: Color = Field(default_factory=lambda: Color(red=0, green=0, blue=0, alpha=0))
    letter_spacing: float = 0
    line_spacing: float = 1.0
    alignment: Literal["left", "center", "right"] = "center"
    transform: Literal["none", "uppercase", "lowercase", "title"] = "none"


class RichTextSpan(StrictModel):
    start: int = Field(ge=0)
    end: int = Field(ge=0)
    style: TextStyle

    @model_validator(mode="after")
    def validate_range(self) -> RichTextSpan:
        if self.end <= self.start:
            raise ValueError("Rich-text span end must be greater than start.")
        return self


class RichTextDocument(StrictModel):
    text: str = ""
    default_style: TextStyle = Field(default_factory=TextStyle)
    spans: list[RichTextSpan] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_spans(self) -> RichTextDocument:
        for span in self.spans:
            if span.end > len(self.text):
                raise ValueError("Rich-text span exceeds text length.")
        return self


class Rect(StrictModel):
    x: float = Field(0, ge=0, le=1)
    y: float = Field(0, ge=0, le=1)
    width: float = Field(1, gt=0, le=1)
    height: float = Field(1, gt=0, le=1)

    @model_validator(mode="after")
    def fit_canvas(self) -> Rect:
        if self.x + self.width > 1.000001 or self.y + self.height > 1.000001:
            raise ValueError("Element bounds exceed the normalized canvas.")
        return self


class PresetLayer(StrictModel):
    id: str
    name: str
    element_type: ElementType
    bounds: Rect
    z_index: int = 0
    rotation_degrees: float = Field(0, ge=-180, le=180)
    locked: bool = False
    hidden: bool = False
    opacity: float = Field(1, ge=0, le=1)
    rich_text: RichTextDocument | None = None
    background_color: Color = Field(default_factory=lambda: Color(red=0, green=0, blue=0, alpha=0))
    asset_id: str | None = None
    start_seconds: float = Field(0, ge=0)
    duration_seconds: float | None = Field(default=None, gt=0)
    volume: float = Field(1, ge=0, le=2)
    enter_animation: str = "none"
    exit_animation: str = "none"


class DurationRule(StrictModel):
    target_seconds: float = Field(65, gt=0)
    minimum_seconds: float = Field(60, gt=0)
    maximum_seconds: float = Field(90, gt=0)
    enforcement: DurationEnforcement = DurationEnforcement.WARN

    @model_validator(mode="after")
    def validate_order(self) -> DurationRule:
        if not self.minimum_seconds <= self.target_seconds <= self.maximum_seconds:
            raise ValueError("Duration target must be between minimum and maximum.")
        return self


class RankingItemOverride(StrictModel):
    active_color: Color | None = None
    inactive_color: Color | None = None
    active_opacity: float | None = Field(default=None, ge=0, le=1)
    inactive_opacity: float | None = Field(default=None, ge=0, le=1)
    caption_style: TextStyle | None = None


class RankingSettings(StrictModel):
    enabled: bool = True
    count: int = Field(5, ge=1, le=20)
    # Kept for v1.0.5 payload compatibility. Ranking semantics are always best-first:
    # rank 1 is the first/top row and the strongest selected clip.
    order: Literal["ascending", "descending"] = "ascending"
    playback_order: Literal["best_to_worst", "worst_to_best"] = "worst_to_best"
    horizontal_alignment: Literal["left", "center", "right"] = "center"
    vertical_alignment: Literal["top", "center", "bottom"] = "center"
    numbers_visible_from_start: bool = True
    active_opacity: float = Field(1, ge=0, le=1)
    inactive_opacity: float = Field(0.45, ge=0, le=1)
    active_color: Color = Field(default_factory=lambda: Color(red=255, green=80, blue=80))
    inactive_color: Color = Field(default_factory=lambda: Color(red=255, green=255, blue=255))
    reveal_offset_seconds: float = Field(0, ge=0)
    captions_persist_after_reveal: bool = True
    spacing: float = Field(0.015, ge=0)
    item_overrides: dict[int, RankingItemOverride] = Field(default_factory=dict)


class HeaderSettings(StrictModel):
    enabled: bool = True
    height_ratio: float = Field(0.18, gt=0, le=0.5)
    background: Color = Field(default_factory=lambda: Color(red=18, green=18, blue=22))
    border_color: Color = Field(default_factory=lambda: Color(red=18, green=18, blue=22))
    border_width: float = Field(0, ge=0, le=30)
    padding_ratio: float = Field(0.025, ge=0, le=0.2)
    automatic_fit: bool = True
    line_wrapping: bool = True
    maximum_lines: int = Field(3, ge=1, le=10)
    visibility: Literal["fixed", "full_video"] = "full_video"
    duration_seconds: float | None = None
    locked_text: bool = False
    accent_color: Color | None = None
    accent_last_words: int = Field(0, ge=0, le=12)


class AudioSettings(StrictModel):
    original_volume: float = Field(1, ge=0, le=2)
    music_volume: float = Field(0.15, ge=0, le=2)
    sfx_volume: float = Field(0.7, ge=0, le=2)
    transition_volume: float = Field(0.7, ge=0, le=2)
    target_loudness_lufs: float = Field(-14, ge=-30, le=-5)
    ducking_enabled: bool = True
    ducking_strength: float = Field(0.6, ge=0, le=1)
    fade_in_seconds: float = Field(0.1, ge=0)
    fade_out_seconds: float = Field(0.15, ge=0)
    limiter_enabled: bool = True
    silence_handling: Literal["preserve", "fill", "reject"] = "fill"
    music_asset_id: str | None = None


class TransitionSettings(StrictModel):
    enabled: bool = False
    type: Literal["cut", "fade", "fixed_asset"] = "fade"
    fixed_asset_id: str | None = None
    sound_asset_id: str | None = None
    duration_seconds: float = Field(0.25, ge=0, le=5)
    sound_start_offset_seconds: float = Field(0, ge=0, le=120)
    sound_duration_seconds: float | None = Field(default=None, gt=0, le=120)
    sound_fade_seconds: float = Field(0.03, ge=0, le=2)
    original_audio_fade_seconds: float = Field(0.04, ge=0, le=2)
    use_asset_audio: bool = True
    placement: Literal["between_clips", "intro", "outro", "all"] = "between_clips"


class InterstitialSettings(StrictModel):
    enabled: bool = False
    asset_id: str | None = None
    duration_seconds: float = Field(1.0, gt=0, le=30)
    use_asset_audio: bool = True
    volume: float = Field(0.7, ge=0, le=2)
    fade_seconds: float = Field(0.1, ge=0, le=5)
    placement: Literal["between_clips", "intro", "outro", "all"] = "between_clips"


class EncodingSettings(StrictModel):
    container: Literal["mp4"] = "mp4"
    video_codec: str = "libx264"
    audio_codec: str = "aac"
    crf: int = Field(20, ge=0, le=51)
    audio_bitrate: str = "192k"
    pixel_format: str = "yuv420p"
    fast_start: bool = True


class SafeZoneSettings(StrictModel):
    top: float = Field(0.06, ge=0, le=0.4)
    right: float = Field(0.12, ge=0, le=0.4)
    bottom: float = Field(0.16, ge=0, le=0.4)
    left: float = Field(0.05, ge=0, le=0.4)


class PresetStyleProfiles(StrictModel):
    design: str | None = None
    ranking_numbers: str | None = None
    captions: str | None = None
    header: str | None = None


class Preset(EntityModel):
    name: str = Field(min_length=1, max_length=120)
    core: bool = False
    platform: Literal["youtube", "tiktok", "generic"]
    video_format: Literal["ranking", "meme", "compilation"]
    width: int = Field(1080, ge=240, le=7680)
    height: int = Field(1920, ge=240, le=7680)
    fps: int = Field(30, ge=15, le=120)
    duration: DurationRule = Field(default_factory=DurationRule)
    header: HeaderSettings = Field(default_factory=HeaderSettings)
    ranking: RankingSettings = Field(default_factory=RankingSettings)
    audio: AudioSettings = Field(default_factory=AudioSettings)
    transition: TransitionSettings = Field(default_factory=TransitionSettings)
    interstitial: InterstitialSettings = Field(default_factory=InterstitialSettings)
    encoding: EncodingSettings = Field(default_factory=EncodingSettings)
    safe_zones: SafeZoneSettings = Field(default_factory=SafeZoneSettings)
    layers: list[PresetLayer] = Field(default_factory=list)
    ai_permissions: AIFieldPermissions = Field(default_factory=AIFieldPermissions)
    subtitles_enabled: bool = False
    style_profiles: PresetStyleProfiles = Field(default_factory=PresetStyleProfiles)
    upload_metadata_defaults: dict[str, object] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_layers(self) -> Preset:
        identifiers = [layer.id for layer in self.layers]
        if len(identifiers) != len(set(identifiers)):
            raise ValueError("Preset layer identifiers must be unique.")
        return self
