"""Publishing channel profiles."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from app.models.base import EntityModel


class ChannelProfile(EntityModel):
    display_name: str
    platform: Literal["youtube", "tiktok"]
    account_identifier: str = ""
    oauth_connection_state: Literal["disconnected", "connected", "expired", "error"] = (
        "disconnected"
    )
    oauth_reference: str | None = None
    default_preset_id: str | None = None
    default_design_profile_id: str | None = None
    default_source_profile_id: str | None = None
    language: str = "en"
    timezone: str = "Europe/Berlin"
    default_upload_metadata: dict[str, object] = Field(default_factory=dict)
    default_tags: list[str] = Field(default_factory=list)
    default_hashtags: list[str] = Field(default_factory=list)
    default_privacy: str = "private"
    schedule_template_id: str | None = None
    enabled: bool = True
