"""Downloaded-media and probing contracts."""

from __future__ import annotations

from pathlib import Path

from pydantic import Field

from app.models.base import StrictModel


class MediaInfo(StrictModel):
    file_path: str
    file_fingerprint: str
    duration_seconds: float = Field(gt=0)
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    aspect_ratio: float = Field(gt=0)
    fps: float = Field(gt=0)
    video_codec: str
    audio_codec: str | None = None
    has_audio: bool
    file_size_bytes: int = Field(gt=0)
    bitrate: int | None = None
    container: str | None = None

    @property
    def path(self) -> Path:
        return Path(self.file_path)


class DownloadedMedia(StrictModel):
    candidate_id: str
    source_url: str
    file_path: str
    file_fingerprint: str
    from_cache: bool = False
    extractor: str | None = None
    title: str | None = None


class TechnicalCheck(StrictModel):
    name: str
    passed: bool
    details: str = ""
    blocking: bool = True


class TechnicalValidationResult(StrictModel):
    passed: bool
    checks: list[TechnicalCheck]
    warnings: list[str] = Field(default_factory=list)
