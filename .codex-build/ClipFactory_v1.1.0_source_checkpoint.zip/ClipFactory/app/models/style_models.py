"""Reusable visual style profile contracts."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field, model_validator

from app.models.base import EntityModel, StrictModel
from app.models.preset_models import Color, RankingItemOverride, TextStyle


class StyleProfileKind(StrEnum):
    RANKING_NUMBERS = "ranking_numbers"
    CAPTIONS = "captions"
    HEADER = "header"


class RankingStyleValues(StrictModel):
    active_color: Color = Field(default_factory=lambda: Color(red=255, green=80, blue=80))
    inactive_color: Color = Field(default_factory=Color)
    active_opacity: float = Field(1, ge=0, le=1)
    inactive_opacity: float = Field(0.45, ge=0, le=1)
    item_overrides: dict[int, RankingItemOverride] = Field(default_factory=dict)


class HeaderStyleValues(StrictModel):
    background: Color = Field(default_factory=lambda: Color(red=18, green=18, blue=22))
    border_color: Color = Field(default_factory=lambda: Color(red=18, green=18, blue=22))
    border_width: float = Field(0, ge=0, le=30)
    height_ratio: float = Field(0.18, gt=0, le=0.5)
    padding_ratio: float = Field(0.025, ge=0, le=0.2)
    accent_color: Color | None = None
    accent_last_words: int = Field(0, ge=0, le=12)


class StyleProfile(EntityModel):
    name: str = Field(min_length=1, max_length=120)
    kind: StyleProfileKind
    core: bool = False
    text_style: TextStyle
    layer_background: Color = Field(default_factory=lambda: Color(red=0, green=0, blue=0, alpha=0))
    layer_opacity: float = Field(1, ge=0, le=1)
    ranking: RankingStyleValues | None = None
    header: HeaderStyleValues | None = None

    @model_validator(mode="after")
    def validate_kind_payload(self) -> StyleProfile:
        if self.kind == StyleProfileKind.RANKING_NUMBERS:
            if self.ranking is None:
                raise ValueError("Ranking-number style profiles require ranking values.")
            if self.header is not None:
                raise ValueError("Ranking-number profiles cannot contain header values.")
        elif self.kind == StyleProfileKind.HEADER:
            if self.header is None:
                raise ValueError("Header style profiles require header values.")
            if self.ranking is not None:
                raise ValueError("Header profiles cannot contain ranking values.")
        elif self.ranking is not None or self.header is not None:
            raise ValueError("Caption profiles cannot contain ranking or header values.")
        return self
