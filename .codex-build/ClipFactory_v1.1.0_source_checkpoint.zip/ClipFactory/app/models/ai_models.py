"""Structured AI inputs, outputs, and accounting records."""

from __future__ import annotations

from datetime import datetime

from pydantic import Field, field_validator

from app.models.base import StrictModel, utc_now


class AIFieldPermissions(StrictModel):
    allow_header_text: bool = True
    allow_ranking_captions: bool = True
    allow_clip_reordering: bool = False
    allow_trim_suggestions: bool = True
    allow_upload_title: bool = True
    allow_upload_description: bool = True
    allow_upload_tags: bool = True
    allow_transition_selection: bool = False
    allow_style_changes: bool = False
    allow_duration_rule_changes: bool = False


class ClipAnalysisResult(StrictModel):
    clip_id: str
    summary: str
    detected_theme: str
    usable: bool
    topic_match_score: float = Field(ge=0, le=100)
    quality_score: float = Field(ge=0, le=100)
    hook_score: float = Field(ge=0, le=100)
    ranking_caption: str
    suggested_trim_start_seconds: float = Field(0, ge=0)
    suggested_trim_end_seconds: float | None = Field(default=None, ge=0)
    contains_watermark: bool = False
    contains_embedded_text: bool = False
    contains_sensitive_content: bool = False
    rejection_reasons: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)

    @field_validator("ranking_caption")
    @classmethod
    def reject_ranking_number_prefix(cls, value: str) -> str:
        stripped = value.strip()
        lowered = stripped.lower()
        if lowered.startswith(
            (
                "#1",
                "#2",
                "#3",
                "#4",
                "#5",
                "number 1",
                "number 2",
                "number 3",
                "number 4",
                "number 5",
            )
        ):
            raise ValueError("Ranking captions must not contain ranking numbers.")
        return stripped


class ProjectCreativeResult(StrictModel):
    header_text: str
    ranking_captions: list[str]
    recommended_clip_order: list[str]
    overall_theme: str
    upload_title_suggestions: list[str] = Field(default_factory=list)
    youtube_description: str = ""
    youtube_tags: list[str] = Field(default_factory=list)
    youtube_hashtags: list[str] = Field(default_factory=list)
    youtube_category_id_suggestion: str | None = None
    youtube_playlist_id_suggestion: str | None = None
    tiktok_caption: str = ""
    tiktok_hashtags: list[str] = Field(default_factory=list)
    tiktok_hook: str = ""
    tiktok_call_to_action: str = ""
    warnings: list[str] = Field(default_factory=list)


class FinalVideoReviewResult(StrictModel):
    approved: bool
    quality_score: float = Field(ge=0, le=100)
    hook_score: float = Field(ge=0, le=100)
    pacing_score: float = Field(ge=0, le=100)
    text_readability_score: float = Field(ge=0, le=100)
    audio_quality_score: float = Field(ge=0, le=100)
    blocking_issues: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    suggested_fixes: list[str] = Field(default_factory=list)


class AIRequestEstimate(StrictModel):
    provider: str
    model: str
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    audio_input_tokens: int = Field(0, ge=0)
    video_seconds: float = Field(0, ge=0)
    estimated_cost_usd: float = Field(ge=0)


class AIUsageRecord(StrictModel):
    id: str
    provider: str
    model: str
    operation: str
    job_id: str | None = None
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    audio_input_tokens: int = Field(0, ge=0)
    cached_tokens: int = Field(0, ge=0)
    video_seconds: float = Field(0, ge=0)
    cost_usd: float = Field(ge=0)
    created_at: datetime = Field(default_factory=utc_now)
