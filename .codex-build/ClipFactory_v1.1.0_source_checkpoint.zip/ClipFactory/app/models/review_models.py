"""Review queue contracts."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import Field

from app.models.ai_models import FinalVideoReviewResult
from app.models.base import EntityModel
from app.models.media_models import TechnicalValidationResult


class ReviewStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXCLUDED = "excluded"


class ReviewItem(EntityModel):
    production_job_id: str
    project_id: str
    video_path: str
    filename: str
    duration_seconds: float
    platform: str
    channel_id: str | None = None
    preset_id: str
    design_profile_id: str | None = None
    header: str
    clip_ids: list[str] = Field(default_factory=list)
    ranking_captions: list[str] = Field(default_factory=list)
    upload_metadata: dict[str, object] = Field(default_factory=dict)
    scheduled_at: datetime | None = None
    technical_validation: TechnicalValidationResult
    ai_review: FinalVideoReviewResult | None = None
    estimated_ai_cost_usd: float = 0
    actual_ai_cost_usd: float = 0
    status: ReviewStatus = ReviewStatus.PENDING
    rejection_reason: str | None = None
    needs_rerender: bool = False
    manual_override_note: str | None = None
    rights_review_required: bool = False
    rights_approved: bool = False
    source_rights: list[dict[str, str]] = Field(default_factory=list)
    theme: str = ""
    language: str = "en"
    ai_original_header: str = ""
    ai_original_ranking_captions: list[str] = Field(default_factory=list)
    ai_original_upload_metadata: dict[str, object] = Field(default_factory=dict)
    review_preset_payload: dict[str, object] | None = None
