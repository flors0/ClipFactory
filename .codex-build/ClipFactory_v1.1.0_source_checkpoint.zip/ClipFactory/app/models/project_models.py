"""Project planning and clip selection contracts."""

from __future__ import annotations

from pydantic import Field, model_validator

from app.models.base import EntityModel, StrictModel
from app.models.source_models import SourceProfile


class QualityThresholds(StrictModel):
    minimum_topic_score: float = Field(60, ge=0, le=100)
    minimum_quality_score: float = Field(60, ge=0, le=100)
    minimum_hook_score: float = Field(50, ge=0, le=100)
    allow_quality_fallback: bool = True
    minimum_fallback_score: float = Field(35, ge=0, le=100)
    reject_sensitive_content: bool = True
    reject_watermark: bool = True
    reject_embedded_text: bool = False
    allow_unknown_rights: bool = True
    minimum_clip_count: int = Field(2, ge=1)
    maximum_clip_count: int = Field(10, ge=1)
    minimum_individual_clip_seconds: float = Field(2, gt=0)
    maximum_individual_clip_seconds: float = Field(30, gt=0)
    avoid_duplicate_posts: bool = True
    avoid_duplicate_media: bool = True
    avoid_previously_used_clips: bool = True

    @model_validator(mode="after")
    def validate_ranges(self) -> QualityThresholds:
        if self.minimum_clip_count > self.maximum_clip_count:
            raise ValueError("Minimum clip count cannot exceed maximum clip count.")
        if self.minimum_individual_clip_seconds > self.maximum_individual_clip_seconds:
            raise ValueError("Minimum clip duration cannot exceed maximum clip duration.")
        return self


class SourceProjectPlan(EntityModel):
    project_id: str
    source_profile: SourceProfile
    preset_id: str
    target_platform: str
    video_format: str
    preliminary_theme: str
    refined_theme: str | None = None
    candidate_ids: list[str] = Field(default_factory=list)
    target_video_count: int = Field(1, ge=1)
    target_duration: float = Field(65, gt=0)
    quality_thresholds: QualityThresholds = Field(default_factory=QualityThresholds)
    warnings: list[str] = Field(default_factory=list)
    project_overrides: dict[str, object] = Field(default_factory=dict)


class SelectedClip(StrictModel):
    clip_id: str
    candidate_id: str
    media_path: str
    media_fingerprint: str
    source_url: str
    start_seconds: float = Field(0, ge=0)
    end_seconds: float = Field(gt=0)
    caption: str
    rank: int = Field(ge=1)
    analysis_score: float = Field(ge=0, le=100)

    @property
    def duration_seconds(self) -> float:
        return self.end_seconds - self.start_seconds


class ClipSelectionResult(StrictModel):
    selected: list[SelectedClip]
    total_duration_seconds: float = Field(ge=0)
    target_met: bool
    rejected_clip_ids: list[str] = Field(default_factory=list)
    rejection_reasons: dict[str, list[str]] = Field(default_factory=dict)
    fallback_clip_ids: list[str] = Field(default_factory=list)
    repaired_trim_clip_ids: list[str] = Field(default_factory=list)
    extended_trim_clip_ids: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
