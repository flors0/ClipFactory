"""Schedule templates and missed-job decisions."""

from __future__ import annotations

from datetime import datetime, time
from enum import StrEnum

from pydantic import Field, model_validator

from app.models.base import EntityModel, StrictModel


class MissedJobPolicy(StrEnum):
    SKIP = "skip"
    UPLOAD_IMMEDIATELY = "upload_immediately"
    SHIFT_REMAINING = "shift_remaining"
    ASK = "ask"


class ScheduleTemplate(EntityModel):
    name: str
    timezone: str = "Europe/Berlin"
    daily_times: list[time] = Field(default_factory=list)
    weekdays: list[int] = Field(default_factory=lambda: list(range(7)))
    missed_job_policy: MissedJobPolicy = MissedJobPolicy.ASK

    @model_validator(mode="after")
    def validate_weekdays(self) -> ScheduleTemplate:
        if any(day < 0 or day > 6 for day in self.weekdays):
            raise ValueError("Weekdays must be in the range 0 through 6.")
        return self


class ScheduleRequest(StrictModel):
    timezone: str
    count: int = Field(ge=1)
    explicit_times: list[datetime] = Field(default_factory=list)
    start_at: datetime | None = None
    interval_hours: float | None = Field(default=None, gt=0)

    @model_validator(mode="after")
    def validate_mode(self) -> ScheduleRequest:
        explicit = bool(self.explicit_times)
        interval = self.start_at is not None and self.interval_hours is not None
        if explicit == interval:
            raise ValueError("Choose exactly one scheduling mode.")
        if explicit and len(self.explicit_times) != self.count:
            raise ValueError("Explicit schedule count does not match requested count.")
        return self
