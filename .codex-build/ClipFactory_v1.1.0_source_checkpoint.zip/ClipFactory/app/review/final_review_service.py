"""Run deterministic checks before optional AI final-video review."""

from __future__ import annotations

from pathlib import Path

from app.ai.analysis_service import AnalysisService
from app.ai.prompt_builder import PromptBuilder
from app.media.media_probe import MediaProbe
from app.media.technical_validator import TechnicalValidator
from app.models.ai_models import AIFieldPermissions, FinalVideoReviewResult
from app.models.media_models import TechnicalValidationResult
from app.models.preset_models import DurationEnforcement, Preset


class FinalReviewService:
    def __init__(
        self,
        probe: MediaProbe,
        validator: TechnicalValidator,
        analysis_service: AnalysisService | None,
        prompt_builder: PromptBuilder,
        *,
        ai_enabled: bool,
        expected_video_codec: callable | None = None,
        expected_audio_codec: callable | None = None,
    ):
        self.probe = probe
        self.validator = validator
        self.analysis_service = analysis_service
        self.prompt_builder = prompt_builder
        self.ai_enabled = ai_enabled
        self.expected_video_codec = expected_video_codec or (
            lambda preset: preset.encoding.video_codec
        )
        self.expected_audio_codec = expected_audio_codec or (
            lambda preset: preset.encoding.audio_codec
        )

    def review(
        self,
        video_path: Path,
        preset: Preset,
        *,
        theme: str,
        platform: str,
        job_id: str,
        deep_scan: bool = True,
    ) -> tuple[TechnicalValidationResult, FinalVideoReviewResult | None, list[str]]:
        technical = self.validator.validate(
            video_path,
            expected_width=preset.width,
            expected_height=preset.height,
            expected_fps=preset.fps,
            minimum_duration=preset.duration.minimum_seconds,
            maximum_duration=preset.duration.maximum_seconds,
            duration_blocking=preset.duration.enforcement != DurationEnforcement.WARN,
            expect_audio=True,
            deep_scan=deep_scan,
            expected_video_codec=self._probe_video_codec(self.expected_video_codec(preset)),
            expected_audio_codec=self._probe_audio_codec(self.expected_audio_codec(preset)),
        )
        if not technical.passed or not self.ai_enabled or not self.analysis_service:
            return technical, None, []
        info = self.probe.probe(video_path)
        prompt = self.prompt_builder.final_review(
            theme=theme,
            platform=platform,
            duration_seconds=info.duration_seconds,
        )
        ai_review, _cached, warnings = self.analysis_service.review_final_video(
            video_path,
            info,
            theme=theme,
            platform=platform,
            prompt=prompt,
            preset_id=preset.id,
            permissions=AIFieldPermissions(),
            job_id=job_id,
        )
        return technical, ai_review, warnings

    @staticmethod
    def _probe_video_codec(value: str) -> str:
        lowered = value.lower()
        if "264" in lowered or lowered in {"avc", "avc1"}:
            return "h264"
        if "265" in lowered or "hevc" in lowered:
            return "hevc"
        return lowered.removeprefix("lib")

    @staticmethod
    def _probe_audio_codec(value: str) -> str:
        return value.lower().removeprefix("lib")
