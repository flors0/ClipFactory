"""Persistent user approval gate between rendering and upload creation."""

from __future__ import annotations

from datetime import UTC, datetime

from app.ai.adaptive_preferences import AdaptivePreferenceService
from app.models.preset_models import Preset
from app.models.render_models import ProductionStatus
from app.models.review_models import ReviewItem, ReviewStatus
from app.storage.repositories.job_repository import ProductionJobRepository, ReviewRepository


class ReviewQueue:
    def __init__(
        self,
        repository: ReviewRepository,
        jobs: ProductionJobRepository,
        preferences: AdaptivePreferenceService | None = None,
    ):
        self.repository = repository
        self.jobs = jobs
        self.preferences = preferences

    def add(self, item: ReviewItem) -> ReviewItem:
        if not item.technical_validation.passed:
            raise ValueError(
                "A video with blocking technical failures cannot enter the approval queue."
            )
        existing = self.repository.get_by_production_job(item.production_job_id)
        if existing:
            item.id = existing.id
            item.created_at = existing.created_at
            if existing.clip_ids == item.clip_ids and existing.source_rights == item.source_rights:
                item.rights_approved = existing.rights_approved
            if existing.ai_original_header:
                item.ai_original_header = existing.ai_original_header
            if existing.ai_original_ranking_captions:
                item.ai_original_ranking_captions = existing.ai_original_ranking_captions
            if existing.ai_original_upload_metadata:
                item.ai_original_upload_metadata = existing.ai_original_upload_metadata
            if existing.review_preset_payload:
                item.review_preset_payload = existing.review_preset_payload
                item.design_profile_id = existing.design_profile_id
        item.status = ReviewStatus.PENDING
        item.rejection_reason = None
        item.manual_override_note = None
        saved = self.repository.save(item)
        job = self.jobs.get(item.production_job_id)
        if job:
            job.status = ProductionStatus.AWAITING_REVIEW
            job.progress = 100
            job.current_step = "Awaiting manual review"
            self.jobs.save(job)
        return saved

    def approve(self, identifier: str, *, override_ai_block: bool = False) -> ReviewItem:
        item = self._required(identifier)
        if item.needs_rerender:
            raise ValueError("Editorial video-text changes must be re-rendered before approval.")
        if item.rights_review_required and not item.rights_approved:
            raise ValueError("Manual source-rights review must be confirmed before approval.")
        if not item.technical_validation.passed:
            raise ValueError("Technical validation must pass before approval.")
        if item.ai_review and not item.ai_review.approved and not override_ai_block:
            raise ValueError(
                "AI review reported blocking issues. Re-render or use an explicit manual override."
            )
        item.status = ReviewStatus.APPROVED
        if item.ai_review and not item.ai_review.approved and override_ai_block:
            item.manual_override_note = "AI blocking issues were explicitly overridden by the user."
        self.repository.save(item)
        job = self.jobs.get(item.production_job_id)
        if job:
            job.status = ProductionStatus.APPROVED
            job.current_step = "Approved for upload batch"
            self.jobs.save(job)
        return item

    def reject(self, identifier: str, reason: str) -> ReviewItem:
        item = self._required(identifier)
        item.status = ReviewStatus.REJECTED
        item.rejection_reason = reason.strip() or "Rejected during manual review"
        self.repository.save(item)
        job = self.jobs.get(item.production_job_id)
        if job:
            job.status = ProductionStatus.REJECTED
            job.current_step = "Rejected during review"
            self.jobs.save(job)
        return item

    def exclude(self, identifier: str) -> ReviewItem:
        item = self._required(identifier)
        item.status = ReviewStatus.EXCLUDED
        self.repository.save(item)
        job = self.jobs.get(item.production_job_id)
        if job and job.status not in {ProductionStatus.PUBLISHED, ProductionStatus.UPLOADING}:
            job.status = ProductionStatus.REJECTED
            job.current_step = "Excluded from upload during review"
            self.jobs.save(job, validate_transition=False)
        return item

    def update_metadata(
        self,
        identifier: str,
        metadata: dict[str, object],
        *,
        learn: bool = True,
    ) -> ReviewItem:
        item = self._required(identifier)
        if not item.ai_original_upload_metadata:
            item.ai_original_upload_metadata = dict(item.upload_metadata)
        if self.preferences:
            self.preferences.capture_metadata(item, metadata, learn=learn)
        item.upload_metadata = metadata
        item.updated_at = datetime.now(UTC)
        return self.repository.save(item)

    def update_schedule(self, identifier: str, scheduled_at: datetime) -> ReviewItem:
        if scheduled_at.tzinfo is None:
            raise ValueError("Scheduled upload time must include a timezone.")
        item = self._required(identifier)
        item.scheduled_at = scheduled_at
        return self.repository.save(item)

    def confirm_rights_review(self, identifier: str, *, confirmed: bool) -> ReviewItem:
        item = self._required(identifier)
        item.rights_approved = confirmed or not item.rights_review_required
        return self.repository.save(item)

    def update_editorial_copy(
        self,
        identifier: str,
        *,
        header: str,
        captions: list[str],
        learn: bool = True,
    ) -> ReviewItem:
        item = self._required(identifier)
        if len(captions) != len(item.ranking_captions):
            raise ValueError("Edited caption count must match the rendered clip count.")
        normalized_header = header.strip()
        normalized_captions = [value.strip() for value in captions]
        if not item.ai_original_header:
            item.ai_original_header = item.header
        if not item.ai_original_ranking_captions:
            item.ai_original_ranking_captions = list(item.ranking_captions)
        if self.preferences:
            self.preferences.capture_editorial_copy(
                item,
                header=normalized_header,
                captions=normalized_captions,
                learn=learn,
            )
        if normalized_header != item.header or normalized_captions != item.ranking_captions:
            item.needs_rerender = True
            item.status = ReviewStatus.PENDING
        item.header = normalized_header
        item.ranking_captions = normalized_captions
        return self.repository.save(item)

    def update_visual_preset(
        self,
        identifier: str,
        *,
        preset: Preset,
        design_profile_id: str | None,
    ) -> ReviewItem:
        item = self._required(identifier)
        payload = preset.model_dump(mode="json")
        if payload != item.review_preset_payload or design_profile_id != item.design_profile_id:
            item.needs_rerender = True
            item.status = ReviewStatus.PENDING
        item.review_preset_payload = payload
        item.design_profile_id = design_profile_id
        item.updated_at = datetime.now(UTC)
        return self.repository.save(item)

    def approve_all_passed(self) -> list[ReviewItem]:
        approved: list[ReviewItem] = []
        for item in self.repository.list(ReviewStatus.PENDING.value):
            if (
                not item.needs_rerender
                and (not item.rights_review_required or item.rights_approved)
                and item.technical_validation.passed
                and (not item.ai_review or item.ai_review.approved)
            ):
                approved.append(self.approve(item.id))
        return approved

    def _required(self, identifier: str) -> ReviewItem:
        item = self.repository.get(identifier)
        if not item:
            raise KeyError(f"Review item does not exist: {identifier}")
        return item
