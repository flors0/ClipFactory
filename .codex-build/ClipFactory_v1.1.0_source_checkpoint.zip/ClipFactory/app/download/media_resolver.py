"""Resolve supported post URLs with yt-dlp without downloading."""

from __future__ import annotations

from dataclasses import dataclass

from yt_dlp import YoutubeDL
from yt_dlp.utils import DownloadError as YtDlpDownloadError

from app.core.exceptions import DownloadError


@dataclass(frozen=True, slots=True)
class ResolvedMedia:
    webpage_url: str
    direct_url: str | None
    extractor: str
    title: str
    duration: float | None
    extension: str | None
    has_audio: bool | None


class MediaResolver:
    def resolve(self, url: str) -> ResolvedMedia:
        options = {
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
            "noplaylist": True,
            "socket_timeout": 30,
        }
        try:
            with YoutubeDL(options) as ydl:
                info = ydl.extract_info(url, download=False)
                if info and info.get("entries"):
                    info = next((entry for entry in info["entries"] if entry), None)
        except YtDlpDownloadError as error:
            raise DownloadError(f"yt-dlp could not resolve the source: {error}") from error
        if not info:
            raise DownloadError("yt-dlp returned no media information.")
        formats = info.get("formats") or []
        has_audio = any(format_info.get("acodec") not in {None, "none"} for format_info in formats)
        return ResolvedMedia(
            webpage_url=str(info.get("webpage_url") or url),
            direct_url=info.get("url"),
            extractor=str(info.get("extractor_key") or info.get("extractor") or "unknown"),
            title=str(info.get("title") or "Untitled"),
            duration=float(info["duration"]) if info.get("duration") is not None else None,
            extension=info.get("ext"),
            has_audio=has_audio if formats else None,
        )
