"""Cancelable, atomic yt-dlp downloader with URL and hash reuse."""

from __future__ import annotations

import ipaddress
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
from collections.abc import Callable, Sequence
from pathlib import Path
from threading import Event
from urllib.parse import unquote, urlparse
from uuid import uuid4

import httpx

from app.core.exceptions import CancelledError, DownloadError
from app.download.download_cache import DownloadCache, file_sha256
from app.download.reddit_media import (
    is_allowed_reddit_media_url,
    select_reddit_media_streams,
)
from app.models.media_models import DownloadedMedia
from app.models.source_models import SourceCandidate

PROGRESS_PATTERN = re.compile(r"\[download\]\s+(\d+(?:\.\d+)?)%")


def safe_stem(value: str, maximum: int = 80) -> str:
    normalized = re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip(".-_")
    return (normalized or "media")[:maximum]


class MediaDownloader:
    def __init__(
        self,
        cache: DownloadCache,
        download_directory: Path,
        temporary_directory: Path,
        *,
        ytdlp_path: str | None = None,
        ffmpeg_path: str = "ffmpeg",
        timeout_seconds: float = 900,
        retry_count: int = 3,
        max_height: int = 1080,
        http_client: httpx.Client | None = None,
    ):
        self.cache = cache
        self.download_directory = download_directory.resolve()
        self.temporary_directory = temporary_directory.resolve()
        self.ytdlp_path = ytdlp_path
        self.ffmpeg_path = ffmpeg_path
        self.timeout_seconds = timeout_seconds
        self.retry_count = retry_count
        self.max_height = max_height
        self.http_client = http_client or httpx.Client(
            timeout=httpx.Timeout(timeout_seconds, connect=30),
            follow_redirects=True,
            headers={"Accept": "*/*", "User-Agent": "ClipFactory/1.1.0"},
        )
        self.download_directory.mkdir(parents=True, exist_ok=True)
        self.temporary_directory.mkdir(parents=True, exist_ok=True)

    def download(
        self,
        candidate: SourceCandidate,
        *,
        cancel_event: Event | None = None,
        progress_callback: Callable[[int, str], None] | None = None,
    ) -> DownloadedMedia:
        cancel_event = cancel_event or Event()
        progress_callback = progress_callback or (lambda _value, _message: None)
        source_url = candidate.media_url or candidate.post_url
        reddit_metadata = candidate.raw_metadata.get("reddit_media")
        if not isinstance(reddit_metadata, dict):
            reddit_metadata = None
        cache_url = (
            str(reddit_metadata.get("cache_key") or source_url) if reddit_metadata else source_url
        )
        cached = self.cache.get(cache_url)
        if cached:
            path, fingerprint = cached
            progress_callback(100, "Reused cached download")
            return DownloadedMedia(
                candidate_id=candidate.post_id,
                source_url=cache_url,
                file_path=str(path),
                file_fingerprint=fingerprint,
                from_cache=True,
            )
        parsed = urlparse(source_url)
        if parsed.scheme == "file":
            if candidate.raw_metadata.get("source") != "mock":
                raise DownloadError(
                    "Local file URLs are allowed only for the explicit mock source provider."
                )
            return self._copy_local_fixture(candidate, Path(unquote(parsed.path)), source_url)
        self._validate_remote_url(parsed)
        last_error = ""
        for attempt in range(self.retry_count + 1):
            if cancel_event.is_set():
                raise CancelledError("Media download was cancelled.")
            try:
                if reddit_metadata:
                    return self._download_reddit_once(
                        candidate,
                        reddit_metadata,
                        cache_url,
                        cancel_event,
                        progress_callback,
                    )
                return self._download_once(candidate, source_url, cancel_event, progress_callback)
            except CancelledError:
                raise
            except DownloadError as error:
                last_error = str(error)
                if attempt < self.retry_count and cancel_event.wait(min(2**attempt, 10)):
                    raise CancelledError("Media download was cancelled.") from error
        raise DownloadError(f"Download failed after retries: {last_error}")

    def _download_reddit_once(
        self,
        candidate: SourceCandidate,
        metadata: dict[str, object],
        cache_url: str,
        cancel_event: Event,
        progress_callback: Callable[[int, str], None],
    ) -> DownloadedMedia:
        dash_url = str(metadata.get("dash_url") or "")
        hls_url = str(metadata.get("hls_url") or "")
        if not is_allowed_reddit_media_url(dash_url):
            if is_allowed_reddit_media_url(hls_url):
                return self._download_once(
                    candidate,
                    hls_url,
                    cancel_event,
                    progress_callback,
                    cache_url=cache_url,
                )
            raise DownloadError("Reddit candidate contains no supported DASH or HLS URL.")

        token = uuid4().hex
        video_part = self.temporary_directory / f"reddit-video-{token}.mp4"
        audio_part = self.temporary_directory / f"reddit-audio-{token}.m4a"
        muxed_part = self.temporary_directory / f"reddit-muxed-{token}.mp4"
        try:
            manifest = self._download_small_document(dash_url, cancel_event)
            streams = select_reddit_media_streams(
                metadata,
                manifest,
                dash_url,
                max_short_edge=self.max_height,
            )
            self._download_http_asset(
                streams.video_url,
                video_part,
                cancel_event,
                progress_callback,
                progress_start=0,
                progress_end=78 if streams.audio_url else 94,
                label="Downloading Reddit video",
            )
            if streams.audio_url:
                self._download_http_asset(
                    streams.audio_url,
                    audio_part,
                    cancel_event,
                    progress_callback,
                    progress_start=78,
                    progress_end=94,
                    label="Downloading original Reddit audio",
                )
                self._mux_reddit_streams(video_part, audio_part, muxed_part, cancel_event)
            else:
                os.replace(video_part, muxed_part)
            destination = (
                self.download_directory / f"{safe_stem(candidate.post_id)}-{token[:10]}.mp4"
            )
            os.replace(muxed_part, destination)
            destination, fingerprint = self._deduplicate(cache_url, destination)
            progress_callback(100, "Reddit video and original audio ready")
            return DownloadedMedia(
                candidate_id=candidate.post_id,
                source_url=cache_url,
                file_path=str(destination),
                file_fingerprint=fingerprint,
                from_cache=False,
                extractor="arctic_shift_direct",
                title=candidate.title,
            )
        except CancelledError:
            raise
        except DownloadError as direct_error:
            if is_allowed_reddit_media_url(hls_url):
                progress_callback(0, "Direct Reddit mux failed; trying HLS fallback")
                return self._download_once(
                    candidate,
                    hls_url,
                    cancel_event,
                    progress_callback,
                    cache_url=cache_url,
                )
            raise direct_error
        finally:
            for path in (video_part, audio_part, muxed_part):
                path.unlink(missing_ok=True)

    def _download_small_document(self, url: str, cancel_event: Event) -> bytes:
        if cancel_event.is_set():
            raise CancelledError("Media download was cancelled.")
        try:
            response = self.http_client.get(url)
        except httpx.HTTPError as error:
            raise DownloadError(f"Reddit DASH manifest request failed: {error}") from error
        self._validate_reddit_response(response)
        if len(response.content) > 2_000_000:
            raise DownloadError("Reddit DASH manifest exceeded the safety limit.")
        return response.content

    def _download_http_asset(
        self,
        url: str,
        destination: Path,
        cancel_event: Event,
        progress_callback: Callable[[int, str], None],
        *,
        progress_start: int,
        progress_end: int,
        label: str,
    ) -> None:
        if not is_allowed_reddit_media_url(url):
            raise DownloadError("Reddit media URL uses an unsupported host.")
        downloaded = 0
        maximum_bytes = 2 * 1024 * 1024 * 1024
        try:
            with self.http_client.stream("GET", url) as response:
                self._validate_reddit_response(response)
                try:
                    total = int(response.headers.get("Content-Length", "0"))
                except ValueError:
                    total = 0
                if total > maximum_bytes:
                    raise DownloadError("Reddit media exceeds the 2 GiB safety limit.")
                with destination.open("wb") as stream:
                    for chunk in response.iter_bytes(1024 * 1024):
                        if cancel_event.is_set():
                            raise CancelledError("Media download was cancelled.")
                        downloaded += len(chunk)
                        if downloaded > maximum_bytes:
                            raise DownloadError("Reddit media exceeds the 2 GiB safety limit.")
                        stream.write(chunk)
                        if total:
                            fraction = min(1.0, downloaded / total)
                            progress_callback(
                                progress_start + round((progress_end - progress_start) * fraction),
                                label,
                            )
        except (CancelledError, DownloadError):
            raise
        except httpx.HTTPError as error:
            raise DownloadError(f"Reddit media request failed: {error}") from error
        if downloaded <= 0:
            raise DownloadError("Reddit media response was empty.")

    @staticmethod
    def _validate_reddit_response(response: httpx.Response) -> None:
        if response.status_code >= 400:
            raise DownloadError(f"Reddit media CDN returned HTTP {response.status_code}.")
        if not is_allowed_reddit_media_url(str(response.url)):
            raise DownloadError("Reddit media request redirected to an unsupported host.")

    def _mux_reddit_streams(
        self,
        video_path: Path,
        audio_path: Path,
        output_path: Path,
        cancel_event: Event,
    ) -> None:
        command = [
            self.ffmpeg_path,
            "-v",
            "error",
            "-y",
            "-i",
            str(video_path),
            "-i",
            str(audio_path),
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-c:v",
            "copy",
            "-c:a",
            "copy",
            "-shortest",
            "-movflags",
            "+faststart",
            str(output_path),
        ]
        creation_flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creation_flags,
        )
        started = time.monotonic()
        while process.poll() is None:
            if cancel_event.is_set():
                self._terminate(process)
                raise CancelledError("Media download was cancelled during Reddit muxing.")
            if time.monotonic() - started > self.timeout_seconds:
                self._terminate(process)
                raise DownloadError("Reddit audio/video mux timed out.")
            cancel_event.wait(0.1)
        _stdout, stderr = process.communicate()
        if process.returncode or not output_path.is_file() or output_path.stat().st_size <= 0:
            raise DownloadError(f"Reddit audio/video mux failed: {stderr[-800:]}")

    def _copy_local_fixture(
        self, candidate: SourceCandidate, source: Path, source_url: str
    ) -> DownloadedMedia:
        source = source.resolve()
        if not source.is_file():
            raise DownloadError("Mock fixture media does not exist.")
        extension = source.suffix.lower() or ".mp4"
        destination = (
            self.download_directory
            / f"{safe_stem(candidate.post_id)}-{source.stat().st_size}{extension}"
        )
        temporary = self.temporary_directory / f"copy-{uuid4().hex}{extension}.part"
        shutil.copy2(source, temporary)
        os.replace(temporary, destination)
        destination, fingerprint = self._deduplicate(source_url, destination)
        return DownloadedMedia(
            candidate_id=candidate.post_id,
            source_url=source_url,
            file_path=str(destination),
            file_fingerprint=fingerprint,
            from_cache=False,
            extractor="local_fixture",
            title=candidate.title,
        )

    def _download_once(
        self,
        candidate: SourceCandidate,
        source_url: str,
        cancel_event: Event,
        progress_callback: Callable[[int, str], None],
        *,
        cache_url: str | None = None,
    ) -> DownloadedMedia:
        token = uuid4().hex
        output_template = str(
            self.temporary_directory / f"{safe_stem(candidate.post_id)}-{token}.%(ext)s"
        )
        command = [
            *self._executable(),
            "--no-playlist",
            "--newline",
            "--no-part",
            "--retries",
            "3",
            "--fragment-retries",
            "3",
            "--socket-timeout",
            "30",
            "--merge-output-format",
            "mp4",
            "--format",
            (f"bv*[height<={self.max_height}]+ba/b[height<={self.max_height}]/bv*+ba/b"),
            "--ffmpeg-location",
            self.ffmpeg_path,
            "--output",
            output_template,
            "--print",
            "after_move:filepath",
            source_url,
        ]
        creation_flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creation_flags,
        )
        lines: queue.Queue[str | None] = queue.Queue()

        def reader() -> None:
            assert process.stdout is not None
            for line in process.stdout:
                lines.put(line.rstrip())
            lines.put(None)

        threading.Thread(target=reader, daemon=True).start()
        started = time.monotonic()
        output_lines: list[str] = []
        final_path: Path | None = None
        stream_done = False
        while process.poll() is None or not stream_done:
            if cancel_event.is_set():
                self._terminate(process)
                self._cleanup_token(token)
                raise CancelledError("Media download was cancelled.")
            if time.monotonic() - started > self.timeout_seconds:
                self._terminate(process)
                self._cleanup_token(token)
                raise DownloadError("Media download timed out.")
            try:
                line = lines.get(timeout=0.2)
            except queue.Empty:
                continue
            if line is None:
                stream_done = True
                continue
            output_lines.append(line)
            match = PROGRESS_PATTERN.search(line)
            if match:
                progress_callback(min(99, int(float(match.group(1)))), "Downloading media")
            candidate_path = Path(line.strip())
            if candidate_path.is_file() and token in candidate_path.name:
                final_path = candidate_path
        return_code = process.wait()
        if return_code != 0:
            self._cleanup_token(token)
            detail = "\n".join(output_lines[-8:])
            raise DownloadError(f"yt-dlp exited with code {return_code}: {detail}")
        if final_path is None:
            matches = [
                path for path in self.temporary_directory.glob(f"*{token}*") if path.is_file()
            ]
            final_path = max(matches, key=lambda path: path.stat().st_mtime) if matches else None
        if final_path is None or final_path.stat().st_size <= 0:
            self._cleanup_token(token)
            raise DownloadError("yt-dlp produced no non-empty media file.")
        extension = final_path.suffix.lower() or ".mp4"
        destination = (
            self.download_directory / f"{safe_stem(candidate.post_id)}-{token[:10]}{extension}"
        )
        os.replace(final_path, destination)
        effective_cache_url = cache_url or source_url
        destination, fingerprint = self._deduplicate(effective_cache_url, destination)
        progress_callback(100, "Download completed")
        return DownloadedMedia(
            candidate_id=candidate.post_id,
            source_url=effective_cache_url,
            file_path=str(destination),
            file_fingerprint=fingerprint,
            from_cache=False,
            title=candidate.title,
        )

    def _executable(self) -> Sequence[str]:
        if self.ytdlp_path:
            return [self.ytdlp_path]
        if getattr(sys, "frozen", False):
            return [sys.executable, "--yt-dlp-worker"]
        return [sys.executable, "-m", "yt_dlp"]

    def _deduplicate(self, source_url: str, destination: Path) -> tuple[Path, str]:
        fingerprint = file_sha256(destination)
        existing = self.cache.find_by_fingerprint(fingerprint)
        if existing and existing != destination.resolve():
            destination.unlink(missing_ok=True)
            destination = existing
        return destination, self.cache.put(source_url, destination)

    @staticmethod
    def _validate_remote_url(parsed) -> None:
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise DownloadError("Media source must use a valid HTTP or HTTPS URL.")
        if parsed.username or parsed.password:
            raise DownloadError("Media source URLs containing user information are rejected.")
        hostname = parsed.hostname.rstrip(".").casefold()
        if (
            hostname == "localhost"
            or hostname.endswith(".localhost")
            or hostname.endswith(".local")
        ):
            raise DownloadError("Local-network media source URLs are rejected.")
        try:
            address = ipaddress.ip_address(hostname)
        except ValueError:
            return
        if not address.is_global:
            raise DownloadError(
                "Private, loopback, reserved, or link-local media URLs are rejected."
            )

    def _terminate(self, process: subprocess.Popen[str]) -> None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)

    def _cleanup_token(self, token: str) -> None:
        for path in self.temporary_directory.glob(f"*{token}*"):
            if path.is_file():
                path.unlink(missing_ok=True)
