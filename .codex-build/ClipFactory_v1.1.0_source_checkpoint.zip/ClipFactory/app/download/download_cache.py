"""Content-aware download cache."""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from pathlib import Path

from app.storage.database import Database


def file_sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def url_cache_key(url: str) -> str:
    return hashlib.sha256(url.strip().encode()).hexdigest()


class DownloadCache:
    def __init__(self, database: Database):
        self.database = database

    def get(self, source_url: str) -> tuple[Path, str] | None:
        row = self.database.fetchone(
            "SELECT file_path, file_fingerprint, file_size FROM download_cache WHERE source_url = ?",
            (source_url,),
        )
        if not row:
            return None
        path = Path(row["file_path"])
        if (
            not path.is_file()
            or path.stat().st_size != row["file_size"]
            or path.stat().st_size <= 0
        ):
            self.database.execute("DELETE FROM download_cache WHERE source_url = ?", (source_url,))
            return None
        fingerprint = file_sha256(path)
        if fingerprint != row["file_fingerprint"]:
            self.database.execute("DELETE FROM download_cache WHERE source_url = ?", (source_url,))
            return None
        self.database.execute(
            "UPDATE download_cache SET accessed_at = ? WHERE source_url = ?",
            (datetime.now(UTC).isoformat(), source_url),
        )
        return path, fingerprint

    def put(self, source_url: str, path: Path) -> str:
        resolved = path.resolve()
        if not resolved.is_file() or resolved.stat().st_size <= 0:
            raise ValueError("Only non-empty downloaded files can be cached.")
        fingerprint = file_sha256(resolved)
        now = datetime.now(UTC).isoformat()
        self.database.execute(
            "INSERT INTO download_cache(cache_key, source_url, file_path, file_fingerprint, file_size, created_at, accessed_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(cache_key) DO UPDATE SET file_path=excluded.file_path, "
            "file_fingerprint=excluded.file_fingerprint, file_size=excluded.file_size, accessed_at=excluded.accessed_at",
            (
                url_cache_key(source_url),
                source_url,
                str(resolved),
                fingerprint,
                resolved.stat().st_size,
                now,
                now,
            ),
        )
        return fingerprint

    def find_by_fingerprint(self, fingerprint: str) -> Path | None:
        rows = self.database.fetchall(
            "SELECT source_url, file_path, file_size FROM download_cache WHERE file_fingerprint = ? ORDER BY accessed_at DESC",
            (fingerprint,),
        )
        for row in rows:
            path = Path(row["file_path"])
            if (
                path.is_file()
                and path.stat().st_size == row["file_size"]
                and path.stat().st_size > 0
                and file_sha256(path) == fingerprint
            ):
                return path.resolve()
            self.database.execute(
                "DELETE FROM download_cache WHERE source_url = ?", (row["source_url"],)
            )
        return None

    def remove_missing(self) -> int:
        removed = 0
        for row in self.database.fetchall("SELECT source_url, file_path FROM download_cache"):
            if not Path(row["file_path"]).is_file():
                self.database.execute(
                    "DELETE FROM download_cache WHERE source_url = ?", (row["source_url"],)
                )
                removed += 1
        return removed
