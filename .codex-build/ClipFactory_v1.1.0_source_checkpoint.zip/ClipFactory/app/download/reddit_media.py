"""Select Reddit video and original-audio streams from a DASH manifest."""

from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urljoin, urlparse
from xml.etree import ElementTree

from app.core.exceptions import DownloadError


@dataclass(frozen=True, slots=True)
class RedditMediaStreams:
    video_url: str
    audio_url: str | None


def is_allowed_reddit_media_url(url: str) -> bool:
    parsed = urlparse(url)
    hostname = (parsed.hostname or "").casefold()
    return parsed.scheme == "https" and (
        hostname == "v.redd.it"
        or hostname == "packaged-media.redd.it"
        or hostname.endswith(".redditmedia.com")
    )


def select_reddit_media_streams(
    metadata: dict[str, object],
    manifest: bytes,
    manifest_url: str,
    *,
    max_short_edge: int,
) -> RedditMediaStreams:
    """Prefer the high-quality fallback video and the highest-bitrate original audio."""
    try:
        root = ElementTree.fromstring(manifest)
    except ElementTree.ParseError as error:
        raise DownloadError("Reddit DASH manifest is invalid XML.") from error

    videos: list[tuple[int, int, str]] = []
    audio: list[tuple[int, str]] = []
    for adaptation in root.iter():
        if _local_name(adaptation.tag) != "AdaptationSet":
            continue
        content_type = str(adaptation.attrib.get("contentType") or "").casefold()
        for representation in adaptation:
            if _local_name(representation.tag) != "Representation":
                continue
            base = next(
                (
                    child.text.strip()
                    for child in representation
                    if _local_name(child.tag) == "BaseURL" and child.text
                ),
                "",
            )
            if not base:
                continue
            stream_url = urljoin(manifest_url, base)
            if not is_allowed_reddit_media_url(stream_url):
                continue
            bandwidth = _integer(representation.attrib.get("bandwidth"))
            mime_type = str(representation.attrib.get("mimeType") or "").casefold()
            if content_type == "audio" or mime_type.startswith("audio/"):
                audio.append((bandwidth, stream_url))
                continue
            if content_type == "video" or mime_type.startswith("video/"):
                width = _integer(representation.attrib.get("width"))
                height = _integer(representation.attrib.get("height"))
                videos.append((min(width, height), bandwidth, stream_url))

    fallback = str(metadata.get("fallback_url") or "")
    fallback_width = _integer(metadata.get("width"))
    fallback_height = _integer(metadata.get("height"))
    fallback_short_edge = min(fallback_width, fallback_height)
    fallback_allowed = is_allowed_reddit_media_url(fallback) and (
        max_short_edge <= 0 or fallback_short_edge <= 0 or fallback_short_edge <= max_short_edge
    )
    if fallback_allowed:
        video_url = fallback
    else:
        eligible = [item for item in videos if max_short_edge <= 0 or item[0] <= max_short_edge]
        pool = eligible or videos
        if not pool:
            if is_allowed_reddit_media_url(fallback):
                video_url = fallback
            else:
                raise DownloadError("Reddit DASH manifest contains no supported video stream.")
        else:
            video_url = max(pool, key=lambda item: (item[0], item[1]))[2]

    has_audio = bool(metadata.get("has_audio"))
    audio_url = max(audio, key=lambda item: item[0])[1] if audio else None
    if has_audio and not audio_url:
        raise DownloadError("Reddit reports original audio, but DASH exposes no audio stream.")
    return RedditMediaStreams(video_url=video_url, audio_url=audio_url)


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _integer(value: object) -> int:
    try:
        return int(float(value)) if value is not None else 0
    except (TypeError, ValueError):
        return 0
