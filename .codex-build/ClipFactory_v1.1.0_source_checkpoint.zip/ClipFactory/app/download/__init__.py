"""Media resolution and download services."""
