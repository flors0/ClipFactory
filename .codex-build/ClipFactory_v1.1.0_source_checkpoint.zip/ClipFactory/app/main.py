"""ClipFactory entry point."""

from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path

from dotenv import load_dotenv

from app import __version__
from app.core.app_context import AppContext
from app.core.logging import configure_logging
from app.core.paths import AppPaths


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="ClipFactory desktop application")
    parser.add_argument("--version", action="store_true", help="Print the application version")
    parser.add_argument("--version-file", type=Path, help=argparse.SUPPRESS)
    parser.add_argument(
        "--scheduler-only",
        action="store_true",
        help="Run only the persistent local upload scheduler",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if arguments and arguments[0] == "--yt-dlp-worker":
        from yt_dlp import main as yt_dlp_main

        yt_dlp_main(arguments[1:])
        return 0
    args = parse_args(arguments)
    version_text = f"ClipFactory {__version__}"
    if args.version_file:
        args.version_file.parent.mkdir(parents=True, exist_ok=True)
        args.version_file.write_text(version_text + "\n", encoding="utf-8")
        return 0
    if args.version:
        if sys.stdout is not None:
            print(version_text)
        return 0
    paths = AppPaths.build()
    load_dotenv(paths.root / ".env", override=False)
    paths.ensure()
    configure_logging(paths.logs, "INFO")
    logger = logging.getLogger(__name__)
    try:
        context = AppContext.build(
            paths.root,
            recover_interrupted_production=not args.scheduler_only,
        )
        configure_logging(paths.logs, context.settings.log_level)
    except Exception:
        logger.exception("Application initialization failed")
        if not args.scheduler_only:
            try:
                from PySide6.QtWidgets import QApplication, QMessageBox

                application = QApplication.instance() or QApplication(sys.argv)
                QMessageBox.critical(
                    None,
                    "ClipFactory could not start",
                    "Initialization failed. See data/logs/clipfactory.log for details.",
                )
            except Exception:
                print(
                    "ClipFactory initialization failed. See data/logs/clipfactory.log for details.",
                    file=sys.stderr,
                )
        return 1
    if context.settings.upload.scheduler_auto_start or args.scheduler_only:
        context.scheduler.start()
    if args.scheduler_only:
        logger.info(
            "Scheduler-only mode started; keep this process running for local TikTok execution times"
        )
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            context.scheduler.stop()
            return 0
    from PySide6.QtWidgets import QApplication

    from app.ui.input_guard import install_numeric_wheel_guard
    from app.ui.main_window import MainWindow, apply_application_style

    application = QApplication(sys.argv)
    application.setApplicationName("ClipFactory")
    application.setApplicationVersion(__version__)
    application.setOrganizationName("ClipFactory")
    install_numeric_wheel_guard(application)
    apply_application_style(application, context.settings.theme)
    window = MainWindow(context)
    window.show()
    return application.exec()


if __name__ == "__main__":
    raise SystemExit(main())
