"""Persistent end-to-end production orchestration after explicit generation approval."""

from __future__ import annotations

import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from threading import Event

from app.ai.adaptive_preferences import AdaptivePreferenceService
from app.ai.analysis_service import AnalysisService
from app.ai.prompt_builder import PromptBuilder
from app.core.exceptions import AIProviderFatalError, CancelledError, ClipFactoryError
from app.core.logging import production_log_context, redact_text
from app.download.media_downloader import MediaDownloader
from app.media.media_probe import MediaProbe
from app.models.ai_models import ProjectCreativeResult
from app.models.channel_models import ChannelProfile
from app.models.preset_models import DurationEnforcement, ElementType, Preset
from app.models.render_models import ProductionJob, ProductionStatus, RenderPlan
from app.models.review_models import ReviewItem
from app.models.source_models import RightsMode
from app.models.upload_models import TikTokMetadata, YouTubeMetadata
from app.planning.batch_planner import BatchPlan, PlannedBatchItem
from app.planning.clip_selection_planner import (
    AnalyzedCandidate,
    ClipSelectionPlanner,
    UsedMediaHistory,
)
from app.planning.source_project_planner import SourceProjectPlanner
from app.presets.asset_library import AssetLibrary
from app.presets.preset_validator import PresetValidator
from app.render.ffmpeg_renderer import FFmpegRenderer
from app.render.render_plan import RenderPlanBuilder
from app.review.final_review_service import FinalReviewService
from app.review.review_queue import ReviewQueue
from app.sources.source_provider import SourceProvider
from app.storage.repositories.job_repository import ProductionJobRepository, ReviewRepository
from app.storage.repositories.json_repository import JsonRepository
from app.storage.repositories.preset_repository import PresetRepository

logger = logging.getLogger(__name__)


class CombinedCancellation:
    """Expose one Event-like token for a whole batch and one production job."""

    def __init__(self, batch_event: Event, job_event: Event):
        self.batch_event = batch_event
        self.job_event = job_event

    def is_set(self) -> bool:
        return self.batch_event.is_set() or self.job_event.is_set()

    def wait(self, timeout: float | None = None) -> bool:
        if self.is_set():
            return True
        if timeout is None:
            while not self.is_set():
                self.batch_event.wait(0.1)
            return True
        remaining = timeout
        while remaining > 0 and not self.is_set():
            interval = min(0.1, remaining)
            self.batch_event.wait(interval)
            remaining -= interval
        return self.is_set()


@dataclass(frozen=True, slots=True)
class ProductionOptions:
    maximum_analyses_per_video: int = 12
    maximum_ai_cost_per_job_usd: float | None = None
    render_parallelism: int = 1
    upload_parallelism: int = 1
    deep_technical_scan: bool = True


class BatchProductionService:
    def __init__(
        self,
        *,
        source_provider_factory: callable,
        analysis_service_factory: callable,
        prompt_builder: PromptBuilder,
        downloader: MediaDownloader,
        probe: MediaProbe,
        source_planner: SourceProjectPlanner,
        selection_planner: ClipSelectionPlanner,
        history: UsedMediaHistory,
        renderer: FFmpegRenderer,
        render_plan_builder: RenderPlanBuilder,
        final_review_factory: callable,
        review_queue: ReviewQueue,
        review_repository: ReviewRepository,
        job_repository: ProductionJobRepository,
        project_repository: JsonRepository,
        preset_repository: PresetRepository,
        asset_library: AssetLibrary,
        output_directory: Path,
        adaptive_preferences: AdaptivePreferenceService | None = None,
    ):
        self.source_provider_factory = source_provider_factory
        self.analysis_service_factory = analysis_service_factory
        self.prompt_builder = prompt_builder
        self.downloader = downloader
        self.probe = probe
        self.source_planner = source_planner
        self.selection_planner = selection_planner
        self.history = history
        self.renderer = renderer
        self.render_plan_builder = render_plan_builder
        self.final_review_factory = final_review_factory
        self.review_queue = review_queue
        self.review_repository = review_repository
        self.job_repository = job_repository
        self.project_repository = project_repository
        self.preset_repository = preset_repository
        self.asset_library = asset_library
        self.output_directory = output_directory.resolve()
        self.adaptive_preferences = adaptive_preferences
        self.output_directory.mkdir(parents=True, exist_ok=True)
        self._selection_lock = threading.Lock()
        self._batch_exclusions: dict[str, set[str]] = {}
        self._batch_titles: dict[str, set[str]] = {}
        self._batch_caption_keys: dict[str, set[str]] = {}
        self._batch_candidate_windows: dict[str, dict[str, tuple[int, int]]] = {}
        self._job_cancel_events: dict[str, Event] = {}

    def generate_batch(
        self,
        batch: BatchPlan,
        *,
        confirmed: bool,
        use_mock_ai: bool = False,
        use_mock_source: bool = False,
        options: ProductionOptions | None = None,
        cancel_event: Event | None = None,
        progress_callback: callable | None = None,
    ) -> list[ProductionJob]:
        if not confirmed:
            raise PermissionError(
                "Generate Batch confirmation is required before analysis or rendering."
            )
        options = options or ProductionOptions()
        cancel_event = cancel_event or Event()
        progress_callback = progress_callback or (lambda _value, _message: None)
        self._batch_exclusions[batch.id] = set()
        self._batch_titles[batch.id] = set()
        self._batch_caption_keys[batch.id] = set()
        source_counts: dict[str, int] = {}
        for item in batch.items:
            source_counts[item.source_profile.id] = source_counts.get(item.source_profile.id, 0) + 1
        source_offsets: dict[str, int] = {}
        candidate_windows: dict[str, tuple[int, int]] = {}
        for item in batch.items:
            source_id = item.source_profile.id
            ordinal = source_offsets.get(source_id, 0)
            source_offsets[source_id] = ordinal + 1
            pool_limit = min(
                200,
                max(
                    item.source_profile.candidate_limit,
                    source_counts[source_id] * options.maximum_analyses_per_video,
                ),
            )
            candidate_windows[item.job.id] = (ordinal, pool_limit)
        self._batch_candidate_windows[batch.id] = candidate_windows
        for item in batch.items:
            if not self.project_repository.get(item.project_id):
                self.project_repository.save(
                    self.source_planner.seed_plan(
                        item.source_profile,
                        item.preset,
                        project_id=item.project_id,
                        thresholds=batch.quality_thresholds,
                        target_platform=item.target_platform,
                    )
                )
            item.job.estimated_ai_cost_usd = round(
                batch.estimated_ai_cost_usd / max(1, len(batch.items)), 6
            )
            item.job.batch_id = batch.id
            item.job.use_mock_ai = use_mock_ai
            item.job.use_mock_source = use_mock_source
            item.job.production_options = {
                "maximum_analyses_per_video": options.maximum_analyses_per_video,
                "maximum_ai_cost_per_job_usd": options.maximum_ai_cost_per_job_usd,
                "render_parallelism": options.render_parallelism,
                "upload_parallelism": options.upload_parallelism,
                "deep_technical_scan": options.deep_technical_scan,
            }
            item.job.log_messages.append(f"Mock AI: {use_mock_ai}; Mock source: {use_mock_source}")
            self.job_repository.save(item.job)
        results: list[ProductionJob] = []
        try:
            with ThreadPoolExecutor(
                max_workers=max(1, options.render_parallelism),
                thread_name_prefix="clipfactory-production",
            ) as executor:
                futures = {
                    executor.submit(
                        self._process_item,
                        batch.id,
                        item,
                        use_mock_ai,
                        use_mock_source,
                        options,
                        self._job_cancellation(item.job.id, cancel_event),
                    ): item
                    for item in batch.items
                }
                for completed_count, future in enumerate(as_completed(futures), start=1):
                    results.append(future.result())
                    progress_callback(
                        round(completed_count / len(futures) * 100),
                        f"Completed {completed_count} of {len(futures)} production jobs",
                    )
            return results
        finally:
            for item in batch.items:
                self._job_cancel_events.pop(item.job.id, None)
            self._batch_exclusions.pop(batch.id, None)
            self._batch_titles.pop(batch.id, None)
            self._batch_caption_keys.pop(batch.id, None)
            self._batch_candidate_windows.pop(batch.id, None)

    def cancel_job(self, job_id: str) -> bool:
        event = self._job_cancel_events.get(job_id)
        if not event:
            return False
        event.set()
        return True

    def _job_cancellation(self, job_id: str, batch_event: Event) -> CombinedCancellation:
        local = Event()
        self._job_cancel_events[job_id] = local
        return CombinedCancellation(batch_event, local)

    def retry_job(
        self,
        batch_id: str,
        item: PlannedBatchItem,
        *,
        use_mock_ai: bool = False,
        use_mock_source: bool = False,
        options: ProductionOptions | None = None,
        cancel_event: Event | None = None,
    ) -> ProductionJob:
        existing = self.job_repository.get(item.job.id)
        retryable = {
            ProductionStatus.FAILED,
            ProductionStatus.CANCELLED,
            ProductionStatus.REJECTED,
        }
        if not existing or existing.status not in retryable:
            raise ValueError("Only failed, cancelled, or rejected production jobs can be retried.")
        existing.retry_count += 1
        existing.status = ProductionStatus.PLANNED
        existing.progress = 0
        existing.last_error = None
        existing.current_step = "Retry planned"
        self.job_repository.save(existing, validate_transition=False)
        retry_item = PlannedBatchItem(
            project_id=item.project_id,
            job=existing,
            source_profile=item.source_profile,
            preset=item.preset,
            channel=item.channel,
        )
        self._batch_exclusions.setdefault(batch_id, set())
        return self._process_item(
            batch_id,
            retry_item,
            use_mock_ai,
            use_mock_source,
            options or ProductionOptions(),
            cancel_event or Event(),
        )

    def _process_item(
        self,
        batch_id: str,
        item: PlannedBatchItem,
        use_mock_ai: bool,
        use_mock_source: bool,
        options: ProductionOptions,
        cancel_event: Event,
    ) -> ProductionJob:
        job = self.job_repository.get(item.job.id) or item.job
        job.attempt_count += 1
        attempt = job.attempt_count
        self.job_repository.save(job, validate_transition=False)
        result: ProductionJob | None = None
        with production_log_context(job.id, attempt, batch_id):
            self._log(
                job,
                "=" * 18
                + f" ATTEMPT {attempt} START | r/{item.source_profile.community} | "
                + f"preset={item.preset.name} "
                + "=" * 18,
            )
            try:
                result = self._process_item_scoped(
                    batch_id,
                    item,
                    use_mock_ai,
                    use_mock_source,
                    options,
                    cancel_event,
                )
                return result
            finally:
                final_job = result or self.job_repository.get(job.id) or job
                self._log(
                    final_job,
                    "=" * 18
                    + f" ATTEMPT {attempt} END | status={final_job.status.value} "
                    + "=" * 18,
                )

    def _process_item_scoped(
        self,
        batch_id: str,
        item: PlannedBatchItem,
        use_mock_ai: bool,
        use_mock_source: bool,
        options: ProductionOptions,
        cancel_event: Event,
    ) -> ProductionJob:
        job = self.job_repository.get(item.job.id) or item.job
        try:
            source_provider: SourceProvider = self.source_provider_factory(use_mock_source)
            analysis_service: AnalysisService = self.analysis_service_factory(use_mock_ai)
            has_header_overlay = item.preset.header.enabled and any(
                layer.element_type == ElementType.HEADER and not layer.hidden
                for layer in item.preset.layers
            )
            has_caption_overlay = any(
                layer.element_type == ElementType.DYNAMIC_CAPTION and not layer.hidden
                for layer in item.preset.layers
            )
            permissions = item.preset.ai_permissions.model_copy(
                update={
                    "allow_header_text": item.preset.ai_permissions.allow_header_text
                    and not item.preset.header.locked_text
                    and has_header_overlay,
                    "allow_ranking_captions": (
                        item.preset.ai_permissions.allow_ranking_captions and has_caption_overlay
                    ),
                }
            )
            if options.maximum_ai_cost_per_job_usd is not None:
                current_budget = analysis_service.budget_guard.settings
                analysis_service.budget_guard.settings = current_budget.model_copy(
                    update={
                        "job_limit_usd": min(
                            current_budget.job_limit_usd,
                            options.maximum_ai_cost_per_job_usd,
                        )
                    }
                )
            self._log(job, "Validating AI provider and configured model access")
            analysis_service.validate_provider()
            self._step(job, ProductionStatus.DISCOVERING, 3, "Discovering source candidates")
            ordinal, pool_limit = self._batch_candidate_windows.get(batch_id, {}).get(
                job.id,
                (0, item.source_profile.candidate_limit),
            )
            discovery_profile = item.source_profile.model_copy(
                update={"candidate_limit": pool_limit}
            )
            discovery = source_provider.discover(discovery_profile, cancel_event=cancel_event)
            for warning in discovery.warnings:
                self._log(job, f"Source warning: {warning}")
            if not discovery.candidates:
                raise ClipFactoryError("No candidates passed the source profile filters.")
            previous_plan = self.project_repository.get(item.project_id)
            project_plan = self.source_planner.create_plan(
                item.source_profile,
                discovery,
                item.preset,
                target_video_count=1,
                thresholds=previous_plan.quality_thresholds if previous_plan else None,
                target_platform=item.target_platform,
            )
            project_plan.id = item.project_id
            project_plan.project_id = item.project_id
            if previous_plan:
                project_plan.project_overrides = previous_plan.project_overrides
            self.project_repository.save(project_plan)
            window_start = ordinal * options.maximum_analyses_per_video
            window_end = window_start + options.maximum_analyses_per_video
            candidates = list(discovery.candidates[window_start:window_end])
            if len(candidates) < options.maximum_analyses_per_video:
                selected_ids = {candidate.post_id for candidate in candidates}
                candidates.extend(
                    candidate
                    for candidate in discovery.candidates
                    if candidate.post_id not in selected_ids
                )
                candidates = candidates[: options.maximum_analyses_per_video]
            self._log(
                job,
                f"Assigned candidate window {window_start + 1}-{window_end} from a "
                f"{len(discovery.candidates)}-candidate batch pool.",
            )

            self._step(job, ProductionStatus.DOWNLOADING, 10, "Downloading candidate media")
            downloaded: list[tuple[object, object]] = []
            for index, candidate in enumerate(candidates):
                self._cancel_if_requested(cancel_event)
                try:
                    media = self.downloader.download(candidate, cancel_event=cancel_event)
                    downloaded.append((candidate, media))
                except CancelledError:
                    raise
                except Exception as error:
                    self._log(job, f"Candidate {candidate.post_id} download failed: {error}")
                self._progress(
                    job,
                    10 + round(20 * (index + 1) / len(candidates)),
                    "Downloading candidate media",
                )
            if not downloaded:
                raise ClipFactoryError("No candidate media could be downloaded.")

            self._step(job, ProductionStatus.PROBING, 32, "Probing downloaded media")
            probed: list[tuple[object, object]] = []
            for candidate, media in downloaded:
                try:
                    probed.append((candidate, self.probe.probe(media.file_path)))
                except Exception as error:
                    self._log(job, f"Candidate {candidate.post_id} probe failed: {error}")
            if not probed:
                raise ClipFactoryError("No downloaded media passed MediaProbe.")

            self._step(job, ProductionStatus.ANALYZING, 40, "Analyzing actual clip content")
            analyzed: list[AnalyzedCandidate] = []
            for index, (candidate, media_info) in enumerate(probed):
                self._cancel_if_requested(cancel_event)
                prompt = self.prompt_builder.clip_analysis(
                    clip_id=candidate.post_id,
                    theme=project_plan.preliminary_theme,
                    platform=item.target_platform,
                    video_format=item.preset.video_format,
                    duration_seconds=media_info.duration_seconds,
                    permissions=permissions,
                )
                try:
                    result, cached, warnings = analysis_service.analyze_clip(
                        Path(media_info.file_path),
                        media_info,
                        clip_id=candidate.post_id,
                        theme=project_plan.preliminary_theme,
                        platform=item.target_platform,
                        video_format=item.preset.video_format,
                        preset_id=item.preset.id,
                        permissions=permissions,
                        prompt=prompt,
                        job_id=job.id,
                    )
                    analyzed.append(AnalyzedCandidate(candidate, media_info, result))
                    self._log(
                        job, f"Analyzed {candidate.post_id}{' from cache' if cached else ''}."
                    )
                    for warning in warnings:
                        self._log(job, warning)
                except AIProviderFatalError:
                    raise
                except Exception as error:
                    self._log(job, f"Candidate {candidate.post_id} analysis failed: {error}")
                self._progress(
                    job, 40 + round(20 * (index + 1) / len(probed)), "Analyzing actual clip content"
                )
            if not analyzed:
                raise ClipFactoryError("No candidate received a valid structured analysis.")
            theme = self.source_planner.refine_theme(
                project_plan, [item.analysis for item in analyzed]
            )
            self.project_repository.save(project_plan)

            self._step(job, ProductionStatus.SELECTING, 62, "Selecting distinct clips")
            with self._selection_lock:
                selection = self.selection_planner.select(
                    analyzed,
                    target_duration=item.preset.duration.target_seconds,
                    thresholds=project_plan.quality_thresholds,
                    channel_id=item.channel.id if item.channel else None,
                    excluded_fingerprints=self._batch_exclusions[batch_id],
                    excluded_caption_keys=self._batch_caption_keys.setdefault(batch_id, set()),
                )
                for warning in selection.warnings:
                    self._log(job, warning)
                if not selection.selected:
                    summary = self.selection_planner.rejection_summary(selection)
                    raise ClipFactoryError(
                        f"Clip selection produced no usable clips. Rejection summary: {summary}."
                    )
                minimum_clip_count_met = (
                    len(selection.selected) >= project_plan.quality_thresholds.minimum_clip_count
                )
                duration_contract_met = (
                    item.preset.duration.minimum_seconds
                    <= selection.total_duration_seconds
                    <= item.preset.duration.maximum_seconds
                )
                selection_contract_met = minimum_clip_count_met and duration_contract_met
                if (
                    not selection_contract_met
                    and item.preset.duration.enforcement != DurationEnforcement.WARN
                ):
                    rejection_summary = self.selection_planner.rejection_summary(selection)
                    raise ClipFactoryError(
                        "Clip selection could not satisfy the preset duration contract before "
                        f"rendering: selected {len(selection.selected)} clip(s), "
                        f"{selection.total_duration_seconds:.2f}s; required at least "
                        f"{project_plan.quality_thresholds.minimum_clip_count} clip(s) and "
                        f"{item.preset.duration.minimum_seconds:.2f}-"
                        f"{item.preset.duration.maximum_seconds:.2f}s "
                        f"(target {item.preset.duration.target_seconds:.2f}s). "
                        f"Rejection summary: {rejection_summary}."
                    )
                if not selection_contract_met:
                    self._log(
                        job,
                        "Duration enforcement is warn; continuing with "
                        f"{len(selection.selected)} clip(s) and "
                        f"{selection.total_duration_seconds:.2f}s despite unmet selection "
                        "constraints. An out-of-range duration will be recorded as a "
                        "non-blocking review warning.",
                    )
                elif not selection.target_met:
                    self._log(
                        job,
                        f"Selected duration is {selection.total_duration_seconds:.2f}s, below the "
                        f"{item.preset.duration.target_seconds:.2f}s target but inside the "
                        "configured allowed range.",
                    )
                self._batch_exclusions[batch_id].update(
                    clip.media_fingerprint for clip in selection.selected
                )
                self._batch_caption_keys.setdefault(batch_id, set()).update(
                    self.selection_planner.normalize_text(clip.caption)
                    for clip in selection.selected
                )

            copy_label = (
                "Generating AI header, captions, and upload metadata"
                if permissions.allow_header_text or permissions.allow_ranking_captions
                else "Generating upload metadata without on-video text"
            )
            self._step(job, ProductionStatus.GENERATING_COPY, 68, copy_label)
            selected_ids = {clip.clip_id for clip in selection.selected}
            selected_analyses = [
                value.analysis for value in analyzed if value.analysis.clip_id in selected_ids
            ]
            language = item.channel.language if item.channel else item.source_profile.language
            preference_context = (
                self.adaptive_preferences.prompt_context(
                    channel_id=item.channel.id if item.channel else None,
                    preset_id=item.preset.id,
                    platform=item.target_platform,
                    language=language,
                    theme=theme,
                )
                if self.adaptive_preferences
                else None
            )
            if preference_context and preference_context.example_count:
                self._log(
                    job,
                    "Applying "
                    f"{preference_context.example_count} learned editorial preference example(s) "
                    f"(revision {preference_context.revision}).",
                )
            creative_prompt = self.prompt_builder.project_creative(
                selected_analyses,
                theme=theme,
                platform=item.target_platform,
                video_format=item.preset.video_format,
                permissions=permissions,
                preference_context=preference_context.text if preference_context else "",
            )
            creative, creative_warnings = analysis_service.create_project_creative(
                selected_analyses,
                theme=theme,
                platform=item.target_platform,
                video_format=item.preset.video_format,
                permissions=permissions,
                prompt=creative_prompt,
                preference_context=preference_context.text if preference_context else "",
                job_id=job.id,
            )
            if item.preset.header.locked_text:
                header_layer = next(
                    (
                        layer
                        for layer in item.preset.layers
                        if layer.element_type == ElementType.HEADER and layer.rich_text
                    ),
                    None,
                )
                creative.header_text = (
                    header_layer.rich_text.text.replace("{theme}", theme)
                    if header_layer and header_layer.rich_text
                    else ""
                )
            caption_overrides = project_plan.project_overrides.get("caption_texts")
            if isinstance(caption_overrides, list) and len(caption_overrides) == len(
                creative.ranking_captions
            ):
                creative.ranking_captions = [str(value) for value in caption_overrides]
            for warning in creative_warnings:
                self._log(job, warning)

            self._step(job, ProductionStatus.RENDERING, 74, "Rendering vertical output")
            asset_paths = self.asset_library.path_map()
            preset_errors = PresetValidator().validate(
                item.preset,
                asset_paths=asset_paths,
            )
            if preset_errors:
                raise ClipFactoryError("; ".join(preset_errors))
            output_path = self.output_directory / f"{item.target_platform}-{job.id}.mp4"
            render_plan = self.render_plan_builder.build(
                project_id=item.project_id,
                job_id=job.id,
                preset=item.preset,
                selection=selection,
                creative=creative,
                output_path=output_path,
                asset_paths=asset_paths,
                project_overrides=project_plan.project_overrides,
            )
            render_plan.metadata["adaptive_preference_revision"] = (
                preference_context.revision if preference_context else "none"
            )
            render_plan.metadata["adaptive_preference_example_count"] = (
                preference_context.example_count if preference_context else 0
            )
            job.render_plan_payload = render_plan.model_dump(mode="json")
            self.job_repository.save(job, validate_transition=False)
            rendered = self.renderer.render(
                render_plan,
                item.preset,
                cancel_event=cancel_event,
                progress_callback=lambda value, message: self._progress(
                    job, 74 + round(value * 0.14), message
                ),
            )
            job.output_path = str(rendered)
            self.job_repository.save(job)

            self._step(
                job, ProductionStatus.VALIDATING, 90, "Running deterministic and optional AI review"
            )
            final_review: FinalReviewService = self.final_review_factory(analysis_service)
            technical, ai_review, review_warnings = final_review.review(
                rendered,
                item.preset,
                theme=theme,
                platform=item.target_platform,
                job_id=job.id,
                deep_scan=options.deep_technical_scan,
            )
            job.actual_ai_cost_usd = analysis_service.ledger.total_since(
                datetime.min.replace(tzinfo=UTC), job_id=job.id
            )
            self.job_repository.save(job, validate_transition=False)
            for warning in technical.warnings:
                self._log(job, f"Technical warning: {warning}")
            if not technical.passed:
                details = "; ".join(
                    check.name for check in technical.checks if check.blocking and not check.passed
                )
                raise ClipFactoryError(f"Technical validation failed: {details}")
            for clip in selection.selected:
                self.history.reserve(
                    clip.media_fingerprint,
                    clip.candidate_id,
                    channel_id=item.channel.id if item.channel else None,
                    batch_id=batch_id,
                )
            for warning in review_warnings:
                self._log(job, warning)
            rendered_info = self.probe.probe(rendered)
            selected_sources = {value.source.post_id: value.source for value in analyzed}
            source_rights = [
                {
                    "clip_id": clip.clip_id,
                    "status": selected_sources[clip.candidate_id].rights_status,
                    "source_url": clip.source_url,
                }
                for clip in selection.selected
                if clip.candidate_id in selected_sources
            ]
            upload_metadata = self._metadata(
                batch_id,
                item.target_platform,
                creative,
                item.channel,
                item.preset,
            )
            review_item = ReviewItem(
                production_job_id=job.id,
                project_id=item.project_id,
                video_path=str(rendered),
                filename=rendered.name,
                duration_seconds=rendered_info.duration_seconds,
                platform=item.target_platform,
                channel_id=item.channel.id if item.channel else None,
                preset_id=item.preset.id,
                design_profile_id=(job.design_profile_id or item.preset.style_profiles.design),
                header=render_plan.header_text,
                clip_ids=[clip.clip_id for clip in render_plan.clips],
                ranking_captions=[caption.text for caption in render_plan.captions],
                upload_metadata=upload_metadata,
                scheduled_at=job.scheduled_at,
                technical_validation=technical,
                ai_review=ai_review,
                estimated_ai_cost_usd=job.estimated_ai_cost_usd,
                actual_ai_cost_usd=job.actual_ai_cost_usd,
                rights_review_required=(
                    item.source_profile.rights_mode == RightsMode.MANUAL_REVIEW
                    and any(value["status"] != "cleared" for value in source_rights)
                ),
                source_rights=source_rights,
                theme=theme,
                language=language,
                ai_original_header=render_plan.header_text,
                ai_original_ranking_captions=[caption.text for caption in render_plan.captions],
                ai_original_upload_metadata=dict(upload_metadata),
                review_preset_payload=item.preset.model_dump(mode="json"),
            )
            self.review_queue.add(review_item)
            return self.job_repository.get(job.id) or job
        except CancelledError as error:
            job.status = ProductionStatus.CANCELLED
            job.current_step = "Cancelled"
            job.last_error = redact_text(error)
            self.job_repository.save(job, validate_transition=False)
            return job
        except Exception as error:
            logger.exception("Production job %s failed", job.id)
            job.status = ProductionStatus.FAILED
            job.current_step = "Failed"
            job.last_error = redact_text(error)
            self._log(job, f"Failed: {error}", persist=False)
            self.job_repository.save(job, validate_transition=False)
            return job

    def rerender(
        self,
        job_id: str,
        *,
        use_mock_ai: bool,
        cancel_event: Event | None = None,
    ) -> ProductionJob:
        cancel_event = cancel_event or Event()
        job = self.job_repository.get(job_id)
        if not job or not job.render_plan_payload:
            raise ValueError("No persisted render plan is available for this job.")
        job.attempt_count += 1
        attempt = job.attempt_count
        self.job_repository.save(job, validate_transition=False)
        result: ProductionJob | None = None
        with production_log_context(job.id, attempt, job.batch_id or "rerender"):
            self._log(
                job,
                "=" * 18 + f" ATTEMPT {attempt} START | editorial re-render " + "=" * 18,
            )
            try:
                result = self._rerender_scoped(job, use_mock_ai, cancel_event)
                return result
            finally:
                final_job = result or self.job_repository.get(job.id) or job
                self._log(
                    final_job,
                    "=" * 18
                    + f" ATTEMPT {attempt} END | status={final_job.status.value} "
                    + "=" * 18,
                )

    def _rerender_scoped(
        self,
        job: ProductionJob,
        use_mock_ai: bool,
        cancel_event: Event,
    ) -> ProductionJob:
        render_plan = RenderPlan.model_validate(job.render_plan_payload)
        project = self.project_repository.get(job.project_id)
        item = self.review_repository.get_by_production_job(job.id)
        preset_model = (
            Preset.model_validate(item.review_preset_payload)
            if item and item.review_preset_payload
            else self.preset_repository.get(job.preset_id)
        )
        if not preset_model:
            raise ValueError("Render preset no longer exists.")
        if item:
            render_plan.header_text = item.header
            if len(item.ranking_captions) == len(render_plan.captions):
                for index, value in enumerate(item.ranking_captions):
                    render_plan.captions[index].text = value
            caption_by_clip = {
                caption.clip_id: caption.text for caption in render_plan.captions if caption.clip_id
            }
            for ranking_item in render_plan.ranking_items:
                if ranking_item.clip_id in caption_by_clip:
                    ranking_item.caption = caption_by_clip[ranking_item.clip_id]
        elif project:
            header = project.project_overrides.get("header_text")
            captions = project.project_overrides.get("caption_texts")
            if isinstance(header, str):
                render_plan.header_text = header
            if isinstance(captions, list) and len(captions) == len(render_plan.captions):
                for index, value in enumerate(captions):
                    render_plan.captions[index].text = str(value)
        header_layer = next(
            (
                layer
                for layer in preset_model.layers
                if layer.element_type == ElementType.HEADER and not layer.hidden
            ),
            None,
        )
        header_document = self.render_plan_builder._accented_header_document(
            preset_model,
            header_layer.rich_text if header_layer else None,
            render_plan.header_text,
        )
        render_plan.metadata["header_document"] = (
            header_document.model_dump(mode="json") if header_document else None
        )
        self.render_plan_builder.apply_current_caption_visibility(render_plan, preset_model)
        self.render_plan_builder.apply_current_ranking_playback(render_plan, preset_model)
        render_plan.metadata["style_selection"] = self.render_plan_builder.style_selection_metadata(
            preset_model
        )
        analysis_service = self.analysis_service_factory(use_mock_ai)
        job.status = ProductionStatus.RENDERING
        job.current_step = "Re-rendering approved editorial changes"
        job.progress = 75
        self.job_repository.save(job, validate_transition=False)
        try:
            output = self.renderer.render(render_plan, preset_model, cancel_event=cancel_event)
            job.status = ProductionStatus.VALIDATING
            job.progress = 90
            self.job_repository.save(job)
            review_service: FinalReviewService = self.final_review_factory(analysis_service)
            technical, ai_review, review_warnings = review_service.review(
                output,
                preset_model,
                theme=str(render_plan.metadata.get("overall_theme", "")),
                platform=project.target_platform if project else preset_model.platform,
                job_id=job.id,
                deep_scan=True,
            )
            for warning in technical.warnings:
                self._log(job, f"Technical warning: {warning}")
            for warning in review_warnings:
                self._log(job, warning)
            if not technical.passed:
                raise ClipFactoryError("Re-rendered video failed technical validation.")
            item = self.review_repository.get_by_production_job(job.id)
            if not item:
                raise ClipFactoryError("Review item no longer exists.")
            rendered_info = self.probe.probe(output)
            item.header = render_plan.header_text
            item.ranking_captions = [caption.text for caption in render_plan.captions]
            item.video_path = str(output)
            item.filename = output.name
            item.duration_seconds = rendered_info.duration_seconds
            item.technical_validation = technical
            item.ai_review = ai_review
            item.status = item.status.__class__.PENDING
            item.needs_rerender = False
            self.review_repository.save(item)
            job.render_plan_payload = render_plan.model_dump(mode="json")
            job.status = ProductionStatus.AWAITING_REVIEW
            job.current_step = "Awaiting review after re-render"
            job.progress = 100
            self.job_repository.save(job)
            return job
        except Exception as error:
            job.status = ProductionStatus.FAILED
            job.last_error = redact_text(error)
            job.current_step = "Re-render failed"
            self.job_repository.save(job, validate_transition=False)
            return job

    def _step(self, job: ProductionJob, status: ProductionStatus, progress: int, text: str) -> None:
        job.status = status
        job.progress = progress
        job.current_step = text
        job.log_messages.append(self._job_log_line(job, text))
        logger.info(text)
        self.job_repository.save(job)

    def _progress(self, job: ProductionJob, progress: int, text: str) -> None:
        job.progress = min(99, max(job.progress, progress))
        job.current_step = text
        self.job_repository.save(job, validate_transition=False)

    def _log(self, job: ProductionJob, text: str, *, persist: bool = True) -> None:
        safe_text = redact_text(text)
        job.log_messages.append(self._job_log_line(job, safe_text))
        logger.info(safe_text)
        if persist:
            self.job_repository.save(job, validate_transition=False)

    @staticmethod
    def _job_log_line(job: ProductionJob, text: str) -> str:
        timestamp = datetime.now(UTC).astimezone().isoformat(timespec="seconds")
        attempt = job.attempt_count or job.retry_count + 1
        return f"{timestamp} | Attempt {attempt} | {job.status.value} | {text}"

    @staticmethod
    def _cancel_if_requested(cancel_event: Event) -> None:
        if cancel_event.is_set():
            raise CancelledError("Production job was cancelled.")

    def _metadata(
        self,
        batch_id: str,
        platform: str,
        creative: ProjectCreativeResult,
        channel: ChannelProfile | None,
        preset: Preset,
    ) -> dict[str, object]:
        defaults = {
            **preset.upload_metadata_defaults,
            **(channel.default_upload_metadata if channel else {}),
        }
        privacy = channel.default_privacy if channel else "private"
        title = self._unique_title(
            batch_id,
            creative.upload_title_suggestions or [creative.header_text],
        )
        if platform == "youtube":
            values = {
                **defaults,
                "title": title[:100],
                "description": creative.youtube_description[:5000],
                "tags": list(
                    dict.fromkeys(
                        [*creative.youtube_tags, *(channel.default_tags if channel else [])]
                    )
                ),
                "hashtags": list(
                    dict.fromkeys(
                        [
                            *creative.youtube_hashtags,
                            *(channel.default_hashtags if channel else []),
                        ]
                    )
                ),
                "privacy_status": (
                    privacy if privacy in {"private", "public", "unlisted"} else "private"
                ),
            }
            if creative.youtube_category_id_suggestion:
                values.setdefault("category_id", creative.youtube_category_id_suggestion)
            if creative.youtube_playlist_id_suggestion:
                values.setdefault("playlist_id", creative.youtube_playlist_id_suggestion)
            return YouTubeMetadata.model_validate(values).model_dump(mode="json")
        caption_parts = [
            creative.tiktok_hook,
            creative.tiktok_caption or title,
            creative.tiktok_call_to_action,
        ]
        values = {
            **defaults,
            "caption": " ".join(value.strip() for value in caption_parts if value.strip())[:2200],
            "hashtags": list(
                dict.fromkeys(
                    [*creative.tiktok_hashtags, *(channel.default_hashtags if channel else [])]
                )
            ),
            "privacy_level": (
                privacy
                if privacy
                in {
                    "PUBLIC_TO_EVERYONE",
                    "MUTUAL_FOLLOW_FRIENDS",
                    "FOLLOWER_OF_CREATOR",
                    "SELF_ONLY",
                }
                else "SELF_ONLY"
            ),
        }
        return TikTokMetadata.model_validate(values).model_dump(mode="json")

    def _unique_title(self, batch_id: str, suggestions: list[str]) -> str:
        with self._selection_lock:
            used = self._batch_titles.setdefault(batch_id, set())
            for suggestion in suggestions:
                cleaned = suggestion.strip()
                if cleaned and cleaned.casefold() not in used:
                    used.add(cleaned.casefold())
                    return cleaned
            base = next(
                (value.strip() for value in suggestions if value.strip()), "ClipFactory video"
            )
            counter = 2
            while f"{base} {counter}".casefold() in used:
                counter += 1
            unique = f"{base} {counter}"
            used.add(unique.casefold())
            return unique
