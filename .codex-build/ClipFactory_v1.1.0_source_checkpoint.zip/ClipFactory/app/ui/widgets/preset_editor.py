"""Visual 9:16 preset editor with direct rich-text selection and styling."""

from __future__ import annotations

from copy import deepcopy
from uuid import uuid4

from PySide6.QtCore import QPointF, QRectF, QSizeF, Qt, Signal
from PySide6.QtGui import (
    QColor,
    QFont,
    QPainter,
    QPen,
    QPixmap,
    QTextCharFormat,
    QTextCursor,
    QTextFormat,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDoubleSpinBox,
    QFontComboBox,
    QFormLayout,
    QGraphicsDropShadowEffect,
    QGraphicsObject,
    QGraphicsScene,
    QGraphicsTextItem,
    QGraphicsView,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSlider,
    QSpinBox,
    QSplitter,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from app.models.preset_models import (
    Color,
    ElementType,
    Preset,
    PresetLayer,
    Rect,
    RichTextDocument,
    TextStyle,
)
from app.models.style_models import StyleProfileKind
from app.presets.layout import LayoutEngine
from app.presets.rich_text import RichTextEditor
from app.presets.style_profile_manager import StyleProfileManager
from app.ui.preset_contract_dialog import PresetContractDialog
from app.ui.style_profiles_dialog import StyleProfilesDialog

STYLE_SHADOW_PROPERTY = int(QTextFormat.Property.UserProperty) + 1
STYLE_LINE_SPACING_PROPERTY = int(QTextFormat.Property.UserProperty) + 2
STYLE_ALIGNMENT_PROPERTY = int(QTextFormat.Property.UserProperty) + 3
STYLE_TRANSFORM_PROPERTY = int(QTextFormat.Property.UserProperty) + 4
STYLE_SHADOW_DISTANCE_PROPERTY = int(QTextFormat.Property.UserProperty) + 5
STYLE_SHADOW_BLUR_PROPERTY = int(QTextFormat.Property.UserProperty) + 6
STYLE_GLOW_ENABLED_PROPERTY = int(QTextFormat.Property.UserProperty) + 7
STYLE_GLOW_COLOR_PROPERTY = int(QTextFormat.Property.UserProperty) + 8
STYLE_GLOW_RADIUS_PROPERTY = int(QTextFormat.Property.UserProperty) + 9
STYLE_GLOW_INTENSITY_PROPERTY = int(QTextFormat.Property.UserProperty) + 10
STYLE_SCALE_PROPERTY = int(QTextFormat.Property.UserProperty) + 11
STYLE_REFERENCE_HEIGHT_PROPERTY = int(QTextFormat.Property.UserProperty) + 12


def qcolor(value: Color) -> QColor:
    return QColor(value.red, value.green, value.blue, value.alpha)


def model_color(value: QColor) -> Color:
    return Color(red=value.red(), green=value.green(), blue=value.blue(), alpha=value.alpha())


class EditableTextItem(QGraphicsTextItem):
    editing_finished = Signal()

    def focusOutEvent(self, event) -> None:
        super().focusOutEvent(event)
        self.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        self.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        self.editing_finished.emit()


class LayerGraphicsItem(QGraphicsObject):
    geometry_changed = Signal(str, object)
    text_changed = Signal(str)
    selected_layer = Signal(str)

    handle_size = 24.0

    def __init__(
        self,
        layer: PresetLayer,
        preset: Preset,
        *,
        snap_enabled: bool,
        grid_size: int,
        asset_paths: dict[str, str],
    ):
        super().__init__()
        self.layer = layer
        self.preset = preset
        self.snap_enabled = snap_enabled
        self.grid_size = grid_size
        self.asset_paths = asset_paths
        pixel = LayoutEngine.layer_rect(preset, layer)
        self._rect = QRectF(0, 0, pixel.width, pixel.height)
        self.setPos(pixel.x, pixel.y)
        self.setZValue(layer.z_index)
        self.setRotation(layer.rotation_degrees)
        self.setOpacity(layer.opacity)
        self.setVisible(not layer.hidden)
        self.setFlag(QGraphicsObject.GraphicsItemFlag.ItemIsSelectable, not layer.locked)
        self.setFlag(QGraphicsObject.GraphicsItemFlag.ItemIsMovable, not layer.locked)
        self.setFlag(QGraphicsObject.GraphicsItemFlag.ItemSendsGeometryChanges, True)
        self._resizing = False
        self._resize_origin = QPointF()
        self._original_rect = QRectF()
        self.text_item: EditableTextItem | None = None
        if layer.rich_text:
            self.text_item = EditableTextItem(self)
            self._position_text_item()
            self.text_item.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
            self._load_document(layer.rich_text)
            self.text_item.editing_finished.connect(lambda: self.text_changed.emit(self.layer.id))

    def boundingRect(self) -> QRectF:
        return self._rect.adjusted(-2, -2, 2, 2)

    def paint(self, painter: QPainter, _option, _widget=None) -> None:
        background = qcolor(self.layer.background_color)
        if background.alpha() > 0:
            painter.fillRect(self._rect, background)
        if self.layer.element_type == ElementType.VIDEO:
            painter.fillRect(self._rect, QColor(34, 38, 48))
            painter.setPen(QColor(180, 185, 195))
            painter.drawText(self._rect, Qt.AlignmentFlag.AlignCenter, "VIDEO")
        elif self.layer.asset_id and self.layer.asset_id in self.asset_paths:
            pixmap = QPixmap(self.asset_paths[self.layer.asset_id])
            if not pixmap.isNull():
                painter.drawPixmap(self._rect.toRect(), pixmap, pixmap.rect())
        elif not self.text_item and self.layer.element_type not in {
            ElementType.BACKGROUND,
            ElementType.SHAPE,
        }:
            painter.setPen(QColor(180, 185, 195))
            painter.drawText(
                self._rect,
                Qt.AlignmentFlag.AlignCenter,
                self.layer.element_type.value.replace("_", " ").upper(),
            )
        if self.isSelected():
            painter.setPen(QPen(QColor(54, 170, 255), 4, Qt.PenStyle.SolidLine))
            painter.drawRect(self._rect)
            handle = QRectF(
                self._rect.right() - self.handle_size,
                self._rect.bottom() - self.handle_size,
                self.handle_size,
                self.handle_size,
            )
            painter.fillRect(handle, QColor(54, 170, 255))
        elif not self.layer.locked:
            painter.setPen(QPen(QColor(255, 255, 255, 45), 2, Qt.PenStyle.DashLine))
            painter.drawRect(self._rect)

    def mousePressEvent(self, event) -> None:
        self.selected_layer.emit(self.layer.id)
        if not self.layer.locked and self._resize_handle().contains(event.pos()):
            self._resizing = True
            self._resize_origin = event.scenePos()
            self._original_rect = QRectF(self._rect)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        if self._resizing:
            delta = event.scenePos() - self._resize_origin
            maximum_width = self.preset.width - self.pos().x()
            maximum_height = self.preset.height - self.pos().y()
            width = max(60, min(maximum_width, self._original_rect.width() + delta.x()))
            height = max(32, min(maximum_height, self._original_rect.height() + delta.y()))
            if self.snap_enabled:
                width = max(60, round(width / self.grid_size) * self.grid_size)
                height = max(32, round(height / self.grid_size) * self.grid_size)
            self.prepareGeometryChange()
            self._rect.setSize(QSizeF(width, height))
            if self.text_item:
                self._position_text_item()
            self.update()
            self._emit_geometry()
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        if self._resizing:
            self._resizing = False
            self._emit_geometry()
            event.accept()
            return
        super().mouseReleaseEvent(event)
        self._emit_geometry()

    def mouseDoubleClickEvent(self, event) -> None:
        if self.text_item and not self.layer.locked:
            self.text_item.setAcceptedMouseButtons(Qt.MouseButton.AllButtons)
            self.text_item.setTextInteractionFlags(Qt.TextInteractionFlag.TextEditorInteraction)
            self.text_item.setFocus(Qt.FocusReason.MouseFocusReason)
            cursor = self.text_item.textCursor()
            position = (
                self.text_item.document()
                .documentLayout()
                .hitTest(event.pos(), Qt.HitTestAccuracy.FuzzyHit)
            )
            cursor.setPosition(max(0, position))
            self.text_item.setTextCursor(cursor)
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def itemChange(self, change, value):
        if change == QGraphicsObject.GraphicsItemChange.ItemPositionChange and self.scene():
            point = QPointF(value)
            if self.snap_enabled:
                point.setX(round(point.x() / self.grid_size) * self.grid_size)
                point.setY(round(point.y() / self.grid_size) * self.grid_size)
            point.setX(max(0, min(self.preset.width - self._rect.width(), point.x())))
            point.setY(max(0, min(self.preset.height - self._rect.height(), point.y())))
            return point
        if change == QGraphicsObject.GraphicsItemChange.ItemPositionHasChanged:
            self._emit_geometry()
        return super().itemChange(change, value)

    def begin_editing(self) -> None:
        if self.text_item:
            self.text_item.setAcceptedMouseButtons(Qt.MouseButton.AllButtons)
            self.text_item.setTextInteractionFlags(Qt.TextInteractionFlag.TextEditorInteraction)
            self.text_item.setFocus(Qt.FocusReason.OtherFocusReason)

    def selected_cursor(self) -> QTextCursor | None:
        return self.text_item.textCursor() if self.text_item else None

    def apply_char_format(self, char_format: QTextCharFormat) -> None:
        if not self.text_item:
            return
        cursor = self.text_item.textCursor()
        if not cursor.hasSelection():
            cursor.select(QTextCursor.SelectionType.Document)
        cursor.mergeCharFormat(char_format)
        self.text_item.setTextCursor(cursor)
        self.text_changed.emit(self.layer.id)

    def to_rich_text(self) -> RichTextDocument | None:
        if not self.text_item or not self.layer.rich_text:
            return None
        text = self.text_item.toPlainText()
        default = deepcopy(self.layer.rich_text.default_style)
        styles: list[TextStyle] = []
        document = self.text_item.document()
        for index in range(len(text)):
            cursor = QTextCursor(document)
            cursor.setPosition(index)
            cursor.movePosition(
                QTextCursor.MoveOperation.NextCharacter, QTextCursor.MoveMode.KeepAnchor
            )
            fmt = cursor.charFormat()
            style = deepcopy(default)
            families = fmt.fontFamilies()
            if families:
                style.font_family = families[0]
            size = fmt.fontPointSize()
            if size > 0:
                style.font_size = size
            style.bold = fmt.fontWeight() >= QFont.Weight.Bold
            style.italic = fmt.fontItalic()
            style.underline = fmt.fontUnderline()
            if fmt.foreground().style() != Qt.BrushStyle.NoBrush:
                style.foreground = model_color(fmt.foreground().color())
            if fmt.background().style() != Qt.BrushStyle.NoBrush:
                style.background = model_color(fmt.background().color())
            outline = fmt.textOutline()
            if outline.style() != Qt.PenStyle.NoPen:
                style.outline = model_color(outline.color())
                style.outline_width = outline.widthF()
            style.letter_spacing = fmt.fontLetterSpacing()
            if fmt.hasProperty(STYLE_SHADOW_PROPERTY):
                style.shadow_enabled = bool(fmt.property(STYLE_SHADOW_PROPERTY))
            if fmt.hasProperty(STYLE_SHADOW_DISTANCE_PROPERTY):
                style.shadow_distance = float(fmt.property(STYLE_SHADOW_DISTANCE_PROPERTY))
            if fmt.hasProperty(STYLE_SHADOW_BLUR_PROPERTY):
                style.shadow_blur = float(fmt.property(STYLE_SHADOW_BLUR_PROPERTY))
            if fmt.hasProperty(STYLE_GLOW_ENABLED_PROPERTY):
                style.glow_enabled = bool(fmt.property(STYLE_GLOW_ENABLED_PROPERTY))
            if fmt.hasProperty(STYLE_GLOW_COLOR_PROPERTY):
                glow_color = fmt.property(STYLE_GLOW_COLOR_PROPERTY)
                if isinstance(glow_color, QColor) and glow_color.isValid():
                    style.glow_color = model_color(glow_color)
                else:
                    style.glow_color = None
            if fmt.hasProperty(STYLE_GLOW_RADIUS_PROPERTY):
                style.glow_radius = float(fmt.property(STYLE_GLOW_RADIUS_PROPERTY))
            if fmt.hasProperty(STYLE_GLOW_INTENSITY_PROPERTY):
                style.glow_intensity = float(fmt.property(STYLE_GLOW_INTENSITY_PROPERTY))
            if fmt.hasProperty(STYLE_SCALE_PROPERTY):
                style.scale_with_canvas = bool(fmt.property(STYLE_SCALE_PROPERTY))
            if fmt.hasProperty(STYLE_REFERENCE_HEIGHT_PROPERTY):
                style.reference_height = int(fmt.property(STYLE_REFERENCE_HEIGHT_PROPERTY))
            if fmt.hasProperty(STYLE_LINE_SPACING_PROPERTY):
                style.line_spacing = float(fmt.property(STYLE_LINE_SPACING_PROPERTY))
            if fmt.hasProperty(STYLE_ALIGNMENT_PROPERTY):
                style.alignment = str(fmt.property(STYLE_ALIGNMENT_PROPERTY))
            if fmt.hasProperty(STYLE_TRANSFORM_PROPERTY):
                style.transform = str(fmt.property(STYLE_TRANSFORM_PROPERTY))
            styles.append(style)
        return RichTextEditor.from_character_styles(text, default, styles)

    def update_style(self, style: TextStyle) -> None:
        if self.text_item:
            self.layer.rich_text.default_style = deepcopy(style)
            self._load_document(self.layer.rich_text)

    def set_layer_bounds(self) -> None:
        pixel = LayoutEngine.layer_rect(self.preset, self.layer)
        self.prepareGeometryChange()
        self._rect = QRectF(0, 0, pixel.width, pixel.height)
        self.setPos(pixel.x, pixel.y)
        if self.text_item:
            self._position_text_item()
        self.update()

    def _position_text_item(self) -> None:
        if not self.text_item:
            return
        padding = (
            round(self.preset.header.padding_ratio * self.preset.width)
            if self.layer.element_type == ElementType.HEADER
            else 0
        )
        horizontal = min(padding, max(0, round((self._rect.width() - 1) / 2)))
        vertical = min(padding, max(0, round((self._rect.height() - 1) / 2)))
        self.text_item.setPos(horizontal, vertical)
        self.text_item.setTextWidth(max(1, self._rect.width() - horizontal * 2))

    def _load_document(self, document: RichTextDocument) -> None:
        assert self.text_item is not None
        self.text_item.setPlainText(document.text)
        base = self._format(document.default_style)
        cursor = QTextCursor(self.text_item.document())
        cursor.select(QTextCursor.SelectionType.Document)
        cursor.setCharFormat(base)
        for span in document.spans:
            cursor = QTextCursor(self.text_item.document())
            cursor.setPosition(span.start)
            cursor.setPosition(span.end, QTextCursor.MoveMode.KeepAnchor)
            cursor.setCharFormat(self._format(span.style))
        self._apply_text_effect(document.default_style)

    def _apply_text_effect(self, style: TextStyle) -> None:
        if not self.text_item:
            return
        if style.glow_enabled and style.glow_radius > 0:
            effect = QGraphicsDropShadowEffect(self.text_item)
            effect.setBlurRadius(style.glow_radius * 2)
            effect.setOffset(0, 0)
            color = qcolor(style.glow_color or style.foreground)
            color.setAlpha(round(color.alpha() * style.glow_intensity))
            effect.setColor(color)
            self.text_item.setGraphicsEffect(effect)
        elif style.shadow_enabled and style.shadow_distance > 0:
            effect = QGraphicsDropShadowEffect(self.text_item)
            effect.setBlurRadius(max(1, style.shadow_blur * 2))
            effect.setOffset(style.shadow_distance, style.shadow_distance)
            effect.setColor(qcolor(style.shadow_color))
            self.text_item.setGraphicsEffect(effect)
        else:
            self.text_item.setGraphicsEffect(None)

    @staticmethod
    def _format(style: TextStyle) -> QTextCharFormat:
        value = QTextCharFormat()
        value.setFontFamilies([style.font_family])
        value.setFontPointSize(style.font_size)
        value.setFontWeight(QFont.Weight.Bold if style.bold else QFont.Weight.Normal)
        value.setFontItalic(style.italic)
        value.setFontUnderline(style.underline)
        value.setForeground(qcolor(style.foreground))
        value.setBackground(qcolor(style.background))
        value.setTextOutline(QPen(qcolor(style.outline), style.outline_width))
        value.setFontLetterSpacing(style.letter_spacing)
        value.setProperty(STYLE_SHADOW_PROPERTY, style.shadow_enabled)
        value.setProperty(STYLE_SHADOW_DISTANCE_PROPERTY, style.shadow_distance)
        value.setProperty(STYLE_SHADOW_BLUR_PROPERTY, style.shadow_blur)
        value.setProperty(STYLE_GLOW_ENABLED_PROPERTY, style.glow_enabled)
        value.setProperty(
            STYLE_GLOW_COLOR_PROPERTY,
            qcolor(style.glow_color) if style.glow_color else QColor(),
        )
        value.setProperty(STYLE_GLOW_RADIUS_PROPERTY, style.glow_radius)
        value.setProperty(STYLE_GLOW_INTENSITY_PROPERTY, style.glow_intensity)
        value.setProperty(STYLE_SCALE_PROPERTY, style.scale_with_canvas)
        value.setProperty(STYLE_REFERENCE_HEIGHT_PROPERTY, style.reference_height)
        value.setProperty(STYLE_LINE_SPACING_PROPERTY, style.line_spacing)
        value.setProperty(STYLE_ALIGNMENT_PROPERTY, style.alignment)
        value.setProperty(STYLE_TRANSFORM_PROPERTY, style.transform)
        return value

    def _resize_handle(self) -> QRectF:
        return QRectF(
            self._rect.right() - self.handle_size,
            self._rect.bottom() - self.handle_size,
            self.handle_size,
            self.handle_size,
        )

    def _emit_geometry(self) -> None:
        bounds = {
            "x": self.pos().x() / self.preset.width,
            "y": self.pos().y() / self.preset.height,
            "width": self._rect.width() / self.preset.width,
            "height": self._rect.height() / self.preset.height,
        }
        self.geometry_changed.emit(self.layer.id, bounds)


class PresetCanvas(QGraphicsView):
    layer_selected = Signal(str)
    layer_geometry_changed = Signal(str, object)
    layer_text_changed = Signal(str)

    def __init__(self):
        super().__init__()
        self.setScene(QGraphicsScene(self))
        self.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
        self.setBackgroundBrush(QColor(22, 24, 30))
        self.preset: Preset | None = None
        self.items_by_id: dict[str, LayerGraphicsItem] = {}
        self.grid_enabled = True
        self.snap_enabled = True
        self.safe_zones_enabled = True
        self.grid_size = 30
        self.asset_paths: dict[str, str] = {}

    def load_preset(self, preset: Preset) -> None:
        self.preset = preset
        self.scene().clear()
        self.scene().setSceneRect(0, 0, preset.width, preset.height)
        self.items_by_id.clear()
        for layer in sorted(preset.layers, key=lambda value: value.z_index):
            item = LayerGraphicsItem(
                layer,
                preset,
                snap_enabled=self.snap_enabled,
                grid_size=self.grid_size,
                asset_paths=self.asset_paths,
            )
            item.selected_layer.connect(self.layer_selected)
            item.geometry_changed.connect(self.layer_geometry_changed)
            item.text_changed.connect(self.layer_text_changed)
            self.scene().addItem(item)
            self.items_by_id[layer.id] = item
        self.fit_canvas()
        self.viewport().update()

    def fit_canvas(self) -> None:
        if self.preset:
            self.fitInView(self.scene().sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)

    def zoom_by(self, factor: float) -> None:
        self.scale(factor, factor)

    def selected_layer_item(self) -> LayerGraphicsItem | None:
        selected = [
            item for item in self.scene().selectedItems() if isinstance(item, LayerGraphicsItem)
        ]
        return selected[0] if selected else None

    def select_layer(self, identifier: str) -> None:
        for item in self.items_by_id.values():
            item.setSelected(item.layer.id == identifier)
        target = self.items_by_id.get(identifier)
        if target:
            self.centerOn(target)

    def set_preview_time(self, seconds: float) -> None:
        for item in self.items_by_id.values():
            duration = item.layer.duration_seconds
            active = seconds >= item.layer.start_seconds and (
                duration is None or seconds <= item.layer.start_seconds + duration
            )
            item.setVisible(active and not item.layer.hidden)

    def drawBackground(self, painter: QPainter, rect: QRectF) -> None:
        super().drawBackground(painter, rect)
        if not self.preset:
            return
        painter.fillRect(self.scene().sceneRect(), QColor(8, 9, 12))
        if self.grid_enabled:
            painter.setPen(QPen(QColor(255, 255, 255, 22), 1))
            left = int(rect.left()) - int(rect.left()) % self.grid_size
            top = int(rect.top()) - int(rect.top()) % self.grid_size
            for x in range(left, int(rect.right()) + self.grid_size, self.grid_size):
                painter.drawLine(x, int(rect.top()), x, int(rect.bottom()))
            for y in range(top, int(rect.bottom()) + self.grid_size, self.grid_size):
                painter.drawLine(int(rect.left()), y, int(rect.right()), y)

    def drawForeground(self, painter: QPainter, rect: QRectF) -> None:
        super().drawForeground(painter, rect)
        if not self.preset or not self.safe_zones_enabled:
            return
        safe = LayoutEngine.safe_zone_rect(self.preset)
        painter.setPen(QPen(QColor(40, 175, 255, 180), 3, Qt.PenStyle.DashLine))
        painter.drawRect(QRectF(safe.x, safe.y, safe.width, safe.height))
        platform_safe = LayoutEngine.platform_ui_safe_zone_rect(self.preset)
        painter.setPen(QPen(QColor(255, 168, 55, 180), 3, Qt.PenStyle.DashDotLine))
        painter.drawRect(
            QRectF(
                platform_safe.x,
                platform_safe.y,
                platform_safe.width,
                platform_safe.height,
            )
        )
        painter.drawText(
            platform_safe.x + 8,
            platform_safe.y + 28,
            f"{self.preset.platform.title()} UI safe area",
        )
        selected = self.selected_layer_item()
        if selected:
            center = selected.sceneBoundingRect().center()
            canvas_center = self.scene().sceneRect().center()
            painter.setPen(QPen(QColor(90, 255, 175, 145), 2, Qt.PenStyle.DashLine))
            if abs(center.x() - canvas_center.x()) <= self.grid_size:
                painter.drawLine(
                    int(canvas_center.x()),
                    0,
                    int(canvas_center.x()),
                    self.preset.height,
                )
            if abs(center.y() - canvas_center.y()) <= self.grid_size:
                painter.drawLine(
                    0,
                    int(canvas_center.y()),
                    self.preset.width,
                    int(canvas_center.y()),
                )


class PresetEditorWidget(QWidget):
    preset_changed = Signal(object)
    save_requested = Signal(object)

    def __init__(
        self,
        style_profile_manager: StyleProfileManager | None = None,
    ):
        super().__init__()
        self.preset: Preset | None = None
        self.style_profile_manager = style_profile_manager
        self._updating_properties = False
        self.asset_options: dict[str, tuple[str, str]] = {}
        root = QVBoxLayout(self)
        toolbar = QHBoxLayout()
        self.zoom_out = QPushButton("−")
        self.zoom_in = QPushButton("+")
        self.fit_button = QPushButton("Fit")
        self.grid_check = QCheckBox("Grid")
        self.grid_check.setChecked(True)
        self.snap_check = QCheckBox("Snap")
        self.snap_check.setChecked(True)
        self.safe_check = QCheckBox("Safe zones")
        self.safe_check.setChecked(True)
        for widget in (
            self.zoom_out,
            self.zoom_in,
            self.fit_button,
            self.grid_check,
            self.snap_check,
            self.safe_check,
        ):
            toolbar.addWidget(widget)
        toolbar.addStretch()
        self.style_profiles_button = QPushButton("Style Profiles…")
        self.style_profiles_button.setEnabled(style_profile_manager is not None)
        toolbar.addWidget(self.style_profiles_button)
        self.contract_button = QPushButton("Preset Contract…")
        toolbar.addWidget(self.contract_button)
        self.save_button = QPushButton("Save Preset")
        toolbar.addWidget(self.save_button)
        root.addLayout(toolbar)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.addWidget(QLabel("Layers"))
        self.layer_list = QListWidget()
        self.layer_list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        left_layout.addWidget(self.layer_list)
        add_row = QHBoxLayout()
        self.add_type = QComboBox()
        supported_layer_types = [
            ElementType.VIDEO,
            ElementType.BACKGROUND,
            ElementType.IMAGE,
            ElementType.MEME,
            ElementType.HEADER,
            ElementType.RICH_TEXT,
            ElementType.RANKING_NUMBER,
            ElementType.DYNAMIC_CAPTION,
            ElementType.SUBTITLE,
            ElementType.AUDIO,
            ElementType.MUSIC,
            ElementType.SOUND_EFFECT,
            ElementType.SHAPE,
        ]
        for element_type in supported_layer_types:
            self.add_type.addItem(element_type.value.replace("_", " ").title(), element_type)
        self.add_button = QPushButton("Add Layer")
        add_row.addWidget(self.add_type, 1)
        add_row.addWidget(self.add_button)
        left_layout.addLayout(add_row)
        layer_buttons = QHBoxLayout()
        self.duplicate_button = QPushButton("Duplicate")
        self.delete_button = QPushButton("Delete")
        self.raise_button = QPushButton("Up")
        self.lower_button = QPushButton("Down")
        for button in (
            self.duplicate_button,
            self.delete_button,
            self.raise_button,
            self.lower_button,
        ):
            layer_buttons.addWidget(button)
        left_layout.addLayout(layer_buttons)
        splitter.addWidget(left)

        self.canvas = PresetCanvas()
        splitter.addWidget(self.canvas)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.addWidget(QLabel("Selected Element"))
        form = QFormLayout()
        self.property_form = form
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.element_name = QLabel("—")
        self.x_spin = self._ratio_spin()
        self.y_spin = self._ratio_spin()
        self.width_spin = self._ratio_spin()
        self.height_spin = self._ratio_spin()
        self.rotation_spin = QDoubleSpinBox()
        self.rotation_spin.setRange(-180, 180)
        self.rotation_spin.setSuffix("°")
        self.opacity_spin = QDoubleSpinBox()
        self.opacity_spin.setRange(0, 1)
        self.opacity_spin.setSingleStep(0.05)
        self.start_spin = QDoubleSpinBox()
        self.start_spin.setRange(0, 7200)
        self.start_spin.setSuffix(" s")
        self.duration_spin = QDoubleSpinBox()
        self.duration_spin.setRange(0, 7200)
        self.duration_spin.setSpecialValueText("Full video")
        self.duration_spin.setSuffix(" s")
        self.volume_spin = QDoubleSpinBox()
        self.volume_spin.setRange(0, 2)
        self.volume_spin.setSingleStep(0.05)
        self.enter_animation = QComboBox()
        self.enter_animation.addItems(["none", "fade", "slide", "zoom"])
        self.exit_animation = QComboBox()
        self.exit_animation.addItems(["none", "fade", "slide", "zoom"])
        self.lock_check = QCheckBox()
        self.hide_check = QCheckBox()
        self.asset_combo = QComboBox()
        self.style_profile_row = QWidget()
        style_profile_layout = QHBoxLayout(self.style_profile_row)
        style_profile_layout.setContentsMargins(0, 0, 0, 0)
        self.style_profile_combo = QComboBox()
        self.style_profile_combo.setMinimumContentsLength(18)
        self.save_style_profile_button = QPushButton("Save as New…")
        style_profile_layout.addWidget(self.style_profile_combo, 1)
        style_profile_layout.addWidget(self.save_style_profile_button)
        self.layer_color_button = QPushButton("Layer color…")
        self.font_combo = QFontComboBox()
        self.font_size = QDoubleSpinBox()
        self.font_size.setRange(6, 300)
        self.font_size.setSuffix(" pt")
        self.style_row = QWidget()
        style_layout = QHBoxLayout(self.style_row)
        style_layout.setContentsMargins(0, 0, 0, 0)
        self.bold_button = QToolButton()
        self.bold_button.setText("B")
        self.bold_button.setCheckable(True)
        self.italic_button = QToolButton()
        self.italic_button.setText("I")
        self.italic_button.setCheckable(True)
        self.underline_button = QToolButton()
        self.underline_button.setText("U")
        self.underline_button.setCheckable(True)
        self.color_button = QPushButton("Color wheel…")
        for button in (
            self.bold_button,
            self.italic_button,
            self.underline_button,
            self.color_button,
        ):
            style_layout.addWidget(button)
        self.outline_color_button = QPushButton("Outline color…")
        self.background_color_button = QPushButton("Background color…")
        self.outline_width = QDoubleSpinBox()
        self.outline_width.setRange(0, 30)
        self.outline_width.setSingleStep(0.5)
        self.shadow_check = QCheckBox()
        self.shadow_distance = QDoubleSpinBox()
        self.shadow_distance.setRange(0, 50)
        self.shadow_distance.setSingleStep(0.5)
        self.shadow_blur = QDoubleSpinBox()
        self.shadow_blur.setRange(0, 50)
        self.shadow_blur.setSingleStep(0.5)
        self.glow_check = QCheckBox()
        self.glow_color_button = QPushButton("Glow color…")
        self.glow_radius = QDoubleSpinBox()
        self.glow_radius.setRange(0, 50)
        self.glow_radius.setSingleStep(0.5)
        self.glow_intensity = QDoubleSpinBox()
        self.glow_intensity.setRange(0, 1)
        self.glow_intensity.setSingleStep(0.05)
        self.responsive_scale = QCheckBox()
        self.reference_height = QSpinBox()
        self.reference_height.setRange(240, 7680)
        self.reference_height.setSuffix(" px")
        self.letter_spacing = QDoubleSpinBox()
        self.letter_spacing.setRange(-20, 100)
        self.line_spacing = QDoubleSpinBox()
        self.line_spacing.setRange(0.5, 4)
        self.line_spacing.setSingleStep(0.1)
        self.alignment = QComboBox()
        self.alignment.addItems(["left", "center", "right"])
        self.transform = QComboBox()
        self.transform.addItems(["none", "uppercase", "lowercase", "title"])
        self._outline_color = QColor(0, 0, 0)
        self._background_color = QColor(0, 0, 0, 0)
        self._glow_color = QColor()
        form.addRow("Name", self.element_name)
        form.addRow("X", self.x_spin)
        form.addRow("Y", self.y_spin)
        form.addRow("Width", self.width_spin)
        form.addRow("Height", self.height_spin)
        form.addRow("Rotation", self.rotation_spin)
        form.addRow("Opacity", self.opacity_spin)
        form.addRow("Start time", self.start_spin)
        form.addRow("Duration", self.duration_spin)
        form.addRow("Audio volume", self.volume_spin)
        form.addRow("Enter animation", self.enter_animation)
        form.addRow("Exit animation", self.exit_animation)
        form.addRow("Locked", self.lock_check)
        form.addRow("Hidden", self.hide_check)
        form.addRow("Asset", self.asset_combo)
        form.addRow("Style profile", self.style_profile_row)
        form.addRow("Layer background", self.layer_color_button)
        form.addRow("Font", self.font_combo)
        form.addRow("Size", self.font_size)
        form.addRow("Selection style", self.style_row)
        form.addRow("Outline color", self.outline_color_button)
        form.addRow("Outline width", self.outline_width)
        form.addRow("Shadow", self.shadow_check)
        form.addRow("Shadow distance", self.shadow_distance)
        form.addRow("Shadow blur", self.shadow_blur)
        form.addRow("Glow", self.glow_check)
        form.addRow("Glow color", self.glow_color_button)
        form.addRow("Glow radius", self.glow_radius)
        form.addRow("Glow intensity", self.glow_intensity)
        form.addRow("Scale with output height", self.responsive_scale)
        form.addRow("Reference height", self.reference_height)
        form.addRow("Text background", self.background_color_button)
        form.addRow("Letter spacing", self.letter_spacing)
        form.addRow("Line spacing", self.line_spacing)
        form.addRow("Alignment", self.alignment)
        form.addRow("Text transform", self.transform)
        right_layout.addLayout(form)
        align_row = QHBoxLayout()
        self.center_h = QPushButton("Center H")
        self.center_v = QPushButton("Center V")
        align_row.addWidget(self.center_h)
        align_row.addWidget(self.center_v)
        right_layout.addLayout(align_row)
        self.editor_hint = QLabel(
            "Double-click text in the canvas, select any characters, then apply font, size, emphasis, or color."
        )
        self.editor_hint.setWordWrap(True)
        right_layout.addWidget(self.editor_hint)
        right_layout.addStretch()
        self.properties_scroll = QScrollArea()
        self.properties_scroll.setObjectName("presetEditorScrollArea")
        self.properties_scroll.setWidgetResizable(True)
        self.properties_scroll.setMinimumWidth(320)
        self.properties_scroll.setWidget(right)
        splitter.addWidget(self.properties_scroll)
        splitter.setSizes([210, 700, 330])
        root.addWidget(splitter, 1)

        timeline = QHBoxLayout()
        timeline.addWidget(QLabel("Preview time"))
        self.timeline = QSlider(Qt.Orientation.Horizontal)
        self.timeline.setRange(0, 65000)
        self.timeline_label = QLabel("0.0 s")
        timeline.addWidget(self.timeline, 1)
        timeline.addWidget(self.timeline_label)
        root.addLayout(timeline)
        self._connect()

    @staticmethod
    def _ratio_spin() -> QDoubleSpinBox:
        value = QDoubleSpinBox()
        value.setRange(0, 1)
        value.setDecimals(4)
        value.setSingleStep(0.01)
        return value

    def load_preset(self, preset: Preset) -> None:
        self.preset = preset.model_copy(deep=True)
        self._refresh_layers()
        self.canvas.load_preset(self.preset)
        self.timeline.setRange(0, round(self.preset.duration.maximum_seconds * 1000))
        if self.preset.layers:
            self.layer_list.setCurrentRow(0)

    def current_preset(self) -> Preset | None:
        self._sync_active_text()
        return self.preset

    def _connect(self) -> None:
        self.zoom_out.clicked.connect(lambda: self.canvas.zoom_by(0.85))
        self.zoom_in.clicked.connect(lambda: self.canvas.zoom_by(1.15))
        self.fit_button.clicked.connect(self.canvas.fit_canvas)
        self.grid_check.toggled.connect(self._toggle_grid)
        self.snap_check.toggled.connect(self._toggle_snap)
        self.safe_check.toggled.connect(self._toggle_safe)
        self.contract_button.clicked.connect(self._edit_contract)
        self.style_profiles_button.clicked.connect(self._edit_style_profiles)
        self.layer_list.currentItemChanged.connect(self._list_selection_changed)
        self.canvas.layer_selected.connect(self._canvas_selection_changed)
        self.canvas.layer_geometry_changed.connect(self._geometry_changed)
        self.canvas.layer_text_changed.connect(self._text_changed)
        self.save_button.clicked.connect(self._save)
        self.add_button.clicked.connect(self._add_layer)
        self.duplicate_button.clicked.connect(self._duplicate)
        self.delete_button.clicked.connect(self._delete)
        self.raise_button.clicked.connect(lambda: self._change_z(1))
        self.lower_button.clicked.connect(lambda: self._change_z(-1))
        for spin in (
            self.x_spin,
            self.y_spin,
            self.width_spin,
            self.height_spin,
            self.rotation_spin,
            self.opacity_spin,
            self.start_spin,
            self.duration_spin,
            self.volume_spin,
        ):
            spin.valueChanged.connect(self._properties_changed)
        self.enter_animation.currentTextChanged.connect(self._properties_changed)
        self.exit_animation.currentTextChanged.connect(self._properties_changed)
        self.lock_check.toggled.connect(self._properties_changed)
        self.hide_check.toggled.connect(self._properties_changed)
        self.asset_combo.currentIndexChanged.connect(self._asset_changed)
        self.style_profile_combo.currentIndexChanged.connect(self._apply_selected_style_profile)
        self.save_style_profile_button.clicked.connect(self._save_active_style_profile)
        self.layer_color_button.clicked.connect(self._choose_layer_color)
        self.font_combo.currentFontChanged.connect(self._apply_font)
        self.font_size.valueChanged.connect(self._apply_size)
        self.bold_button.toggled.connect(self._apply_emphasis)
        self.italic_button.toggled.connect(self._apply_emphasis)
        self.underline_button.toggled.connect(self._apply_emphasis)
        self.color_button.clicked.connect(self._choose_color)
        self.outline_color_button.clicked.connect(self._choose_outline_color)
        self.background_color_button.clicked.connect(self._choose_background_color)
        self.glow_color_button.clicked.connect(self._choose_glow_color)
        self.outline_width.valueChanged.connect(self._apply_advanced_text_style)
        self.shadow_check.toggled.connect(self._apply_advanced_text_style)
        self.shadow_distance.valueChanged.connect(self._apply_advanced_text_style)
        self.shadow_blur.valueChanged.connect(self._apply_advanced_text_style)
        self.glow_check.toggled.connect(self._apply_advanced_text_style)
        self.glow_radius.valueChanged.connect(self._apply_advanced_text_style)
        self.glow_intensity.valueChanged.connect(self._apply_advanced_text_style)
        self.responsive_scale.toggled.connect(self._apply_advanced_text_style)
        self.reference_height.valueChanged.connect(self._apply_advanced_text_style)
        self.letter_spacing.valueChanged.connect(self._apply_advanced_text_style)
        self.line_spacing.valueChanged.connect(self._apply_advanced_text_style)
        self.alignment.currentTextChanged.connect(self._apply_advanced_text_style)
        self.transform.currentTextChanged.connect(self._apply_advanced_text_style)
        self.center_h.clicked.connect(lambda: self._center(True))
        self.center_v.clicked.connect(lambda: self._center(False))
        self.timeline.valueChanged.connect(self._timeline_changed)

    def _active_layer(self) -> PresetLayer | None:
        item = self.layer_list.currentItem()
        if not item or not self.preset:
            return None
        identifier = item.data(Qt.ItemDataRole.UserRole)
        return next((layer for layer in self.preset.layers if layer.id == identifier), None)

    def set_assets(self, values: dict[str, tuple[str, str]]) -> None:
        self.asset_options = values
        active = self._active_layer()
        current = active.asset_id if active else None
        self._updating_properties = True
        try:
            self.asset_combo.clear()
            self.asset_combo.addItem("No asset", None)
            for identifier, (label, _path) in sorted(values.items(), key=lambda item: item[1][0]):
                self.asset_combo.addItem(label, identifier)
            self.asset_combo.setCurrentIndex(max(0, self.asset_combo.findData(current)))
            self.canvas.asset_paths = {
                identifier: path for identifier, (_label, path) in values.items()
            }
            if self.preset:
                self.canvas.load_preset(self.preset)
        finally:
            self._updating_properties = False

    def _active_item(self) -> LayerGraphicsItem | None:
        layer = self._active_layer()
        return self.canvas.items_by_id.get(layer.id) if layer else None

    def _refresh_layers(self) -> None:
        self.layer_list.clear()
        if not self.preset:
            return
        for layer in sorted(self.preset.layers, key=lambda value: value.z_index, reverse=True):
            marker = "🔒 " if layer.locked else ""
            marker += "◌ " if layer.hidden else ""
            item = QListWidgetItem(f"{marker}{layer.name}")
            item.setData(Qt.ItemDataRole.UserRole, layer.id)
            self.layer_list.addItem(item)

    def _list_selection_changed(
        self, current: QListWidgetItem | None, _previous: QListWidgetItem | None
    ) -> None:
        if current:
            identifier = current.data(Qt.ItemDataRole.UserRole)
            self.canvas.select_layer(identifier)
            self._populate_properties()

    def _canvas_selection_changed(self, identifier: str) -> None:
        for index in range(self.layer_list.count()):
            item = self.layer_list.item(index)
            if item.data(Qt.ItemDataRole.UserRole) == identifier:
                self.layer_list.setCurrentItem(item)
                break

    def _populate_properties(self) -> None:
        layer = self._active_layer()
        self._updating_properties = True
        try:
            if not layer:
                self.element_name.setText("—")
                return
            self.element_name.setText(layer.name)
            self.x_spin.setValue(layer.bounds.x)
            self.y_spin.setValue(layer.bounds.y)
            self.width_spin.setValue(layer.bounds.width)
            self.height_spin.setValue(layer.bounds.height)
            self.rotation_spin.setValue(layer.rotation_degrees)
            self.opacity_spin.setValue(layer.opacity)
            self.start_spin.setValue(layer.start_seconds)
            self.duration_spin.setValue(layer.duration_seconds or 0)
            self.volume_spin.setValue(layer.volume)
            self.enter_animation.setCurrentText(layer.enter_animation)
            self.exit_animation.setCurrentText(layer.exit_animation)
            self.lock_check.setChecked(layer.locked)
            self.hide_check.setChecked(layer.hidden)
            self._populate_asset_combo(layer)
            self._populate_style_profile_combo(layer)
            layer_color = qcolor(layer.background_color)
            self.layer_color_button.setStyleSheet(f"background: {layer_color.name()};")
            text_enabled = (
                layer.rich_text is not None and layer.element_type != ElementType.SUBTITLE
            )
            for widget in (
                self.font_combo,
                self.font_size,
                self.bold_button,
                self.italic_button,
                self.underline_button,
                self.color_button,
                self.outline_color_button,
                self.outline_width,
                self.shadow_check,
                self.shadow_distance,
                self.shadow_blur,
                self.glow_check,
                self.glow_color_button,
                self.glow_radius,
                self.glow_intensity,
                self.responsive_scale,
                self.reference_height,
                self.background_color_button,
                self.letter_spacing,
                self.line_spacing,
                self.alignment,
                self.transform,
            ):
                widget.setEnabled(text_enabled)
            if layer.rich_text:
                style = layer.rich_text.default_style
                self.font_combo.setCurrentFont(QFont(style.font_family))
                self.font_size.setValue(style.font_size)
                self.bold_button.setChecked(style.bold)
                self.italic_button.setChecked(style.italic)
                self.underline_button.setChecked(style.underline)
                self._outline_color = qcolor(style.outline)
                self._background_color = qcolor(style.background)
                self.outline_color_button.setStyleSheet(
                    f"background: {self._outline_color.name()};"
                )
                self.background_color_button.setStyleSheet(
                    f"background: {self._background_color.name()};"
                )
                self.outline_width.setValue(style.outline_width)
                self.shadow_check.setChecked(style.shadow_enabled)
                self.shadow_distance.setValue(style.shadow_distance)
                self.shadow_blur.setValue(style.shadow_blur)
                self.glow_check.setChecked(style.glow_enabled)
                self._glow_color = qcolor(style.glow_color) if style.glow_color else QColor()
                self.glow_color_button.setText(
                    style.glow_color.to_hex() if style.glow_color else "Use text color"
                )
                self.glow_color_button.setStyleSheet(
                    f"background: {self._glow_color.name()};" if self._glow_color.isValid() else ""
                )
                self.glow_radius.setValue(style.glow_radius)
                self.glow_intensity.setValue(style.glow_intensity)
                self.responsive_scale.setChecked(style.scale_with_canvas)
                self.reference_height.setValue(style.reference_height)
                self.letter_spacing.setValue(style.letter_spacing)
                self.line_spacing.setValue(style.line_spacing)
                self.alignment.setCurrentText(style.alignment)
                self.transform.setCurrentText(style.transform)
            geometry_enabled = layer.element_type not in {
                ElementType.BACKGROUND,
                ElementType.AUDIO,
                ElementType.MUSIC,
                ElementType.SOUND_EFFECT,
                ElementType.SUBTITLE,
            }
            rotation_enabled = layer.element_type in {
                ElementType.IMAGE,
                ElementType.MEME,
                ElementType.HEADER,
                ElementType.RICH_TEXT,
                ElementType.RANKING_NUMBER,
                ElementType.DYNAMIC_CAPTION,
                ElementType.SHAPE,
            }
            timing_enabled = layer.element_type in {
                ElementType.IMAGE,
                ElementType.MEME,
                ElementType.HEADER,
                ElementType.RICH_TEXT,
                ElementType.DYNAMIC_CAPTION,
                ElementType.AUDIO,
                ElementType.SOUND_EFFECT,
                ElementType.SHAPE,
            }
            audio_enabled = layer.element_type in {
                ElementType.AUDIO,
                ElementType.SOUND_EFFECT,
            }
            animation_enabled = layer.element_type in {
                ElementType.HEADER,
                ElementType.RICH_TEXT,
                ElementType.RANKING_NUMBER,
                ElementType.DYNAMIC_CAPTION,
            }
            color_enabled = layer.element_type in {
                ElementType.BACKGROUND,
                ElementType.HEADER,
                ElementType.RICH_TEXT,
                ElementType.RANKING_NUMBER,
                ElementType.DYNAMIC_CAPTION,
                ElementType.SHAPE,
            }
            asset_enabled = self.asset_combo.isEnabled()
            for widget in (self.x_spin, self.y_spin, self.width_spin, self.height_spin):
                self._set_property_row_visible(widget, geometry_enabled)
            for widget in (self.rotation_spin, self.opacity_spin):
                self._set_property_row_visible(widget, rotation_enabled)
            for widget in (self.start_spin, self.duration_spin):
                self._set_property_row_visible(widget, timing_enabled)
            self._set_property_row_visible(self.volume_spin, audio_enabled)
            for widget in (self.enter_animation, self.exit_animation):
                self._set_property_row_visible(widget, animation_enabled)
            self._set_property_row_visible(self.asset_combo, asset_enabled)
            self._set_property_row_visible(
                self.style_profile_row,
                self._style_kind_for_layer(layer) is not None and not layer.hidden,
            )
            self._set_property_row_visible(self.layer_color_button, color_enabled)
            for widget in (
                self.font_combo,
                self.font_size,
                self.style_row,
                self.outline_color_button,
                self.outline_width,
                self.shadow_check,
                self.shadow_distance,
                self.shadow_blur,
                self.glow_check,
                self.glow_color_button,
                self.glow_radius,
                self.glow_intensity,
                self.responsive_scale,
                self.reference_height,
                self.background_color_button,
                self.letter_spacing,
                self.line_spacing,
                self.alignment,
                self.transform,
            ):
                self._set_property_row_visible(widget, text_enabled)
        finally:
            self._updating_properties = False

    def _geometry_changed(self, identifier: str, bounds: dict[str, float]) -> None:
        if not self.preset:
            return
        layer = next((value for value in self.preset.layers if value.id == identifier), None)
        if layer:
            layer.bounds = layer.bounds.model_copy(update=bounds)
            self._populate_properties()
            self.preset_changed.emit(self.preset)

    def _text_changed(self, identifier: str) -> None:
        if not self.preset:
            return
        layer = next((value for value in self.preset.layers if value.id == identifier), None)
        item = self.canvas.items_by_id.get(identifier)
        if layer and item:
            layer.rich_text = item.to_rich_text()
            self._populate_style_profile_combo(layer)
            self.preset_changed.emit(self.preset)

    def _properties_changed(self) -> None:
        if self._updating_properties:
            return
        layer = self._active_layer()
        item = self._active_item()
        if not layer or not item:
            return
        width = min(self.width_spin.value(), 1 - self.x_spin.value())
        height = min(self.height_spin.value(), 1 - self.y_spin.value())
        layer.bounds = layer.bounds.model_copy(
            update={
                "x": self.x_spin.value(),
                "y": self.y_spin.value(),
                "width": max(0.001, width),
                "height": max(0.001, height),
            }
        )
        layer.rotation_degrees = self.rotation_spin.value()
        layer.opacity = self.opacity_spin.value()
        layer.start_seconds = self.start_spin.value()
        layer.duration_seconds = self.duration_spin.value() or None
        layer.volume = self.volume_spin.value()
        layer.enter_animation = self.enter_animation.currentText()
        layer.exit_animation = self.exit_animation.currentText()
        layer.locked = self.lock_check.isChecked()
        layer.hidden = self.hide_check.isChecked()
        item.setRotation(layer.rotation_degrees)
        item.setOpacity(layer.opacity)
        item.setVisible(not layer.hidden)
        item.setFlag(QGraphicsObject.GraphicsItemFlag.ItemIsMovable, not layer.locked)
        item.setFlag(QGraphicsObject.GraphicsItemFlag.ItemIsSelectable, not layer.locked)
        item.set_layer_bounds()
        self._refresh_layers_preserve(layer.id)
        self.preset_changed.emit(self.preset)

    def _apply_font(self, font: QFont) -> None:
        if self._updating_properties:
            return
        item = self._active_item()
        layer = self._active_layer()
        if not item or not layer or not layer.rich_text:
            return
        char_format = QTextCharFormat()
        char_format.setFontFamilies([font.family()])
        item.apply_char_format(char_format)
        layer.rich_text = item.to_rich_text()

    def _asset_changed(self) -> None:
        if self._updating_properties:
            return
        layer = self._active_layer()
        if not layer or not self.preset:
            return
        layer.asset_id = self.asset_combo.currentData()
        self.canvas.load_preset(self.preset)
        self._refresh_layers_preserve(layer.id)
        self.preset_changed.emit(self.preset)

    def _apply_size(self, value: float) -> None:
        if self._updating_properties:
            return
        item = self._active_item()
        if item and item.text_item:
            char_format = QTextCharFormat()
            char_format.setFontPointSize(value)
            item.apply_char_format(char_format)
            self._text_changed(item.layer.id)

    def _apply_emphasis(self) -> None:
        if self._updating_properties:
            return
        item = self._active_item()
        if item and item.text_item:
            char_format = QTextCharFormat()
            char_format.setFontWeight(
                QFont.Weight.Bold if self.bold_button.isChecked() else QFont.Weight.Normal
            )
            char_format.setFontItalic(self.italic_button.isChecked())
            char_format.setFontUnderline(self.underline_button.isChecked())
            item.apply_char_format(char_format)
            self._text_changed(item.layer.id)

    def _choose_color(self) -> None:
        layer = self._active_layer()
        item = self._active_item()
        if not layer or not layer.rich_text or not item:
            return
        initial = qcolor(layer.rich_text.default_style.foreground)
        color = QColorDialog.getColor(
            initial, self, "Choose text color", QColorDialog.ColorDialogOption.ShowAlphaChannel
        )
        if not color.isValid():
            return
        char_format = QTextCharFormat()
        char_format.setForeground(color)
        item.apply_char_format(char_format)
        layer.rich_text = item.to_rich_text()
        self.color_button.setStyleSheet(f"background: {color.name()};")
        self.preset_changed.emit(self.preset)

    def _choose_layer_color(self) -> None:
        layer = self._active_layer()
        if not layer or not self.preset:
            return
        color = QColorDialog.getColor(
            qcolor(layer.background_color),
            self,
            "Choose layer background color",
            QColorDialog.ColorDialogOption.ShowAlphaChannel,
        )
        if not color.isValid():
            return
        layer.background_color = model_color(color)
        self.layer_color_button.setStyleSheet(f"background: {color.name()};")
        self.canvas.load_preset(self.preset)
        self._refresh_layers_preserve(layer.id)
        self.preset_changed.emit(self.preset)

    def _choose_outline_color(self) -> None:
        color = QColorDialog.getColor(
            self._outline_color,
            self,
            "Choose outline color",
            QColorDialog.ColorDialogOption.ShowAlphaChannel,
        )
        if color.isValid():
            self._outline_color = color
            self.outline_color_button.setStyleSheet(f"background: {color.name()};")
            self._apply_advanced_text_style()

    def _choose_background_color(self) -> None:
        color = QColorDialog.getColor(
            self._background_color,
            self,
            "Choose text background color",
            QColorDialog.ColorDialogOption.ShowAlphaChannel,
        )
        if color.isValid():
            self._background_color = color
            self.background_color_button.setStyleSheet(f"background: {color.name()};")
            self._apply_advanced_text_style()

    def _choose_glow_color(self) -> None:
        initial = self._glow_color if self._glow_color.isValid() else QColor(255, 255, 255)
        color = QColorDialog.getColor(
            initial,
            self,
            "Choose glow color",
            QColorDialog.ColorDialogOption.ShowAlphaChannel,
        )
        if color.isValid():
            self._glow_color = color
            self.glow_color_button.setText(color.name(QColor.NameFormat.HexArgb))
            self.glow_color_button.setStyleSheet(f"background: {color.name()};")
            self._apply_advanced_text_style()

    def _apply_advanced_text_style(self) -> None:
        if self._updating_properties:
            return
        item = self._active_item()
        layer = self._active_layer()
        if not item or not item.text_item or not layer:
            return
        char_format = QTextCharFormat()
        char_format.setTextOutline(QPen(self._outline_color, self.outline_width.value()))
        char_format.setBackground(self._background_color)
        char_format.setFontLetterSpacing(self.letter_spacing.value())
        char_format.setProperty(STYLE_SHADOW_PROPERTY, self.shadow_check.isChecked())
        char_format.setProperty(STYLE_SHADOW_DISTANCE_PROPERTY, self.shadow_distance.value())
        char_format.setProperty(STYLE_SHADOW_BLUR_PROPERTY, self.shadow_blur.value())
        char_format.setProperty(STYLE_GLOW_ENABLED_PROPERTY, self.glow_check.isChecked())
        char_format.setProperty(
            STYLE_GLOW_COLOR_PROPERTY,
            self._glow_color if self._glow_color.isValid() else QColor(),
        )
        char_format.setProperty(STYLE_GLOW_RADIUS_PROPERTY, self.glow_radius.value())
        char_format.setProperty(STYLE_GLOW_INTENSITY_PROPERTY, self.glow_intensity.value())
        char_format.setProperty(STYLE_SCALE_PROPERTY, self.responsive_scale.isChecked())
        char_format.setProperty(STYLE_REFERENCE_HEIGHT_PROPERTY, self.reference_height.value())
        char_format.setProperty(STYLE_LINE_SPACING_PROPERTY, self.line_spacing.value())
        char_format.setProperty(STYLE_ALIGNMENT_PROPERTY, self.alignment.currentText())
        char_format.setProperty(STYLE_TRANSFORM_PROPERTY, self.transform.currentText())
        item.apply_char_format(char_format)
        self._text_changed(item.layer.id)
        if layer.rich_text:
            item._apply_text_effect(layer.rich_text.default_style)

    def _duplicate(self) -> None:
        layer = self._active_layer()
        if not self.preset or not layer:
            return
        clone = layer.model_copy(deep=True)
        clone.id = f"{layer.id}-{uuid4().hex[:8]}"
        clone.name = f"{layer.name} Copy"
        clone.z_index = max(value.z_index for value in self.preset.layers) + 1
        clone.bounds.x = min(1 - clone.bounds.width, clone.bounds.x + 0.02)
        clone.bounds.y = min(1 - clone.bounds.height, clone.bounds.y + 0.02)
        self.preset.layers.append(clone)
        self.canvas.load_preset(self.preset)
        self._refresh_layers_preserve(clone.id)
        self.preset_changed.emit(self.preset)

    def _add_layer(self) -> None:
        if not self.preset:
            return
        element_type = self.add_type.currentData()
        text_types = {
            ElementType.HEADER,
            ElementType.RICH_TEXT,
            ElementType.RANKING_NUMBER,
            ElementType.DYNAMIC_CAPTION,
            ElementType.SUBTITLE,
        }
        full_canvas = element_type == ElementType.BACKGROUND
        layer = PresetLayer(
            id=f"{element_type.value}-{uuid4().hex[:8]}",
            name=element_type.value.replace("_", " ").title(),
            element_type=element_type,
            bounds=(
                Rect(x=0, y=0, width=1, height=1)
                if full_canvas
                else Rect(x=0.10, y=0.10, width=0.80, height=0.15)
            ),
            z_index=max((value.z_index for value in self.preset.layers), default=0) + 10,
            rich_text=(
                RichTextDocument(text="Edit text", default_style=TextStyle())
                if element_type in text_types
                else None
            ),
            background_color=(
                Color(red=40, green=40, blue=48)
                if element_type in {ElementType.BACKGROUND, ElementType.SHAPE}
                else Color(red=0, green=0, blue=0, alpha=0)
            ),
        )
        self.preset.layers.append(layer)
        self.canvas.load_preset(self.preset)
        self._refresh_layers_preserve(layer.id)
        self.preset_changed.emit(self.preset)

    def _delete(self) -> None:
        layer = self._active_layer()
        if not self.preset or not layer:
            return
        self.preset.layers = [value for value in self.preset.layers if value.id != layer.id]
        self.canvas.load_preset(self.preset)
        self._refresh_layers()
        self.preset_changed.emit(self.preset)

    def _change_z(self, delta: int) -> None:
        layer = self._active_layer()
        if not self.preset or not layer:
            return
        ordered = sorted(self.preset.layers, key=lambda value: value.z_index)
        index = ordered.index(layer)
        target = max(0, min(len(ordered) - 1, index + delta))
        if target == index:
            return
        ordered[index], ordered[target] = ordered[target], ordered[index]
        for z_index, value in enumerate(ordered):
            value.z_index = z_index * 10
        self.canvas.load_preset(self.preset)
        self._refresh_layers_preserve(layer.id)
        self.preset_changed.emit(self.preset)

    def _center(self, horizontal: bool) -> None:
        layer = self._active_layer()
        item = self._active_item()
        if not layer or not item:
            return
        if horizontal:
            layer.bounds.x = (1 - layer.bounds.width) / 2
        else:
            layer.bounds.y = (1 - layer.bounds.height) / 2
        item.set_layer_bounds()
        self._populate_properties()
        self.preset_changed.emit(self.preset)

    def _toggle_grid(self, enabled: bool) -> None:
        self.canvas.grid_enabled = enabled
        self.canvas.viewport().update()

    def _toggle_snap(self, enabled: bool) -> None:
        self.canvas.snap_enabled = enabled
        for item in self.canvas.items_by_id.values():
            item.snap_enabled = enabled

    def _toggle_safe(self, enabled: bool) -> None:
        self.canvas.safe_zones_enabled = enabled
        self.canvas.viewport().update()

    def _timeline_changed(self, value: int) -> None:
        self.timeline_label.setText(f"{value / 1000:.1f} s")
        self.canvas.set_preview_time(value / 1000)

    def _edit_contract(self) -> None:
        if not self.preset:
            return
        dialog = PresetContractDialog(self.preset, self.asset_options, self)
        if dialog.exec() == dialog.DialogCode.Accepted and dialog.result_preset:
            self.preset = dialog.result_preset
            self._refresh_layers()
            self.canvas.load_preset(self.preset)
            self.timeline.setRange(0, round(self.preset.duration.maximum_seconds * 1000))
            self.preset_changed.emit(self.preset)

    def _edit_style_profiles(self) -> None:
        if not self.preset or not self.style_profile_manager:
            return
        dialog = StyleProfilesDialog(
            self.preset,
            self.style_profile_manager,
            self,
        )
        if dialog.exec() == dialog.DialogCode.Accepted and dialog.result_preset:
            self.preset = dialog.result_preset
            self._refresh_layers()
            self.canvas.load_preset(self.preset)
            self.preset_changed.emit(self.preset)

    def _populate_style_profile_combo(self, layer: PresetLayer) -> None:
        combo = self.style_profile_combo
        combo.blockSignals(True)
        try:
            combo.clear()
            kind = self._style_kind_for_layer(layer)
            if kind is None or layer.hidden or not self.preset or not self.style_profile_manager:
                combo.addItem("Not available for this layer", None)
                combo.setEnabled(False)
                self.save_style_profile_button.setEnabled(False)
                return
            profiles = self.style_profile_manager.list(kind)
            if not profiles:
                self.style_profile_manager.ensure_core_profiles()
                profiles = self.style_profile_manager.list(kind)
            matching = self.style_profile_manager.matching_profile(self.preset, kind)
            if matching is None:
                combo.addItem("Custom (unsaved)", None)
            for profile in profiles:
                prefix = "◆ " if profile.core else ""
                combo.addItem(f"{prefix}{profile.name}", profile.id)
            selected_id = matching.id if matching else None
            selected_index = combo.findData(selected_id)
            combo.setCurrentIndex(selected_index if selected_index >= 0 else 0)
            combo.setEnabled(bool(profiles))
            self.save_style_profile_button.setEnabled(True)
        finally:
            combo.blockSignals(False)

    def _apply_selected_style_profile(self) -> None:
        if self._updating_properties or not self.preset or not self.style_profile_manager:
            return
        identifier = self.style_profile_combo.currentData()
        layer = self._active_layer()
        if not identifier or not layer:
            return
        layer_id = layer.id
        try:
            self._sync_active_text()
            self.preset = self.style_profile_manager.apply(self.preset, str(identifier))
            self.canvas.load_preset(self.preset)
            self._refresh_layers_preserve(layer_id)
            self.preset_changed.emit(self.preset)
        except Exception as error:
            QMessageBox.warning(self, "Style profile could not be applied", str(error))
            self._populate_properties()

    def _save_active_style_profile(self) -> None:
        layer = self._active_layer()
        kind = self._style_kind_for_layer(layer)
        if not layer or kind is None or not self.preset or not self.style_profile_manager:
            return
        name, accepted = QInputDialog.getText(
            self,
            "Save style profile",
            f"Name for this {kind.value.replace('_', ' ')} style",
        )
        if not accepted or not name.strip():
            return
        try:
            self._sync_active_text()
            profile = self.style_profile_manager.create_from_preset(
                self.preset,
                kind,
                name.strip(),
            )
            self.preset = self.style_profile_manager.apply(self.preset, profile.id)
            self.canvas.load_preset(self.preset)
            self._refresh_layers_preserve(layer.id)
            self.preset_changed.emit(self.preset)
        except Exception as error:
            QMessageBox.warning(self, "Style profile was not saved", str(error))

    @staticmethod
    def _style_kind_for_layer(layer: PresetLayer | None) -> StyleProfileKind | None:
        if layer is None:
            return None
        return {
            ElementType.RANKING_NUMBER: StyleProfileKind.RANKING_NUMBERS,
            ElementType.DYNAMIC_CAPTION: StyleProfileKind.CAPTIONS,
            ElementType.HEADER: StyleProfileKind.HEADER,
        }.get(layer.element_type)

    def _sync_active_text(self) -> None:
        layer = self._active_layer()
        item = self._active_item()
        if layer and item and layer.rich_text:
            layer.rich_text = item.to_rich_text()

    def _save(self) -> None:
        if self.preset:
            self._sync_active_text()
            self.save_requested.emit(self.preset)

    def _refresh_layers_preserve(self, identifier: str) -> None:
        self._refresh_layers()
        for index in range(self.layer_list.count()):
            item = self.layer_list.item(index)
            if item.data(Qt.ItemDataRole.UserRole) == identifier:
                self.layer_list.setCurrentItem(item)
                break

    def _populate_asset_combo(self, layer: PresetLayer) -> None:
        current = layer.asset_id
        allowed = {
            ElementType.BACKGROUND: {"backgrounds", "images", "memes"},
            ElementType.IMAGE: {"images", "memes", "backgrounds"},
            ElementType.MEME: {"memes", "images"},
            ElementType.INTERSTITIAL: {"interstitials", "transitions"},
            ElementType.AUDIO: {"sounds", "music"},
            ElementType.MUSIC: {"music"},
            ElementType.SOUND_EFFECT: {"sounds"},
            ElementType.SUBTITLE: {"subtitles"},
        }.get(layer.element_type, set())
        self.asset_combo.clear()
        self.asset_combo.addItem("No asset", None)
        for identifier, (label, _path) in sorted(
            self.asset_options.items(), key=lambda item: item[1][0]
        ):
            asset_type = label.split(":", 1)[0].strip()
            if asset_type in allowed:
                self.asset_combo.addItem(label, identifier)
        self.asset_combo.setEnabled(bool(allowed))
        self.asset_combo.setCurrentIndex(max(0, self.asset_combo.findData(current)))

    def _set_property_row_visible(self, widget: QWidget, visible: bool) -> None:
        widget.setVisible(visible)
        label = self.property_form.labelForField(widget)
        if label:
            label.setVisible(visible)
