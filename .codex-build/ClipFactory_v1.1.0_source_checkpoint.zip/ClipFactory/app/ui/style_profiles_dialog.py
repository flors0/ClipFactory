"""Manage and apply reusable visual style profiles to a video preset."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.models.preset_models import ElementType, Preset
from app.models.style_models import StyleProfile, StyleProfileKind
from app.presets.style_profile_manager import StyleProfileManager


class StyleProfilesDialog(QDialog):
    """Apply built-in profiles or persist a custom style from the current preset."""

    def __init__(
        self,
        preset: Preset,
        manager: StyleProfileManager,
        parent: QWidget | None = None,
    ):
        super().__init__(parent)
        self.setWindowTitle("Overlay Style Profiles")
        self.resize(720, 420)
        self._working = preset.model_copy(deep=True)
        self._manager = manager
        self._result: Preset | None = None

        root = QVBoxLayout(self)
        intro = QLabel(
            "Style profiles are reusable visual templates. Applying one updates the current "
            "preset; the normal layer controls remain available for manual fine-tuning."
        )
        intro.setWordWrap(True)
        root.addWidget(intro)

        selectors = QGridLayout()
        self.kind = QComboBox()
        for kind, label in self._available_kinds():
            # Store the stable string value. On Windows, Qt may normalize a StrEnum
            # user-data value to ``str`` when it crosses the QVariant boundary.
            self.kind.addItem(label, kind.value)
        self.profile = QComboBox()
        selectors.addWidget(QLabel("Overlay area"), 0, 0)
        selectors.addWidget(self.kind, 0, 1)
        selectors.addWidget(QLabel("Style profile"), 1, 0)
        selectors.addWidget(self.profile, 1, 1)
        root.addLayout(selectors)

        self.summary = QLabel()
        self.summary.setWordWrap(True)
        self.summary.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        root.addWidget(self.summary)

        apply_row = QHBoxLayout()
        self.apply_button = QPushButton("Apply to Current Preset")
        self.create_button = QPushButton("Save Current Style as New…")
        self.update_button = QPushButton("Update Profile from Current Style")
        apply_row.addWidget(self.apply_button)
        apply_row.addWidget(self.create_button)
        apply_row.addWidget(self.update_button)
        root.addLayout(apply_row)

        manage_row = QHBoxLayout()
        self.duplicate_button = QPushButton("Duplicate…")
        self.rename_button = QPushButton("Rename…")
        self.delete_button = QPushButton("Delete")
        self.reset_button = QPushButton("Reset Built-in")
        for button in (
            self.duplicate_button,
            self.rename_button,
            self.delete_button,
            self.reset_button,
        ):
            manage_row.addWidget(button)
        manage_row.addStretch()
        root.addLayout(manage_row)

        self.status = QLabel(
            "Apply one or more profiles, then choose Save to return the styled preset to the editor."
        )
        self.status.setWordWrap(True)
        root.addWidget(self.status)
        root.addStretch()

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        self.kind.currentIndexChanged.connect(self._refresh_profiles)
        self.profile.currentIndexChanged.connect(self._profile_changed)
        self.apply_button.clicked.connect(self._apply)
        self.create_button.clicked.connect(self._create)
        self.update_button.clicked.connect(self._update)
        self.duplicate_button.clicked.connect(self._duplicate)
        self.rename_button.clicked.connect(self._rename)
        self.delete_button.clicked.connect(self._delete)
        self.reset_button.clicked.connect(self._reset)
        self._refresh_profiles()

    @property
    def result_preset(self) -> Preset | None:
        return self._result

    def _available_kinds(self) -> list[tuple[StyleProfileKind, str]]:
        visible = {
            layer.element_type
            for layer in self._working.layers
            if not layer.hidden and layer.rich_text
        }
        values = []
        for kind, element_type, label in (
            (
                StyleProfileKind.RANKING_NUMBERS,
                ElementType.RANKING_NUMBER,
                "Ranking Numbers",
            ),
            (StyleProfileKind.CAPTIONS, ElementType.DYNAMIC_CAPTION, "Captions"),
            (StyleProfileKind.HEADER, ElementType.HEADER, "Header"),
        ):
            if element_type in visible:
                values.append((kind, label))
        return values

    def _current_kind(self) -> StyleProfileKind | None:
        value = self.kind.currentData()
        if isinstance(value, StyleProfileKind):
            return value
        try:
            return StyleProfileKind(str(value))
        except (TypeError, ValueError):
            return None

    def _current_profile(self) -> StyleProfile | None:
        identifier = self.profile.currentData()
        return self._manager.get(identifier) if identifier else None

    def _refresh_profiles(self, selected_id: str | None = None) -> None:
        kind = self._current_kind()
        self.profile.blockSignals(True)
        self.profile.clear()
        if kind is None:
            self.profile.addItem("No styleable text layer", None)
            self.profile.blockSignals(False)
            self._profile_changed()
            return
        applied_id = selected_id or self._selection_id(kind)
        matching = self._manager.matching_profile(self._working, kind)
        if matching:
            applied_id = matching.id
        else:
            self.profile.addItem("Custom (unsaved)", None)
        profiles = self._manager.list(kind)
        if not profiles:
            self._manager.ensure_core_profiles()
            profiles = self._manager.list(kind)
        for profile in profiles:
            prefix = "◆ " if profile.core else ""
            self.profile.addItem(f"{prefix}{profile.name}", profile.id)
        index = self.profile.findData(applied_id)
        self.profile.setCurrentIndex(index if index >= 0 else 0)
        self.profile.blockSignals(False)
        self._profile_changed()

    def _profile_changed(self) -> None:
        profile = self._current_profile()
        if profile is None:
            self.summary.setText(
                "The current style does not exactly match a saved profile. Save it as a new "
                "custom profile or select a profile to apply."
            )
            self.apply_button.setEnabled(False)
            self.update_button.setEnabled(False)
            self.duplicate_button.setEnabled(False)
            self.rename_button.setEnabled(False)
            self.delete_button.setEnabled(False)
            self.reset_button.setEnabled(False)
            return
        style = profile.text_style
        profile_type = "Built-in" if profile.core else "Custom"
        glow = (
            f", glow {style.glow_radius:g}"
            if style.glow_enabled and style.glow_radius > 0
            else ", no glow"
        )
        self.summary.setText(
            f"{profile_type} · {style.font_family} {style.font_size:g} at "
            f"{style.reference_height}px reference height · outline "
            f"{style.outline_width:g}{glow}."
        )
        self.apply_button.setEnabled(True)
        self.update_button.setEnabled(True)
        self.duplicate_button.setEnabled(True)
        self.rename_button.setEnabled(not profile.core)
        self.delete_button.setEnabled(not profile.core)
        self.reset_button.setEnabled(profile.core)

    def _apply(self) -> None:
        profile = self._current_profile()
        if profile is None:
            return
        try:
            self._working = self._manager.apply(self._working, profile.id)
            self.status.setText(f"Applied '{profile.name}' to {self._kind_label(profile.kind)}.")
            self._refresh_profiles(profile.id)
        except Exception as error:
            QMessageBox.critical(self, "Style profile could not be applied", str(error))

    def _create(self) -> None:
        kind = self._current_kind()
        if kind is None:
            return
        name, accepted = QInputDialog.getText(
            self,
            "Save style profile",
            "Profile name",
        )
        if not accepted or not name.strip():
            return
        try:
            profile = self._manager.create_from_preset(
                self._working,
                kind,
                name.strip(),
            )
            self._set_selection_id(kind, profile.id)
            self.status.setText(f"Saved custom profile '{profile.name}'.")
            self._refresh_profiles(profile.id)
        except Exception as error:
            QMessageBox.warning(self, "Style profile was not saved", str(error))

    def _update(self) -> None:
        profile = self._current_profile()
        if profile is None:
            return
        if profile.core and (
            QMessageBox.question(
                self,
                "Update built-in profile",
                "Update this built-in profile from the current preset style? "
                "Reset Built-in can restore the shipped values.",
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        try:
            updated = self._manager.update_from_preset(profile.id, self._working)
            self._working = self._manager.apply(self._working, updated.id)
            self.status.setText(f"Updated profile '{updated.name}'.")
            self._refresh_profiles(updated.id)
        except Exception as error:
            QMessageBox.warning(self, "Style profile was not updated", str(error))

    def _duplicate(self) -> None:
        profile = self._current_profile()
        if profile is None:
            return
        name, accepted = QInputDialog.getText(
            self,
            "Duplicate style profile",
            "Profile name",
            text=f"{profile.name} Copy",
        )
        if not accepted or not name.strip():
            return
        try:
            duplicate = self._manager.duplicate(profile.id, name.strip())
            self.status.setText(f"Created custom profile '{duplicate.name}'.")
            self._refresh_profiles(duplicate.id)
        except Exception as error:
            QMessageBox.warning(self, "Style profile was not duplicated", str(error))

    def _rename(self) -> None:
        profile = self._current_profile()
        if profile is None or profile.core:
            return
        name, accepted = QInputDialog.getText(
            self,
            "Rename style profile",
            "Profile name",
            text=profile.name,
        )
        if not accepted or not name.strip():
            return
        try:
            renamed = self._manager.rename(profile.id, name.strip())
            self.status.setText(f"Renamed profile to '{renamed.name}'.")
            self._refresh_profiles(renamed.id)
        except Exception as error:
            QMessageBox.warning(self, "Style profile was not renamed", str(error))

    def _delete(self) -> None:
        profile = self._current_profile()
        if profile is None or profile.core:
            return
        if (
            QMessageBox.question(
                self,
                "Delete style profile",
                f"Delete custom profile '{profile.name}'?",
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        try:
            self._manager.delete(profile.id)
            if self._selection_id(profile.kind) == profile.id:
                self._set_selection_id(profile.kind, None)
            self.status.setText(f"Deleted custom profile '{profile.name}'.")
            self._refresh_profiles()
        except Exception as error:
            QMessageBox.warning(self, "Style profile was not deleted", str(error))

    def _reset(self) -> None:
        profile = self._current_profile()
        if profile is None or not profile.core:
            return
        if (
            QMessageBox.question(
                self,
                "Reset built-in style profile",
                f"Restore '{profile.name}' to its ClipFactory v1.1.0 values?",
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        try:
            reset = self._manager.reset_core(profile.id)
            self._working = self._manager.apply(self._working, reset.id)
            self.status.setText(f"Reset and applied '{reset.name}'.")
            self._refresh_profiles(reset.id)
        except Exception as error:
            QMessageBox.warning(self, "Style profile was not reset", str(error))

    def _accept(self) -> None:
        self._manager.reconcile_preset(self._working)
        self._result = self._working
        self.accept()

    def _selection_id(self, kind: StyleProfileKind) -> str | None:
        return {
            StyleProfileKind.RANKING_NUMBERS: self._working.style_profiles.ranking_numbers,
            StyleProfileKind.CAPTIONS: self._working.style_profiles.captions,
            StyleProfileKind.HEADER: self._working.style_profiles.header,
        }[kind]

    def _set_selection_id(
        self,
        kind: StyleProfileKind,
        identifier: str | None,
    ) -> None:
        if kind == StyleProfileKind.RANKING_NUMBERS:
            self._working.style_profiles.ranking_numbers = identifier
        elif kind == StyleProfileKind.CAPTIONS:
            self._working.style_profiles.captions = identifier
        else:
            self._working.style_profiles.header = identifier

    @staticmethod
    def _kind_label(kind: StyleProfileKind) -> str:
        return {
            StyleProfileKind.RANKING_NUMBERS: "Ranking Numbers",
            StyleProfileKind.CAPTIONS: "Captions",
            StyleProfileKind.HEADER: "Header",
        }[kind]
