"""Pure path helpers shared by UI pages and headless tests."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol


class HasVideoPath(Protocol):
    video_path: str


def resolve_output_folder(item: HasVideoPath | None, default: Path) -> Path:
    """Return the item's folder, or the configured output folder for an empty queue."""
    return Path(item.video_path).parent if item else default
