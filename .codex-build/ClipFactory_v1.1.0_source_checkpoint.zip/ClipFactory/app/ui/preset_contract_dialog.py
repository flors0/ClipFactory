"""Complete preset-level style and technical contract editor."""

from __future__ import annotations

import json

from PySide6.QtWidgets import (
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from app.models.preset_models import Color, DurationEnforcement, Preset


class ColorButton(QPushButton):
    def __init__(self, value: Color, title: str):
        super().__init__()
        self.value = value.model_copy(deep=True)
        self.title = title
        self.clicked.connect(self._choose)
        self._refresh()

    def _choose(self) -> None:
        initial = self._to_qcolor()
        selected = QColorDialog.getColor(
            initial,
            self,
            self.title,
            QColorDialog.ColorDialogOption.ShowAlphaChannel,
        )
        if selected.isValid():
            self.value = Color(
                red=selected.red(),
                green=selected.green(),
                blue=selected.blue(),
                alpha=selected.alpha(),
            )
            self._refresh()

    def _to_qcolor(self):
        from PySide6.QtGui import QColor

        return QColor(self.value.red, self.value.green, self.value.blue, self.value.alpha)

    def _refresh(self) -> None:
        foreground = (
            "#000000"
            if sum((self.value.red, self.value.green, self.value.blue)) > 500
            else "#FFFFFF"
        )
        self.setText(self.value.to_hex())
        self.setStyleSheet(f"background: {self.value.to_hex(False)}; color: {foreground};")


class PresetContractDialog(QDialog):
    """Edit every non-layer preset contract field with validated controls."""

    def __init__(
        self,
        preset: Preset,
        assets: dict[str, tuple[str, str]],
        parent: QWidget | None = None,
    ):
        super().__init__(parent)
        self.setWindowTitle("Preset Contract")
        self.resize(760, 860)
        self._source = preset.model_copy(deep=True)
        self._result: Preset | None = None
        self._assets = assets
        root = QVBoxLayout(self)
        intro = QLabel(
            "These controls define the complete visual, timing, audio, AI-permission, and encoding contract."
        )
        intro.setWordWrap(True)
        root.addWidget(intro)
        scroll = QScrollArea()
        scroll.setObjectName("presetContractScrollArea")
        scroll.setWidgetResizable(True)
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.addWidget(self._general_group())
        content_layout.addWidget(self._header_group())
        content_layout.addWidget(self._ranking_group())
        content_layout.addWidget(self._transition_group())
        content_layout.addWidget(self._audio_group())
        content_layout.addWidget(self._encoding_group())
        content_layout.addWidget(self._permissions_group())
        content_layout.addWidget(self._metadata_group())
        content_layout.addStretch()
        scroll.setWidget(content)
        root.addWidget(scroll, 1)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self._validate_and_accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    @property
    def result_preset(self) -> Preset | None:
        return self._result

    def _general_group(self) -> QGroupBox:
        group, form = self._group("General, canvas, and duration")
        self.name = QLineEdit(self._source.name)
        self.name.setEnabled(not self._source.core)
        if self._source.core:
            self.name.setToolTip(
                "Core preset names stay stable; all rendering settings remain editable."
            )
        self.platform = self._combo(["youtube", "tiktok", "generic"], self._source.platform)
        self.video_format = self._combo(
            ["ranking", "meme", "compilation"], self._source.video_format
        )
        self.width = self._integer(240, 7680, self._source.width)
        self.height = self._integer(240, 7680, self._source.height)
        self.fps = self._integer(15, 120, self._source.fps)
        self.minimum_duration = self._number(0.1, 7200, self._source.duration.minimum_seconds)
        self.target_duration = self._number(0.1, 7200, self._source.duration.target_seconds)
        self.maximum_duration = self._number(0.1, 7200, self._source.duration.maximum_seconds)
        self.duration_enforcement = self._combo(
            [value.value for value in DurationEnforcement],
            self._source.duration.enforcement.value,
        )
        self.subtitles = self._checked(self._source.subtitles_enabled)
        safe = self._source.safe_zones
        self.safe_top = self._number(0, 0.4, safe.top, 0.01, 3)
        self.safe_right = self._number(0, 0.4, safe.right, 0.01, 3)
        self.safe_bottom = self._number(0, 0.4, safe.bottom, 0.01, 3)
        self.safe_left = self._number(0, 0.4, safe.left, 0.01, 3)
        for label, widget in (
            ("Name", self.name),
            ("Platform", self.platform),
            ("Video format", self.video_format),
            ("Width", self.width),
            ("Height", self.height),
            ("FPS", self.fps),
            ("Minimum duration", self.minimum_duration),
            ("Target duration", self.target_duration),
            ("Maximum duration", self.maximum_duration),
            ("Duration enforcement", self.duration_enforcement),
            ("Subtitles enabled", self.subtitles),
            ("Safe zone top", self.safe_top),
            ("Safe zone right", self.safe_right),
            ("Safe zone bottom", self.safe_bottom),
            ("Safe zone left", self.safe_left),
        ):
            form.addRow(label, widget)
        return group

    def _header_group(self) -> QGroupBox:
        group, form = self._group("Header")
        value = self._source.header
        self.header_enabled = self._checked(value.enabled)
        self.header_height = self._number(0.01, 0.5, value.height_ratio, 0.01, 3)
        self.header_background = ColorButton(value.background, "Choose header background")
        self.header_border_color = ColorButton(value.border_color, "Choose header border")
        self.header_border_width = self._number(0, 30, value.border_width)
        self.header_padding = self._number(0, 0.2, value.padding_ratio, 0.005, 3)
        self.header_auto_fit = self._checked(value.automatic_fit)
        self.header_wrap = self._checked(value.line_wrapping)
        self.header_lines = self._integer(1, 10, value.maximum_lines)
        self.header_visibility = self._combo(["fixed", "full_video"], value.visibility)
        self.header_duration = self._number(0, 7200, value.duration_seconds or 0)
        self.header_duration.setSpecialValueText("Layer/full duration")
        self.header_locked = self._checked(value.locked_text)
        for label, widget in (
            ("Enabled", self.header_enabled),
            ("Height ratio", self.header_height),
            ("Background color", self.header_background),
            ("Border color", self.header_border_color),
            ("Border width", self.header_border_width),
            ("Padding ratio", self.header_padding),
            ("Automatic text fit", self.header_auto_fit),
            ("Line wrapping", self.header_wrap),
            ("Maximum lines", self.header_lines),
            ("Visibility", self.header_visibility),
            ("Fixed duration", self.header_duration),
            ("Lock preset header text", self.header_locked),
        ):
            form.addRow(label, widget)
        return group

    def _ranking_group(self) -> QGroupBox:
        group, form = self._group("Ranking overlay")
        value = self._source.ranking
        self.ranking_enabled = self._checked(value.enabled)
        self.ranking_count = self._integer(1, 20, value.count)
        self.ranking_playback = QComboBox()
        self.ranking_playback.addItem(
            "Best last (N → 1 countdown)",
            "worst_to_best",
        )
        self.ranking_playback.addItem(
            "Best first (1 → N)",
            "best_to_worst",
        )
        self.ranking_playback.setCurrentIndex(
            max(0, self.ranking_playback.findData(value.playback_order))
        )
        self.ranking_horizontal = self._combo(
            ["left", "center", "right"],
            value.horizontal_alignment,
        )
        self.ranking_vertical = self._combo(
            ["top", "center", "bottom"],
            value.vertical_alignment,
        )
        self.numbers_visible = self._checked(value.numbers_visible_from_start)
        self.active_opacity = self._number(0, 1, value.active_opacity, 0.05, 2)
        self.inactive_opacity = self._number(0, 1, value.inactive_opacity, 0.05, 2)
        self.active_color = ColorButton(value.active_color, "Choose active ranking color")
        self.inactive_color = ColorButton(value.inactive_color, "Choose inactive ranking color")
        self.reveal_offset = self._number(0, 60, value.reveal_offset_seconds)
        self.persist_captions = self._checked(value.captions_persist_after_reveal)
        self.ranking_spacing = self._number(0, 1, value.spacing, 0.005, 3)
        for label, widget in (
            ("Enabled", self.ranking_enabled),
            ("Count", self.ranking_count),
            ("Playback order", self.ranking_playback),
            ("Horizontal alignment", self.ranking_horizontal),
            ("Vertical alignment", self.ranking_vertical),
            ("Numbers visible from start", self.numbers_visible),
            ("Active opacity", self.active_opacity),
            ("Inactive opacity", self.inactive_opacity),
            ("Active color", self.active_color),
            ("Inactive color", self.inactive_color),
            ("Caption reveal offset", self.reveal_offset),
            ("Keep revealed captions visible", self.persist_captions),
            ("Item spacing", self.ranking_spacing),
        ):
            form.addRow(label, widget)
        return group

    def _transition_group(self) -> QGroupBox:
        group, form = self._group("Transitions and interstitials")
        transition = self._source.transition
        self.transition_enabled = self._checked(transition.enabled)
        self.transition_type = self._combo(["cut", "fade", "fixed_asset"], transition.type)
        self.transition_asset = self._asset_combo(transition.fixed_asset_id, "transitions")
        self.transition_sound = self._asset_combo(transition.sound_asset_id, "sounds")
        self.transition_duration = self._number(0, 5, transition.duration_seconds)
        self.transition_audio = self._checked(transition.use_asset_audio)
        self.transition_sound_offset = self._number(
            0,
            120,
            transition.sound_start_offset_seconds,
            0.01,
            3,
        )
        self.transition_sound_duration = self._number(
            0,
            120,
            transition.sound_duration_seconds or 0,
            0.01,
            3,
        )
        self.transition_sound_duration.setSpecialValueText("Use remaining asset")
        self.transition_sound_fade = self._number(
            0,
            2,
            transition.sound_fade_seconds,
            0.01,
            3,
        )
        self.transition_original_fade = self._number(
            0,
            2,
            transition.original_audio_fade_seconds,
            0.01,
            3,
        )
        interstitial = self._source.interstitial
        self.interstitial_enabled = self._checked(interstitial.enabled)
        self.interstitial_asset = self._asset_combo(interstitial.asset_id, "interstitials")
        self.interstitial_duration = self._number(0.1, 30, interstitial.duration_seconds)
        self.interstitial_audio = self._checked(interstitial.use_asset_audio)
        self.interstitial_volume = self._number(0, 2, interstitial.volume)
        self.interstitial_fade = self._number(0, 5, interstitial.fade_seconds)
        self.interstitial_placement = self._combo(
            ["between_clips", "intro", "outro", "all"], interstitial.placement
        )
        for label, widget in (
            ("Transitions enabled", self.transition_enabled),
            ("Transition type", self.transition_type),
            ("Visual asset from Asset Library", self.transition_asset),
            ("Sound from Asset Library", self.transition_sound),
            ("Transition duration", self.transition_duration),
            ("Use visual asset audio", self.transition_audio),
            ("Sound source start offset", self.transition_sound_offset),
            ("Sound source duration", self.transition_sound_duration),
            ("Transition sound fades", self.transition_sound_fade),
            ("Original audio boundary fades", self.transition_original_fade),
            ("Interstitial enabled", self.interstitial_enabled),
            ("Interstitial asset", self.interstitial_asset),
            ("Interstitial duration", self.interstitial_duration),
            ("Interstitial audio", self.interstitial_audio),
            ("Interstitial volume", self.interstitial_volume),
            ("Interstitial fade", self.interstitial_fade),
            ("Interstitial placement", self.interstitial_placement),
        ):
            form.addRow(label, widget)
        return group

    def _audio_group(self) -> QGroupBox:
        group, form = self._group("Audio")
        value = self._source.audio
        self.original_volume = self._number(0, 2, value.original_volume)
        self.music_volume = self._number(0, 2, value.music_volume)
        self.sfx_volume = self._number(0, 2, value.sfx_volume)
        self.transition_volume = self._number(0, 2, value.transition_volume)
        self.loudness = self._number(-30, -5, value.target_loudness_lufs)
        self.ducking = self._checked(value.ducking_enabled)
        self.ducking_strength = self._number(0, 1, value.ducking_strength)
        self.fade_in = self._number(0, 30, value.fade_in_seconds)
        self.fade_out = self._number(0, 30, value.fade_out_seconds)
        self.limiter = self._checked(value.limiter_enabled)
        self.silence = self._combo(["preserve", "fill", "reject"], value.silence_handling)
        self.music_asset = self._asset_combo(value.music_asset_id, "music")
        for label, widget in (
            ("Original audio volume", self.original_volume),
            ("Music volume", self.music_volume),
            ("SFX volume", self.sfx_volume),
            ("Transition volume", self.transition_volume),
            ("Target loudness (LUFS)", self.loudness),
            ("Ducking enabled", self.ducking),
            ("Ducking strength", self.ducking_strength),
            ("Fade in", self.fade_in),
            ("Fade out", self.fade_out),
            ("Limiter / peak protection", self.limiter),
            ("Silence handling", self.silence),
            ("Music asset", self.music_asset),
        ):
            form.addRow(label, widget)
        return group

    def _encoding_group(self) -> QGroupBox:
        group, form = self._group("Encoding")
        value = self._source.encoding
        self.video_codec = QLineEdit(value.video_codec)
        self.audio_codec = QLineEdit(value.audio_codec)
        self.crf = self._integer(0, 51, value.crf)
        self.audio_bitrate = QLineEdit(value.audio_bitrate)
        self.pixel_format = QLineEdit(value.pixel_format)
        self.fast_start = self._checked(value.fast_start)
        for label, widget in (
            ("Video codec", self.video_codec),
            ("Audio codec", self.audio_codec),
            ("CRF", self.crf),
            ("Audio bitrate", self.audio_bitrate),
            ("Pixel format", self.pixel_format),
            ("Fast start", self.fast_start),
        ):
            form.addRow(label, widget)
        return group

    def _permissions_group(self) -> QGroupBox:
        group, form = self._group("AI field permissions")
        value = self._source.ai_permissions
        self.permission_widgets: dict[str, QCheckBox] = {}
        labels = {
            "allow_header_text": "Generate header text",
            "allow_ranking_captions": "Generate ranking captions",
            "allow_clip_reordering": "Reorder selected clips",
            "allow_trim_suggestions": "Suggest clip trims",
            "allow_upload_title": "Generate upload titles",
            "allow_upload_description": "Generate upload descriptions",
            "allow_upload_tags": "Generate tags and hashtags",
        }
        for field_name, label in labels.items():
            widget = self._checked(bool(getattr(value, field_name)))
            self.permission_widgets[field_name] = widget
            form.addRow(label, widget)
        warning = QLabel(
            "Style and duration permissions are off by default. The production pipeline still enforces the preset contract."
        )
        warning.setWordWrap(True)
        form.addRow(warning)
        return group

    def _metadata_group(self) -> QGroupBox:
        group, form = self._group("Upload metadata defaults")
        self.metadata = QPlainTextEdit(
            json.dumps(self._source.upload_metadata_defaults, indent=2, ensure_ascii=False)
        )
        self.metadata.setMinimumHeight(120)
        form.addRow("Validated JSON object", self.metadata)
        return group

    def _validate_and_accept(self) -> None:
        try:
            metadata = json.loads(self.metadata.toPlainText() or "{}")
            if not isinstance(metadata, dict):
                raise ValueError("Upload metadata defaults must be a JSON object.")
            payload = self._source.model_dump(mode="python")
            payload.update(
                {
                    "name": self.name.text().strip(),
                    "platform": self.platform.currentText(),
                    "video_format": self.video_format.currentText(),
                    "width": self.width.value(),
                    "height": self.height.value(),
                    "fps": self.fps.value(),
                    "subtitles_enabled": self.subtitles.isChecked(),
                    "upload_metadata_defaults": metadata,
                }
            )
            payload["duration"].update(
                {
                    "minimum_seconds": self.minimum_duration.value(),
                    "target_seconds": self.target_duration.value(),
                    "maximum_seconds": self.maximum_duration.value(),
                    "enforcement": self.duration_enforcement.currentText(),
                }
            )
            payload["safe_zones"].update(
                {
                    "top": self.safe_top.value(),
                    "right": self.safe_right.value(),
                    "bottom": self.safe_bottom.value(),
                    "left": self.safe_left.value(),
                }
            )
            payload["header"].update(
                {
                    "enabled": self.header_enabled.isChecked(),
                    "height_ratio": self.header_height.value(),
                    "background": self.header_background.value.model_dump(),
                    "border_color": self.header_border_color.value.model_dump(),
                    "border_width": self.header_border_width.value(),
                    "padding_ratio": self.header_padding.value(),
                    "automatic_fit": self.header_auto_fit.isChecked(),
                    "line_wrapping": self.header_wrap.isChecked(),
                    "maximum_lines": self.header_lines.value(),
                    "visibility": self.header_visibility.currentText(),
                    "duration_seconds": self.header_duration.value() or None,
                    "locked_text": self.header_locked.isChecked(),
                }
            )
            payload["ranking"].update(
                {
                    "enabled": self.ranking_enabled.isChecked(),
                    "count": self.ranking_count.value(),
                    "order": "ascending",
                    "playback_order": self.ranking_playback.currentData(),
                    "horizontal_alignment": self.ranking_horizontal.currentText(),
                    "vertical_alignment": self.ranking_vertical.currentText(),
                    "numbers_visible_from_start": self.numbers_visible.isChecked(),
                    "active_opacity": self.active_opacity.value(),
                    "inactive_opacity": self.inactive_opacity.value(),
                    "active_color": self.active_color.value.model_dump(),
                    "inactive_color": self.inactive_color.value.model_dump(),
                    "reveal_offset_seconds": self.reveal_offset.value(),
                    "captions_persist_after_reveal": self.persist_captions.isChecked(),
                    "spacing": self.ranking_spacing.value(),
                }
            )
            payload["transition"].update(
                {
                    "enabled": self.transition_enabled.isChecked(),
                    "type": self.transition_type.currentText(),
                    "fixed_asset_id": self.transition_asset.currentData(),
                    "sound_asset_id": self.transition_sound.currentData(),
                    "duration_seconds": self.transition_duration.value(),
                    "sound_start_offset_seconds": self.transition_sound_offset.value(),
                    "sound_duration_seconds": self.transition_sound_duration.value() or None,
                    "sound_fade_seconds": self.transition_sound_fade.value(),
                    "original_audio_fade_seconds": self.transition_original_fade.value(),
                    "use_asset_audio": self.transition_audio.isChecked(),
                    "placement": "between_clips",
                }
            )
            payload["interstitial"].update(
                {
                    "enabled": self.interstitial_enabled.isChecked(),
                    "asset_id": self.interstitial_asset.currentData(),
                    "duration_seconds": self.interstitial_duration.value(),
                    "use_asset_audio": self.interstitial_audio.isChecked(),
                    "volume": self.interstitial_volume.value(),
                    "fade_seconds": self.interstitial_fade.value(),
                    "placement": self.interstitial_placement.currentText(),
                }
            )
            payload["audio"].update(
                {
                    "original_volume": self.original_volume.value(),
                    "music_volume": self.music_volume.value(),
                    "sfx_volume": self.sfx_volume.value(),
                    "transition_volume": self.transition_volume.value(),
                    "target_loudness_lufs": self.loudness.value(),
                    "ducking_enabled": self.ducking.isChecked(),
                    "ducking_strength": self.ducking_strength.value(),
                    "fade_in_seconds": self.fade_in.value(),
                    "fade_out_seconds": self.fade_out.value(),
                    "limiter_enabled": self.limiter.isChecked(),
                    "silence_handling": self.silence.currentText(),
                    "music_asset_id": self.music_asset.currentData(),
                }
            )
            payload["encoding"].update(
                {
                    "video_codec": self.video_codec.text().strip(),
                    "audio_codec": self.audio_codec.text().strip(),
                    "crf": self.crf.value(),
                    "audio_bitrate": self.audio_bitrate.text().strip(),
                    "pixel_format": self.pixel_format.text().strip(),
                    "fast_start": self.fast_start.isChecked(),
                }
            )
            payload["ai_permissions"].update(
                {name: widget.isChecked() for name, widget in self.permission_widgets.items()}
            )
            self._result = Preset.model_validate(payload)
            self.accept()
        except Exception as error:
            QMessageBox.critical(self, "Preset contract is invalid", str(error))

    def _asset_combo(self, selected: str | None, asset_type: str) -> QComboBox:
        combo = QComboBox()
        combo.addItem(f"No {asset_type.rstrip('s')} selected in Asset Library", None)
        for identifier, (label, _path) in sorted(self._assets.items(), key=lambda item: item[1][0]):
            if label.split(":", 1)[0].strip() == asset_type:
                combo.addItem(label, identifier)
        combo.setCurrentIndex(max(0, combo.findData(selected)))
        return combo

    @staticmethod
    def _group(title: str) -> tuple[QGroupBox, QFormLayout]:
        group = QGroupBox(title)
        form = QFormLayout(group)
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        return group, form

    @staticmethod
    def _checked(value: bool) -> QCheckBox:
        widget = QCheckBox()
        widget.setChecked(value)
        return widget

    @staticmethod
    def _combo(values: list[str], selected: str) -> QComboBox:
        widget = QComboBox()
        widget.addItems(values)
        widget.setCurrentText(selected)
        return widget

    @staticmethod
    def _integer(minimum: int, maximum: int, value: int) -> QSpinBox:
        widget = QSpinBox()
        widget.setRange(minimum, maximum)
        widget.setValue(value)
        return widget

    @staticmethod
    def _number(
        minimum: float,
        maximum: float,
        value: float,
        step: float = 0.1,
        decimals: int = 2,
    ) -> QDoubleSpinBox:
        widget = QDoubleSpinBox()
        widget.setRange(minimum, maximum)
        widget.setDecimals(decimals)
        widget.setSingleStep(step)
        widget.setValue(value)
        return widget
