"""ClipFactory main navigation and background orchestration."""

from __future__ import annotations

from PySide6.QtCore import QThreadPool, QTimer
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QStackedWidget,
    QStatusBar,
    QWidget,
)

from app import __version__
from app.core.app_context import AppContext
from app.core.workers import BackgroundWorker
from app.models.render_models import ProductionStatus
from app.planning.batch_planner import PlannedBatchItem
from app.services.production_service import ProductionOptions
from app.ui.pages.ai_usage import AIUsagePage
from app.ui.pages.asset_library import AssetLibraryPage
from app.ui.pages.batch_planner import BatchPlannerPage
from app.ui.pages.channels import ChannelsPage
from app.ui.pages.dashboard import DashboardPage
from app.ui.pages.logs import LogsPage
from app.ui.pages.presets import PresetsPage
from app.ui.pages.production_queue import ProductionQueuePage
from app.ui.pages.review_queue import ReviewQueuePage
from app.ui.pages.settings import SettingsPage
from app.ui.pages.sources import SourcesPage
from app.ui.pages.upload_queue import UploadQueuePage


class MainWindow(QMainWindow):
    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        self.setWindowTitle(f"ClipFactory {__version__}")
        self.resize(1500, 940)
        self.active_workers: dict[str, BackgroundWorker] = {}
        central = QWidget()
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        self.navigation = QListWidget()
        self.navigation.setFixedWidth(220)
        self.navigation.setObjectName("navigation")
        self.stack = QStackedWidget()
        layout.addWidget(self.navigation)
        layout.addWidget(self.stack, 1)
        self.setCentralWidget(central)
        self.dashboard = DashboardPage(context)
        self.sources = SourcesPage(context)
        self.presets = PresetsPage(context)
        self.batch = BatchPlannerPage(context)
        self.production = ProductionQueuePage(context)
        self.review = ReviewQueuePage(context)
        self.uploads = UploadQueuePage(context)
        self.channels = ChannelsPage(context)
        self.assets = AssetLibraryPage(context)
        self.ai_usage = AIUsagePage(context)
        self.settings = SettingsPage(context)
        self.logs = LogsPage(context)
        pages = [
            ("Dashboard", self.dashboard),
            ("Sources", self.sources),
            ("Presets", self.presets),
            ("Batch Planner", self.batch),
            ("Production Queue", self.production),
            ("Review Queue", self.review),
            ("Upload Queue", self.uploads),
            ("Channels", self.channels),
            ("Asset Library", self.assets),
            ("AI Usage", self.ai_usage),
            ("Settings", self.settings),
            ("Logs", self.logs),
        ]
        for name, page in pages:
            self.navigation.addItem(QListWidgetItem(name))
            self.stack.addWidget(page)
        self.navigation.currentRowChanged.connect(self._page_changed)
        self.navigation.setCurrentRow(0)
        self.batch.generate_requested.connect(self._generate_batch)
        self.production.cancel_requested.connect(self._cancel_job)
        self.production.retry_requested.connect(self._retry_job)
        self.review.rerender_requested.connect(self._rerender)
        self.review.replace_clip_requested.connect(self._retry_job)
        status = QStatusBar()
        self.status_text = QLabel("Ready")
        self.status_progress = QProgressBar()
        self.status_progress.setMaximumWidth(220)
        self.status_progress.hide()
        status.addWidget(self.status_text, 1)
        status.addPermanentWidget(self.status_progress)
        self.setStatusBar(status)
        self.refresh_timer = QTimer(self)
        self.refresh_timer.setInterval(5000)
        self.refresh_timer.timeout.connect(self._refresh_operational_pages)
        self.refresh_timer.start()

    def _page_changed(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        page = self.stack.currentWidget()
        refresh = getattr(page, "refresh", None)
        if callable(refresh):
            refresh()

    def _generate_batch(
        self,
        plan,
        use_mock_ai: bool,
        use_mock_source: bool,
        max_analyses: int,
        maximum_ai_cost: float,
        render_parallelism: int,
        upload_parallelism: int,
    ) -> None:
        if any(job_id in self.active_workers for job_id in [item.job.id for item in plan.items]):
            return

        def task(*, cancel_event, progress_callback):
            self.context.scheduler.max_concurrency = max(1, min(4, upload_parallelism))
            return self.context.production.generate_batch(
                plan,
                confirmed=True,
                use_mock_ai=use_mock_ai,
                use_mock_source=use_mock_source,
                options=ProductionOptions(
                    maximum_analyses_per_video=max_analyses,
                    maximum_ai_cost_per_job_usd=(maximum_ai_cost / max(1, len(plan.items))),
                    render_parallelism=render_parallelism,
                    upload_parallelism=upload_parallelism,
                ),
                cancel_event=cancel_event,
                progress_callback=progress_callback,
            )

        worker = BackgroundWorker(task)
        for item in plan.items:
            self.active_workers[item.job.id] = worker
        self._start_worker(worker, [item.job.id for item in plan.items], "Generating batch")
        worker.signals.result.connect(self._batch_finished)

    def _start_worker(self, worker: BackgroundWorker, identifiers: list[str], label: str) -> None:
        self.status_text.setText(label)
        self.status_progress.setValue(0)
        self.status_progress.show()
        worker.signals.progress.connect(self._progress)
        worker.signals.error.connect(
            lambda value: QMessageBox.critical(
                self, "Background operation failed", value.splitlines()[-1]
            )
        )

        def finished() -> None:
            for identifier in identifiers:
                self.active_workers.pop(identifier, None)
            self.status_text.setText("Ready")
            self.status_progress.hide()
            self._refresh_operational_pages()

        worker.signals.finished.connect(finished)
        QThreadPool.globalInstance().start(worker)

    def _batch_finished(self, jobs) -> None:
        failed = [job for job in jobs if job.status == ProductionStatus.FAILED]
        cancelled = [job for job in jobs if job.status == ProductionStatus.CANCELLED]
        QMessageBox.information(
            self,
            "Batch production finished",
            f"Completed {len(jobs) - len(failed) - len(cancelled)}; failed {len(failed)}; cancelled {len(cancelled)}. Successful videos are waiting in Review Queue.",
        )

    def _progress(self, value: int, text: str) -> None:
        self.status_progress.setValue(value)
        self.status_text.setText(text)

    def _cancel_job(self, identifier: str) -> None:
        worker = self.active_workers.get(identifier)
        if worker:
            if self.context.production.cancel_job(identifier):
                self.status_text.setText("Production-job cancellation requested")
            else:
                worker.cancel()
                self.status_text.setText("Batch cancellation requested")
            return
        job = self.context.production_jobs.get(identifier)
        if job and job.status not in {ProductionStatus.PUBLISHED, ProductionStatus.CANCELLED}:
            job.status = ProductionStatus.CANCELLED
            job.current_step = "Cancelled before execution"
            self.context.production_jobs.save(job, validate_transition=False)
            self.production.refresh()

    def _retry_job(self, identifier: str) -> None:
        if identifier in self.active_workers:
            return
        job = self.context.production_jobs.get(identifier)
        if not job:
            return
        project = self.context.projects.get(job.project_id)
        preset = self.context.presets.get(job.preset_id)
        channel = self.context.channels.get(job.channel_id) if job.channel_id else None
        if not project or not preset:
            QMessageBox.warning(
                self, "Retry unavailable", "The persisted project or preset is missing."
            )
            return
        if job.design_profile_id:
            try:
                preset = self.context.design_profile_manager.apply(
                    preset,
                    job.design_profile_id,
                )
            except (KeyError, ValueError) as error:
                QMessageBox.warning(
                    self,
                    "Retry design unavailable",
                    f"The saved design for this job cannot be restored: {error}",
                )
                return
        mock_ai = job.use_mock_ai or any("Mock AI: True" in value for value in job.log_messages)
        mock_source = job.use_mock_source or any(
            "Mock source: True" in value for value in job.log_messages
        )
        option_values = job.production_options
        options = ProductionOptions(
            maximum_analyses_per_video=int(option_values.get("maximum_analyses_per_video", 12)),
            maximum_ai_cost_per_job_usd=(
                float(option_values["maximum_ai_cost_per_job_usd"])
                if option_values.get("maximum_ai_cost_per_job_usd") is not None
                else None
            ),
            render_parallelism=int(option_values.get("render_parallelism", 1)),
            upload_parallelism=int(option_values.get("upload_parallelism", 1)),
            deep_technical_scan=bool(option_values.get("deep_technical_scan", True)),
        )
        item = PlannedBatchItem(job.project_id, job, project.source_profile, preset, channel)

        def task(*, cancel_event, progress_callback):
            return self.context.production.retry_job(
                f"retry-{job.id}",
                item,
                use_mock_ai=mock_ai,
                use_mock_source=mock_source,
                options=options,
                cancel_event=cancel_event,
            )

        worker = BackgroundWorker(task)
        self.active_workers[job.id] = worker
        self._start_worker(worker, [job.id], "Retrying production job")

    def _rerender(self, identifier: str) -> None:
        if identifier in self.active_workers:
            return
        job = self.context.production_jobs.get(identifier)
        if not job:
            return
        mock_ai = job.use_mock_ai or any("Mock AI: True" in value for value in job.log_messages)

        def task(*, cancel_event, progress_callback):
            progress_callback(10, "Starting re-render")
            result = self.context.production.rerender(
                job.id, use_mock_ai=mock_ai, cancel_event=cancel_event
            )
            progress_callback(100, "Re-render finished")
            return result

        worker = BackgroundWorker(task)
        self.active_workers[job.id] = worker
        self._start_worker(worker, [job.id], "Re-rendering video")

    def _refresh_operational_pages(self) -> None:
        self.dashboard.refresh()
        self.production.refresh()
        self.review.refresh(self.review.current_id)
        self.uploads.refresh()
        self.ai_usage.refresh()

    def closeEvent(self, event) -> None:
        active = set(self.active_workers.values())
        if (
            active
            and QMessageBox.question(
                self,
                "Operations are active",
                "Cancel active production operations and exit? Scheduled local uploads require ClipFactory to remain running.",
            )
            != QMessageBox.StandardButton.Yes
        ):
            event.ignore()
            return
        for worker in active:
            worker.cancel()
        self.context.scheduler.stop()
        event.accept()


def apply_application_style(application: QApplication, theme: str) -> None:
    if theme == "system":
        application.setStyleSheet("")
        return
    if theme == "light":
        application.setStyleSheet(
            "QWidget { font-size: 13px; } QLabel#pageTitle { font-size: 24px; font-weight: 700; }"
        )
        return
    application.setStyleSheet(
        """
        QWidget { background: #17191f; color: #edf0f5; font-size: 13px; }
        QMainWindow, QStackedWidget { background: #111318; }
        QListWidget#navigation { background: #0d0f13; border: none; padding: 12px; font-size: 15px; }
        QListWidget#navigation::item { padding: 13px 10px; border-radius: 6px; }
        QListWidget#navigation::item:selected { background: #315bdb; color: white; }
        QLabel#pageTitle { font-size: 25px; font-weight: 700; padding: 8px 0; }
        QLabel#metricValue { font-size: 25px; font-weight: 700; color: #82a7ff; }
        QLabel#warningBanner { background: #4a3516; color: #ffd891; padding: 10px; border-radius: 5px; }
        QPushButton { background: #2a2e38; border: 1px solid #3b404d; padding: 7px 11px; border-radius: 5px; }
        QPushButton:hover { background: #353b49; }
        QPushButton#primaryButton { background: #315bdb; color: white; font-weight: 700; padding: 11px; }
        QLineEdit, QPlainTextEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateTimeEdit { background: #20232b; border: 1px solid #3b404d; padding: 5px; border-radius: 4px; }
        QTableWidget, QListWidget { background: #15171d; alternate-background-color: #1b1e25; gridline-color: #2e323d; }
        QHeaderView::section { background: #262a33; padding: 7px; border: none; }
        QGroupBox { border: 1px solid #303541; border-radius: 7px; margin-top: 8px; padding: 10px; }
        QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }
        """
    )
