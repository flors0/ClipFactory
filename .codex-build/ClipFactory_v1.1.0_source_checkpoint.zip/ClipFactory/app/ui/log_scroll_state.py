"""Qt-independent per-log scroll-state behavior."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class LogScrollState:
    positions: dict[str, int] = field(default_factory=dict)
    follow_tail: dict[str, bool] = field(default_factory=dict)
    maximum_entries: int = 200

    def remember(self, key: str, value: int, maximum: int) -> bool:
        at_bottom = value >= max(0, maximum - 1)
        self.positions.pop(key, None)
        self.positions[key] = max(0, value)
        self.follow_tail.pop(key, None)
        self.follow_tail[key] = at_bottom
        while len(self.positions) > self.maximum_entries:
            oldest = next(iter(self.positions))
            self.positions.pop(oldest, None)
            self.follow_tail.pop(oldest, None)
        return at_bottom

    def restored_value(
        self,
        key: str,
        maximum: int,
        *,
        follow_tail: bool | None = None,
    ) -> int:
        follows = self.follow_tail.get(key, False) if follow_tail is None else follow_tail
        return maximum if follows else min(self.positions.get(key, 0), maximum)
