"""Global input guards for settings controls."""

from __future__ import annotations

from PySide6.QtCore import QEvent, QObject, QPointF
from PySide6.QtGui import QWheelEvent
from PySide6.QtWidgets import QAbstractScrollArea, QAbstractSpinBox, QApplication, QWidget


class NumericWheelGuard(QObject):
    """Never edit a numeric field with the wheel; forward the gesture to its scroll page."""

    def eventFilter(self, watched: QObject, event: QEvent) -> bool:
        if event.type() != QEvent.Type.Wheel or not isinstance(event, QWheelEvent):
            return False
        spin_box = self._spin_box_for(watched)
        if spin_box is None:
            return False
        scroll_area = self._scroll_area_for(spin_box)
        if scroll_area is not None:
            viewport = scroll_area.viewport()
            local_position = viewport.mapFromGlobal(event.globalPosition().toPoint())
            forwarded = QWheelEvent(
                QPointF(local_position),
                event.globalPosition(),
                event.pixelDelta(),
                event.angleDelta(),
                event.buttons(),
                event.modifiers(),
                event.phase(),
                event.inverted(),
                event.source(),
            )
            QApplication.sendEvent(viewport, forwarded)
        event.accept()
        return True

    @staticmethod
    def _spin_box_for(watched: QObject) -> QAbstractSpinBox | None:
        if isinstance(watched, QAbstractSpinBox):
            return watched
        parent = watched.parent() if isinstance(watched, QObject) else None
        return parent if isinstance(parent, QAbstractSpinBox) else None

    @staticmethod
    def _scroll_area_for(widget: QWidget) -> QAbstractScrollArea | None:
        parent = widget.parentWidget()
        while parent is not None:
            if isinstance(parent, QAbstractScrollArea):
                return parent
            parent = parent.parentWidget()
        return None


def install_numeric_wheel_guard(application: QApplication) -> NumericWheelGuard:
    guard = NumericWheelGuard(application)
    application.installEventFilter(guard)
    # Keep an explicit Python reference for the entire QApplication lifetime.
    application._clipfactory_numeric_wheel_guard = guard  # type: ignore[attr-defined]
    return guard
