"""Multiple YouTube/TikTok channel profiles and OAuth connections."""

from __future__ import annotations

import json
import os
from pathlib import Path

from PySide6.QtCore import Qt, QThreadPool
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.app_context import AppContext
from app.core.workers import BackgroundWorker
from app.models.channel_models import ChannelProfile


class ChannelsPage(QWidget):
    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        self.current_id: str | None = None
        self.worker: BackgroundWorker | None = None
        root = QVBoxLayout(self)
        title = QLabel("Channels")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Name", "Platform", "Account", "OAuth", "Privacy", "Enabled"]
        )
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        root.addWidget(self.table)
        form = QFormLayout()
        self.name = QLineEdit()
        self.platform = QComboBox()
        self.platform.addItems(["youtube", "tiktok"])
        self.language = QLineEdit("en")
        self.timezone = QLineEdit(context.settings.timezone)
        self.privacy = QComboBox()
        self.default_preset = QComboBox()
        self.default_design = QComboBox()
        self.default_source = QComboBox()
        self.default_tags = QLineEdit()
        self.default_hashtags = QLineEdit()
        self.default_metadata = QPlainTextEdit("{}")
        self.default_metadata.setMaximumHeight(80)
        self.schedule_template = QComboBox()
        self.enabled = QCheckBox()
        self.enabled.setChecked(True)
        form.addRow("Display name", self.name)
        form.addRow("Platform", self.platform)
        form.addRow("Language", self.language)
        form.addRow("Timezone", self.timezone)
        form.addRow("Default privacy", self.privacy)
        form.addRow("Default preset", self.default_preset)
        form.addRow("Default visual design", self.default_design)
        form.addRow("Default source", self.default_source)
        form.addRow("Default tags", self.default_tags)
        form.addRow("Default hashtags", self.default_hashtags)
        form.addRow("Default upload metadata (JSON)", self.default_metadata)
        form.addRow("Schedule template", self.schedule_template)
        form.addRow("Enabled", self.enabled)
        root.addLayout(form)
        row = QHBoxLayout()
        self.new_button = QPushButton("New")
        self.save_button = QPushButton("Save")
        self.delete_button = QPushButton("Delete")
        self.connect_button = QPushButton("Connect OAuth")
        self.disconnect_button = QPushButton("Disconnect")
        self.capabilities_button = QPushButton("Refresh Capabilities")
        for button in (
            self.new_button,
            self.save_button,
            self.delete_button,
            self.connect_button,
            self.disconnect_button,
            self.capabilities_button,
        ):
            row.addWidget(button)
        root.addLayout(row)
        self.capabilities = QLabel("Select a channel to inspect platform capabilities.")
        self.capabilities.setWordWrap(True)
        root.addWidget(self.capabilities)
        self.platform.currentTextChanged.connect(self._privacy_options)
        self.new_button.clicked.connect(self._new)
        self.save_button.clicked.connect(self._save)
        self.delete_button.clicked.connect(self._delete)
        self.connect_button.clicked.connect(self._connect_oauth)
        self.disconnect_button.clicked.connect(self._disconnect)
        self.capabilities_button.clicked.connect(self._refresh_capabilities)
        self.table.itemSelectionChanged.connect(self._load)
        self._privacy_options()
        self._refresh_profile_options()
        self.refresh()

    def _refresh_profile_options(self) -> None:
        selections = (
            (self.default_preset, self.context.presets.list(), "No default preset"),
            (
                self.default_design,
                self.context.design_profile_manager.list(),
                "Use preset's saved design",
            ),
            (self.default_source, self.context.source_profiles.list(), "No default source"),
            (
                self.schedule_template,
                self.context.schedule_templates.list(),
                "No schedule template",
            ),
        )
        for combo, values, empty_label in selections:
            current = combo.currentData()
            combo.clear()
            combo.addItem(empty_label, None)
            for value in values:
                combo.addItem(value.name, value.id)
                if value.id == current:
                    combo.setCurrentIndex(combo.count() - 1)

    def _privacy_options(self) -> None:
        current = self.privacy.currentText()
        self.privacy.clear()
        if self.platform.currentText() == "youtube":
            self.privacy.addItems(["private", "unlisted", "public"])
        else:
            self.privacy.addItems(
                ["SELF_ONLY", "MUTUAL_FOLLOW_FRIENDS", "FOLLOWER_OF_CREATOR", "PUBLIC_TO_EVERYONE"]
            )
        if current:
            self.privacy.setCurrentText(current)

    def refresh(self, selected_id: str | None = None) -> None:
        self._refresh_profile_options()
        channels = self.context.channels.list()
        self.table.setRowCount(len(channels))
        for row, channel in enumerate(channels):
            values = [
                channel.display_name,
                channel.platform,
                channel.account_identifier or "—",
                channel.oauth_connection_state,
                channel.default_privacy,
                "Yes" if channel.enabled else "No",
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.ItemDataRole.UserRole, channel.id)
                self.table.setItem(row, column, item)
            if channel.id == selected_id:
                self.table.selectRow(row)
        self.table.resizeColumnsToContents()

    def _selected(self) -> ChannelProfile | None:
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return None
        return self.context.channels.get(
            self.table.item(rows[0].row(), 0).data(Qt.ItemDataRole.UserRole)
        )

    def _new(self) -> None:
        self.current_id = None
        self.name.clear()
        self.default_preset.setCurrentIndex(0)
        self.default_design.setCurrentIndex(0)
        self.default_source.setCurrentIndex(0)
        self.default_tags.clear()
        self.default_hashtags.clear()
        self.default_metadata.setPlainText("{}")
        self.schedule_template.setCurrentIndex(0)
        self.enabled.setChecked(True)
        self.capabilities.setText("New channel profile is not connected.")

    def _save(self) -> None:
        try:
            existing = self.context.channels.get(self.current_id) if self.current_id else None
            channel = existing or ChannelProfile(
                display_name=self.name.text() or "New Channel", platform=self.platform.currentText()
            )
            channel.display_name = self.name.text().strip() or channel.display_name
            channel.platform = self.platform.currentText()
            channel.language = self.language.text().strip() or "en"
            channel.timezone = self.timezone.text().strip() or self.context.settings.timezone
            channel.default_privacy = self.privacy.currentText()
            channel.default_preset_id = self.default_preset.currentData()
            channel.default_design_profile_id = self.default_design.currentData()
            if channel.default_preset_id and channel.default_design_profile_id:
                preset = self.context.presets.get(channel.default_preset_id)
                design = self.context.design_profile_manager.get(channel.default_design_profile_id)
                if preset and design and preset.video_format != design.video_format:
                    raise ValueError(
                        f"Design '{design.name}' cannot be used with preset '{preset.name}'."
                    )
            channel.default_source_profile_id = self.default_source.currentData()
            channel.default_tags = self._csv(self.default_tags.text())
            channel.default_hashtags = self._csv(self.default_hashtags.text())
            metadata = json.loads(self.default_metadata.toPlainText() or "{}")
            if not isinstance(metadata, dict):
                raise ValueError("Default upload metadata must be a JSON object.")
            channel.default_upload_metadata = metadata
            channel.schedule_template_id = self.schedule_template.currentData()
            channel.enabled = self.enabled.isChecked()
            self.context.channels.save(channel)
            self.current_id = channel.id
            self.refresh(channel.id)
        except Exception as error:
            QMessageBox.critical(self, "Channel validation failed", str(error))

    def _load(self) -> None:
        channel = self._selected()
        if not channel:
            return
        self.current_id = channel.id
        self.name.setText(channel.display_name)
        self.platform.setCurrentText(channel.platform)
        self.language.setText(channel.language)
        self.timezone.setText(channel.timezone)
        self.privacy.setCurrentText(channel.default_privacy)
        self.default_preset.setCurrentIndex(
            max(0, self.default_preset.findData(channel.default_preset_id))
        )
        self.default_design.setCurrentIndex(
            max(0, self.default_design.findData(channel.default_design_profile_id))
        )
        self.default_source.setCurrentIndex(
            max(0, self.default_source.findData(channel.default_source_profile_id))
        )
        self.default_tags.setText(", ".join(channel.default_tags))
        self.default_hashtags.setText(", ".join(channel.default_hashtags))
        self.default_metadata.setPlainText(
            json.dumps(channel.default_upload_metadata, indent=2, ensure_ascii=False)
        )
        self.schedule_template.setCurrentIndex(
            max(0, self.schedule_template.findData(channel.schedule_template_id))
        )
        self.enabled.setChecked(channel.enabled)
        self.capabilities.setText(f"OAuth state: {channel.oauth_connection_state}")

    def _delete(self) -> None:
        channel = self._selected()
        if (
            channel
            and QMessageBox.question(
                self, "Delete channel", "Disconnect credentials and delete this channel profile?"
            )
            == QMessageBox.StandardButton.Yes
        ):
            self.context.oauth.disconnect(channel.id)
            self.context.channels.delete(channel.id)
            self._new()
            self.refresh()

    def _connect_oauth(self) -> None:
        channel = self._selected()
        if not channel or self.worker:
            return
        if channel.platform == "youtube":
            filename, _ = QFileDialog.getOpenFileName(
                self, "Select Google OAuth desktop client JSON", "", "JSON (*.json)"
            )
            if not filename:
                return

            def task(*, cancel_event, progress_callback):
                return self.context.oauth.connect_youtube(channel.id, Path(filename))
        else:
            if not all(
                os.getenv(name)
                for name in ("TIKTOK_CLIENT_KEY", "TIKTOK_CLIENT_SECRET", "TIKTOK_REDIRECT_URI")
            ):
                QMessageBox.warning(
                    self,
                    "TikTok credentials missing",
                    "Set TIKTOK_CLIENT_KEY, TIKTOK_CLIENT_SECRET, and TIKTOK_REDIRECT_URI before connecting.",
                )
                return

            def task(*, cancel_event, progress_callback):
                return self.context.oauth.connect_tiktok_interactive(channel.id)

        worker = BackgroundWorker(task)
        self.worker = worker
        self.connect_button.setEnabled(False)
        worker.signals.result.connect(lambda _result: self._connected(channel.id))
        worker.signals.error.connect(
            lambda value: QMessageBox.critical(self, "OAuth failed", value.splitlines()[-1])
        )
        worker.signals.finished.connect(self._oauth_finished)
        QThreadPool.globalInstance().start(worker)

    def _connected(self, channel_id: str) -> None:
        channel = self.context.channels.get(channel_id)
        if channel:
            channel.oauth_connection_state = "connected"
            self.context.channels.save(channel)
            self.refresh(channel.id)
            if channel.platform == "tiktok":
                self._refresh_capabilities()

    def _oauth_finished(self) -> None:
        self.worker = None
        self.connect_button.setEnabled(True)

    def _disconnect(self) -> None:
        channel = self._selected()
        if channel:
            self.context.oauth.disconnect(channel.id)
            channel.oauth_connection_state = "disconnected"
            channel.account_identifier = ""
            self.context.channels.save(channel)
            self.refresh(channel.id)

    def _refresh_capabilities(self) -> None:
        channel = self._selected()
        if not channel or self.worker:
            return

        def task(*, cancel_event, progress_callback):
            uploader = self.context.scheduler.uploaders[channel.platform]
            return uploader.capabilities(channel.id)

        worker = BackgroundWorker(task)
        self.worker = worker
        worker.signals.result.connect(
            lambda value: self._show_capabilities(channel.id, channel.platform, value)
        )
        worker.signals.error.connect(
            lambda value: QMessageBox.critical(
                self, "Capability query failed", value.splitlines()[-1]
            )
        )
        worker.signals.finished.connect(self._oauth_finished)
        QThreadPool.globalInstance().start(worker)

    def _show_capabilities(self, channel_id: str, platform: str, value) -> None:
        channel = self.context.channels.get(channel_id)
        if platform == "youtube":
            if channel:
                channel.account_identifier = str(value.get("channel_id", ""))
                self.context.channels.save(channel)
            self.capabilities.setText(
                f"Channel: {value.get('title', 'unknown')} | ID: {value.get('channel_id', 'unknown')} | "
                f"Uploads playlist: {value.get('uploads_playlist_id', 'unknown')}"
            )
            self.refresh(channel_id)
            return
        if channel:
            channel.account_identifier = value.creator_username
            self.context.channels.save(channel)
        self.capabilities.setText(
            f"Creator: {value.creator_nickname} (@{value.creator_username})\n"
            f"Privacy: {', '.join(value.privacy_level_options)}\n"
            f"Maximum duration: {value.max_video_duration_seconds}s | Comments: {value.comments_allowed} | "
            f"Duet: {value.duet_allowed} | Stitch: {value.stitch_allowed} | "
            f"Direct Post: {value.direct_post_available} | Draft Upload: {value.draft_upload_available}"
        )
        self.refresh(channel_id)

    @staticmethod
    def _csv(value: str) -> list[str]:
        return [item.strip() for item in value.split(",") if item.strip()]
