"""Application settings and OS-backed credential editor."""

from __future__ import annotations

import os
from zoneinfo import ZoneInfo

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from app.core.app_context import AppContext
from app.core.config import AppSettings
from app.core.credentials import (
    GEMINI_API_KEY,
    REDDIT_CLIENT_ID,
    REDDIT_CLIENT_SECRET,
    REDDIT_REFRESH_TOKEN,
    TIKTOK_CLIENT_KEY,
    TIKTOK_CLIENT_SECRET,
    TIKTOK_REDIRECT_URI,
    TIKTOK_SCOPES,
)


class SettingsPage(QWidget):
    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        root = QVBoxLayout(self)
        title = QLabel("Settings")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        form = QFormLayout(content)
        settings = context.settings
        self.output = QLineEdit(settings.output_directory or str(context.paths.outputs))
        self.cache = QLineEdit(settings.cache_directory or str(context.paths.cache))
        self.temp = QLineEdit(settings.temporary_directory or str(context.paths.temp))
        self.ffmpeg = QLineEdit(settings.ffmpeg_path)
        self.ffprobe = QLineEdit(settings.ffprobe_path)
        self.ytdlp = QLineEdit(settings.ytdlp_path or "")
        self.theme = QComboBox()
        self.theme.addItems(["system", "dark", "light"])
        self.theme.setCurrentText(settings.theme)
        self.language = QLineEdit(settings.language)
        self.timezone = QLineEdit(settings.timezone)
        self.log_level = QComboBox()
        self.log_level.addItems(["DEBUG", "INFO", "WARNING", "ERROR"])
        self.log_level.setCurrentText(settings.log_level)
        self.auto_updates = QCheckBox()
        self.auto_updates.setChecked(settings.auto_update_checks)
        self.reddit_provider = QComboBox()
        self.reddit_provider.addItems(["archive", "oauth", "mock"])
        self.reddit_provider.setCurrentText(
            "archive"
            if settings.source.reddit_provider == "public"
            else settings.source.reddit_provider
        )
        self.request_rate = QDoubleSpinBox()
        self.request_rate.setRange(0.5, 60)
        self.request_rate.setValue(settings.source.request_interval_seconds)
        self.source_timeout = QDoubleSpinBox()
        self.source_timeout.setRange(1, 300)
        self.source_timeout.setValue(settings.source.timeout_seconds)
        self.source_retries = QSpinBox()
        self.source_retries.setRange(0, 10)
        self.source_retries.setValue(settings.source.retry_count)
        self.source_cache_ttl = QSpinBox()
        self.source_cache_ttl.setRange(0, 86400)
        self.source_cache_ttl.setValue(settings.source.cache_ttl_seconds)
        self.default_candidates = QSpinBox()
        self.default_candidates.setRange(1, 200)
        self.default_candidates.setValue(settings.source.default_candidate_limit)
        self.max_download_height = QSpinBox()
        self.max_download_height.setRange(240, 4320)
        self.max_download_height.setValue(settings.source.max_download_height)
        self.archive_max_pages = QSpinBox()
        self.archive_max_pages.setRange(1, 10)
        self.archive_max_pages.setValue(settings.source.archive_max_pages)
        self.archive_min_short_edge = QSpinBox()
        self.archive_min_short_edge.setRange(0, 2160)
        self.archive_min_short_edge.setSpecialValueText("No minimum")
        self.archive_min_short_edge.setValue(settings.source.archive_min_short_edge)
        self.archive_require_audio = QCheckBox()
        self.archive_require_audio.setChecked(settings.source.archive_require_audio)
        self.archive_score_maturity = QSpinBox()
        self.archive_score_maturity.setRange(0, 168)
        self.archive_score_maturity.setSuffix(" hours")
        self.archive_score_maturity.setValue(settings.source.archive_score_maturity_hours)
        self.user_agent = QLineEdit(settings.source.user_agent)
        self.reddit_client_id_env = QLineEdit(settings.source.oauth_client_id_env)
        self.reddit_client_secret_env = QLineEdit(settings.source.oauth_client_secret_env)
        self.reddit_refresh_token_env = QLineEdit(settings.source.oauth_refresh_token_env)
        self.ai_provider = QComboBox()
        self.ai_provider.addItems(["gemini", "mock", "twelvelabs"])
        self.ai_provider.setCurrentText(settings.ai.provider)
        self.ai_model = QLineEdit(settings.ai.model)
        self.media_resolution = QComboBox()
        self.media_resolution.addItems(["low", "medium", "high"])
        self.media_resolution.setCurrentText(settings.ai.media_resolution)
        self.ai_key_env = QLineEdit(settings.ai.api_key_env)
        self.ai_key_env.setPlaceholderText("GEMINI_API_KEY")
        self.ai_key_env.setToolTip(
            "Optional migration fallback. The actual key can be entered directly below."
        )
        self.gemini_api_key = self._credential_entry(
            GEMINI_API_KEY, settings.ai.api_key_env, secret=True
        )
        self.reddit_client_id = self._credential_entry(
            REDDIT_CLIENT_ID, settings.source.oauth_client_id_env, secret=True
        )
        self.reddit_client_secret = self._credential_entry(
            REDDIT_CLIENT_SECRET, settings.source.oauth_client_secret_env, secret=True
        )
        self.reddit_refresh_token = self._credential_entry(
            REDDIT_REFRESH_TOKEN, settings.source.oauth_refresh_token_env, secret=True
        )
        self.tiktok_client_key = self._credential_entry(
            TIKTOK_CLIENT_KEY, "TIKTOK_CLIENT_KEY", secret=True
        )
        self.tiktok_client_secret = self._credential_entry(
            TIKTOK_CLIENT_SECRET, "TIKTOK_CLIENT_SECRET", secret=True
        )
        self.tiktok_redirect_uri = self._credential_entry(
            TIKTOK_REDIRECT_URI, "TIKTOK_REDIRECT_URI", secret=False
        )
        self.tiktok_scopes = self._credential_entry(TIKTOK_SCOPES, "TIKTOK_SCOPES", secret=False)
        self.ai_request_timeout = QDoubleSpinBox()
        self.ai_request_timeout.setRange(1, 3600)
        self.ai_request_timeout.setValue(settings.ai.request_timeout_seconds)
        self.ai_processing_timeout = QDoubleSpinBox()
        self.ai_processing_timeout.setRange(1, 7200)
        self.ai_processing_timeout.setValue(settings.ai.processing_timeout_seconds)
        self.ai_cache = QCheckBox()
        self.ai_cache.setChecked(settings.ai.cache_enabled)
        self.final_review = QCheckBox()
        self.final_review.setChecked(settings.ai.final_review_enabled)
        self.adaptive_prompt = QCheckBox()
        self.adaptive_prompt.setChecked(settings.ai.adaptive_prompt_enabled)
        self.adaptive_examples = QSpinBox()
        self.adaptive_examples.setRange(1, 20)
        self.adaptive_examples.setValue(settings.ai.adaptive_prompt_maximum_examples)
        self.adaptive_recurrence = QSpinBox()
        self.adaptive_recurrence.setRange(2, 20)
        self.adaptive_recurrence.setValue(settings.ai.adaptive_prompt_minimum_pattern_occurrences)
        self.adaptive_status = QLabel(
            f"{context.adaptive_preferences.count()} saved editorial correction(s)"
        )
        self.clear_adaptive = QPushButton("Forget Learned Writing Preferences")
        self.warning_threshold = QSpinBox()
        self.warning_threshold.setRange(1, 100)
        self.warning_threshold.setValue(settings.ai.budget.warning_threshold_percent)
        self.max_tokens = QSpinBox()
        self.max_tokens.setRange(1, 2_000_000)
        self.max_tokens.setValue(settings.ai.budget.max_tokens_per_request)
        self.max_video_seconds = QDoubleSpinBox()
        self.max_video_seconds.setRange(1, 7200)
        self.max_video_seconds.setValue(settings.ai.budget.max_video_seconds_per_request)
        self.clip_prompt_version = QLineEdit(settings.ai.clip_prompt_version)
        self.creative_prompt_version = QLineEdit(settings.ai.creative_prompt_version)
        self.review_prompt_version = QLineEdit(settings.ai.review_prompt_version)
        self.clip_token_estimate = QSpinBox()
        self.clip_token_estimate.setRange(100, 32_000)
        self.clip_token_estimate.setValue(settings.ai.clip_output_token_estimate)
        self.creative_token_estimate = QSpinBox()
        self.creative_token_estimate.setRange(100, 32_000)
        self.creative_token_estimate.setValue(settings.ai.creative_output_token_estimate)
        self.review_token_estimate = QSpinBox()
        self.review_token_estimate.setRange(100, 32_000)
        self.review_token_estimate.setValue(settings.ai.review_output_token_estimate)
        self.request_budget = self._money(settings.ai.budget.request_limit_usd)
        self.job_budget = self._money(settings.ai.budget.job_limit_usd)
        self.daily_budget = self._money(settings.ai.budget.daily_limit_usd)
        self.monthly_budget = self._money(settings.ai.budget.monthly_limit_usd)
        self.render_parallel = QSpinBox()
        self.render_parallel.setRange(1, 4)
        self.render_parallel.setValue(settings.render.parallel_renders)
        self.hardware_acceleration = QLineEdit(settings.render.hardware_acceleration or "")
        self.render_codec = QLineEdit(settings.render.codec)
        self.render_crf = QSpinBox()
        self.render_crf.setRange(0, 51)
        self.render_crf.setValue(settings.render.crf)
        self.encoder_preset = QLineEdit(settings.render.preset)
        self.video_bitrate = QLineEdit(settings.render.video_bitrate or "")
        self.audio_bitrate = QLineEdit(settings.render.audio_bitrate)
        self.cleanup_temp = QCheckBox()
        self.cleanup_temp.setChecked(settings.render.cleanup_temporary_files)
        self.preview_quality = QComboBox()
        self.preview_quality.addItems(["low", "medium", "high"])
        self.preview_quality.setCurrentText(settings.render.preview_quality)
        self.upload_parallel = QSpinBox()
        self.upload_parallel.setRange(1, 4)
        self.upload_parallel.setValue(settings.upload.concurrency)
        self.upload_retries = QSpinBox()
        self.upload_retries.setRange(0, 10)
        self.upload_retries.setValue(settings.upload.retry_count)
        self.default_privacy = QLineEdit(settings.upload.default_privacy)
        self.metadata_language = QLineEdit(settings.upload.metadata_language)
        self.scheduler_auto_start = QCheckBox()
        self.scheduler_auto_start.setChecked(settings.upload.scheduler_auto_start)
        self.missed = QComboBox()
        self.missed.addItems(["ask", "skip", "upload_immediately", "shift_remaining"])
        self.missed.setCurrentText(settings.upload.missed_job_policy)
        self.secret_status = QLabel(self._credential_status_text())
        self.secret_status.setWordWrap(True)
        fields = [
            ("Output directory", self.output),
            ("Cache directory", self.cache),
            ("Temporary directory", self.temp),
            ("FFmpeg", self.ffmpeg),
            ("ffprobe", self.ffprobe),
            ("yt-dlp executable (blank uses Python module)", self.ytdlp),
            ("Theme", self.theme),
            ("Language", self.language),
            ("Timezone", self.timezone),
            ("Log level", self.log_level),
            ("Automatic update checks", self.auto_updates),
            ("Reddit provider", self.reddit_provider),
            ("Minimum source request interval", self.request_rate),
            ("Source timeout", self.source_timeout),
            ("Source retry count", self.source_retries),
            ("Source cache TTL", self.source_cache_ttl),
            ("Default candidate limit", self.default_candidates),
            ("Source User-Agent", self.user_agent),
            ("Maximum download short edge", self.max_download_height),
            ("Arctic Shift maximum pages", self.archive_max_pages),
            ("Arctic Shift minimum short edge", self.archive_min_short_edge),
            ("Require original clip audio", self.archive_require_audio),
            ("Score maturity threshold", self.archive_score_maturity),
            ("Reddit client ID environment name", self.reddit_client_id_env),
            ("Reddit client secret environment name", self.reddit_client_secret_env),
            ("Reddit refresh token environment name", self.reddit_refresh_token_env),
            ("Reddit OAuth client ID (optional)", self.reddit_client_id),
            ("Reddit OAuth client secret (optional)", self.reddit_client_secret),
            ("Reddit OAuth refresh token (optional)", self.reddit_refresh_token),
            ("AI provider", self.ai_provider),
            ("AI model", self.ai_model),
            ("AI media resolution", self.media_resolution),
            ("Gemini API key", self.gemini_api_key),
            ("Gemini environment fallback name", self.ai_key_env),
            ("AI request timeout", self.ai_request_timeout),
            ("AI processing timeout", self.ai_processing_timeout),
            ("AI cache enabled", self.ai_cache),
            ("AI final review enabled", self.final_review),
            ("Learn automatically from Review edits", self.adaptive_prompt),
            ("Maximum learned examples per prompt", self.adaptive_examples),
            ("Repeats required for global pattern", self.adaptive_recurrence),
            ("Learned writing memory", self.adaptive_status),
            ("Reset learned writing memory", self.clear_adaptive),
            ("Request budget", self.request_budget),
            ("Production-job budget", self.job_budget),
            ("Daily budget", self.daily_budget),
            ("Monthly budget", self.monthly_budget),
            ("Budget warning threshold", self.warning_threshold),
            ("Maximum tokens per request", self.max_tokens),
            ("Maximum video seconds per request", self.max_video_seconds),
            ("Clip prompt version", self.clip_prompt_version),
            ("Creative prompt version", self.creative_prompt_version),
            ("Review prompt version", self.review_prompt_version),
            ("Clip output-token estimate", self.clip_token_estimate),
            ("Creative output-token estimate", self.creative_token_estimate),
            ("Review output-token estimate", self.review_token_estimate),
            ("Parallel renders", self.render_parallel),
            ("Hardware acceleration", self.hardware_acceleration),
            ("Default render codec", self.render_codec),
            ("Default CRF", self.render_crf),
            ("FFmpeg encoder preset", self.encoder_preset),
            ("Default video bitrate", self.video_bitrate),
            ("Default audio bitrate", self.audio_bitrate),
            ("Clean temporary render files", self.cleanup_temp),
            ("Preview quality", self.preview_quality),
            ("Upload concurrency", self.upload_parallel),
            ("Upload retry count", self.upload_retries),
            ("Default upload privacy", self.default_privacy),
            ("Metadata language", self.metadata_language),
            ("Start scheduler automatically", self.scheduler_auto_start),
            ("Missed-job policy", self.missed),
            ("TikTok client key (optional)", self.tiktok_client_key),
            ("TikTok client secret (optional)", self.tiktok_client_secret),
            ("TikTok redirect URI (optional)", self.tiktok_redirect_uri),
            ("TikTok scopes (optional)", self.tiktok_scopes),
            ("Credential status", self.secret_status),
        ]
        for label, widget in fields:
            form.addRow(label, widget)
        scroll.setWidget(content)
        root.addWidget(scroll)
        self.save = QPushButton("Save Settings")
        root.addWidget(self.save)
        self.save.clicked.connect(self._save)
        self.clear_adaptive.clicked.connect(self._clear_adaptive_preferences)

    @staticmethod
    def _money(value: float) -> QDoubleSpinBox:
        widget = QDoubleSpinBox()
        widget.setRange(0, 10000)
        widget.setDecimals(2)
        widget.setPrefix("$")
        widget.setValue(value)
        return widget

    def _credential_entry(
        self,
        reference: str,
        environment_name: str,
        *,
        secret: bool,
    ) -> QLineEdit:
        widget = QLineEdit()
        if secret:
            widget.setEchoMode(QLineEdit.EchoMode.Password)
        widget.setPlaceholderText(
            "Saved — leave blank to keep, or type a replacement"
            if self._credential_available(reference, environment_name)
            else "Paste value here; it will be stored by Windows, not in .env"
        )
        return widget

    def _credential_available(self, reference: str, environment_name: str) -> bool:
        try:
            return bool(self.context.credentials.get(reference) or os.getenv(environment_name))
        except Exception:
            return bool(os.getenv(environment_name))

    def _credential_status_text(self) -> str:
        gemini = self._credential_available(GEMINI_API_KEY, self.context.settings.ai.api_key_env)
        reddit = all(
            (
                self._credential_available(
                    REDDIT_CLIENT_ID, self.context.settings.source.oauth_client_id_env
                ),
                self._credential_available(
                    REDDIT_CLIENT_SECRET, self.context.settings.source.oauth_client_secret_env
                ),
                self._credential_available(
                    REDDIT_REFRESH_TOKEN, self.context.settings.source.oauth_refresh_token_env
                ),
            )
        )
        tiktok = all(
            (
                self._credential_available(TIKTOK_CLIENT_KEY, "TIKTOK_CLIENT_KEY"),
                self._credential_available(TIKTOK_CLIENT_SECRET, "TIKTOK_CLIENT_SECRET"),
                self._credential_available(TIKTOK_REDIRECT_URI, "TIKTOK_REDIRECT_URI"),
            )
        )
        return (
            f"Gemini: {'ready' if gemini else 'missing'} | "
            f"Reddit OAuth: {'ready' if reddit else 'optional / incomplete'} | "
            f"TikTok app: {'ready' if tiktok else 'optional / incomplete'}"
        )

    def _save(self) -> None:
        # Build and validate a detached draft so a failed save cannot modify the live services.
        settings = self.context.settings.model_copy(deep=True)
        try:
            ZoneInfo(self.timezone.text().strip())
            settings.output_directory = str(
                self.context.paths.validate_user_directory(self.output.text().strip(), create=True)
            )
            settings.cache_directory = str(
                self.context.paths.validate_user_directory(self.cache.text().strip(), create=True)
            )
            settings.temporary_directory = str(
                self.context.paths.validate_user_directory(self.temp.text().strip(), create=True)
            )
            settings.ffmpeg_path = self.ffmpeg.text().strip()
            settings.ffprobe_path = self.ffprobe.text().strip()
            settings.ytdlp_path = self.ytdlp.text().strip() or None
            settings.theme = self.theme.currentText()
            settings.language = self.language.text().strip() or "en"
            settings.timezone = self.timezone.text().strip()
            settings.log_level = self.log_level.currentText()
            settings.auto_update_checks = self.auto_updates.isChecked()
            settings.source.reddit_provider = self.reddit_provider.currentText()
            settings.source.request_interval_seconds = self.request_rate.value()
            settings.source.timeout_seconds = self.source_timeout.value()
            settings.source.retry_count = self.source_retries.value()
            settings.source.cache_ttl_seconds = self.source_cache_ttl.value()
            settings.source.default_candidate_limit = self.default_candidates.value()
            settings.source.max_download_height = self.max_download_height.value()
            settings.source.archive_max_pages = self.archive_max_pages.value()
            settings.source.archive_min_short_edge = self.archive_min_short_edge.value()
            settings.source.archive_require_audio = self.archive_require_audio.isChecked()
            settings.source.archive_score_maturity_hours = self.archive_score_maturity.value()
            settings.source.user_agent = self.user_agent.text().strip()
            settings.source.oauth_client_id_env = self.reddit_client_id_env.text().strip()
            settings.source.oauth_client_secret_env = self.reddit_client_secret_env.text().strip()
            settings.source.oauth_refresh_token_env = self.reddit_refresh_token_env.text().strip()
            settings.ai.provider = self.ai_provider.currentText()
            settings.ai.model = self.ai_model.text().strip()
            settings.ai.media_resolution = self.media_resolution.currentText()
            settings.ai.api_key_env = self.ai_key_env.text().strip()
            settings.ai.request_timeout_seconds = self.ai_request_timeout.value()
            settings.ai.processing_timeout_seconds = self.ai_processing_timeout.value()
            settings.ai.cache_enabled = self.ai_cache.isChecked()
            settings.ai.final_review_enabled = self.final_review.isChecked()
            settings.ai.adaptive_prompt_enabled = self.adaptive_prompt.isChecked()
            settings.ai.adaptive_prompt_maximum_examples = self.adaptive_examples.value()
            settings.ai.adaptive_prompt_minimum_pattern_occurrences = (
                self.adaptive_recurrence.value()
            )
            settings.ai.budget.request_limit_usd = self.request_budget.value()
            settings.ai.budget.job_limit_usd = self.job_budget.value()
            settings.ai.budget.daily_limit_usd = self.daily_budget.value()
            settings.ai.budget.monthly_limit_usd = self.monthly_budget.value()
            settings.ai.budget.warning_threshold_percent = self.warning_threshold.value()
            settings.ai.budget.max_tokens_per_request = self.max_tokens.value()
            settings.ai.budget.max_video_seconds_per_request = self.max_video_seconds.value()
            settings.ai.clip_prompt_version = self.clip_prompt_version.text().strip()
            settings.ai.creative_prompt_version = self.creative_prompt_version.text().strip()
            settings.ai.review_prompt_version = self.review_prompt_version.text().strip()
            settings.ai.clip_output_token_estimate = self.clip_token_estimate.value()
            settings.ai.creative_output_token_estimate = self.creative_token_estimate.value()
            settings.ai.review_output_token_estimate = self.review_token_estimate.value()
            settings.render.parallel_renders = self.render_parallel.value()
            settings.render.hardware_acceleration = (
                self.hardware_acceleration.text().strip() or None
            )
            settings.render.codec = self.render_codec.text().strip()
            settings.render.crf = self.render_crf.value()
            settings.render.preset = self.encoder_preset.text().strip() or "medium"
            settings.render.video_bitrate = self.video_bitrate.text().strip() or None
            settings.render.audio_bitrate = self.audio_bitrate.text().strip()
            settings.render.cleanup_temporary_files = self.cleanup_temp.isChecked()
            settings.render.preview_quality = self.preview_quality.currentText()
            settings.upload.concurrency = self.upload_parallel.value()
            settings.upload.retry_count = self.upload_retries.value()
            settings.upload.default_privacy = self.default_privacy.text().strip()
            settings.upload.metadata_language = self.metadata_language.text().strip() or "en"
            settings.upload.scheduler_auto_start = self.scheduler_auto_start.isChecked()
            settings.upload.missed_job_policy = self.missed.currentText()
            settings = AppSettings.model_validate(settings.model_dump(mode="python"))
            self.context.settings_store.save(settings)
            self.context.settings = settings
            self.context.adaptive_preferences.enabled = settings.ai.adaptive_prompt_enabled
            self.context.adaptive_preferences.maximum_examples = (
                settings.ai.adaptive_prompt_maximum_examples
            )
            self.context.adaptive_preferences.minimum_pattern_occurrences = (
                settings.ai.adaptive_prompt_minimum_pattern_occurrences
            )
            for reference, widget in (
                (GEMINI_API_KEY, self.gemini_api_key),
                (REDDIT_CLIENT_ID, self.reddit_client_id),
                (REDDIT_CLIENT_SECRET, self.reddit_client_secret),
                (REDDIT_REFRESH_TOKEN, self.reddit_refresh_token),
                (TIKTOK_CLIENT_KEY, self.tiktok_client_key),
                (TIKTOK_CLIENT_SECRET, self.tiktok_client_secret),
                (TIKTOK_REDIRECT_URI, self.tiktok_redirect_uri),
                (TIKTOK_SCOPES, self.tiktok_scopes),
            ):
                value = widget.text().strip()
                if value:
                    self.context.credentials.set(reference, value)
                widget.clear()
            self.secret_status.setText(self._credential_status_text())
            QMessageBox.information(
                self,
                "Settings saved",
                "Settings and entered credentials were saved. New Gemini jobs can use the key "
                "immediately. Restart ClipFactory after changing paths, providers, or runtime limits.",
            )
        except Exception as error:
            QMessageBox.critical(self, "Settings could not be saved", str(error))

    def _clear_adaptive_preferences(self) -> None:
        if (
            QMessageBox.question(
                self,
                "Forget learned writing preferences",
                "Delete all stored AI-original → user-edit examples? This cannot be undone.",
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        amount = self.context.adaptive_preferences.clear()
        self.adaptive_status.setText("0 saved editorial correction(s)")
        QMessageBox.information(
            self,
            "Writing memory cleared",
            f"Deleted {amount} saved correction(s).",
        )
