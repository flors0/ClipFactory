"""Source profile CRUD and automatic Reddit discovery diagnostics."""

from __future__ import annotations

from PySide6.QtCore import Qt, QThreadPool
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.app_context import AppContext
from app.core.workers import BackgroundWorker
from app.models.source_models import RightsMode
from app.sources.provider_factory import create_source_provider
from app.sources.source_profile_factory import SourceProfileFactory


class SourcesPage(QWidget):
    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        self.factory = SourceProfileFactory()
        self.current_id: str | None = None
        self.active_worker: BackgroundWorker | None = None
        root = QVBoxLayout(self)
        title = QLabel("Sources")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        editor = QWidget()
        form = QFormLayout(editor)
        self.name = QLineEdit()
        self.subreddit = QLineEdit()
        self.subreddit.setPlaceholderText("SillyCats, r/SillyCats, or a full subreddit URL")
        self.sort = QComboBox()
        self.sort.addItems(["top", "hot", "new"])
        self.time_filter = QComboBox()
        self.time_filter.addItems(["hour", "day", "week", "month", "year", "all"])
        self.time_filter.setCurrentText("week")
        self.limit = QSpinBox()
        self.limit.setRange(1, 200)
        self.limit.setValue(50)
        self.min_score = QSpinBox()
        self.min_score.setRange(0, 10_000_000)
        self.min_comments = QSpinBox()
        self.min_comments.setRange(0, 10_000_000)
        self.max_age = QSpinBox()
        self.max_age.setRange(1, 8760)
        self.max_age.setValue(168)
        self.allow_gifs = QCheckBox()
        self.allow_gifs.setChecked(True)
        self.allow_nsfw = QCheckBox()
        self.require_video = QCheckBox()
        self.require_video.setChecked(True)
        self.allow_crossposts = QCheckBox()
        self.allow_crossposts.setChecked(True)
        self.allowed_flairs = QLineEdit()
        self.allowed_flairs.setPlaceholderText("Comma-separated; blank allows all")
        self.blocked_flairs = QLineEdit()
        self.blocked_flairs.setPlaceholderText("Comma-separated")
        self.language = QLineEdit("en")
        self.theme_hint = QLineEdit()
        self.rights = QComboBox()
        self.rights.addItems([mode.value for mode in RightsMode])
        self.rights.setCurrentText(RightsMode.MANUAL_REVIEW.value)
        form.addRow("Profile name", self.name)
        form.addRow("Subreddit", self.subreddit)
        form.addRow("Sort", self.sort)
        form.addRow("Time filter", self.time_filter)
        form.addRow("Candidate limit", self.limit)
        form.addRow("Minimum score", self.min_score)
        form.addRow("Minimum comments", self.min_comments)
        form.addRow("Maximum age (hours)", self.max_age)
        form.addRow("Require video", self.require_video)
        form.addRow("Allow GIFs", self.allow_gifs)
        form.addRow("Allow NSFW", self.allow_nsfw)
        form.addRow("Allow crossposts", self.allow_crossposts)
        form.addRow("Allowed flairs", self.allowed_flairs)
        form.addRow("Blocked flairs", self.blocked_flairs)
        form.addRow("Language", self.language)
        form.addRow("Theme hint", self.theme_hint)
        form.addRow("Rights mode", self.rights)
        buttons = QHBoxLayout()
        self.new_button = QPushButton("New")
        self.save_button = QPushButton("Save")
        self.delete_button = QPushButton("Delete")
        self.test_button = QPushButton("Test Discovery")
        for button in (self.new_button, self.save_button, self.delete_button, self.test_button):
            buttons.addWidget(button)
        form.addRow(buttons)
        self.health = QLabel("Source health has not been checked.")
        self.health.setWordWrap(True)
        form.addRow("Source health", self.health)
        splitter.addWidget(editor)
        right = QWidget()
        right_layout = QVBoxLayout(right)
        self.profile_table = QTableWidget(0, 4)
        self.profile_table.setHorizontalHeaderLabels(["Name", "Community", "Sort", "Rights"])
        self.profile_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.profile_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        right_layout.addWidget(self.profile_table)
        self.candidate_table = QTableWidget(0, 6)
        self.candidate_table.setHorizontalHeaderLabels(
            ["Title", "Type", "Score", "Comments", "Age", "Rights"]
        )
        self.candidate_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        right_layout.addWidget(QLabel("Last candidates"))
        right_layout.addWidget(self.candidate_table)
        splitter.addWidget(right)
        splitter.setSizes([370, 900])
        root.addWidget(splitter)
        self.new_button.clicked.connect(self.clear_form)
        self.save_button.clicked.connect(self.save_profile)
        self.delete_button.clicked.connect(self.delete_profile)
        self.test_button.clicked.connect(self.test_discovery)
        self.profile_table.itemSelectionChanged.connect(self.load_selected)
        self.refresh_profiles()

    def refresh_profiles(self) -> None:
        profiles = self.context.source_profiles.list()
        self.profile_table.setRowCount(len(profiles))
        for row, profile in enumerate(profiles):
            values = [profile.name, profile.community, profile.sort, profile.rights_mode.value]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.ItemDataRole.UserRole, profile.id)
                self.profile_table.setItem(row, column, item)
        self.profile_table.resizeColumnsToContents()

    def clear_form(self) -> None:
        self.current_id = None
        self.name.clear()
        self.subreddit.clear()
        self.health.setText("Source health has not been checked.")

    def save_profile(self) -> None:
        try:
            profile = self.factory.create(
                self.subreddit.text(),
                name=self.name.text().strip() or None,
                sort=self.sort.currentText(),
                time_filter=self.time_filter.currentText(),
                candidate_limit=self.limit.value(),
                min_score=self.min_score.value(),
                min_comment_count=self.min_comments.value(),
                max_post_age_hours=self.max_age.value(),
                require_video=self.require_video.isChecked(),
                allow_nsfw=self.allow_nsfw.isChecked(),
                allow_gifs=self.allow_gifs.isChecked(),
                allow_crossposts=self.allow_crossposts.isChecked(),
                allowed_flairs=self._csv(self.allowed_flairs.text()),
                blocked_flairs=self._csv(self.blocked_flairs.text()),
                language=self.language.text().strip() or "en",
                theme_hint=self.theme_hint.text().strip() or None,
                rights_mode=RightsMode(self.rights.currentText()),
            )
            if self.current_id:
                existing = self.context.source_profiles.get(self.current_id)
                if existing:
                    profile.id = existing.id
                    profile.created_at = existing.created_at
            self.context.source_profiles.save(profile)
            self.current_id = profile.id
            self.refresh_profiles()
        except Exception as error:
            QMessageBox.critical(self, "Invalid source profile", str(error))

    def delete_profile(self) -> None:
        if not self.current_id:
            return
        if (
            QMessageBox.question(self, "Delete source", "Delete this source profile?")
            != QMessageBox.StandardButton.Yes
        ):
            return
        self.context.source_profiles.delete(self.current_id)
        self.clear_form()
        self.refresh_profiles()

    def load_selected(self) -> None:
        rows = self.profile_table.selectionModel().selectedRows()
        if not rows:
            return
        identifier = self.profile_table.item(rows[0].row(), 0).data(Qt.ItemDataRole.UserRole)
        profile = self.context.source_profiles.get(identifier)
        if not profile:
            return
        self.current_id = profile.id
        self.name.setText(profile.name)
        self.subreddit.setText(profile.source_url)
        self.sort.setCurrentText(profile.sort)
        self.time_filter.setCurrentText(profile.time_filter)
        self.limit.setValue(profile.candidate_limit)
        self.min_score.setValue(profile.min_score)
        self.min_comments.setValue(profile.min_comment_count)
        self.max_age.setValue(profile.max_post_age_hours)
        self.require_video.setChecked(profile.require_video)
        self.allow_gifs.setChecked(profile.allow_gifs)
        self.allow_nsfw.setChecked(profile.allow_nsfw)
        self.allow_crossposts.setChecked(profile.allow_crossposts)
        self.allowed_flairs.setText(", ".join(profile.allowed_flairs))
        self.blocked_flairs.setText(", ".join(profile.blocked_flairs))
        self.language.setText(profile.language)
        self.theme_hint.setText(profile.theme_hint or "")
        self.rights.setCurrentText(profile.rights_mode.value)

    def test_discovery(self) -> None:
        if self.active_worker:
            return
        try:
            profile = self.factory.create(
                self.subreddit.text(),
                name=self.name.text().strip() or None,
                sort=self.sort.currentText(),
                time_filter=self.time_filter.currentText(),
                candidate_limit=self.limit.value(),
                min_score=self.min_score.value(),
                min_comment_count=self.min_comments.value(),
                max_post_age_hours=self.max_age.value(),
                require_video=self.require_video.isChecked(),
                allow_nsfw=self.allow_nsfw.isChecked(),
                allow_gifs=self.allow_gifs.isChecked(),
                allow_crossposts=self.allow_crossposts.isChecked(),
                allowed_flairs=self._csv(self.allowed_flairs.text()),
                blocked_flairs=self._csv(self.blocked_flairs.text()),
                language=self.language.text().strip() or "en",
                theme_hint=self.theme_hint.text().strip() or None,
                rights_mode=RightsMode(self.rights.currentText()),
            )
        except Exception as error:
            QMessageBox.critical(self, "Invalid source", str(error))
            return
        provider = create_source_provider(
            self.context.settings.source,
            self.context.database,
            self.context.credentials,
        )

        def task(*, cancel_event, progress_callback):
            progress_callback(10, "Checking automatic Reddit source")
            return provider.discover(profile, cancel_event=cancel_event)

        worker = BackgroundWorker(task)
        self.active_worker = worker
        self.test_button.setText("Checking…")
        self.test_button.setEnabled(False)
        worker.signals.result.connect(self._show_discovery)
        worker.signals.error.connect(
            lambda value: QMessageBox.critical(self, "Discovery failed", value.splitlines()[-1])
        )
        worker.signals.finished.connect(self._discovery_finished)
        QThreadPool.globalInstance().start(worker)

    def _show_discovery(self, result) -> None:
        self.health.setText(
            f"{result.health.message} Provider: {result.health.provider}. Cache: {'hit' if result.health.cache_hit else 'miss'}."
        )
        self.candidate_table.setRowCount(len(result.candidates))
        now = result.health.checked_at
        for row, candidate in enumerate(result.candidates):
            values = [
                candidate.title,
                candidate.media_type.value,
                candidate.score if candidate.score is not None else "unknown",
                candidate.comment_count if candidate.comment_count is not None else "unknown",
                f"{(now - candidate.published_at).total_seconds() / 3600:.1f} h",
                candidate.rights_status,
            ]
            for column, value in enumerate(values):
                self.candidate_table.setItem(row, column, QTableWidgetItem(str(value)))
        self.candidate_table.resizeColumnsToContents()

    def _discovery_finished(self) -> None:
        self.active_worker = None
        self.test_button.setText("Test Discovery")
        self.test_button.setEnabled(True)

    @staticmethod
    def _csv(value: str) -> list[str]:
        return [item.strip() for item in value.split(",") if item.strip()]
