"""Redacted application log viewer."""

from __future__ import annotations

import re
from pathlib import Path

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QComboBox,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.core.app_context import AppContext
from app.core.logging import redact_text
from app.ui.log_scroll_state import LogScrollState


class LogsPage(QWidget):
    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        self._active_key: str | None = None
        self._restoring = False
        self._scroll_state = LogScrollState(
            positions=dict(context.settings.ui.log_scroll_positions),
            follow_tail=dict(context.settings.ui.log_follow_tail),
        )
        self._persist_timer = QTimer(self)
        self._persist_timer.setSingleShot(True)
        self._persist_timer.setInterval(400)
        self._persist_timer.timeout.connect(self._persist_scroll_state)
        root = QVBoxLayout(self)
        title = QLabel("Logs")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        self.selection = QComboBox()
        self.selection.currentIndexChanged.connect(self._load_selected)
        root.addWidget(QLabel("Log block"))
        root.addWidget(self.selection)
        self.viewer = QPlainTextEdit()
        self.viewer.setReadOnly(True)
        self.viewer.verticalScrollBar().valueChanged.connect(self._scroll_changed)
        root.addWidget(self.viewer)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.refresh)
        root.addWidget(refresh)
        self.refresh()

    def refresh(self) -> None:
        current = self.selection.currentData()
        application_log = self.context.paths.logs / "clipfactory.log"
        attempt_files = sorted(
            (self.context.paths.logs / "attempts").glob("job-*-attempt-*.log"),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
        self.selection.blockSignals(True)
        self.selection.clear()
        self.selection.addItem("All application logs (combined)", str(application_log))
        for path in attempt_files:
            match = re.fullmatch(r"job-(.+)-attempt-(\d+)\.log", path.name)
            if match:
                job_id, attempt = match.groups()
                label = f"Attempt {attempt} — Job {job_id}"
            else:
                label = path.name
            self.selection.addItem(label, str(path))
        selected_index = self.selection.findData(current)
        self.selection.setCurrentIndex(selected_index if selected_index >= 0 else 0)
        self.selection.blockSignals(False)
        self._load_selected()

    def _load_selected(self) -> None:
        previous_key = self._active_key
        previous_at_bottom = False
        if previous_key is not None:
            previous_at_bottom = self._store_current_position()
        selected = self.selection.currentData()
        path = Path(selected) if selected else self.context.paths.logs / "clipfactory.log"
        key = self._key(path)
        follow_tail = (
            previous_at_bottom
            if previous_key == key
            else self._scroll_state.follow_tail.get(key, False)
        )
        self._restoring = True
        if not path.exists():
            self.viewer.setPlainText("No application log has been created yet.")
        else:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            self.viewer.setPlainText(redact_text("\n".join(lines[-4000:])))
        self._active_key = key
        bar = self.viewer.verticalScrollBar()
        bar.setValue(
            self._scroll_state.restored_value(
                key,
                bar.maximum(),
                follow_tail=follow_tail,
            )
        )
        self._restoring = False
        self._store_current_position()

    @staticmethod
    def _key(path: Path) -> str:
        return "combined" if path.name == "clipfactory.log" else path.name

    def _store_current_position(self) -> bool:
        if self._active_key is None:
            return False
        bar = self.viewer.verticalScrollBar()
        return self._scroll_state.remember(
            self._active_key,
            bar.value(),
            bar.maximum(),
        )

    def _scroll_changed(self, _value: int) -> None:
        if self._restoring or self._active_key is None:
            return
        self._store_current_position()
        self._persist_timer.start()

    def _persist_scroll_state(self) -> None:
        self._store_current_position()
        self.context.settings.ui = self.context.settings.ui.model_copy(
            update={
                "log_scroll_positions": dict(self._scroll_state.positions),
                "log_follow_tail": dict(self._scroll_state.follow_tail),
            }
        )
        self.context.settings_store.save(self.context.settings)

    def hideEvent(self, event) -> None:
        self._persist_scroll_state()
        super().hideEvent(event)
