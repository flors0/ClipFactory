"""Upload batch approval and scheduler controls."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.app_context import AppContext
from app.models.schedule_models import MissedJobPolicy
from app.models.upload_models import UploadStatus


class UploadQueuePage(QWidget):
    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        root = QVBoxLayout(self)
        title = QLabel("Upload Queue")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        warning = QLabel(
            "No platform upload can start until the separate “Approve Upload Batch” action below."
        )
        warning.setObjectName("warningBanner")
        root.addWidget(warning)
        self.table = QTableWidget(0, 11)
        self.table.setHorizontalHeaderLabels(
            [
                "Status",
                "Platform",
                "Channel",
                "Publish time",
                "Execution time",
                "Progress",
                "Retries",
                "Updated",
                "Remote ID",
                "Error",
                "Last log",
            ]
        )
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        root.addWidget(self.table)
        row = QHBoxLayout()
        self.approve = QPushButton("Approve Upload Batch")
        self.pause = QPushButton("Pause Job")
        self.resume = QPushButton("Resume Job")
        self.retry = QPushButton("Retry")
        self.missed_now = QPushButton("Missed: Upload Now")
        self.missed_shift = QPushButton("Missed: Shift Batch")
        self.missed_skip = QPushButton("Missed: Skip")
        self.queue_pause = QPushButton("Pause Scheduler")
        self.refresh_button = QPushButton("Refresh")
        for button in (
            self.approve,
            self.pause,
            self.resume,
            self.retry,
            self.missed_now,
            self.missed_shift,
            self.missed_skip,
            self.queue_pause,
            self.refresh_button,
        ):
            row.addWidget(button)
        root.addLayout(row)
        self.approve.clicked.connect(self._approve)
        self.pause.clicked.connect(self._pause)
        self.resume.clicked.connect(self._resume)
        self.retry.clicked.connect(self._retry)
        self.missed_now.clicked.connect(
            lambda: self._resolve_missed(MissedJobPolicy.UPLOAD_IMMEDIATELY)
        )
        self.missed_shift.clicked.connect(
            lambda: self._resolve_missed(MissedJobPolicy.SHIFT_REMAINING)
        )
        self.missed_skip.clicked.connect(lambda: self._resolve_missed(MissedJobPolicy.SKIP))
        self.queue_pause.clicked.connect(self._toggle_scheduler)
        self.refresh_button.clicked.connect(self.refresh)
        self.refresh()

    def refresh(self) -> None:
        jobs = self.context.upload_jobs.list()
        self.table.setRowCount(len(jobs))
        for row, job in enumerate(jobs):
            values = [
                job.status.value,
                job.platform,
                job.channel_id,
                job.scheduled_at.isoformat(timespec="minutes"),
                (job.execution_at or job.scheduled_at).isoformat(timespec="minutes"),
                f"{job.progress}%",
                job.retry_count,
                job.updated_at.isoformat(timespec="seconds"),
                job.remote_id or "—",
                job.last_error or "",
                job.log_messages[-1] if job.log_messages else "",
            ]
            for column, value in enumerate(values):
                cell = QTableWidgetItem(str(value))
                cell.setData(Qt.ItemDataRole.UserRole, job.id)
                self.table.setItem(row, column, cell)
        self.table.resizeColumnsToContents()
        if not self.context.scheduler.running:
            self.queue_pause.setText("Start Scheduler")
        else:
            self.queue_pause.setText(
                "Resume Scheduler" if self.context.scheduler.paused else "Pause Scheduler"
            )

    def _selected_ids(self) -> list[str]:
        return [
            self.table.item(index.row(), 0).data(Qt.ItemDataRole.UserRole)
            for index in self.table.selectionModel().selectedRows()
        ]

    def _approve(self) -> None:
        identifiers = [
            identifier
            for identifier in self._selected_ids()
            if self.context.upload_jobs.get(identifier).status == UploadStatus.BLOCKED_APPROVAL
        ]
        if not identifiers:
            QMessageBox.information(
                self,
                "No blocked jobs selected",
                "Select one or more reviewed jobs awaiting upload-batch approval.",
            )
            return
        if (
            QMessageBox.question(
                self,
                "Confirm Upload Batch",
                f"Approve {len(identifiers)} upload job(s)? YouTube may upload immediately for native scheduling; TikTok uploads start at their local execution time.",
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        try:
            self.context.upload_queue.approve_upload_batch(identifiers)
            self.refresh()
        except Exception as error:
            QMessageBox.critical(self, "Upload approval failed", str(error))

    def _single(self) -> str | None:
        values = self._selected_ids()
        return values[0] if len(values) == 1 else None

    def _pause(self) -> None:
        identifier = self._single()
        if identifier:
            try:
                self.context.upload_queue.pause(identifier)
                self.refresh()
            except Exception as error:
                QMessageBox.warning(self, "Cannot pause", str(error))

    def _resume(self) -> None:
        identifier = self._single()
        if identifier:
            try:
                self.context.upload_queue.resume(identifier)
                self.refresh()
            except Exception as error:
                QMessageBox.warning(self, "Cannot resume", str(error))

    def _retry(self) -> None:
        identifier = self._single()
        if identifier:
            try:
                self.context.upload_queue.retry(identifier)
                self.refresh()
            except Exception as error:
                QMessageBox.warning(self, "Cannot retry", str(error))

    def _toggle_scheduler(self) -> None:
        if not self.context.scheduler.running:
            self.context.scheduler.start()
        elif self.context.scheduler.paused:
            self.context.scheduler.resume()
        else:
            self.context.scheduler.pause()
        self.refresh()

    def _resolve_missed(self, policy: MissedJobPolicy) -> None:
        try:
            self.context.upload_queue.resolve_missed(self._selected_ids(), policy)
            self.refresh()
        except Exception as error:
            QMessageBox.warning(self, "Catch-up action unavailable", str(error))
