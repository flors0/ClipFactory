"""Preset list and visual editor page."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QInputDialog,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from app.core.app_context import AppContext
from app.ui.widgets.preset_editor import PresetEditorWidget


class PresetsPage(QWidget):
    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        root = QVBoxLayout(self)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        sidebar = QWidget()
        side_layout = QVBoxLayout(sidebar)
        self.list = QListWidget()
        side_layout.addWidget(self.list)
        row = QHBoxLayout()
        self.new_button = QPushButton("New from Selected")
        self.duplicate = QPushButton("Duplicate")
        self.rename = QPushButton("Rename")
        self.delete = QPushButton("Delete")
        row.addWidget(self.new_button)
        row.addWidget(self.duplicate)
        row.addWidget(self.rename)
        row.addWidget(self.delete)
        side_layout.addLayout(row)
        row2 = QHBoxLayout()
        self.import_button = QPushButton("Import")
        self.export_button = QPushButton("Export")
        self.reset_button = QPushButton("Reset Core")
        row2.addWidget(self.import_button)
        row2.addWidget(self.export_button)
        row2.addWidget(self.reset_button)
        side_layout.addLayout(row2)
        splitter.addWidget(sidebar)
        self.editor = PresetEditorWidget(context.style_profile_manager)
        splitter.addWidget(self.editor)
        splitter.setSizes([220, 1100])
        root.addWidget(splitter)
        self.list.currentItemChanged.connect(self._load)
        self.editor.save_requested.connect(self._save)
        self.new_button.clicked.connect(self._new)
        self.duplicate.clicked.connect(self._duplicate)
        self.rename.clicked.connect(self._rename)
        self.delete.clicked.connect(self._delete)
        self.import_button.clicked.connect(self._import)
        self.export_button.clicked.connect(self._export)
        self.reset_button.clicked.connect(self._reset_core)
        self.refresh()

    def refresh(self, selected_id: str | None = None) -> None:
        self.editor.set_assets(
            {
                asset.id: (
                    f"{asset.asset_type}: {Path(asset.file_path).name}",
                    asset.file_path,
                )
                for asset in self.context.asset_library.list()
            }
        )
        self.list.clear()
        for preset in self.context.presets.list():
            item = QListWidgetItem(f"{'◆ ' if preset.core else ''}{preset.name}")
            item.setData(Qt.ItemDataRole.UserRole, preset.id)
            self.list.addItem(item)
            if selected_id == preset.id:
                self.list.setCurrentItem(item)
        if self.list.currentRow() < 0 and self.list.count():
            self.list.setCurrentRow(0)

    def _current_id(self) -> str | None:
        item = self.list.currentItem()
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def _load(self, current: QListWidgetItem | None, _previous: QListWidgetItem | None) -> None:
        if current:
            preset = self.context.presets.get(current.data(Qt.ItemDataRole.UserRole))
            if preset:
                self.editor.load_preset(preset)
                self.rename.setEnabled(not preset.core)
                self.delete.setEnabled(not preset.core)
                self.reset_button.setEnabled(preset.core)

    def _save(self, preset) -> None:
        try:
            self.context.preset_manager.save(preset)
            self.refresh(preset.id)
        except Exception as error:
            QMessageBox.critical(self, "Preset validation failed", str(error))

    def _duplicate(self) -> None:
        identifier = self._current_id()
        if identifier:
            preset = self.context.preset_manager.duplicate(identifier)
            self.refresh(preset.id)

    def _new(self) -> None:
        identifier = self._current_id()
        if not identifier:
            values = self.context.presets.list()
            identifier = values[0].id if values else None
        if not identifier:
            return
        name, accepted = QInputDialog.getText(self, "Create preset", "Preset name")
        if accepted and name.strip():
            try:
                preset = self.context.preset_manager.duplicate(identifier, name.strip())
                self.refresh(preset.id)
            except Exception as error:
                QMessageBox.critical(self, "Preset creation failed", str(error))

    def _rename(self) -> None:
        identifier = self._current_id()
        preset = self.context.presets.get(identifier) if identifier else None
        if not preset:
            return
        name, accepted = QInputDialog.getText(
            self,
            "Rename preset",
            "Preset name",
            text=preset.name,
        )
        if accepted and name.strip():
            try:
                renamed = self.context.preset_manager.rename(preset.id, name.strip())
                self.refresh(renamed.id)
            except Exception as error:
                QMessageBox.warning(self, "Preset rename failed", str(error))

    def _delete(self) -> None:
        identifier = self._current_id()
        if not identifier:
            return
        try:
            if (
                QMessageBox.question(self, "Delete preset", "Delete this custom preset?")
                == QMessageBox.StandardButton.Yes
            ):
                self.context.preset_manager.delete(identifier)
                self.refresh()
        except Exception as error:
            QMessageBox.warning(self, "Preset protected", str(error))

    def _reset_core(self) -> None:
        identifier = self._current_id()
        preset = self.context.presets.get(identifier) if identifier else None
        if not preset or not preset.core:
            return
        if (
            QMessageBox.question(
                self,
                "Reset core preset",
                f"Restore '{preset.name}' to the ClipFactory v1.1.0 shipped settings?",
            )
            != QMessageBox.StandardButton.Yes
        ):
            return
        try:
            restored = self.context.preset_manager.reset_core(preset.id)
            self.refresh(restored.id)
        except Exception as error:
            QMessageBox.critical(self, "Core reset failed", str(error))

    def _import(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(
            self, "Import preset", "", "ClipFactory Preset (*.json)"
        )
        if filename:
            try:
                preset = self.context.preset_manager.import_file(Path(filename))
                self.refresh(preset.id)
            except Exception as error:
                QMessageBox.critical(self, "Import failed", str(error))

    def _export(self) -> None:
        identifier = self._current_id()
        if not identifier:
            return
        filename, _ = QFileDialog.getSaveFileName(
            self, "Export preset", "preset.json", "ClipFactory Preset (*.json)"
        )
        if filename:
            try:
                self.context.preset_manager.export_file(identifier, Path(filename))
            except Exception as error:
                QMessageBox.critical(self, "Export failed", str(error))
