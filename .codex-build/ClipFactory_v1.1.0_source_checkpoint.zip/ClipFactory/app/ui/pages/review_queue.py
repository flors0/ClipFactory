"""Manual video review, metadata editing, and approval UI."""

from __future__ import annotations

import json

from PySide6.QtCore import QDateTime, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateTimeEdit,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSlider,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.app_context import AppContext
from app.models.preset_models import Color, Preset
from app.models.style_models import StyleProfileKind
from app.models.upload_models import TikTokMetadata, UploadStatus, YouTubeMetadata
from app.ui.path_helpers import resolve_output_folder
from app.ui.review_style_dialog import ReviewStyleDialog


class ReviewQueuePage(QWidget):
    rerender_requested = Signal(str)
    replace_clip_requested = Signal(str)

    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        self.current_id: str | None = None
        self.review_preset: Preset | None = None
        self._loading = False
        self._dirty = False
        self._dirty_sections: set[str] = set()
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.player.setAudioOutput(self.audio)
        self._splitter_persist_timer = QTimer(self)
        self._splitter_persist_timer.setSingleShot(True)
        self._splitter_persist_timer.setInterval(350)
        self._splitter_persist_timer.timeout.connect(self._persist_splitter_sizes)
        root = QVBoxLayout(self)
        title = QLabel("Review Queue")
        title.setObjectName("pageTitle")
        title.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        root.addWidget(title, 0, Qt.AlignmentFlag.AlignTop)
        self.main_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.main_splitter.setObjectName("reviewQueueMainSplitter")
        self.main_splitter.setChildrenCollapsible(False)
        self.main_splitter.setHandleWidth(8)
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            [
                "Status",
                "File",
                "Platform",
                "Channel",
                "Preset",
                "Design",
                "Schedule",
                "Technical",
            ]
        )
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        left_layout.addWidget(self.table)
        self.main_splitter.addWidget(left)

        self.detail_splitter = QSplitter(Qt.Orientation.Vertical)
        self.detail_splitter.setObjectName("reviewQueueDetailSplitter")
        self.detail_splitter.setChildrenCollapsible(False)
        self.detail_splitter.setHandleWidth(8)

        player_panel = QWidget()
        player_layout = QVBoxLayout(player_panel)
        player_layout.setContentsMargins(0, 0, 0, 0)
        self.video = QVideoWidget()
        self.video.setMinimumHeight(180)
        self.video.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.player.setVideoOutput(self.video)
        player_layout.addWidget(self.video, 1)
        playback = QHBoxLayout()
        self.play = QPushButton("Play")
        self.pause = QPushButton("Pause")
        self.folder = QPushButton("Open Output Folder")
        playback.addWidget(self.play)
        playback.addWidget(self.pause)
        playback.addWidget(self.folder)
        player_layout.addLayout(playback)
        seek_row = QHBoxLayout()
        self.seek = QSlider(Qt.Orientation.Horizontal)
        self.seek.setRange(0, 0)
        self.position_label = QLabel("00:00 / 00:00")
        seek_row.addWidget(self.seek, 1)
        seek_row.addWidget(self.position_label)
        player_layout.addLayout(seek_row)
        self.detail_splitter.addWidget(player_panel)

        details = QWidget()
        details_layout = QVBoxLayout(details)
        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.header = QLineEdit()
        self.captions = QPlainTextEdit()
        self.captions.setMaximumHeight(100)
        self.upload_title = QLineEdit()
        self.upload_description = QPlainTextEdit()
        self.upload_description.setMaximumHeight(90)
        self.metadata = QPlainTextEdit()
        self.metadata.setMaximumHeight(150)
        self.schedule = QDateTimeEdit()
        self.schedule.setCalendarPopup(True)
        self.schedule.setDisplayFormat("yyyy-MM-dd HH:mm")
        self.checks = QLabel("—")
        self.checks.setWordWrap(True)
        self.ai_review = QLabel("—")
        self.ai_review.setWordWrap(True)
        self.costs = QLabel("—")
        self.rights_details = QLabel("—")
        self.rights_details.setWordWrap(True)
        self.rights_confirmed = QCheckBox(
            "I reviewed the source links and confirmed that publication is authorized."
        )
        self.learn_from_edits = QCheckBox(
            "Let Gemini learn from my saved title, header, and caption corrections"
        )
        self.learn_from_edits.setChecked(True)
        self.learning_status = QLabel()
        self.learning_status.setWordWrap(True)
        form.addRow("Header", self.header)
        form.addRow("Ranking captions (one per line)", self.captions)
        form.addRow("Upload title / TikTok caption", self.upload_title)
        form.addRow("YouTube description", self.upload_description)
        form.addRow("Upload metadata (JSON)", self.metadata)
        form.addRow("Adaptive writing", self.learn_from_edits)
        form.addRow("Learned memory", self.learning_status)
        form.addRow("Scheduled time", self.schedule)
        form.addRow("Technical checks", self.checks)
        form.addRow("AI final review", self.ai_review)
        form.addRow("AI cost", self.costs)
        form.addRow("Source rights", self.rights_details)
        form.addRow("Rights decision", self.rights_confirmed)
        details_layout.addLayout(form)

        design_group = QGroupBox("Design for this video")
        design_form = QFormLayout(design_group)
        design_form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.design = QComboBox()
        self.ranking_style = QComboBox()
        self.caption_style = QComboBox()
        self.header_style = QComboBox()
        self.header_background = QComboBox()
        self.header_background.addItem("From selected header style", "style")
        self.header_background.addItem("Transparent", "transparent")
        self.header_background.addItem("Black panel", "black")
        design_form.addRow("Complete design", self.design)
        design_form.addRow("Numbering style", self.ranking_style)
        design_form.addRow("Caption style", self.caption_style)
        design_form.addRow("Header style", self.header_style)
        design_form.addRow("Header background", self.header_background)
        design_buttons = QHBoxLayout()
        self.save_visual = QPushButton("Save Design for Video")
        self.save_design = QPushButton("Save Current as New Design…")
        self.advanced_design = QPushButton("Advanced Layout & Style…")
        design_buttons.addWidget(self.save_visual)
        design_buttons.addWidget(self.save_design)
        design_buttons.addWidget(self.advanced_design)
        design_form.addRow(design_buttons)
        details_layout.addWidget(design_group)
        edit_row = QGridLayout()
        self.save_copy = QPushButton("Save Video Text & Learn")
        self.save_metadata = QPushButton("Save Upload Copy & Learn")
        self.save_schedule = QPushButton("Change Schedule")
        self.save_rights = QPushButton("Save Rights Decision")
        edit_row.addWidget(self.save_copy, 0, 0)
        edit_row.addWidget(self.save_metadata, 0, 1)
        edit_row.addWidget(self.save_schedule, 1, 0)
        edit_row.addWidget(self.save_rights, 1, 1)
        details_layout.addLayout(edit_row)
        action_row = QGridLayout()
        self.approve = QPushButton("Approve")
        self.reject = QPushButton("Reject")
        self.rerender = QPushButton("Re-render")
        self.replace = QPushButton("Replace Clip")
        self.exclude = QPushButton("Exclude from Upload")
        for index, button in enumerate(
            (self.approve, self.reject, self.rerender, self.replace, self.exclude)
        ):
            action_row.addWidget(button, index // 3, index % 3)
        details_layout.addLayout(action_row)
        self.approve_all = QPushButton("Approve All Passed Videos")
        details_layout.addWidget(self.approve_all)
        details_layout.addStretch()
        self.details_scroll = QScrollArea()
        self.details_scroll.setObjectName("reviewQueueDetailsScrollArea")
        self.details_scroll.setWidgetResizable(True)
        self.details_scroll.setMinimumWidth(360)
        self.details_scroll.setMinimumHeight(150)
        self.details_scroll.setWidget(details)
        self.detail_splitter.addWidget(self.details_scroll)

        self.main_splitter.addWidget(self.detail_splitter)
        self.main_splitter.setStretchFactor(0, 1)
        self.main_splitter.setStretchFactor(1, 2)
        self.detail_splitter.setStretchFactor(0, 3)
        self.detail_splitter.setStretchFactor(1, 2)
        self.main_splitter.setSizes(list(self.context.settings.ui.review_queue_horizontal_sizes))
        self.detail_splitter.setSizes(list(self.context.settings.ui.review_queue_vertical_sizes))
        root.addWidget(self.main_splitter, 1)
        self.main_splitter.splitterMoved.connect(self._schedule_splitter_persist)
        self.detail_splitter.splitterMoved.connect(self._schedule_splitter_persist)
        self.table.itemSelectionChanged.connect(self._load_selected)
        self.play.clicked.connect(self.player.play)
        self.pause.clicked.connect(self.player.pause)
        self.folder.clicked.connect(self._open_folder)
        self.save_copy.clicked.connect(lambda: self._save_copy())
        self.save_metadata.clicked.connect(lambda: self._save_metadata())
        self.save_visual.clicked.connect(lambda: self._save_visual())
        self.save_design.clicked.connect(self._save_design_profile)
        self.advanced_design.clicked.connect(self._advanced_design)
        self.save_schedule.clicked.connect(self._save_schedule)
        self.save_rights.clicked.connect(self._save_rights)
        self.approve.clicked.connect(self._approve)
        self.reject.clicked.connect(self._reject)
        self.approve_all.clicked.connect(self._approve_all)
        self.rerender.clicked.connect(self._rerender)
        self.replace.clicked.connect(self._replace)
        self.exclude.clicked.connect(self._exclude)
        self.player.durationChanged.connect(self._duration_changed)
        self.player.positionChanged.connect(self._position_changed)
        self.seek.sliderMoved.connect(self.player.setPosition)
        self.design.currentIndexChanged.connect(self._design_changed)
        self.ranking_style.currentIndexChanged.connect(self._component_style_changed)
        self.caption_style.currentIndexChanged.connect(self._component_style_changed)
        self.header_style.currentIndexChanged.connect(self._component_style_changed)
        self.header_background.currentIndexChanged.connect(self._header_background_changed)
        self.header.textChanged.connect(lambda: self._mark_dirty("copy"))
        self.captions.textChanged.connect(lambda: self._mark_dirty("copy"))
        self.upload_title.textChanged.connect(lambda: self._mark_dirty("metadata"))
        self.upload_description.textChanged.connect(lambda: self._mark_dirty("metadata"))
        self.metadata.textChanged.connect(lambda: self._mark_dirty("metadata"))
        self.refresh()

    def refresh(self, selected_id: str | None = None) -> None:
        target_id = selected_id or self.current_id
        self._loading = True
        items = self.context.reviews.list()
        self.table.setRowCount(len(items))
        for row, item in enumerate(items):
            design = (
                self.context.design_profile_manager.get(item.design_profile_id)
                if item.design_profile_id
                else None
            )
            values = [
                item.status.value,
                item.filename,
                item.platform,
                item.channel_id or "—",
                item.preset_id,
                design.name if design else "Custom / preset",
                item.scheduled_at.isoformat(timespec="minutes") if item.scheduled_at else "—",
                "Passed" if item.technical_validation.passed else "Failed",
            ]
            for column, value in enumerate(values):
                cell = QTableWidgetItem(str(value))
                cell.setData(Qt.ItemDataRole.UserRole, item.id)
                self.table.setItem(row, column, cell)
            if target_id == item.id:
                self.table.selectRow(row)
        self.table.resizeColumnsToContents()
        self._loading = False
        if target_id and (not self._dirty or target_id != self.current_id):
            self._load_selected(force=True)

    def _selected(self):
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return None
        identifier = self.table.item(rows[0].row(), 0).data(Qt.ItemDataRole.UserRole)
        return self.context.reviews.get(identifier)

    def _load_selected(self, *, force: bool = False) -> None:
        if self._loading:
            return
        item = self._selected()
        if not item:
            return
        if self._dirty and self.current_id and item.id != self.current_id and not force:
            discard = QMessageBox.question(
                self,
                "Unsaved Review changes",
                "Discard the unsaved text or design changes and open the selected video?",
            )
            if discard != QMessageBox.StandardButton.Yes:
                self.refresh(self.current_id)
                return
        if self._dirty and item.id == self.current_id and not force:
            return
        self._loading = True
        self.current_id = item.id
        self.player.setSource(QUrl.fromLocalFile(item.video_path))
        self.header.setText(item.header)
        self.captions.setPlainText("\n".join(item.ranking_captions))
        self.metadata.setPlainText(json.dumps(item.upload_metadata, indent=2, ensure_ascii=False))
        if item.platform == "youtube":
            self.upload_title.setText(str(item.upload_metadata.get("title", "")))
            self.upload_description.setPlainText(str(item.upload_metadata.get("description", "")))
            self.upload_description.setEnabled(True)
        else:
            self.upload_title.setText(str(item.upload_metadata.get("caption", "")))
            self.upload_description.clear()
            self.upload_description.setEnabled(False)
        self.learning_status.setText(
            f"{self.context.adaptive_preferences.count()} saved correction(s). "
            "Only saved edits are reused; the original AI text remains auditable."
        )
        self.review_preset = (
            Preset.model_validate(item.review_preset_payload)
            if item.review_preset_payload
            else self.context.presets.get(item.preset_id)
        )
        self._populate_visual_options(item.design_profile_id)
        if item.scheduled_at:
            self.schedule.setDateTime(QDateTime(item.scheduled_at))
        checks = [
            f"{'✓' if check.passed else '✗' if check.blocking else '⚠'} "
            f"{check.name}: {check.details}"
            for check in item.technical_validation.checks
        ]
        self.checks.setText("\n".join(checks))
        if item.needs_rerender:
            self.checks.setText(
                self.checks.text()
                + "\n⚠ Editorial text changed: re-render is required before approval."
            )
        if item.ai_review:
            self.ai_review.setText(
                f"{'Approved' if item.ai_review.approved else 'Blocked'} | Quality {item.ai_review.quality_score:.0f} | "
                f"Hook {item.ai_review.hook_score:.0f} | Pacing {item.ai_review.pacing_score:.0f}\n"
                + "\n".join(item.ai_review.blocking_issues + item.ai_review.warnings)
            )
        else:
            self.ai_review.setText(
                "AI final review was disabled or skipped after a technical failure."
            )
        self.costs.setText(
            f"Estimated ${item.estimated_ai_cost_usd:.4f} | Actual ${item.actual_ai_cost_usd:.4f}"
        )
        rights_lines = [
            f"{value.get('status', 'unknown')}: {value.get('source_url', '')}"
            for value in item.source_rights
        ]
        self.rights_details.setText(
            "\n".join(rights_lines)
            if rights_lines
            else "No separate source-rights decision is required by this profile."
        )
        self.rights_confirmed.setEnabled(item.rights_review_required)
        self.rights_confirmed.setChecked(item.rights_approved or not item.rights_review_required)
        self._dirty = False
        self._dirty_sections.clear()
        self._loading = False

    def _populate_visual_options(self, design_id: str | None = None) -> None:
        if not self.review_preset:
            return
        previous_loading = self._loading
        self._loading = True
        try:
            self.design.clear()
            self.design.addItem("Custom (this video)", None)
            for profile in self.context.design_profile_manager.list(
                self.review_preset.video_format
            ):
                self.design.addItem(
                    f"{'Built-in · ' if profile.core else ''}{profile.name}", profile.id
                )
            selected_design = design_id or self.review_preset.style_profiles.design
            self.design.setCurrentIndex(max(0, self.design.findData(selected_design)))
            for combo, kind, current in (
                (
                    self.ranking_style,
                    StyleProfileKind.RANKING_NUMBERS,
                    self.review_preset.style_profiles.ranking_numbers,
                ),
                (
                    self.caption_style,
                    StyleProfileKind.CAPTIONS,
                    self.review_preset.style_profiles.captions,
                ),
                (
                    self.header_style,
                    StyleProfileKind.HEADER,
                    self.review_preset.style_profiles.header,
                ),
            ):
                combo.clear()
                combo.addItem("Custom (unsaved)", None)
                for profile in self.context.style_profile_manager.list(kind):
                    combo.addItem(
                        f"{'Built-in · ' if profile.core else ''}{profile.name}",
                        profile.id,
                    )
                combo.setCurrentIndex(max(0, combo.findData(current)))
            ranking_visible = self.review_preset.ranking.enabled
            self.ranking_style.setEnabled(ranking_visible)
            self.caption_style.setEnabled(ranking_visible)
            self.header_style.setEnabled(self.review_preset.header.enabled)
            self.header_background.setEnabled(self.review_preset.header.enabled)
            background_mode = "style"
            header_profile = self.context.style_profile_manager.get(
                self.review_preset.style_profiles.header or ""
            )
            background = self.review_preset.header.background
            if (
                not header_profile
                or not header_profile.header
                or (background != header_profile.header.background)
            ):
                if background.alpha == 0:
                    background_mode = "transparent"
                elif background.red == background.green == background.blue == 0:
                    background_mode = "black"
            self.header_background.setCurrentIndex(
                max(0, self.header_background.findData(background_mode))
            )
        finally:
            self._loading = previous_loading

    def _design_changed(self) -> None:
        if self._loading or not self.review_preset:
            return
        identifier = self.design.currentData()
        if not identifier:
            return
        try:
            self.review_preset = self.context.design_profile_manager.apply(
                self.review_preset,
                str(identifier),
            )
            self._populate_visual_options(str(identifier))
            self._mark_dirty("visual")
        except Exception as error:
            QMessageBox.warning(self, "Design could not be applied", str(error))

    def _component_style_changed(self) -> None:
        if self._loading or not self.review_preset:
            return
        sender = self.sender()
        if not isinstance(sender, QComboBox) or not sender.currentData():
            return
        try:
            self.review_preset = self.context.style_profile_manager.apply(
                self.review_preset,
                str(sender.currentData()),
            )
            self.review_preset.style_profiles.design = None
            self.design.blockSignals(True)
            self.design.setCurrentIndex(0)
            self.design.blockSignals(False)
            self._mark_dirty("visual")
        except Exception as error:
            QMessageBox.warning(self, "Style could not be applied", str(error))

    def _header_background_changed(self) -> None:
        if self._loading or not self.review_preset:
            return
        mode = self.header_background.currentData()
        if mode == "style" and self.review_preset.style_profiles.header:
            self.review_preset = self.context.style_profile_manager.apply(
                self.review_preset,
                self.review_preset.style_profiles.header,
            )
        elif mode == "transparent":
            self.review_preset.header.background = Color(red=0, green=0, blue=0, alpha=0)
            self.review_preset.header.border_color = Color(red=0, green=0, blue=0, alpha=0)
            self.review_preset.header.border_width = 0
        elif mode == "black":
            self.review_preset.header.background = Color(red=0, green=0, blue=0, alpha=220)
            self.review_preset.header.border_color = Color(red=0, green=0, blue=0, alpha=0)
            self.review_preset.header.border_width = 0
        self.review_preset.style_profiles.design = None
        self.design.blockSignals(True)
        self.design.setCurrentIndex(0)
        self.design.blockSignals(False)
        self._mark_dirty("visual")

    def _save_visual(self, *, refresh: bool = True) -> bool:
        item = self.context.reviews.get(self.current_id) if self.current_id else None
        if not item or not self.review_preset:
            return False
        try:
            self.context.review_queue.update_visual_preset(
                item.id,
                preset=self.review_preset,
                design_profile_id=self.review_preset.style_profiles.design,
            )
            self._section_saved("visual")
            if refresh and not self._dirty:
                self.refresh(item.id)
            return True
        except Exception as error:
            QMessageBox.critical(self, "Video design could not be saved", str(error))
            return False

    def _save_design_profile(self) -> None:
        if not self.review_preset:
            return
        name, accepted = QInputDialog.getText(
            self,
            "Save visual design",
            "Name for this reusable design",
        )
        if not accepted or not name.strip():
            return
        try:
            profile = self.context.design_profile_manager.create_from_preset(
                self.review_preset,
                name.strip(),
            )
            self.review_preset.style_profiles.design = profile.id
            self._populate_visual_options(profile.id)
            self._mark_dirty("visual")
            self._save_visual()
        except Exception as error:
            QMessageBox.warning(self, "Design was not saved", str(error))

    def _advanced_design(self) -> None:
        if not self.review_preset:
            return
        dialog = ReviewStyleDialog(self.context, self.review_preset, self)
        if dialog.exec() and dialog.result_preset:
            self.review_preset = dialog.result_preset
            self.context.style_profile_manager.reconcile_preset(self.review_preset)
            self.context.design_profile_manager.reconcile_preset(self.review_preset)
            self._populate_visual_options(self.review_preset.style_profiles.design)
            self._mark_dirty("visual")

    def _mark_dirty(self, section: str = "general") -> None:
        if not self._loading:
            self._dirty_sections.add(section)
            self._dirty = True

    def _section_saved(self, section: str) -> None:
        self._dirty_sections.discard(section)
        self._dirty = bool(self._dirty_sections)

    def _save_copy(self, *, refresh: bool = True) -> bool:
        item = self.context.reviews.get(self.current_id) if self.current_id else None
        if not item:
            return False
        captions = self.captions.toPlainText().splitlines()
        try:
            self.context.review_queue.update_editorial_copy(
                item.id,
                header=self.header.text(),
                captions=captions,
                learn=self.learn_from_edits.isChecked(),
            )
            plan = self.context.projects.get(item.project_id)
            if plan:
                plan.project_overrides["header_text"] = self.header.text()
                plan.project_overrides["caption_texts"] = captions
                self.context.projects.save(plan)
            self._section_saved("copy")
            self.learning_status.setText(
                f"{self.context.adaptive_preferences.count()} saved correction(s). "
                "Your correction will be considered for the next matching Gemini request."
            )
            if refresh and not self._dirty:
                self.refresh(item.id)
            return True
        except Exception as error:
            QMessageBox.critical(self, "Editorial edit failed", str(error))
            return False

    def _save_metadata(self, *, refresh: bool = True) -> bool:
        item = self.context.reviews.get(self.current_id) if self.current_id else None
        if not item:
            return False
        try:
            raw = json.loads(self.metadata.toPlainText())
            if item.platform == "youtube":
                raw["title"] = self.upload_title.text().strip()
                raw["description"] = self.upload_description.toPlainText().strip()
            else:
                raw["caption"] = self.upload_title.text().strip()
            validated = (
                YouTubeMetadata.model_validate(raw)
                if item.platform == "youtube"
                else TikTokMetadata.model_validate(raw)
            )
            values = validated.model_dump(mode="json")
            self.context.review_queue.update_metadata(
                item.id,
                values,
                learn=self.learn_from_edits.isChecked(),
            )
            self._loading = True
            self.metadata.setPlainText(json.dumps(values, indent=2, ensure_ascii=False))
            self._loading = False
            self._section_saved("metadata")
            self.learning_status.setText(
                f"{self.context.adaptive_preferences.count()} saved correction(s). "
                "Your correction will be considered for the next matching Gemini request."
            )
            if refresh and not self._dirty:
                self.refresh(item.id)
            return True
        except Exception as error:
            self._loading = False
            QMessageBox.critical(self, "Metadata validation failed", str(error))
            return False

    def _save_schedule(self) -> None:
        item = self._selected()
        if not item:
            return
        value = self.schedule.dateTime().toPython()
        if value.tzinfo is None and item.scheduled_at:
            value = value.replace(tzinfo=item.scheduled_at.tzinfo)
        try:
            self.context.review_queue.update_schedule(item.id, value)
            self.refresh(item.id)
        except Exception as error:
            QMessageBox.critical(self, "Schedule invalid", str(error))

    def _save_rights(self) -> None:
        item = self._selected()
        if not item:
            return
        self.context.review_queue.confirm_rights_review(
            item.id,
            confirmed=self.rights_confirmed.isChecked(),
        )
        self.refresh(item.id)

    def _approve(self) -> None:
        item = self._selected()
        if not item:
            return
        try:
            override_ai = False
            if item.ai_review and not item.ai_review.approved:
                if (
                    QMessageBox.warning(
                        self,
                        "AI review reported blocking issues",
                        "The deterministic checks passed, but AI review reported blocking issues. Override the AI result and approve anyway?",
                        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                        QMessageBox.StandardButton.No,
                    )
                    != QMessageBox.StandardButton.Yes
                ):
                    return
                override_ai = True
            item = self.context.review_queue.approve(item.id, override_ai_block=override_ai)
            self._ensure_upload_job(item)
            self.refresh(item.id)
        except Exception as error:
            QMessageBox.critical(self, "Approval blocked", str(error))

    def _approve_all(self) -> None:
        try:
            items = self.context.review_queue.approve_all_passed()
            for item in items:
                self._ensure_upload_job(item)
            self.refresh()
        except Exception as error:
            QMessageBox.critical(self, "Bulk approval failed", str(error))

    def _ensure_upload_job(self, item) -> None:
        if not item.channel_id:
            return
        if any(job.review_item_id == item.id for job in self.context.upload_jobs.list()):
            return
        channel = self.context.channels.get(item.channel_id)
        if channel:
            self.context.upload_queue.create_from_review(item, channel)

    def _reject(self) -> None:
        item = self._selected()
        if not item:
            return
        reason, accepted = QInputDialog.getText(self, "Reject video", "Reason")
        if accepted:
            self.context.review_queue.reject(item.id, reason)
            self.refresh(item.id)

    def _rerender(self) -> None:
        item = self.context.reviews.get(self.current_id) if self.current_id else None
        if not item:
            return
        if not self._save_copy(refresh=False):
            return
        if not self._save_metadata(refresh=False):
            return
        if not self._save_visual(refresh=False):
            return
        self._dirty_sections.clear()
        self._dirty = False
        self.rerender_requested.emit(item.production_job_id)

    def _replace(self) -> None:
        item = self._selected()
        if item:
            self.context.review_queue.reject(
                item.id, "Clip replacement requested during manual review"
            )
            self.replace_clip_requested.emit(item.production_job_id)

    def _exclude(self) -> None:
        item = self._selected()
        if item:
            uploads = [
                job for job in self.context.upload_jobs.list() if job.review_item_id == item.id
            ]
            if any(
                job.status in {UploadStatus.UPLOADING, UploadStatus.PUBLISHED} for job in uploads
            ):
                QMessageBox.warning(
                    self,
                    "Exclusion unavailable",
                    "A video cannot be excluded after its platform transfer has started.",
                )
                return
            for job in uploads:
                job.status = UploadStatus.CANCELLED
                job.last_error = "Excluded by the user before upload."
                self.context.upload_jobs.save(job)
            self.context.review_queue.exclude(item.id)
            self.refresh(item.id)

    def _duration_changed(self, duration: int) -> None:
        self.seek.setRange(0, duration)
        self._update_position_label(self.player.position(), duration)

    def _position_changed(self, position: int) -> None:
        if not self.seek.isSliderDown():
            self.seek.setValue(position)
        self._update_position_label(position, self.player.duration())

    def _update_position_label(self, position: int, duration: int) -> None:
        def stamp(milliseconds: int) -> str:
            seconds = max(0, milliseconds // 1000)
            return f"{seconds // 60:02d}:{seconds % 60:02d}"

        self.position_label.setText(f"{stamp(position)} / {stamp(duration)}")

    def _open_folder(self) -> None:
        item = self._selected()
        folder = resolve_output_folder(item, self.context.production.output_directory)
        folder.mkdir(parents=True, exist_ok=True)
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder))):
            QMessageBox.warning(
                self,
                "Output folder could not be opened",
                f"Open this directory manually:\n{folder}",
            )

    def _schedule_splitter_persist(self, *_args) -> None:
        self._splitter_persist_timer.start()

    def _persist_splitter_sizes(self) -> None:
        horizontal = tuple(self.main_splitter.sizes())
        vertical = tuple(self.detail_splitter.sizes())
        if (
            len(horizontal) != 2
            or len(vertical) != 2
            or any(value <= 0 for value in (*horizontal, *vertical))
        ):
            return
        current = self.context.settings.ui
        if (
            horizontal == current.review_queue_horizontal_sizes
            and vertical == current.review_queue_vertical_sizes
        ):
            return
        self.context.settings.ui = current.model_copy(
            update={
                "review_queue_horizontal_sizes": horizontal,
                "review_queue_vertical_sizes": vertical,
            }
        )
        self.context.settings_store.save(self.context.settings)

    def hideEvent(self, event) -> None:
        self._persist_splitter_sizes()
        super().hideEvent(event)
