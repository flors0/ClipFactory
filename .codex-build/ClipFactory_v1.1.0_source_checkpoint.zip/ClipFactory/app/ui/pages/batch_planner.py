"""Batch planning UI with cost estimate and first explicit confirmation gate."""

from __future__ import annotations

from datetime import datetime, time
from zoneinfo import ZoneInfo

from PySide6.QtCore import QDateTime, Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateTimeEdit,
    QDoubleSpinBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from app.ai.request_estimator import RequestEstimator
from app.core.app_context import AppContext
from app.models.project_models import QualityThresholds
from app.models.schedule_models import ScheduleRequest, ScheduleTemplate
from app.planning.batch_planner import BatchPlanner
from app.planning.schedule_planner import SchedulePlanner


class BatchPlannerPage(QWidget):
    generate_requested = Signal(object, bool, bool, int, float, int, int)

    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        self.batch_planner = BatchPlanner(context.design_profile_manager)
        self.schedule_planner = SchedulePlanner()
        self.request_estimator = RequestEstimator(context.pricing)
        root = QVBoxLayout(self)
        title = QLabel("Batch Planner")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        columns = QHBoxLayout()
        self.sources = QListWidget()
        self.presets = QListWidget()
        self.channels = QListWidget()
        for widget in (self.sources, self.presets, self.channels):
            widget.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        for label, widget in (
            ("Source Profiles", self.sources),
            ("Presets", self.presets),
            ("Target Channels", self.channels),
        ):
            box = QVBoxLayout()
            box.addWidget(QLabel(label))
            box.addWidget(widget)
            columns.addLayout(box, 1)
        root.addLayout(columns)
        self.automatic_presets = QCheckBox(
            "Automatically use each channel's default preset and design"
        )
        self.automatic_presets.setChecked(True)
        self.automatic_presets.setToolTip(
            "The selected channels choose their own configured Core preset and visual design."
        )
        root.addWidget(self.automatic_presets)
        form = QFormLayout()
        self.count = QSpinBox()
        self.count.setRange(1, 100)
        self.count.setValue(1)
        self.count_per_channel = QCheckBox("Treat count as videos per selected channel")
        self.schedule_mode = QComboBox()
        self.schedule_mode.addItem("Interval", "interval")
        self.schedule_mode.addItem("Individual times", "explicit")
        self.schedule_mode.addItem("Schedule template", "template")
        self.start = QDateTimeEdit(QDateTime.currentDateTime().addSecs(3600))
        self.start.setCalendarPopup(True)
        self.start.setDisplayFormat("yyyy-MM-dd HH:mm")
        self.interval = QDoubleSpinBox()
        self.interval.setRange(0.25, 168)
        self.interval.setValue(4)
        self.interval.setSuffix(" hours")
        self.explicit_times = QPlainTextEdit()
        self.explicit_times.setPlaceholderText("One local time per line: YYYY-MM-DD HH:MM")
        self.explicit_times.setMaximumHeight(90)
        self.template = QComboBox()
        self.template_name = QLineEdit()
        self.template_name.setPlaceholderText("Daily Six Uploads")
        self.template_weekdays = QLineEdit("0,1,2,3,4,5,6")
        self.template_weekdays.setPlaceholderText("0=Monday … 6=Sunday")
        self.template_times = QLineEdit("00:00,04:00,08:00,12:00,16:00,20:00")
        self.save_template = QPushButton("Save Schedule Template")
        self.max_analyses = QSpinBox()
        self.max_analyses.setRange(1, 50)
        self.max_analyses.setValue(12)
        self.maximum_cost = QDoubleSpinBox()
        self.maximum_cost.setRange(0, 1000)
        self.maximum_cost.setValue(self.context.settings.ai.budget.job_limit_usd)
        self.maximum_cost.setPrefix("$")
        self.render_parallel = QSpinBox()
        self.render_parallel.setRange(1, 4)
        self.render_parallel.setValue(self.context.settings.render.parallel_renders)
        self.upload_parallel = QSpinBox()
        self.upload_parallel.setRange(1, 4)
        self.upload_parallel.setValue(self.context.settings.upload.concurrency)
        defaults = QualityThresholds()
        self.minimum_topic = QSpinBox()
        self.minimum_quality = QSpinBox()
        self.minimum_hook = QSpinBox()
        for widget, value in (
            (self.minimum_topic, defaults.minimum_topic_score),
            (self.minimum_quality, defaults.minimum_quality_score),
            (self.minimum_hook, defaults.minimum_hook_score),
        ):
            widget.setRange(0, 100)
            widget.setValue(round(value))
        self.allow_quality_fallback = QCheckBox(
            "Use strongest safe clips when strict AI scores leave too few"
        )
        self.allow_quality_fallback.setChecked(defaults.allow_quality_fallback)
        self.minimum_fallback = QSpinBox()
        self.minimum_fallback.setRange(0, 100)
        self.minimum_fallback.setValue(round(defaults.minimum_fallback_score))
        self.reject_sensitive = QCheckBox("Sensitive")
        self.reject_sensitive.setChecked(defaults.reject_sensitive_content)
        self.reject_watermark = QCheckBox("Watermarks")
        self.reject_watermark.setChecked(defaults.reject_watermark)
        self.reject_embedded = QCheckBox("Embedded text")
        self.reject_embedded.setChecked(defaults.reject_embedded_text)
        self.allow_unknown_rights = QCheckBox("Allow unknown rights")
        self.allow_unknown_rights.setChecked(defaults.allow_unknown_rights)
        self.minimum_clips = QSpinBox()
        self.minimum_clips.setRange(1, 20)
        self.minimum_clips.setValue(defaults.minimum_clip_count)
        self.maximum_clips = QSpinBox()
        self.maximum_clips.setRange(1, 50)
        self.maximum_clips.setValue(defaults.maximum_clip_count)
        self.minimum_clip_duration = QDoubleSpinBox()
        self.minimum_clip_duration.setRange(0.1, 600)
        self.minimum_clip_duration.setValue(defaults.minimum_individual_clip_seconds)
        self.maximum_clip_duration = QDoubleSpinBox()
        self.maximum_clip_duration.setRange(0.1, 600)
        self.maximum_clip_duration.setValue(defaults.maximum_individual_clip_seconds)
        self.avoid_posts = QCheckBox("Posts")
        self.avoid_posts.setChecked(defaults.avoid_duplicate_posts)
        self.avoid_media = QCheckBox("Media")
        self.avoid_media.setChecked(defaults.avoid_duplicate_media)
        self.avoid_history = QCheckBox("Published history")
        self.avoid_history.setChecked(defaults.avoid_previously_used_clips)
        self.mock_ai = QCheckBox("Use deterministic Mock AI (no paid API calls)")
        self.mock_source = QCheckBox("Use Mock source (development only)")
        self.estimate = QLabel("Select inputs to estimate the batch.")
        self.estimate.setWordWrap(True)
        form.addRow("Finished videos / videos per channel", self.count)
        form.addRow(self.count_per_channel)
        form.addRow("Schedule mode", self.schedule_mode)
        form.addRow("First publish time", self.start)
        form.addRow("Interval", self.interval)
        form.addRow("Individual publish times", self.explicit_times)
        form.addRow("Saved template", self.template)
        form.addRow("Template name", self.template_name)
        form.addRow("Template weekdays", self.template_weekdays)
        form.addRow("Template daily times", self.template_times)
        form.addRow(self.save_template)
        form.addRow("Maximum analyses per video", self.max_analyses)
        form.addRow("Maximum estimated AI cost", self.maximum_cost)
        form.addRow("Render parallelism", self.render_parallel)
        form.addRow("Upload parallelism", self.upload_parallel)
        form.addRow(
            "Minimum scores",
            self._inline(
                ("Topic", self.minimum_topic),
                ("Quality", self.minimum_quality),
                ("Hook", self.minimum_hook),
            ),
        )
        form.addRow("Automatic quality fallback", self.allow_quality_fallback)
        form.addRow("Fallback score floor", self.minimum_fallback)
        form.addRow(
            "Reject content",
            self._inline(
                ("", self.reject_sensitive),
                ("", self.reject_watermark),
                ("", self.reject_embedded),
                ("", self.allow_unknown_rights),
            ),
        )
        form.addRow(
            "Clip count",
            self._inline(("Minimum", self.minimum_clips), ("Maximum", self.maximum_clips)),
        )
        form.addRow(
            "Individual clip duration",
            self._inline(
                ("Minimum", self.minimum_clip_duration),
                ("Maximum", self.maximum_clip_duration),
            ),
        )
        form.addRow(
            "Avoid duplicates",
            self._inline(
                ("", self.avoid_posts),
                ("", self.avoid_media),
                ("", self.avoid_history),
            ),
        )
        form.addRow(self.mock_ai)
        form.addRow(self.mock_source)
        form.addRow("Estimate", self.estimate)
        root.addLayout(form)
        self.generate = QPushButton("Generate Batch")
        self.generate.setObjectName("primaryButton")
        root.addWidget(self.generate)
        self.generate.clicked.connect(self._generate)
        self.save_template.clicked.connect(self._save_template)
        self.schedule_mode.currentIndexChanged.connect(self._schedule_mode_changed)
        for widget in (self.sources, self.presets, self.channels):
            widget.itemSelectionChanged.connect(self.update_estimate)
        self.count.valueChanged.connect(self.update_estimate)
        self.count_per_channel.toggled.connect(self.update_estimate)
        self.automatic_presets.toggled.connect(self._automatic_presets_changed)
        self.max_analyses.valueChanged.connect(self.update_estimate)
        self.mock_ai.toggled.connect(self.update_estimate)
        self.refresh()
        self._automatic_presets_changed(self.automatic_presets.isChecked())
        self._schedule_mode_changed()

    def refresh(self) -> None:
        self._fill(
            self.sources, [(item.id, item.name) for item in self.context.source_profiles.list()]
        )
        self._fill(self.presets, [(item.id, item.name) for item in self.context.presets.list()])
        self._fill(
            self.channels,
            [
                (item.id, f"{item.display_name} ({item.platform})")
                for item in self.context.channels.list()
                if item.enabled
            ],
        )
        self._refresh_templates()
        self.update_estimate()

    def _refresh_templates(self, selected_id: str | None = None) -> None:
        current = selected_id or self.template.currentData()
        self.template.clear()
        for value in self.context.schedule_templates.list():
            self.template.addItem(f"{value.name} ({value.timezone})", value.id)
            if value.id == current:
                self.template.setCurrentIndex(self.template.count() - 1)

    def _schedule_mode_changed(self) -> None:
        mode = self.schedule_mode.currentData()
        self.start.setEnabled(mode == "interval")
        self.interval.setEnabled(mode == "interval")
        self.explicit_times.setEnabled(mode == "explicit")
        self.template.setEnabled(mode == "template")

    def _automatic_presets_changed(self, checked: bool) -> None:
        self.presets.setEnabled(not checked)
        self.presets.setToolTip(
            "Preset selection comes from each selected channel."
            if checked
            else "Select one or more presets manually."
        )
        self.update_estimate()

    def _save_template(self) -> None:
        try:
            weekdays = [
                int(value.strip())
                for value in self.template_weekdays.text().split(",")
                if value.strip()
            ]
            daily_times = [
                time.fromisoformat(value.strip())
                for value in self.template_times.text().split(",")
                if value.strip()
            ]
            template = ScheduleTemplate(
                name=self.template_name.text().strip() or "Schedule Template",
                timezone=self.context.settings.timezone,
                weekdays=weekdays,
                daily_times=daily_times,
            )
            if not template.daily_times:
                raise ValueError("A schedule template requires at least one daily time.")
            self.context.schedule_templates.save(template)
            self._refresh_templates(template.id)
            QMessageBox.information(
                self, "Template saved", "The recurring weekly schedule template was saved."
            )
        except Exception as error:
            QMessageBox.critical(self, "Schedule template invalid", str(error))

    def _build_schedule(self) -> list[datetime]:
        timezone = ZoneInfo(self.context.settings.timezone)
        video_count = self._effective_video_count()
        mode = self.schedule_mode.currentData()
        if mode == "explicit":
            values = [
                line.strip()
                for line in self.explicit_times.toPlainText().splitlines()
                if line.strip()
            ]
            parsed = [
                datetime.strptime(value, "%Y-%m-%d %H:%M").replace(tzinfo=timezone)
                for value in values
            ]
            return self.schedule_planner.build(
                ScheduleRequest(
                    timezone=self.context.settings.timezone,
                    count=video_count,
                    explicit_times=parsed,
                )
            )
        if mode == "template":
            identifier = self.template.currentData()
            template = self.context.schedule_templates.get(identifier) if identifier else None
            if not template:
                raise ValueError("Select or save a schedule template.")
            return self.schedule_planner.next_from_template(template, count=video_count)
        start_python = self.start.dateTime().toPython()
        if start_python.tzinfo is None:
            start_python = start_python.replace(tzinfo=timezone)
        return self.schedule_planner.build(
            ScheduleRequest(
                timezone=self.context.settings.timezone,
                count=video_count,
                start_at=start_python,
                interval_hours=self.interval.value(),
            )
        )

    @staticmethod
    def _fill(widget: QListWidget, values: list[tuple[str, str]]) -> None:
        widget.clear()
        for identifier, label in values:
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, identifier)
            widget.addItem(item)

    @staticmethod
    def _ids(widget: QListWidget) -> list[str]:
        return [item.data(Qt.ItemDataRole.UserRole) for item in widget.selectedItems()]

    def update_estimate(self) -> None:
        video_count = self._effective_video_count()
        requests = video_count * (self.max_analyses.value() + 2)
        cost_per_request = self._estimated_request_cost()
        cost = requests * cost_per_request
        downloads = video_count * self.max_analyses.value()
        self.estimate.setText(
            f"Up to {downloads} downloads, {requests} AI requests, estimated ${cost:.2f}. Cache hits reduce actual work and cost."
        )

    def _generate(self) -> None:
        source_values = [
            self.context.source_profiles.get(value) for value in self._ids(self.sources)
        ]
        preset_values = (
            self.context.presets.list()
            if self.automatic_presets.isChecked()
            else [self.context.presets.get(value) for value in self._ids(self.presets)]
        )
        channel_values = [self.context.channels.get(value) for value in self._ids(self.channels)]
        sources = [value for value in source_values if value]
        presets = [value for value in preset_values if value]
        channels = [value for value in channel_values if value]
        if not sources or not presets:
            QMessageBox.warning(
                self,
                "Batch incomplete",
                "Select at least one source profile and one preset."
                if not self.automatic_presets.isChecked()
                else "Select at least one source profile.",
            )
            return
        if self.automatic_presets.isChecked() and not channels:
            QMessageBox.warning(
                self,
                "Batch incomplete",
                "Select at least one target channel for automatic preset selection.",
            )
            return
        try:
            schedule = self._build_schedule()
            plan = self.batch_planner.build(
                sources=sources,
                presets=presets,
                channels=channels,
                video_count=self._effective_video_count(),
                videos_per_channel=self.count.value()
                if self.count_per_channel.isChecked()
                else None,
                schedule=schedule,
                analyses_per_video=self.max_analyses.value(),
                estimated_cost_per_analysis=self._estimated_request_cost(),
                quality_thresholds=self._quality_thresholds(),
                automatic_presets=self.automatic_presets.isChecked(),
            )
        except Exception as error:
            QMessageBox.critical(self, "Batch plan invalid", str(error))
            return
        if plan.estimated_ai_cost_usd > self.maximum_cost.value():
            QMessageBox.warning(
                self,
                "Batch budget exceeded",
                "The estimated AI cost exceeds this batch's configured maximum.",
            )
            return
        message = (
            f"Generate {len(plan.items)} video(s)?\n\n"
            f"Estimated downloads: {plan.estimated_downloads}\n"
            f"Estimated AI requests: {plan.estimated_ai_requests}\n"
            f"Estimated AI cost: ${plan.estimated_ai_cost_usd:.2f}\n\n"
            "Paid analysis and rendering begin only after this confirmation. Upload remains blocked until a separate approval."
        )
        if (
            QMessageBox.question(self, "Confirm Generate Batch", message)
            != QMessageBox.StandardButton.Yes
        ):
            return
        self.generate_requested.emit(
            plan,
            self.mock_ai.isChecked(),
            self.mock_source.isChecked(),
            self.max_analyses.value(),
            self.maximum_cost.value(),
            self.render_parallel.value(),
            self.upload_parallel.value(),
        )

    def _effective_video_count(self) -> int:
        selected_channels = len(self._ids(self.channels))
        if self.count_per_channel.isChecked():
            return self.count.value() * max(1, selected_channels)
        return self.count.value()

    def _estimated_request_cost(self) -> float:
        if self.mock_ai.isChecked() or self.context.settings.ai.provider != "gemini":
            return 0
        estimate = self.request_estimator.estimate(
            provider="gemini",
            model=self.context.settings.ai.model,
            prompt="Conservative ClipFactory batch preflight estimate",
            video_seconds=min(
                15,
                self.context.settings.ai.budget.max_video_seconds_per_request,
            ),
            has_audio=True,
            media_resolution=self.context.settings.ai.media_resolution,
            expected_output_tokens=self.context.settings.ai.clip_output_token_estimate,
        )
        return estimate.estimated_cost_usd

    def _quality_thresholds(self) -> QualityThresholds:
        return QualityThresholds(
            minimum_topic_score=self.minimum_topic.value(),
            minimum_quality_score=self.minimum_quality.value(),
            minimum_hook_score=self.minimum_hook.value(),
            allow_quality_fallback=self.allow_quality_fallback.isChecked(),
            minimum_fallback_score=self.minimum_fallback.value(),
            reject_sensitive_content=self.reject_sensitive.isChecked(),
            reject_watermark=self.reject_watermark.isChecked(),
            reject_embedded_text=self.reject_embedded.isChecked(),
            allow_unknown_rights=self.allow_unknown_rights.isChecked(),
            minimum_clip_count=self.minimum_clips.value(),
            maximum_clip_count=self.maximum_clips.value(),
            minimum_individual_clip_seconds=self.minimum_clip_duration.value(),
            maximum_individual_clip_seconds=self.maximum_clip_duration.value(),
            avoid_duplicate_posts=self.avoid_posts.isChecked(),
            avoid_duplicate_media=self.avoid_media.isChecked(),
            avoid_previously_used_clips=self.avoid_history.isChecked(),
        )

    @staticmethod
    def _inline(*values: tuple[str, QWidget]) -> QWidget:
        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        for label, widget in values:
            if label:
                layout.addWidget(QLabel(label))
            layout.addWidget(widget)
        layout.addStretch()
        return container
