"""Production queue status, cancel, and retry controls."""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.app_context import AppContext


class ProductionQueuePage(QWidget):
    cancel_requested = Signal(str)
    retry_requested = Signal(str)

    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        root = QVBoxLayout(self)
        title = QLabel("Production Queue")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(
            ["Status", "Progress", "Current step", "Retries", "Preset", "Error", "Job ID"]
        )
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        root.addWidget(self.table)
        self.logs = QPlainTextEdit()
        self.logs.setReadOnly(True)
        self.logs.setMaximumHeight(150)
        root.addWidget(QLabel("Selected job logs"))
        root.addWidget(self.logs)
        row = QHBoxLayout()
        self.refresh_button = QPushButton("Refresh")
        self.cancel_button = QPushButton("Cancel")
        self.retry_button = QPushButton("Retry")
        row.addWidget(self.refresh_button)
        row.addWidget(self.cancel_button)
        row.addWidget(self.retry_button)
        row.addStretch()
        root.addLayout(row)
        self.refresh_button.clicked.connect(self.refresh)
        self.cancel_button.clicked.connect(self._cancel)
        self.retry_button.clicked.connect(self._retry)
        self.table.itemSelectionChanged.connect(self._show_logs)
        self.refresh()

    def refresh(self) -> None:
        jobs = self.context.production_jobs.list()
        self.table.setRowCount(len(jobs))
        for row, job in enumerate(jobs):
            values = [
                job.status.value,
                f"{job.progress}%",
                job.current_step,
                job.retry_count,
                job.preset_id,
                job.last_error or "",
                job.id,
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.ItemDataRole.UserRole, job.id)
                self.table.setItem(row, column, item)
        self.table.resizeColumnsToContents()

    def selected_id(self) -> str | None:
        rows = self.table.selectionModel().selectedRows()
        return self.table.item(rows[0].row(), 0).data(Qt.ItemDataRole.UserRole) if rows else None

    def _cancel(self) -> None:
        identifier = self.selected_id()
        if identifier:
            self.cancel_requested.emit(identifier)

    def _retry(self) -> None:
        identifier = self.selected_id()
        if identifier:
            self.retry_requested.emit(identifier)

    def _show_logs(self) -> None:
        identifier = self.selected_id()
        job = self.context.production_jobs.get(identifier) if identifier else None
        self.logs.setPlainText("\n".join(job.log_messages) if job else "")
