"""AI cost ledger and budget status."""

from __future__ import annotations

from datetime import UTC, datetime

from PySide6.QtWidgets import (
    QLabel,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.app_context import AppContext


class AIUsagePage(QWidget):
    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        root = QVBoxLayout(self)
        title = QLabel("AI Usage")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        self.summary = QLabel()
        root.addWidget(self.summary)
        self.daily_bar = QProgressBar()
        self.monthly_bar = QProgressBar()
        root.addWidget(QLabel("Daily budget"))
        root.addWidget(self.daily_bar)
        root.addWidget(QLabel("Monthly budget"))
        root.addWidget(self.monthly_bar)
        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels(
            [
                "Time",
                "Provider",
                "Model",
                "Operation",
                "Input",
                "Audio input",
                "Output",
                "Video",
                "Cost",
            ]
        )
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        root.addWidget(self.table)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.refresh)
        root.addWidget(refresh)
        self.refresh()

    def refresh(self) -> None:
        now = datetime.now(UTC)
        daily = self.context.ledger.total_since(
            now.replace(hour=0, minute=0, second=0, microsecond=0)
        )
        monthly = self.context.ledger.total_since(
            now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        )
        budget = self.context.settings.ai.budget
        self.summary.setText(
            f"Today: ${daily:.4f} / ${budget.daily_limit_usd:.2f} | "
            f"Month: ${monthly:.4f} / ${budget.monthly_limit_usd:.2f} | "
            f"Pricing table checked: {self.context.pricing.source_checked}"
        )
        self.daily_bar.setValue(
            round(daily / budget.daily_limit_usd * 100) if budget.daily_limit_usd else 0
        )
        self.monthly_bar.setValue(
            round(monthly / budget.monthly_limit_usd * 100) if budget.monthly_limit_usd else 0
        )
        records = self.context.ledger.list_recent()
        self.table.setRowCount(len(records))
        for row, record in enumerate(records):
            values = [
                record.created_at.isoformat(timespec="seconds"),
                record.provider,
                record.model,
                record.operation,
                record.input_tokens,
                record.audio_input_tokens,
                record.output_tokens,
                f"{record.video_seconds:.1f}s",
                f"${record.cost_usd:.6f}",
            ]
            for column, value in enumerate(values):
                self.table.setItem(row, column, QTableWidgetItem(str(value)))
        self.table.resizeColumnsToContents()
