"""Asset library scan and metadata browser."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.app_context import AppContext


class AssetLibraryPage(QWidget):
    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        root = QVBoxLayout(self)
        title = QLabel("Asset Library")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            ["Type", "File", "MIME", "Duration", "Resolution", "Audio", "Tags", "Thumbnail"]
        )
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        root.addWidget(self.table)
        self.preview = QLabel("Select an asset to preview its thumbnail.")
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumHeight(220)
        root.addWidget(self.preview)
        row = QHBoxLayout()
        self.scan = QPushButton("Scan Asset Folders")
        self.status = QLabel()
        row.addWidget(self.scan)
        row.addWidget(self.status)
        row.addStretch()
        root.addLayout(row)
        self.scan.clicked.connect(self._scan)
        self.table.itemSelectionChanged.connect(self._show_preview)
        self._assets = []
        self.refresh()

    def _scan(self) -> None:
        values = self.context.asset_library.scan()
        self.status.setText(f"Scanned {len(values)} assets.")
        self.refresh()

    def refresh(self) -> None:
        values = self.context.asset_library.list()
        self._assets = values
        self.table.setRowCount(len(values))
        for row, item in enumerate(values):
            fields = [
                item.asset_type,
                item.file_path,
                item.mime_type or "—",
                f"{item.duration_seconds:.2f}s" if item.duration_seconds is not None else "—",
                f"{item.width}x{item.height}" if item.width and item.height else "—",
                "Yes" if item.has_audio else "No",
                ", ".join(item.tags),
                item.thumbnail_path or "—",
            ]
            for column, value in enumerate(fields):
                self.table.setItem(row, column, QTableWidgetItem(str(value)))
        self.table.resizeColumnsToContents()

    def _show_preview(self) -> None:
        row = self.table.currentRow()
        if row < 0 or row >= len(self._assets):
            self.preview.setPixmap(QPixmap())
            self.preview.setText("Select an asset to preview its thumbnail.")
            return
        item = self._assets[row]
        candidate = item.thumbnail_path
        if not candidate and item.asset_type in {"images", "memes"}:
            candidate = item.file_path
        if not candidate or not Path(candidate).is_file():
            self.preview.setPixmap(QPixmap())
            self.preview.setText("No visual thumbnail is available for this asset.")
            return
        pixmap = QPixmap(candidate)
        if pixmap.isNull():
            self.preview.setPixmap(QPixmap())
            self.preview.setText("The thumbnail could not be decoded.")
            return
        self.preview.setText("")
        self.preview.setPixmap(
            pixmap.scaled(
                640,
                220,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        )
