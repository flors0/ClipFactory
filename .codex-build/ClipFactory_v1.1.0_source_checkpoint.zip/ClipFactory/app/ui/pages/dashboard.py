"""Operational dashboard."""

from __future__ import annotations

from datetime import UTC, datetime

from PySide6.QtWidgets import (
    QGridLayout,
    QGroupBox,
    QLabel,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from app.core.app_context import AppContext
from app.models.render_models import ProductionStatus


class DashboardPage(QWidget):
    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        root = QVBoxLayout(self)
        title = QLabel("Dashboard")
        title.setObjectName("pageTitle")
        root.addWidget(title)
        cards = QGridLayout()
        self.active = self._card("Active jobs")
        self.today = self._card("Uploads today")
        self.cost_today = self._card("AI cost today")
        self.cost_month = self._card("AI cost this month")
        self.budget = self._card("Monthly budget remaining")
        self.errors = self._card("Failed jobs")
        for index, card in enumerate(
            (self.active, self.today, self.cost_today, self.cost_month, self.budget, self.errors)
        ):
            cards.addWidget(card[0], index // 3, index % 3)
        root.addLayout(cards)
        self.recent = QTableWidget(0, 5)
        self.recent.setHorizontalHeaderLabels(["Status", "Step", "Preset", "Schedule", "Output"])
        self.recent.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        root.addWidget(QLabel("Recent production"))
        root.addWidget(self.recent)
        self.channel_status = QTableWidget(0, 4)
        self.channel_status.setHorizontalHeaderLabels(["Channel", "Platform", "OAuth", "Enabled"])
        self.channel_status.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        root.addWidget(QLabel("Channel status"))
        root.addWidget(self.channel_status)
        self.refresh()

    @staticmethod
    def _card(name: str) -> tuple[QGroupBox, QLabel]:
        group = QGroupBox(name)
        layout = QVBoxLayout(group)
        value = QLabel("0")
        value.setObjectName("metricValue")
        layout.addWidget(value)
        return group, value

    def refresh(self) -> None:
        jobs = self.context.production_jobs.list()
        active_states = {
            ProductionStatus.DISCOVERING,
            ProductionStatus.DOWNLOADING,
            ProductionStatus.PROBING,
            ProductionStatus.ANALYZING,
            ProductionStatus.SELECTING,
            ProductionStatus.GENERATING_COPY,
            ProductionStatus.RENDERING,
            ProductionStatus.VALIDATING,
            ProductionStatus.UPLOADING,
        }
        now = datetime.now(UTC)
        day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        uploads = self.context.upload_jobs.list()
        today_count = sum(
            1 for job in uploads if job.scheduled_at.astimezone(UTC).date() == now.date()
        )
        daily = self.context.ledger.total_since(day_start)
        monthly = self.context.ledger.total_since(month_start)
        values = (
            (self.active, sum(1 for job in jobs if job.status in active_states)),
            (self.today, today_count),
            (self.cost_today, f"${daily:.3f}"),
            (self.cost_month, f"${monthly:.3f}"),
            (
                self.budget,
                f"${max(0, self.context.settings.ai.budget.monthly_limit_usd - monthly):.2f}",
            ),
            (self.errors, sum(1 for job in jobs if job.status == ProductionStatus.FAILED)),
        )
        for card, value in values:
            card[1].setText(str(value))
        recent = jobs[:20]
        self.recent.setRowCount(len(recent))
        for row, job in enumerate(recent):
            values = [
                job.status.value,
                job.current_step,
                job.preset_id,
                job.scheduled_at.isoformat(timespec="minutes") if job.scheduled_at else "—",
                job.output_path or "—",
            ]
            for column, value in enumerate(values):
                self.recent.setItem(row, column, QTableWidgetItem(str(value)))
        self.recent.resizeColumnsToContents()
        channels = self.context.channels.list()
        self.channel_status.setRowCount(len(channels))
        for row, channel in enumerate(channels):
            for column, value in enumerate(
                [
                    channel.display_name,
                    channel.platform,
                    channel.oauth_connection_state,
                    "Yes" if channel.enabled else "No",
                ]
            ):
                self.channel_status.setItem(row, column, QTableWidgetItem(str(value)))
        self.channel_status.resizeColumnsToContents()
