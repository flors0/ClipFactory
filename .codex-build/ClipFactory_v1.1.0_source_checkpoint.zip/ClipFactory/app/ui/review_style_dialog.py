"""Per-video advanced visual editor used from the Review Queue."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QDialog, QDialogButtonBox, QVBoxLayout

from app.core.app_context import AppContext
from app.models.preset_models import Preset
from app.ui.widgets.preset_editor import PresetEditorWidget


class ReviewStyleDialog(QDialog):
    def __init__(self, context: AppContext, preset: Preset, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Advanced Design for This Video")
        self.resize(1380, 860)
        self.result_preset: Preset | None = None
        layout = QVBoxLayout(self)
        self.editor = PresetEditorWidget(context.style_profile_manager)
        self.editor.save_button.setText("Use for This Video")
        self.editor.set_assets(
            {
                asset.id: (
                    f"{asset.asset_type}: {Path(asset.file_path).name}",
                    asset.file_path,
                )
                for asset in context.asset_library.list()
            }
        )
        self.editor.load_preset(preset)
        self.editor.save_requested.connect(self._accept_preset)
        layout.addWidget(self.editor, 1)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _accept_preset(self, preset: Preset) -> None:
        self.result_preset = preset.model_copy(deep=True)
        self.accept()
