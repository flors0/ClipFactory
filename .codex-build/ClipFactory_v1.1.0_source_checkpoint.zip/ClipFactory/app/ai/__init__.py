"""AI analysis providers and safety controls."""
