"""Versioned AI price lookup and actual-cost calculation."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class ModelPrice:
    input_per_million: float
    audio_input_per_million: float
    output_per_million: float


class PricingCatalog:
    def __init__(self, config_path: Path):
        data = json.loads(config_path.read_text(encoding="utf-8"))
        self.source_checked = str(data["source_checked"])
        self._prices = {
            model: ModelPrice(
                input_per_million=float(values["input_text_image_video"]),
                audio_input_per_million=float(values["input_audio"]),
                output_per_million=float(values["output"]),
            )
            for model, values in data["per_million_tokens"].items()
        }

    def price_for(self, model: str) -> ModelPrice:
        if model not in self._prices:
            raise ValueError(
                f"No verified pricing entry exists for {model}. Add a current official price before enabling paid calls."
            )
        return self._prices[model]

    def calculate(
        self,
        model: str,
        input_tokens: int,
        output_tokens: int,
        *,
        audio_input_tokens: int = 0,
    ) -> float:
        price = self.price_for(model)
        audio_tokens = min(max(0, audio_input_tokens), max(0, input_tokens))
        other_input_tokens = max(0, input_tokens - audio_tokens)
        return (
            other_input_tokens * price.input_per_million
            + audio_tokens * price.audio_input_per_million
            + output_tokens * price.output_per_million
        ) / 1_000_000
