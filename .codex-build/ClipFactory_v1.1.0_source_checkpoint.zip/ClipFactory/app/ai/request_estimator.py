"""Conservative preflight token and request-cost estimator."""

from __future__ import annotations

import math

from app.ai.pricing import PricingCatalog
from app.models.ai_models import AIRequestEstimate


class RequestEstimator:
    VIDEO_TOKENS_PER_SECOND = {"low": 100, "medium": 260, "high": 520}
    AUDIO_TOKENS_PER_SECOND = 32

    def __init__(self, pricing: PricingCatalog):
        self.pricing = pricing

    def estimate(
        self,
        *,
        provider: str,
        model: str,
        prompt: str,
        video_seconds: float = 0,
        has_audio: bool = False,
        media_resolution: str = "low",
        expected_output_tokens: int = 1000,
    ) -> AIRequestEstimate:
        text_tokens = max(1, math.ceil(len(prompt) / 3.5))
        video_tokens = math.ceil(video_seconds * self.VIDEO_TOKENS_PER_SECOND[media_resolution])
        audio_tokens = math.ceil(video_seconds * self.AUDIO_TOKENS_PER_SECOND) if has_audio else 0
        input_tokens = text_tokens + video_tokens + audio_tokens
        cost = (
            self.pricing.calculate(
                model,
                input_tokens,
                expected_output_tokens,
                audio_input_tokens=audio_tokens,
            )
            if provider == "gemini"
            else 0
        )
        return AIRequestEstimate(
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=expected_output_tokens,
            audio_input_tokens=audio_tokens,
            video_seconds=video_seconds,
            estimated_cost_usd=cost,
        )
