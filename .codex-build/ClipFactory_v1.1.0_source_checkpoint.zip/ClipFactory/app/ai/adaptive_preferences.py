"""Automatic, bounded prompt memory derived from user editorial corrections."""

from __future__ import annotations

import hashlib
import json
import re
from collections import defaultdict
from dataclasses import dataclass
from difflib import SequenceMatcher

from app.models.feedback_models import AIEditFeedback, EditorialFieldKind
from app.models.review_models import ReviewItem
from app.storage.repositories.feedback_repository import AIEditFeedbackRepository

_TERMINAL_PUNCTUATION = re.compile(r"[.!?]+$")
_EMOJI_LIKE = re.compile(r"[^\x00-\x7F]")


@dataclass(frozen=True, slots=True)
class AdaptivePromptContext:
    text: str = ""
    revision: str = "none"
    example_count: int = 0


class AdaptivePreferenceService:
    """Turns passive Review edits into safe, scoped few-shot prompt context."""

    def __init__(
        self,
        repository: AIEditFeedbackRepository,
        *,
        enabled: bool = True,
        maximum_examples: int = 8,
        minimum_pattern_occurrences: int = 3,
    ):
        self.repository = repository
        self.enabled = enabled
        self.maximum_examples = max(1, min(20, maximum_examples))
        self.minimum_pattern_occurrences = max(2, min(20, minimum_pattern_occurrences))

    def capture_editorial_copy(
        self,
        item: ReviewItem,
        *,
        header: str,
        captions: list[str],
        learn: bool = True,
    ) -> None:
        if not self.enabled or not learn:
            return
        original_header = item.ai_original_header or item.header
        self._record(
            item,
            EditorialFieldKind.HEADER,
            "header",
            original_header,
            header,
        )
        originals = item.ai_original_ranking_captions or item.ranking_captions
        for index, edited in enumerate(captions):
            original = originals[index] if index < len(originals) else ""
            key = item.clip_ids[index] if index < len(item.clip_ids) else str(index + 1)
            self._record(
                item,
                EditorialFieldKind.RANKING_CAPTION,
                key,
                original,
                edited,
            )

    def capture_metadata(
        self,
        item: ReviewItem,
        metadata: dict[str, object],
        *,
        learn: bool = True,
    ) -> None:
        if not self.enabled or not learn:
            return
        originals = item.ai_original_upload_metadata or item.upload_metadata
        if item.platform == "youtube":
            pairs = (
                (
                    EditorialFieldKind.UPLOAD_TITLE,
                    "title",
                    originals.get("title", ""),
                    metadata.get("title", ""),
                ),
                (
                    EditorialFieldKind.UPLOAD_DESCRIPTION,
                    "description",
                    originals.get("description", ""),
                    metadata.get("description", ""),
                ),
            )
        else:
            pairs = (
                (
                    EditorialFieldKind.TIKTOK_CAPTION,
                    "caption",
                    originals.get("caption", ""),
                    metadata.get("caption", ""),
                ),
            )
        for kind, key, original, edited in pairs:
            self._record(item, kind, key, str(original), str(edited))

    def prompt_context(
        self,
        *,
        channel_id: str | None,
        preset_id: str,
        platform: str,
        language: str,
        theme: str,
    ) -> AdaptivePromptContext:
        if not self.enabled:
            return AdaptivePromptContext()
        kinds = set(EditorialFieldKind)
        candidates = self.repository.list(kinds, limit=500)
        if not candidates:
            return AdaptivePromptContext()
        theme_tokens = self._tokens(theme)
        signature_reviews: dict[tuple[str, str], set[str]] = defaultdict(set)
        for item in candidates:
            if item.edit_signature:
                signature_reviews[(item.field_kind.value, item.edit_signature)].add(
                    item.review_item_id
                )
        signature_counts = {key: len(review_ids) for key, review_ids in signature_reviews.items()}

        def score(value: AIEditFeedback) -> tuple[int, float]:
            amount = 0
            if channel_id and value.channel_id == channel_id:
                amount += 120
            if value.preset_id == preset_id:
                amount += 45
            if value.platform == platform:
                amount += 20
            if value.language.casefold() == language.casefold():
                amount += 10
            overlap = len(theme_tokens & self._tokens(value.theme))
            amount += min(15, overlap * 5)
            return amount, value.updated_at.timestamp()

        eligible = [
            value
            for value in candidates
            if (
                (channel_id and value.channel_id == channel_id)
                or (
                    signature_counts.get((value.field_kind.value, value.edit_signature), 0)
                    >= self.minimum_pattern_occurrences
                    and value.platform == platform
                    and value.language.casefold() == language.casefold()
                )
            )
        ]
        selected = sorted(eligible, key=score, reverse=True)[: self.maximum_examples]
        if not selected:
            return AdaptivePromptContext()
        selected_signatures = {
            (value.field_kind.value, value.edit_signature)
            for value in selected
            if value.edit_signature
        }
        payload = {
            "scope": {
                "channel_id": channel_id,
                "preset_id": preset_id,
                "platform": platform,
                "language": language,
                "theme": theme,
            },
            "stable_patterns": [
                {
                    "field": field,
                    "edit_signature": signature,
                    "occurrences": signature_counts[(field, signature)],
                }
                for field, signature in sorted(selected_signatures)
                if signature_counts[(field, signature)] >= self.minimum_pattern_occurrences
            ],
            "examples": [
                {
                    "field": value.field_kind.value,
                    "ai_original": self._prompt_text(value),
                    "user_preferred": self._prompt_text(value, edited=True),
                }
                for value in selected
            ],
        }
        encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        revision = hashlib.sha256(encoded.encode("utf-8")).hexdigest()[:16]
        return AdaptivePromptContext(text=encoded, revision=revision, example_count=len(selected))

    def count(self) -> int:
        return self.repository.count()

    def clear(self) -> int:
        return self.repository.clear()

    def _record(
        self,
        item: ReviewItem,
        kind: EditorialFieldKind,
        field_key: str,
        original: str,
        edited: str,
    ) -> None:
        original_clean = self._clean(original)
        edited_clean = self._clean(edited)
        if original_clean == edited_clean or not edited_clean:
            self.repository.delete_field(item.id, kind, field_key)
            return
        stable_id = hashlib.sha256(f"{item.id}\x1f{kind.value}\x1f{field_key}".encode()).hexdigest()
        self.repository.save(
            AIEditFeedback(
                id=f"feedback-{stable_id[:32]}",
                review_item_id=item.id,
                production_job_id=item.production_job_id,
                project_id=item.project_id,
                channel_id=item.channel_id,
                preset_id=item.preset_id,
                platform=item.platform,
                language=item.language,
                theme=item.theme,
                field_kind=kind,
                field_key=field_key,
                original_text=original_clean,
                edited_text=edited_clean,
                edit_signature=self._signature(original_clean, edited_clean),
                context={"clip_ids": item.clip_ids, "design_profile_id": item.design_profile_id},
            )
        )

    @staticmethod
    def _clean(value: str) -> str:
        return " ".join(value.split())

    @staticmethod
    def _tokens(value: str) -> set[str]:
        return {token for token in re.findall(r"[\w'-]+", value.casefold()) if len(token) > 2}

    @staticmethod
    def _prompt_text(value: AIEditFeedback, *, edited: bool = False) -> str:
        text = value.edited_text if edited else value.original_text
        limit = 900 if value.field_kind == EditorialFieldKind.UPLOAD_DESCRIPTION else 320
        return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"

    @staticmethod
    def _signature(original: str, edited: str) -> str:
        values: list[str] = []
        ratio = len(edited) / max(1, len(original))
        if ratio <= 0.72:
            values.append("much_shorter")
        elif ratio <= 0.9:
            values.append("shorter")
        elif ratio >= 1.35:
            values.append("much_longer")
        elif ratio >= 1.1:
            values.append("longer")
        if _TERMINAL_PUNCTUATION.search(original) and not _TERMINAL_PUNCTUATION.search(edited):
            values.append("terminal_punctuation_removed")
        if _EMOJI_LIKE.search(original) and not _EMOJI_LIKE.search(edited):
            values.append("emoji_removed")
        if not _EMOJI_LIKE.search(original) and _EMOJI_LIKE.search(edited):
            values.append("emoji_added")
        if original.isupper() and not edited.isupper():
            values.append("all_caps_removed")
        similarity = SequenceMatcher(None, original.casefold(), edited.casefold()).ratio()
        values.append("light_rewrite" if similarity >= 0.72 else "substantive_rewrite")
        return "|".join(values)
