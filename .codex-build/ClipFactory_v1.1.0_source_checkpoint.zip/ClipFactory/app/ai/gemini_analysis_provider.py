"""Gemini multimodal provider using structured Pydantic output and ephemeral files."""

from __future__ import annotations

import json
import logging
import math
import mimetypes
import os
import sys
import time
from pathlib import Path
from typing import TypeVar

from google import genai
from google.genai import types
from pydantic import BaseModel

from app.ai.analysis_provider import AIAnalysisProvider, ProviderResponse, ProviderUsage
from app.ai.prompt_builder import PromptBuilder
from app.core.exceptions import AIProviderError, AIProviderFatalError, ConfigurationError
from app.models.ai_models import (
    AIFieldPermissions,
    ClipAnalysisResult,
    FinalVideoReviewResult,
    ProjectCreativeResult,
)
from app.models.media_models import MediaInfo

ResultT = TypeVar("ResultT", bound=BaseModel)
logger = logging.getLogger(__name__)

_INLINE_MEDIA_LIMIT_BYTES = 14 * 1024 * 1024
_TRANSIENT_RETRY_DELAYS_SECONDS = (1, 2, 4)


class GeminiAnalysisProvider(AIAnalysisProvider):
    name = "gemini"

    def __init__(
        self,
        *,
        model: str,
        api_key_env: str,
        api_key: str | None = None,
        prompt_builder: PromptBuilder,
        media_resolution: str = "low",
        request_timeout_seconds: float = 120,
        processing_timeout_seconds: float = 600,
        client: genai.Client | None = None,
    ):
        resolved_api_key = api_key or os.getenv(api_key_env)
        if not resolved_api_key and client is None:
            raise ConfigurationError(
                "Gemini is selected, but no API key is configured. Add the Gemini API key "
                "directly in ClipFactory Settings."
            )
        self.model = model
        self.prompt_builder = prompt_builder
        self.media_resolution = media_resolution
        self.processing_timeout_seconds = processing_timeout_seconds
        self.client = client or genai.Client(
            api_key=resolved_api_key,
            http_options=types.HttpOptions(timeout=round(request_timeout_seconds * 1000)),
        )
        self._model_validated = False

    def validate_ready(self) -> None:
        """Verify model visibility and generateContent support before media uploads."""
        if self._model_validated:
            return
        try:
            model_info = self.client.models.get(model=self.model)
        except Exception as error:
            code = self._api_error_code(error)
            if code == 404:
                available = self._available_generate_content_models()
                suffix = (
                    " Models visible to this API key that support generateContent: "
                    + ", ".join(available[:15])
                    + (" ..." if len(available) > 15 else "")
                    if available
                    else " The API did not return any generateContent models for this key."
                )
                raise ConfigurationError(
                    f"Gemini model '{self.model}' is not available to this API key/project."
                    f"{suffix} Select an available model in Settings and save."
                ) from error
            if code in {401, 403}:
                raise ConfigurationError(
                    "Gemini rejected the configured API key or its permissions. Create a "
                    "Gemini API auth key in Google AI Studio and save it in ClipFactory Settings."
                ) from error
            raise AIProviderError(
                f"Gemini model preflight failed: {self._safe_api_error(error)}"
            ) from error

        actions = [
            str(action).replace("_", "").casefold()
            for action in (getattr(model_info, "supported_actions", None) or [])
        ]
        if actions and "generatecontent" not in actions:
            raise ConfigurationError(
                f"Gemini model '{self.model}' does not advertise generateContent support. "
                "Choose a multimodal generateContent model in Settings."
            )
        self._model_validated = True

    def analyze_clip(
        self,
        media_path: Path,
        media_info: MediaInfo,
        *,
        clip_id: str,
        theme: str,
        platform: str,
        video_format: str,
        permissions: AIFieldPermissions,
    ) -> ProviderResponse[ClipAnalysisResult]:
        prompt = self.prompt_builder.clip_analysis(
            clip_id=clip_id,
            theme=theme,
            platform=platform,
            video_format=video_format,
            duration_seconds=media_info.duration_seconds,
            permissions=permissions,
        )
        result, usage = self._generate_with_file(
            media_path, prompt, ClipAnalysisResult, media_info.duration_seconds
        )
        if result.clip_id != clip_id:
            result.clip_id = clip_id
        if not permissions.allow_trim_suggestions:
            result.suggested_trim_start_seconds = 0
            result.suggested_trim_end_seconds = media_info.duration_seconds
        return ProviderResponse(result=result, usage=usage)

    def create_project_creative(
        self,
        analyses: list[ClipAnalysisResult],
        *,
        theme: str,
        platform: str,
        video_format: str,
        permissions: AIFieldPermissions,
        preference_context: str = "",
    ) -> ProviderResponse[ProjectCreativeResult]:
        prompt = self.prompt_builder.project_creative(
            analyses,
            theme=theme,
            platform=platform,
            video_format=video_format,
            permissions=permissions,
            preference_context=preference_context,
        )
        result, usage = self._generate_text(prompt, ProjectCreativeResult)
        input_ids = [analysis.clip_id for analysis in analyses]
        if not permissions.allow_clip_reordering:
            result.recommended_clip_order = input_ids
        if set(result.recommended_clip_order) != set(input_ids):
            raise AIProviderError("Gemini returned an invalid clip-order mapping.")
        if len(result.ranking_captions) != len(analyses):
            raise AIProviderError(
                "Gemini returned a ranking-caption count that does not match the clips."
            )
        if not permissions.allow_header_text:
            result.header_text = ""
        if not permissions.allow_ranking_captions:
            result.ranking_captions = [""] * len(analyses)
        if not permissions.allow_upload_title:
            result.upload_title_suggestions = []
        if not permissions.allow_upload_description:
            result.youtube_description = ""
            result.tiktok_caption = ""
            result.tiktok_hook = ""
            result.tiktok_call_to_action = ""
        if not permissions.allow_upload_tags:
            result.youtube_tags = []
            result.youtube_hashtags = []
            result.tiktok_hashtags = []
        return ProviderResponse(result=result, usage=usage)

    def review_final_video(
        self,
        media_path: Path,
        media_info: MediaInfo,
        *,
        theme: str,
        platform: str,
    ) -> ProviderResponse[FinalVideoReviewResult]:
        prompt = self.prompt_builder.final_review(
            theme=theme, platform=platform, duration_seconds=media_info.duration_seconds
        )
        result, usage = self._generate_with_file(
            media_path, prompt, FinalVideoReviewResult, media_info.duration_seconds
        )
        return ProviderResponse(result=result, usage=usage)

    def _generate_text(
        self, prompt: str, result_type: type[ResultT]
    ) -> tuple[ResultT, ProviderUsage]:
        try:
            self.validate_ready()
            response = self._generate_content_with_retries(
                contents=prompt,
                config=self._structured_config(result_type, temperature=0.4),
                operation="structured text generation",
            )
            return self._parse_response(response, result_type, 0)
        except AIProviderError:
            raise
        except Exception as error:
            raise AIProviderError(f"Gemini structured request failed: {error}") from error

    def _generate_with_file(
        self,
        media_path: Path,
        prompt: str,
        result_type: type[ResultT],
        video_seconds: float,
    ) -> tuple[ResultT, ProviderUsage]:
        self.validate_ready()
        if media_path.stat().st_size <= _INLINE_MEDIA_LIMIT_BYTES:
            try:
                mime_type = mimetypes.guess_type(media_path.name)[0] or "video/mp4"
                media_part = types.Part.from_bytes(
                    data=media_path.read_bytes(),
                    mime_type=mime_type,
                )
                resolution_name = f"MEDIA_RESOLUTION_{self.media_resolution.upper()}"
                resolution = getattr(types.MediaResolution, resolution_name, None)
                response = self._generate_content_with_retries(
                    contents=[media_part, prompt],
                    config=self._structured_config(
                        result_type,
                        temperature=0.15,
                        media_resolution=resolution,
                    ),
                    operation="inline video analysis",
                )
                return self._parse_response(response, result_type, video_seconds)
            except AIProviderError:
                raise
            except Exception as error:
                raise AIProviderError(f"Gemini inline video analysis failed: {error}") from error

        uploaded = None
        try:
            uploaded = self.client.files.upload(file=str(media_path.resolve()))
            uploaded = self._wait_until_active(uploaded)
            resolution_name = f"MEDIA_RESOLUTION_{self.media_resolution.upper()}"
            resolution = getattr(types.MediaResolution, resolution_name, None)
            response = self._generate_content_with_retries(
                contents=[uploaded, prompt],
                config=self._structured_config(
                    result_type,
                    temperature=0.15,
                    media_resolution=resolution,
                ),
                operation="uploaded video analysis",
                retry_file_not_found=True,
            )
            return self._parse_response(response, result_type, video_seconds)
        except AIProviderError:
            raise
        except Exception as error:
            raise AIProviderError(f"Gemini video analysis failed: {error}") from error
        finally:
            request_failed = sys.exc_info()[0] is not None
            if uploaded is not None and getattr(uploaded, "name", None):
                try:
                    self._delete_uploaded_file(uploaded.name)
                except Exception as deletion_error:
                    message = (
                        "Gemini uploaded-file deletion failed after three attempts: "
                        f"{deletion_error}"
                    )
                    if not request_failed:
                        raise AIProviderError(message) from deletion_error
                    logger.error(message)

    def _generate_content_with_retries(
        self,
        *,
        contents: object,
        config: types.GenerateContentConfig,
        operation: str,
        retry_file_not_found: bool = False,
    ) -> object:
        last_error: Exception | None = None
        for attempt in range(len(_TRANSIENT_RETRY_DELAYS_SECONDS) + 1):
            try:
                return self.client.models.generate_content(
                    model=self.model,
                    contents=contents,
                    config=config,
                )
            except Exception as error:
                last_error = error
                code = self._api_error_code(error)
                retryable = code in {429, 500, 502, 503, 504} or (
                    retry_file_not_found and code == 404
                )
                if retryable and attempt < len(_TRANSIENT_RETRY_DELAYS_SECONDS):
                    time.sleep(_TRANSIENT_RETRY_DELAYS_SECONDS[attempt])
                    continue
                if code == 404 and retry_file_not_found:
                    raise AIProviderFatalError(
                        "Gemini repeatedly returned 404 for a file that the Files API had already "
                        "reported ACTIVE. The configured model passed its preflight check, so this "
                        "is an unresolved uploaded-file reference rather than a missing model. "
                        f"{self._safe_api_error(error)}"
                    ) from error
                if code in {400, 401, 403, 404}:
                    raise AIProviderFatalError(
                        f"Gemini rejected {operation}; repeating it for other candidates cannot "
                        f"repair the request. {self._safe_api_error(error)}"
                    ) from error
                if retryable:
                    raise AIProviderFatalError(
                        f"Gemini {operation} still failed after controlled retries. "
                        f"{self._safe_api_error(error)}"
                    ) from error
                raise
        assert last_error is not None
        raise last_error

    def _available_generate_content_models(self) -> list[str]:
        try:
            available: list[str] = []
            for model in self.client.models.list():
                actions = [
                    str(action).replace("_", "").casefold()
                    for action in (getattr(model, "supported_actions", None) or [])
                ]
                if "generatecontent" not in actions:
                    continue
                name = str(getattr(model, "name", "") or "")
                if name.startswith("models/"):
                    name = name.removeprefix("models/")
                if name:
                    available.append(name)
            return sorted(set(available))
        except Exception:
            return []

    @staticmethod
    def _api_error_code(error: Exception) -> int | None:
        value = getattr(error, "code", None)
        try:
            return int(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    @classmethod
    def _safe_api_error(cls, error: Exception) -> str:
        code = cls._api_error_code(error)
        status = str(getattr(error, "status", "") or "").strip()
        message = str(getattr(error, "message", "") or "").strip()
        prefix = " ".join(value for value in (str(code) if code else "", status) if value)
        return f"{prefix}: {message}" if message else (prefix or error.__class__.__name__)

    @staticmethod
    def _structured_config(
        result_type: type[ResultT],
        *,
        temperature: float,
        media_resolution: types.MediaResolution | None = None,
    ) -> types.GenerateContentConfig:
        # StrictModel emits JSON Schema's `additionalProperties: false`. Passing the
        # Pydantic class through response_schema converts that to the legacy
        # `additional_properties` protobuf field, which Gemini rejects. The SDK's
        # native JSON Schema path preserves the supported camel-case keyword while
        # local Pydantic validation remains strict.
        return types.GenerateContentConfig(
            response_mime_type="application/json",
            response_json_schema=result_type.model_json_schema(),
            temperature=temperature,
            media_resolution=media_resolution,
        )

    def _delete_uploaded_file(self, name: str) -> None:
        last_error: Exception | None = None
        for attempt in range(3):
            try:
                self.client.files.delete(name=name)
                return
            except Exception as error:
                last_error = error
                if attempt < 2:
                    time.sleep(2**attempt)
        assert last_error is not None
        raise last_error

    def _wait_until_active(self, uploaded: object) -> object:
        started = time.monotonic()
        current = uploaded
        while True:
            state = str(getattr(current, "state", "ACTIVE")).upper()
            if state.endswith("ACTIVE"):
                return current
            if state.endswith("FAILED"):
                raise AIProviderError("Gemini failed while processing the uploaded video.")
            if time.monotonic() - started > self.processing_timeout_seconds:
                raise AIProviderError("Gemini file processing timed out.")
            time.sleep(2)
            current = self.client.files.get(name=current.name)

    def _parse_response(
        self, response: object, result_type: type[ResultT], video_seconds: float
    ) -> tuple[ResultT, ProviderUsage]:
        parsed = getattr(response, "parsed", None)
        if isinstance(parsed, result_type):
            result = parsed
        elif parsed is not None:
            result = result_type.model_validate(parsed)
        else:
            text = getattr(response, "text", None)
            if not text:
                raise AIProviderError("Gemini returned no structured content.")
            result = result_type.model_validate(json.loads(text))
        metadata = getattr(response, "usage_metadata", None)
        audio_input_tokens = sum(
            int(getattr(value, "token_count", 0) or 0)
            for value in (getattr(metadata, "prompt_tokens_details", None) or [])
            if str(getattr(value, "modality", "")).upper().endswith("AUDIO")
        )
        prompt_tokens = int(getattr(metadata, "prompt_token_count", 0) or 0)
        if video_seconds > 0 and audio_input_tokens == 0:
            audio_input_tokens = min(prompt_tokens, math.ceil(video_seconds * 32))
        usage = ProviderUsage(
            input_tokens=prompt_tokens,
            output_tokens=int(getattr(metadata, "candidates_token_count", 0) or 0),
            cached_tokens=int(getattr(metadata, "cached_content_token_count", 0) or 0),
            video_seconds=video_seconds,
            audio_input_tokens=audio_input_tokens,
        )
        return result, usage
