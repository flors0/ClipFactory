"""Reject paid AI work before sending a request if any limit would be exceeded."""

from __future__ import annotations

import threading
from contextlib import contextmanager
from datetime import UTC, datetime
from uuid import uuid4

from app.ai.usage_ledger import AIUsageLedger
from app.core.config import BudgetSettings
from app.core.exceptions import BudgetExceededError
from app.models.ai_models import AIRequestEstimate


class AIBudgetGuard:
    _pending_lock = threading.Lock()
    _pending: dict[str, tuple[float, str | None]] = {}

    def __init__(self, settings: BudgetSettings, ledger: AIUsageLedger):
        self.settings = settings
        self.ledger = ledger

    def check(self, estimate: AIRequestEstimate, *, job_id: str | None = None) -> list[str]:
        with self._pending_lock:
            return self._check_locked(estimate, job_id=job_id)

    @contextmanager
    def reserve(self, estimate: AIRequestEstimate, *, job_id: str | None = None):
        reservation_id = str(uuid4())
        with self._pending_lock:
            warnings = self._check_locked(estimate, job_id=job_id)
            self._pending[reservation_id] = (estimate.estimated_cost_usd, job_id)
        try:
            yield warnings
        finally:
            with self._pending_lock:
                self._pending.pop(reservation_id, None)

    def _check_locked(self, estimate: AIRequestEstimate, *, job_id: str | None = None) -> list[str]:
        if estimate.input_tokens + estimate.output_tokens > self.settings.max_tokens_per_request:
            raise BudgetExceededError(
                "Estimated request tokens exceed the configured request token limit."
            )
        if estimate.video_seconds > self.settings.max_video_seconds_per_request:
            raise BudgetExceededError("Video duration exceeds the configured per-request limit.")
        if estimate.estimated_cost_usd > self.settings.request_limit_usd:
            raise BudgetExceededError(
                "Estimated request cost exceeds the configured per-request budget."
            )
        now = datetime.now(UTC)
        day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        pending_total = sum(value[0] for value in self._pending.values())
        daily = self.ledger.total_since(day_start) + pending_total
        monthly = self.ledger.total_since(month_start) + pending_total
        job_total = (
            self.ledger.total_since(datetime.min.replace(tzinfo=UTC), job_id=job_id)
            + sum(value[0] for value in self._pending.values() if value[1] == job_id)
            if job_id
            else 0
        )
        projected = estimate.estimated_cost_usd
        if job_id and job_total + projected > self.settings.job_limit_usd:
            raise BudgetExceededError(
                "Projected production-job AI cost exceeds its configured budget."
            )
        if daily + projected > self.settings.daily_limit_usd:
            raise BudgetExceededError("Projected daily AI cost exceeds the configured budget.")
        if monthly + projected > self.settings.monthly_limit_usd:
            raise BudgetExceededError("Projected monthly AI cost exceeds the configured budget.")
        warnings: list[str] = []
        threshold = self.settings.warning_threshold_percent / 100
        checks = (
            ("request", projected, self.settings.request_limit_usd),
            ("job", job_total + projected, self.settings.job_limit_usd),
            ("daily", daily + projected, self.settings.daily_limit_usd),
            ("monthly", monthly + projected, self.settings.monthly_limit_usd),
        )
        for name, value, limit in checks:
            if limit > 0 and value >= limit * threshold:
                warnings.append(
                    f"Projected {name} AI cost has reached {self.settings.warning_threshold_percent}% of its limit."
                )
        return warnings
