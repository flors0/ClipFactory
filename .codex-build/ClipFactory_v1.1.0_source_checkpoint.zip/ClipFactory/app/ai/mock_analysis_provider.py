"""Deterministic no-cost AI provider for tests and controlled smoke runs."""

from __future__ import annotations

import hashlib
from pathlib import Path

from app.ai.analysis_provider import AIAnalysisProvider, ProviderResponse, ProviderUsage
from app.models.ai_models import (
    AIFieldPermissions,
    ClipAnalysisResult,
    FinalVideoReviewResult,
    ProjectCreativeResult,
)
from app.models.media_models import MediaInfo


class MockAIAnalysisProvider(AIAnalysisProvider):
    name = "mock"
    model = "mock-v1"

    def analyze_clip(
        self,
        media_path: Path,
        media_info: MediaInfo,
        *,
        clip_id: str,
        theme: str,
        platform: str,
        video_format: str,
        permissions: AIFieldPermissions,
    ) -> ProviderResponse[ClipAnalysisResult]:
        seed = int(
            hashlib.sha256(f"{media_info.file_fingerprint}:{theme}".encode()).hexdigest()[:8], 16
        )
        quality = 72 + seed % 24
        hook = 66 + (seed // 7) % 30
        end = min(media_info.duration_seconds, 14 + seed % 8)
        result = ClipAnalysisResult(
            clip_id=clip_id,
            summary=f"A clearly visible short clip related to {theme}.",
            detected_theme=theme,
            usable=True,
            topic_match_score=88,
            quality_score=quality,
            hook_score=hook,
            ranking_caption=f"{theme.title()} chaos {clip_id[-8:]}",
            suggested_trim_start_seconds=0,
            suggested_trim_end_seconds=end
            if permissions.allow_trim_suggestions
            else media_info.duration_seconds,
            tags=[part for part in theme.lower().split() if part],
        )
        return ProviderResponse(
            result=result, usage=ProviderUsage(0, 0, video_seconds=media_info.duration_seconds)
        )

    def create_project_creative(
        self,
        analyses: list[ClipAnalysisResult],
        *,
        theme: str,
        platform: str,
        video_format: str,
        permissions: AIFieldPermissions,
        preference_context: str = "",
    ) -> ProviderResponse[ProjectCreativeResult]:
        ordered = sorted(
            analyses, key=lambda item: item.hook_score + item.quality_score, reverse=True
        )
        if not permissions.allow_clip_reordering:
            ordered = analyses
        captions = (
            [item.ranking_caption for item in ordered]
            if permissions.allow_ranking_captions
            else [""] * len(ordered)
        )
        header = f"{theme.title()} moments worth watching" if permissions.allow_header_text else ""
        title = f"These {theme.title()} Moments Escalate Fast"
        result = ProjectCreativeResult(
            header_text=header,
            ranking_captions=captions,
            recommended_clip_order=[item.clip_id for item in ordered],
            overall_theme=theme,
            upload_title_suggestions=[title] if permissions.allow_upload_title else [],
            youtube_description=f"A reviewed compilation of {theme} clips."
            if permissions.allow_upload_description
            else "",
            youtube_tags=[theme, "shorts"] if permissions.allow_upload_tags else [],
            youtube_hashtags=["Shorts", theme.replace(" ", "")],
            youtube_category_id_suggestion="22",
            tiktok_caption=f"Which {theme} moment wins?"
            if permissions.allow_upload_description
            else "",
            tiktok_hashtags=[theme.replace(" ", ""), "ranking"]
            if permissions.allow_upload_tags
            else [],
            tiktok_hook=f"Watch these {theme} moments escalate",
            tiktok_call_to_action="Choose your favorite in the comments",
        )
        return ProviderResponse(result=result, usage=ProviderUsage(0, 0))

    def review_final_video(
        self,
        media_path: Path,
        media_info: MediaInfo,
        *,
        theme: str,
        platform: str,
    ) -> ProviderResponse[FinalVideoReviewResult]:
        result = FinalVideoReviewResult(
            approved=True,
            quality_score=90,
            hook_score=84,
            pacing_score=86,
            text_readability_score=92,
            audio_quality_score=88,
        )
        return ProviderResponse(
            result=result, usage=ProviderUsage(0, 0, video_seconds=media_info.duration_seconds)
        )
