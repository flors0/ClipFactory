"""Replaceable AI provider interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Generic, TypeVar

from app.models.ai_models import (
    AIFieldPermissions,
    ClipAnalysisResult,
    FinalVideoReviewResult,
    ProjectCreativeResult,
)
from app.models.media_models import MediaInfo

ResultT = TypeVar("ResultT")


@dataclass(frozen=True, slots=True)
class ProviderUsage:
    input_tokens: int
    output_tokens: int
    cached_tokens: int = 0
    video_seconds: float = 0
    audio_input_tokens: int = 0


@dataclass(frozen=True, slots=True)
class ProviderResponse(Generic[ResultT]):
    result: ResultT
    usage: ProviderUsage


class AIAnalysisProvider(ABC):
    name: str
    model: str

    def validate_ready(self) -> None:
        """Validate provider/model access before expensive media work when supported."""
        return None

    @abstractmethod
    def analyze_clip(
        self,
        media_path: Path,
        media_info: MediaInfo,
        *,
        clip_id: str,
        theme: str,
        platform: str,
        video_format: str,
        permissions: AIFieldPermissions,
    ) -> ProviderResponse[ClipAnalysisResult]:
        """Analyze actual clip content and return a structured result."""

    @abstractmethod
    def create_project_creative(
        self,
        analyses: list[ClipAnalysisResult],
        *,
        theme: str,
        platform: str,
        video_format: str,
        permissions: AIFieldPermissions,
        preference_context: str = "",
    ) -> ProviderResponse[ProjectCreativeResult]:
        """Generate copy and ordering within explicit permissions."""

    @abstractmethod
    def review_final_video(
        self,
        media_path: Path,
        media_info: MediaInfo,
        *,
        theme: str,
        platform: str,
    ) -> ProviderResponse[FinalVideoReviewResult]:
        """Review the actual final render after deterministic checks."""


class TwelveLabsAnalysisProvider(AIAnalysisProvider):
    """Declared extension boundary; construction is rejected until configured by a plugin."""

    name = "twelvelabs"
    model = "external"

    def __init__(self) -> None:
        raise RuntimeError(
            "TwelveLabs is an extension boundary, not an enabled provider. Install and configure a provider implementation before selecting it."
        )
