"""Write actual successful AI usage and query budget windows."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

from app.models.ai_models import AIUsageRecord
from app.storage.database import Database


class AIUsageLedger:
    def __init__(self, database: Database):
        self.database = database

    def record_success(
        self,
        *,
        provider: str,
        model: str,
        operation: str,
        job_id: str | None,
        input_tokens: int,
        output_tokens: int,
        cached_tokens: int,
        video_seconds: float,
        cost_usd: float,
        audio_input_tokens: int = 0,
    ) -> AIUsageRecord:
        record = AIUsageRecord(
            id=str(uuid4()),
            provider=provider,
            model=model,
            operation=operation,
            job_id=job_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            audio_input_tokens=audio_input_tokens,
            cached_tokens=cached_tokens,
            video_seconds=video_seconds,
            cost_usd=cost_usd,
        )
        self.database.execute(
            "INSERT INTO ai_usage(id, provider, model, operation, job_id, input_tokens, output_tokens, audio_input_tokens, cached_tokens, video_seconds, cost_usd, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                record.id,
                record.provider,
                record.model,
                record.operation,
                record.job_id,
                record.input_tokens,
                record.output_tokens,
                record.audio_input_tokens,
                record.cached_tokens,
                record.video_seconds,
                record.cost_usd,
                record.created_at.isoformat(),
            ),
        )
        return record

    def total_since(self, since: datetime, *, job_id: str | None = None) -> float:
        if since.tzinfo is None:
            since = since.replace(tzinfo=UTC)
        if job_id:
            row = self.database.fetchone(
                "SELECT COALESCE(SUM(cost_usd), 0) AS total FROM ai_usage WHERE created_at >= ? AND job_id = ?",
                (since.isoformat(), job_id),
            )
        else:
            row = self.database.fetchone(
                "SELECT COALESCE(SUM(cost_usd), 0) AS total FROM ai_usage WHERE created_at >= ?",
                (since.isoformat(),),
            )
        return float(row["total"] if row else 0)

    def list_recent(self, limit: int = 200) -> list[AIUsageRecord]:
        rows = self.database.fetchall(
            "SELECT * FROM ai_usage ORDER BY created_at DESC LIMIT ?", (limit,)
        )
        return [AIUsageRecord.model_validate(dict(row)) for row in rows]
