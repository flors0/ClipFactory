"""Context-complete analysis cache."""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from typing import TypeVar

from pydantic import BaseModel

from app.storage.database import Database
from app.storage.repositories.json_repository import canonical_json

ResultT = TypeVar("ResultT", bound=BaseModel)


class AnalysisCache:
    def __init__(self, database: Database):
        self.database = database

    @staticmethod
    def build_key(
        *,
        file_fingerprint: str,
        provider: str,
        model: str,
        prompt_version: str,
        theme: str,
        platform: str,
        video_format: str,
        preset_id: str,
        permissions: BaseModel,
        options: dict[str, object] | None = None,
    ) -> str:
        context = {
            "file_fingerprint": file_fingerprint,
            "provider": provider,
            "model": model,
            "prompt_version": prompt_version,
            "theme": theme,
            "platform": platform,
            "video_format": video_format,
            "preset_id": preset_id,
            "permissions": permissions.model_dump(mode="json"),
            "options": options or {},
        }
        return hashlib.sha256(canonical_json(context).encode()).hexdigest()

    def get(self, key: str, model_type: type[ResultT]) -> ResultT | None:
        row = self.database.fetchone("SELECT payload FROM ai_cache WHERE cache_key = ?", (key,))
        if not row:
            return None
        self.database.execute(
            "UPDATE ai_cache SET accessed_at = ? WHERE cache_key = ?",
            (datetime.now(UTC).isoformat(), key),
        )
        return model_type.model_validate_json(row["payload"])

    def put(self, key: str, provider: str, model: str, result: BaseModel) -> None:
        now = datetime.now(UTC).isoformat()
        self.database.execute(
            "INSERT INTO ai_cache(cache_key, provider, model, result_type, payload, created_at, accessed_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(cache_key) DO UPDATE SET payload=excluded.payload, accessed_at=excluded.accessed_at",
            (key, provider, model, result.__class__.__name__, result.model_dump_json(), now, now),
        )
