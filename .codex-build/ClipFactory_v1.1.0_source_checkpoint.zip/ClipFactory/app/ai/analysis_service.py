"""Cache, budget, provider, and actual-usage orchestration."""

from __future__ import annotations

from contextlib import nullcontext
from pathlib import Path

from app.ai.analysis_cache import AnalysisCache
from app.ai.analysis_provider import AIAnalysisProvider, ProviderResponse
from app.ai.budget_guard import AIBudgetGuard
from app.ai.pricing import PricingCatalog
from app.ai.request_estimator import RequestEstimator
from app.ai.usage_ledger import AIUsageLedger
from app.models.ai_models import (
    AIFieldPermissions,
    ClipAnalysisResult,
    FinalVideoReviewResult,
    ProjectCreativeResult,
)
from app.models.media_models import MediaInfo


class AnalysisService:
    def __init__(
        self,
        provider: AIAnalysisProvider,
        cache: AnalysisCache,
        ledger: AIUsageLedger,
        budget_guard: AIBudgetGuard,
        estimator: RequestEstimator,
        pricing: PricingCatalog,
        *,
        prompt_version: str,
        media_resolution: str,
        cache_enabled: bool = True,
        clip_output_token_estimate: int = 1200,
        creative_output_token_estimate: int = 1800,
        review_output_token_estimate: int = 1200,
    ):
        self.provider = provider
        self.cache = cache
        self.ledger = ledger
        self.budget_guard = budget_guard
        self.estimator = estimator
        self.pricing = pricing
        self.prompt_version = prompt_version
        self.media_resolution = media_resolution
        self.cache_enabled = cache_enabled
        self.clip_output_token_estimate = clip_output_token_estimate
        self.creative_output_token_estimate = creative_output_token_estimate
        self.review_output_token_estimate = review_output_token_estimate

    def validate_provider(self) -> None:
        self.provider.validate_ready()

    def analyze_clip(
        self,
        media_path: Path,
        media_info: MediaInfo,
        *,
        clip_id: str,
        theme: str,
        platform: str,
        video_format: str,
        preset_id: str,
        permissions: AIFieldPermissions,
        prompt: str,
        job_id: str | None = None,
    ) -> tuple[ClipAnalysisResult, bool, list[str]]:
        key = AnalysisCache.build_key(
            file_fingerprint=media_info.file_fingerprint,
            provider=self.provider.name,
            model=self.provider.model,
            prompt_version=self.prompt_version,
            theme=theme,
            platform=platform,
            video_format=video_format,
            preset_id=preset_id,
            permissions=permissions,
            options={"media_resolution": self.media_resolution},
        )
        if self.cache_enabled:
            cached = self.cache.get(key, ClipAnalysisResult)
            if cached:
                return cached, True, []
        reservation = nullcontext([])
        if self.provider.name != "mock":
            estimate = self.estimator.estimate(
                provider=self.provider.name,
                model=self.provider.model,
                prompt=prompt,
                video_seconds=media_info.duration_seconds,
                has_audio=media_info.has_audio,
                media_resolution=self.media_resolution,
                expected_output_tokens=self.clip_output_token_estimate,
            )
            reservation = self.budget_guard.reserve(estimate, job_id=job_id)
        with reservation as warnings:
            response = self.provider.analyze_clip(
                media_path,
                media_info,
                clip_id=clip_id,
                theme=theme,
                platform=platform,
                video_format=video_format,
                permissions=permissions,
            )
            self._record(response, "clip_analysis", job_id)
        if self.cache_enabled:
            self.cache.put(key, self.provider.name, self.provider.model, response.result)
        return response.result, False, warnings

    def _record(
        self, response: ProviderResponse[object], operation: str, job_id: str | None
    ) -> None:
        if self.provider.name == "mock":
            return
        usage = response.usage
        cost = self.pricing.calculate(
            self.provider.model,
            usage.input_tokens,
            usage.output_tokens,
            audio_input_tokens=usage.audio_input_tokens,
        )
        self.ledger.record_success(
            provider=self.provider.name,
            model=self.provider.model,
            operation=operation,
            job_id=job_id,
            input_tokens=usage.input_tokens,
            output_tokens=usage.output_tokens,
            audio_input_tokens=usage.audio_input_tokens,
            cached_tokens=usage.cached_tokens,
            video_seconds=usage.video_seconds,
            cost_usd=cost,
        )

    def create_project_creative(
        self,
        analyses: list[ClipAnalysisResult],
        *,
        theme: str,
        platform: str,
        video_format: str,
        permissions: AIFieldPermissions,
        prompt: str,
        preference_context: str = "",
        job_id: str | None = None,
    ) -> tuple[ProjectCreativeResult, list[str]]:
        reservation = nullcontext([])
        if self.provider.name != "mock":
            estimate = self.estimator.estimate(
                provider=self.provider.name,
                model=self.provider.model,
                prompt=prompt,
                expected_output_tokens=self.creative_output_token_estimate,
            )
            reservation = self.budget_guard.reserve(estimate, job_id=job_id)
        with reservation as warnings:
            response = self.provider.create_project_creative(
                analyses,
                theme=theme,
                platform=platform,
                video_format=video_format,
                permissions=permissions,
                preference_context=preference_context,
            )
            self._record(response, "project_creative", job_id)
        return response.result, warnings

    def review_final_video(
        self,
        media_path: Path,
        media_info: MediaInfo,
        *,
        theme: str,
        platform: str,
        prompt: str,
        preset_id: str,
        permissions: AIFieldPermissions,
        job_id: str | None = None,
    ) -> tuple[FinalVideoReviewResult, bool, list[str]]:
        key = AnalysisCache.build_key(
            file_fingerprint=media_info.file_fingerprint,
            provider=self.provider.name,
            model=self.provider.model,
            prompt_version=f"{self.prompt_version}:final-review",
            theme=theme,
            platform=platform,
            video_format="final_review",
            preset_id=preset_id,
            permissions=permissions,
            options={"media_resolution": self.media_resolution},
        )
        if self.cache_enabled:
            cached = self.cache.get(key, FinalVideoReviewResult)
            if cached:
                return cached, True, []
        reservation = nullcontext([])
        if self.provider.name != "mock":
            estimate = self.estimator.estimate(
                provider=self.provider.name,
                model=self.provider.model,
                prompt=prompt,
                video_seconds=media_info.duration_seconds,
                has_audio=media_info.has_audio,
                media_resolution=self.media_resolution,
                expected_output_tokens=self.review_output_token_estimate,
            )
            reservation = self.budget_guard.reserve(estimate, job_id=job_id)
        with reservation as warnings:
            response = self.provider.review_final_video(
                media_path,
                media_info,
                theme=theme,
                platform=platform,
            )
            self._record(response, "final_video_review", job_id)
        if self.cache_enabled:
            self.cache.put(key, self.provider.name, self.provider.model, response.result)
        return response.result, False, warnings
