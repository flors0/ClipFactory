"""Persistent local scheduling engine."""
