"""Persistent upload scheduling queries."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from app.models.upload_models import UploadJob, UploadStatus
from app.storage.repositories.job_repository import UploadJobRepository


class PersistentJobStore:
    def __init__(self, repository: UploadJobRepository):
        self.repository = repository

    def due(self, now: datetime, limit: int = 1) -> list[UploadJob]:
        return self.repository.due(now, limit=limit)

    def claim_due(self, now: datetime, limit: int = 1) -> list[UploadJob]:
        return self.repository.claim_due(now, limit=limit)

    def recover_interrupted(
        self,
        *,
        now: datetime | None = None,
        stale_after: timedelta = timedelta(minutes=30),
    ) -> list[UploadJob]:
        now = now or datetime.now(UTC)
        cutoff = now - stale_after
        recovered: list[UploadJob] = []
        for job in self.repository.list(UploadStatus.UPLOADING):
            if job.updated_at > cutoff:
                continue
            job.status = UploadStatus.FAILED
            job.last_error = "Application stopped during upload. Retry will reuse the persisted resumable reference when supported."
            self.repository.save(job)
            recovered.append(job)
        return recovered
