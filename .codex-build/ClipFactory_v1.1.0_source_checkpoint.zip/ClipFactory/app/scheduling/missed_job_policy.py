"""Apply explicit catch-up rules without upload bursts."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from app.models.schedule_models import MissedJobPolicy
from app.models.upload_models import UploadJob, UploadStatus


def reconcile_missed_jobs(
    jobs: list[UploadJob],
    *,
    policy: MissedJobPolicy,
    now: datetime | None = None,
    stagger_minutes: int = 10,
) -> list[UploadJob]:
    now = now or datetime.now(UTC)
    missed = sorted(
        [
            job
            for job in jobs
            if (job.execution_at or job.scheduled_at) < now
            and job.status in {UploadStatus.SCHEDULED, UploadStatus.QUEUED}
        ],
        key=lambda job: job.execution_at or job.scheduled_at,
    )
    if not missed:
        return jobs
    if policy == MissedJobPolicy.SKIP:
        for job in missed:
            job.status = UploadStatus.CANCELLED
            job.last_error = "Skipped by the configured missed-job policy."
            job.log_messages.append(job.last_error)
    elif policy == MissedJobPolicy.UPLOAD_IMMEDIATELY:
        for index, job in enumerate(missed):
            job.execution_at = now + timedelta(minutes=index * stagger_minutes)
            job.status = UploadStatus.QUEUED if index == 0 else UploadStatus.SCHEDULED
            job.log_messages.append(
                "Missed execution was staggered by the upload-immediately policy."
            )
    elif policy == MissedJobPolicy.SHIFT_REMAINING:
        for batch_id in {job.batch_id or job.id for job in missed}:
            group_missed = [job for job in missed if (job.batch_id or job.id) == batch_id]
            first = group_missed[0].execution_at or group_missed[0].scheduled_at
            shift = now + timedelta(minutes=1) - first
            for job in jobs:
                if (
                    (job.batch_id or job.id) == batch_id
                    and job.status in {UploadStatus.SCHEDULED, UploadStatus.QUEUED}
                    and (job.execution_at or job.scheduled_at) >= first
                ):
                    job.execution_at = (job.execution_at or job.scheduled_at) + shift
                    job.scheduled_at = job.scheduled_at + shift
                    job.status = UploadStatus.SCHEDULED
                    job.log_messages.append(
                        "Missed execution was shifted forward with the remaining batch schedule."
                    )
    else:
        for job in missed:
            job.status = UploadStatus.PAUSED
            job.last_error = "Missed while ClipFactory was closed; choose a catch-up action."
            job.log_messages.append(job.last_error)
    return jobs
