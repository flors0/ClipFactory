"""Optional explicit Windows Task Scheduler registration helper."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


class WindowsTaskSchedulerHelper:
    task_name = "ClipFactory Scheduler"

    def registration_command(self, project_root: Path) -> list[str]:
        if sys.platform != "win32":
            raise RuntimeError("Windows Task Scheduler integration is only available on Windows.")
        if getattr(sys, "frozen", False):
            command = f'"{Path(sys.executable).resolve()}" --scheduler-only'
        else:
            root = project_root.resolve()
            command = f'cmd /c "cd /d {root} && uv run python -m app.main --scheduler-only"'
        return [
            "schtasks",
            "/Create",
            "/TN",
            self.task_name,
            "/SC",
            "ONLOGON",
            "/TR",
            command,
            "/F",
        ]

    def register(self, project_root: Path) -> None:
        completed = subprocess.run(
            self.registration_command(project_root), capture_output=True, text=True, check=False
        )
        if completed.returncode != 0:
            raise RuntimeError(f"Task Scheduler registration failed: {completed.stderr.strip()}")
