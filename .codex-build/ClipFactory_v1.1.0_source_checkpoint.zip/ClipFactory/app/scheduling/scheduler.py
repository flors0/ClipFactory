"""Single-flight persistent upload scheduler for local execution times."""

from __future__ import annotations

import logging
import threading
import time
from datetime import UTC, datetime, timedelta
from threading import Event, Thread

from app.core.logging import redact_text
from app.models.render_models import ProductionStatus
from app.models.upload_models import UploadJob, UploadStatus
from app.planning.clip_selection_planner import UsedMediaHistory
from app.scheduling.job_store import PersistentJobStore
from app.storage.repositories.channel_repository import ChannelRepository
from app.storage.repositories.job_repository import ProductionJobRepository, UploadJobRepository
from app.uploads.uploader import Uploader

logger = logging.getLogger(__name__)


class PersistentUploadScheduler:
    def __init__(
        self,
        job_store: PersistentJobStore,
        repository: UploadJobRepository,
        channels: ChannelRepository,
        production_jobs: ProductionJobRepository,
        uploaders: dict[str, Uploader],
        *,
        poll_seconds: float = 5,
        used_media_history: UsedMediaHistory | None = None,
        max_concurrency: int = 1,
    ):
        self.job_store = job_store
        self.repository = repository
        self.channels = channels
        self.production_jobs = production_jobs
        self.uploaders = uploaders
        self.poll_seconds = poll_seconds
        self.used_media_history = used_media_history
        self.max_concurrency = max(1, min(4, max_concurrency))
        self._stop = Event()
        self._paused = Event()
        self._thread: Thread | None = None
        self._active_cancels: dict[str, Event] = {}
        self._active_threads: dict[str, Thread] = {}
        self._lock = threading.Lock()

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    @property
    def paused(self) -> bool:
        return self._paused.is_set()

    def start(self) -> None:
        with self._lock:
            if self.running:
                return
            self.job_store.recover_interrupted()
            self._stop.clear()
            self._thread = Thread(
                target=self._run, name="clipfactory-upload-scheduler", daemon=True
            )
            self._thread.start()

    def stop(self, timeout: float = 10) -> None:
        self._stop.set()
        with self._lock:
            active_cancels = list(self._active_cancels.values())
            active_threads = list(self._active_threads.values())
        for cancel_event in active_cancels:
            cancel_event.set()
        if self._thread:
            self._thread.join(timeout=timeout)
        deadline = time.monotonic() + timeout
        for thread in active_threads:
            thread.join(timeout=max(0, deadline - time.monotonic()))

    def pause(self) -> None:
        self._paused.set()

    def resume(self) -> None:
        self._paused.clear()

    def run_due_once(self, now: datetime | None = None) -> UploadJob | None:
        now = now or datetime.now(UTC)
        jobs = self.job_store.claim_due(now, limit=1)
        job = jobs[0] if jobs else None
        if not job:
            return None
        cancel_event = Event()
        with self._lock:
            self._active_cancels[job.id] = cancel_event
        try:
            self._execute(job, cancel_event)
        finally:
            with self._lock:
                self._active_cancels.pop(job.id, None)
        return self.repository.get(job.id)

    def _run(self) -> None:
        while not self._stop.wait(self.poll_seconds):
            if self._paused.is_set():
                continue
            try:
                self._dispatch_due_jobs()
            except Exception:
                logger.exception("Scheduled upload iteration failed")

    def _dispatch_due_jobs(self) -> None:
        with self._lock:
            available = self.max_concurrency - len(self._active_cancels)
        if available <= 0:
            return
        candidates = self.job_store.claim_due(datetime.now(UTC), limit=available)
        for job in candidates:
            if available <= 0:
                break
            with self._lock:
                if job.id in self._active_cancels:
                    continue
                cancel_event = Event()
                thread = Thread(
                    target=self._execute_managed,
                    args=(job, cancel_event),
                    name=f"clipfactory-upload-{job.id[:8]}",
                    daemon=True,
                )
                self._active_cancels[job.id] = cancel_event
                self._active_threads[job.id] = thread
            thread.start()
            available -= 1

    def _execute_managed(self, job: UploadJob, cancel_event: Event) -> None:
        try:
            self._execute(job, cancel_event)
        finally:
            with self._lock:
                self._active_cancels.pop(job.id, None)
                self._active_threads.pop(job.id, None)

    def _is_active(self, job_id: str) -> bool:
        with self._lock:
            return job_id in self._active_cancels

    def _execute(self, job: UploadJob, cancel_event: Event) -> None:
        channel = self.channels.get(job.channel_id)
        if not channel or not channel.enabled:
            self._fail(job, "Target channel is missing or disabled.")
            return
        uploader = self.uploaders.get(job.platform)
        if not uploader:
            self._fail(job, f"No uploader is registered for {job.platform}.")
            return
        production = self.production_jobs.get(job.production_job_id)
        if production:
            production.status = ProductionStatus.UPLOADING
            production.current_step = f"Uploading to {job.platform}"
            self.production_jobs.save(production)
        job.log_messages.append(f"Scheduled execution started for {job.platform}.")
        try:
            result = uploader.upload(
                job,
                channel,
                cancel_event=cancel_event,
                progress_callback=lambda value, _text: self._persist_progress(job, value),
                state_callback=self.repository.save,
            )
            job.remote_id = result.remote_id
            job.status = result.status
            job.published_at = result.published_at
            job.progress = 99 if result.status == UploadStatus.PROCESSING else 100
            job.last_error = None
            if result.status == UploadStatus.PROCESSING:
                job.execution_at = datetime.now(UTC) + timedelta(minutes=2)
                job.log_messages.append(
                    "Platform processing is incomplete; a persisted status check was scheduled."
                )
            elif result.status == UploadStatus.SCHEDULED and job.remote_id:
                job.execution_at = max(
                    datetime.now(UTC) + timedelta(minutes=5),
                    job.scheduled_at + timedelta(minutes=1),
                )
                job.log_messages.append(
                    "Remote scheduled publication will be checked again after its publish time."
                )
            job.log_messages.append(
                f"Platform transfer completed with remote ID {result.remote_id}."
            )
            self.repository.save(job)
            production = self.production_jobs.get(job.production_job_id)
            if production:
                production.status = (
                    ProductionStatus.PUBLISHED
                    if result.status == UploadStatus.PUBLISHED
                    else ProductionStatus.SCHEDULED
                )
                production.current_step = f"Remote ID: {result.remote_id}"
                self.production_jobs.save(production)
                if result.status == UploadStatus.PUBLISHED and self.used_media_history:
                    plan = production.render_plan_payload or {}
                    for clip in plan.get("clips", []):
                        fingerprint = (
                            clip.get("media_fingerprint") if isinstance(clip, dict) else None
                        )
                        if fingerprint:
                            self.used_media_history.mark_published(str(fingerprint), job.channel_id)
        except Exception as error:
            self._fail(job, str(error))

    def _persist_progress(self, job: UploadJob, value: int) -> None:
        job.progress = value
        job.status = UploadStatus.UPLOADING
        self.repository.save(job)

    def _fail(self, job: UploadJob, error: str) -> None:
        error = redact_text(error)
        job.status = UploadStatus.FAILED
        job.last_error = error
        job.retry_count += 1
        job.log_messages.append(f"Upload failed: {error}")
        self.repository.save(job)
        production = self.production_jobs.get(job.production_job_id)
        if production:
            production.status = ProductionStatus.FAILED
            production.last_error = error
            production.current_step = "Upload failed"
            self.production_jobs.save(production, validate_transition=False)
