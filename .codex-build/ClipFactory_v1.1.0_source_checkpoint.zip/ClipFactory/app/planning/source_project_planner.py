"""Derive a project theme and immutable source plan."""

from __future__ import annotations

import re
from collections import Counter
from uuid import uuid4

from app.models.ai_models import ClipAnalysisResult
from app.models.preset_models import Preset
from app.models.project_models import QualityThresholds, SourceProjectPlan
from app.models.source_models import DiscoveryResult, SourceProfile

STOP_WORDS = {
    "the",
    "a",
    "an",
    "and",
    "or",
    "of",
    "to",
    "in",
    "on",
    "for",
    "with",
    "this",
    "that",
    "my",
    "your",
    "is",
    "are",
    "was",
    "were",
    "i",
    "it",
    "at",
    "from",
    "r",
    "reddit",
}


def readable_community_name(value: str) -> str:
    spaced = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", value.replace("_", " "))
    return re.sub(r"\s+", " ", spaced).strip().lower()


class SourceProjectPlanner:
    def seed_plan(
        self,
        profile: SourceProfile,
        preset: Preset,
        *,
        project_id: str,
        target_video_count: int = 1,
        thresholds: QualityThresholds | None = None,
        target_platform: str | None = None,
    ) -> SourceProjectPlan:
        """Persist enough intent to recover a job even if discovery is interrupted."""
        thresholds = self._effective_thresholds(profile, preset, thresholds)
        return SourceProjectPlan(
            id=project_id,
            project_id=project_id,
            source_profile=profile,
            preset_id=preset.id,
            target_platform=target_platform or preset.platform,
            video_format=preset.video_format,
            preliminary_theme=profile.theme_hint or readable_community_name(profile.community),
            target_video_count=target_video_count,
            target_duration=preset.duration.target_seconds,
            quality_thresholds=thresholds,
            warnings=["Production intent was persisted before external work started."],
        )

    def create_plan(
        self,
        profile: SourceProfile,
        discovery: DiscoveryResult,
        preset: Preset,
        *,
        target_video_count: int,
        thresholds: QualityThresholds | None = None,
        target_platform: str | None = None,
    ) -> SourceProjectPlan:
        preliminary = profile.theme_hint or self._derive_preliminary(profile, discovery)
        effective_thresholds = self._effective_thresholds(profile, preset, thresholds)
        return SourceProjectPlan(
            project_id=str(uuid4()),
            source_profile=profile,
            preset_id=preset.id,
            target_platform=target_platform or preset.platform,
            video_format=preset.video_format,
            preliminary_theme=preliminary,
            candidate_ids=[candidate.post_id for candidate in discovery.candidates],
            target_video_count=target_video_count,
            target_duration=preset.duration.target_seconds,
            quality_thresholds=effective_thresholds,
            warnings=list(discovery.warnings),
        )

    def refine_theme(self, plan: SourceProjectPlan, analyses: list[ClipAnalysisResult]) -> str:
        usable = [
            analysis.detected_theme.strip().lower()
            for analysis in analyses
            if analysis.usable and analysis.detected_theme.strip()
        ]
        if not usable:
            return plan.preliminary_theme
        weighted: Counter[str] = Counter()
        for analysis in analyses:
            theme = analysis.detected_theme.strip().lower()
            if theme and analysis.usable:
                weighted[theme] += max(1, round(analysis.topic_match_score / 20))
        plan.refined_theme = weighted.most_common(1)[0][0]
        return plan.refined_theme

    def _derive_preliminary(self, profile: SourceProfile, discovery: DiscoveryResult) -> str:
        community_theme = readable_community_name(profile.community)
        corpus = " ".join(
            [community_theme, discovery.community_description or ""]
            + [candidate.title for candidate in discovery.candidates[:20]]
        ).lower()
        words = [
            word for word in re.findall(r"[a-z][a-z0-9'-]{2,}", corpus) if word not in STOP_WORDS
        ]
        frequent = [word for word, _count in Counter(words).most_common(3)]
        if frequent and all(word not in community_theme for word in frequent[:1]):
            return f"{community_theme} {frequent[0]}".strip()
        return community_theme

    @staticmethod
    def _effective_thresholds(
        profile: SourceProfile,
        preset: Preset,
        thresholds: QualityThresholds | None,
    ) -> QualityThresholds:
        payload = (thresholds or QualityThresholds()).model_dump(mode="python")
        if profile.rights_mode.value == "strict":
            payload["allow_unknown_rights"] = False
        if preset.ranking.enabled:
            payload["minimum_clip_count"] = preset.ranking.count
            payload["maximum_clip_count"] = preset.ranking.count
        return QualityThresholds.model_validate(payload)
