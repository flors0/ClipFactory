"""Timezone-aware explicit, interval, template, and missed-job scheduling."""

from __future__ import annotations

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from app.models.schedule_models import MissedJobPolicy, ScheduleRequest, ScheduleTemplate


class SchedulePlanner:
    def build(self, request: ScheduleRequest) -> list[datetime]:
        timezone = ZoneInfo(request.timezone)
        if request.explicit_times:
            values = [self._localized(value, timezone) for value in request.explicit_times]
        else:
            assert request.start_at is not None and request.interval_hours is not None
            start = self._localized(request.start_at, timezone)
            values = [
                start + timedelta(hours=request.interval_hours * index)
                for index in range(request.count)
            ]
        if values != sorted(values):
            raise ValueError("Schedule times must be chronological.")
        if len(set(values)) != len(values):
            raise ValueError("Schedule times must be unique.")
        return values

    def next_from_template(
        self, template: ScheduleTemplate, *, count: int, after: datetime | None = None
    ) -> list[datetime]:
        timezone = ZoneInfo(template.timezone)
        cursor = self._localized(after or datetime.now(timezone), timezone)
        results: list[datetime] = []
        for offset in range(0, 370):
            day = (cursor + timedelta(days=offset)).date()
            if day.weekday() not in template.weekdays:
                continue
            for local_time in sorted(template.daily_times):
                candidate = datetime.combine(day, local_time, tzinfo=timezone)
                if candidate > cursor:
                    results.append(candidate)
                    if len(results) == count:
                        return results
        raise ValueError("Schedule template could not produce enough dates within one year.")

    def apply_missed_policy(
        self,
        scheduled: list[datetime],
        *,
        now: datetime,
        policy: MissedJobPolicy,
    ) -> tuple[list[datetime], list[datetime]]:
        missed = [value for value in scheduled if value <= now]
        future = [value for value in scheduled if value > now]
        if not missed or policy == MissedJobPolicy.ASK:
            return scheduled, missed
        if policy == MissedJobPolicy.SKIP:
            return future, missed
        if policy == MissedJobPolicy.UPLOAD_IMMEDIATELY:
            staggered = [now + timedelta(minutes=5 * index) for index in range(len(missed))]
            return staggered + future, missed
        if policy == MissedJobPolicy.SHIFT_REMAINING:
            original_start = min(scheduled)
            delta = now + timedelta(minutes=1) - original_start
            return [value + delta for value in scheduled], missed
        return scheduled, missed

    @staticmethod
    def _localized(value: datetime, timezone: ZoneInfo) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone)
        return value.astimezone(timezone)
