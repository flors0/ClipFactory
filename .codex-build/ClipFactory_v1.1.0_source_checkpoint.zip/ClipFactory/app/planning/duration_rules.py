"""Duration-rule validation without blind looping."""

from __future__ import annotations

from app.models.preset_models import DurationEnforcement, DurationRule


def evaluate_duration(
    duration_seconds: float, rule: DurationRule, *, additional_clips_available: bool = False
) -> tuple[bool, list[str]]:
    warnings: list[str] = []
    if rule.minimum_seconds <= duration_seconds <= rule.maximum_seconds:
        return True, warnings
    message = f"Duration {duration_seconds:.2f}s is outside {rule.minimum_seconds:.2f}-{rule.maximum_seconds:.2f}s."
    if rule.enforcement == DurationEnforcement.WARN:
        return True, [message]
    if rule.enforcement == DurationEnforcement.BLOCK:
        return False, [message]
    if duration_seconds < rule.minimum_seconds and additional_clips_available:
        return False, [
            message,
            "Auto-extend requires selecting additional distinct clips or an explicit filler asset.",
        ]
    return False, [message, "Auto-extend refused to loop existing footage blindly."]
