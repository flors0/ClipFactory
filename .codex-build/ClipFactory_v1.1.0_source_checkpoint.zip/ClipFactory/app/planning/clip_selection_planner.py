"""Select high-quality, non-duplicate clips while enforcing duration rules."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import UTC, datetime
from difflib import SequenceMatcher

from app.models.ai_models import ClipAnalysisResult
from app.models.media_models import MediaInfo
from app.models.project_models import ClipSelectionResult, QualityThresholds, SelectedClip
from app.models.source_models import SourceCandidate
from app.storage.database import Database


@dataclass(frozen=True, slots=True)
class AnalyzedCandidate:
    source: SourceCandidate
    media: MediaInfo
    analysis: ClipAnalysisResult


class UsedMediaHistory:
    def __init__(self, database: Database):
        self.database = database

    def is_used(self, media_fingerprint: str, *, channel_id: str | None = None) -> bool:
        if channel_id:
            row = self.database.fetchone(
                "SELECT 1 FROM used_media WHERE media_fingerprint = ? AND channel_id IN (?, '') LIMIT 1",
                (media_fingerprint, channel_id),
            )
        else:
            row = self.database.fetchone(
                "SELECT 1 FROM used_media WHERE media_fingerprint = ? LIMIT 1", (media_fingerprint,)
            )
        return row is not None

    def reserve(
        self,
        media_fingerprint: str,
        source_post_id: str,
        *,
        channel_id: str | None,
        batch_id: str,
        published: bool = False,
    ) -> None:
        self.database.execute(
            "INSERT OR IGNORE INTO used_media(media_fingerprint, source_post_id, channel_id, batch_id, used_at, published) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                media_fingerprint,
                source_post_id,
                channel_id or "",
                batch_id,
                datetime.now(UTC).isoformat(),
                int(published),
            ),
        )

    def mark_published(self, media_fingerprint: str, channel_id: str) -> None:
        self.database.execute(
            "UPDATE used_media SET published = 1 WHERE media_fingerprint = ? AND channel_id = ?",
            (media_fingerprint, channel_id),
        )


class ClipSelectionPlanner:
    def __init__(self, history: UsedMediaHistory):
        self.history = history

    def select(
        self,
        candidates: list[AnalyzedCandidate],
        *,
        target_duration: float,
        thresholds: QualityThresholds,
        channel_id: str | None = None,
        excluded_fingerprints: set[str] | None = None,
        excluded_caption_keys: set[str] | None = None,
    ) -> ClipSelectionResult:
        excluded_fingerprints = set(excluded_fingerprints or set())
        excluded_caption_keys = set(excluded_caption_keys or set())
        strict_eligible: list[AnalyzedCandidate] = []
        fallback_eligible: list[AnalyzedCandidate] = []
        rejection_reasons: dict[str, list[str]] = {}
        seen_posts: set[str] = set()
        seen_media: set[str] = set()
        seen_titles: list[str] = []
        for item in sorted(candidates, key=self._score, reverse=True):
            hard_reasons = self._hard_policy_reasons(item, thresholds)
            fingerprint = item.media.file_fingerprint
            if fingerprint in excluded_fingerprints:
                hard_reasons.append("already selected elsewhere in this batch")
            if thresholds.avoid_duplicate_posts and item.source.post_id in seen_posts:
                hard_reasons.append("duplicate source post")
            if thresholds.avoid_duplicate_media and fingerprint in seen_media:
                hard_reasons.append("duplicate media")
            normalized_title = self.normalize_text(item.source.title)
            if any(
                SequenceMatcher(None, normalized_title, previous).ratio() >= 0.90
                for previous in seen_titles
            ):
                hard_reasons.append("near-duplicate source title")
            if thresholds.avoid_previously_used_clips and self.history.is_used(
                fingerprint, channel_id=channel_id
            ):
                hard_reasons.append("previously used media")
            if hard_reasons:
                rejection_reasons[item.analysis.clip_id] = hard_reasons
                continue

            seen_posts.add(item.source.post_id)
            seen_media.add(fingerprint)
            seen_titles.append(normalized_title)

            quality_reasons = self._quality_reasons(item, thresholds)
            if not quality_reasons:
                strict_eligible.append(item)
                continue
            rejection_reasons[item.analysis.clip_id] = quality_reasons
            if thresholds.allow_quality_fallback and self._passes_fallback_floor(item, thresholds):
                fallback_eligible.append(item)

        selected: list[SelectedClip] = []
        total = 0.0
        fallback_clip_ids: list[str] = []
        repaired_trim_clip_ids: list[str] = []
        duplicate_caption_clip_ids: list[str] = []
        seen_captions = set(excluded_caption_keys)
        selection_pool = [(item, False) for item in strict_eligible] + [
            (item, True) for item in fallback_eligible
        ]
        for item, is_fallback in selection_pool:
            if len(selected) >= thresholds.maximum_clip_count or (
                total >= target_duration and len(selected) >= thresholds.minimum_clip_count
            ):
                break
            start, end, repaired_trim = self._trim_window(item, thresholds)
            available = min(end - start, thresholds.maximum_individual_clip_seconds)
            required_after_this = max(
                0,
                thresholds.minimum_clip_count - len(selected) - 1,
            )
            reserved_duration = required_after_this * thresholds.minimum_individual_clip_seconds
            remaining = target_duration - total - reserved_duration
            duration = min(available, max(thresholds.minimum_individual_clip_seconds, remaining))
            if duration < thresholds.minimum_individual_clip_seconds:
                rejection_reasons.setdefault(item.analysis.clip_id, []).append(
                    "usable trim is shorter than the minimum clip duration"
                )
                continue
            caption_key = self.normalize_text(item.analysis.ranking_caption)
            if caption_key and any(
                SequenceMatcher(None, caption_key, previous).ratio() >= 0.88
                for previous in seen_captions
                if previous
            ):
                duplicate_caption_clip_ids.append(item.analysis.clip_id)
            if caption_key:
                seen_captions.add(caption_key)
            selected.append(
                SelectedClip(
                    clip_id=item.analysis.clip_id,
                    candidate_id=item.source.post_id,
                    media_path=item.media.file_path,
                    media_fingerprint=item.media.file_fingerprint,
                    source_url=item.source.post_url,
                    start_seconds=start,
                    end_seconds=start + duration,
                    caption=item.analysis.ranking_caption,
                    rank=len(selected) + 1,
                    analysis_score=self._score(item),
                )
            )
            total += duration
            rejection_reasons.pop(item.analysis.clip_id, None)
            if is_fallback:
                fallback_clip_ids.append(item.analysis.clip_id)
            if repaired_trim:
                repaired_trim_clip_ids.append(item.analysis.clip_id)

        selected_ids = {item.clip_id for item in selected}
        analyzed_by_clip = {item.analysis.clip_id: item for item in candidates}
        extended_trim_clip_ids = self._extend_selected_clips(
            selected,
            analyzed_by_clip,
            target_duration=target_duration,
            thresholds=thresholds,
        )
        total = sum(clip.duration_seconds for clip in selected)
        rejected = [
            item.analysis.clip_id
            for item in candidates
            if item.analysis.clip_id not in selected_ids
        ]
        retained_rejection_reasons = {
            clip_id: reasons
            for clip_id, reasons in rejection_reasons.items()
            if clip_id in rejected
        }
        warnings: list[str] = []
        if fallback_clip_ids:
            warnings.append(
                "Automatic quality fallback filled the ranking with the strongest safe clips "
                "that missed one or more strict AI quality gates: "
                + ", ".join(fallback_clip_ids)
                + "."
            )
        if repaired_trim_clip_ids:
            warnings.append(
                "Ignored an AI trim that was shorter than the configured minimum for: "
                + ", ".join(repaired_trim_clip_ids)
                + "."
            )
        if extended_trim_clip_ids:
            warnings.append(
                "Expanded the preferred AI trim windows within the original source media to "
                "satisfy the preset duration without looping footage: "
                + ", ".join(extended_trim_clip_ids)
                + "."
            )
        if duplicate_caption_clip_ids:
            warnings.append(
                "Initial AI captions were similar for: "
                + ", ".join(duplicate_caption_clip_ids)
                + "; the clips were retained for project-level caption rewriting."
            )
        if len(selected) < thresholds.minimum_clip_count:
            warnings.append(
                f"Selected {len(selected)} distinct clip(s); the configured minimum is "
                f"{thresholds.minimum_clip_count}."
            )
        target_met = (
            total >= target_duration - 0.05 and len(selected) >= thresholds.minimum_clip_count
        )
        if not target_met:
            warnings.append(f"Selected duration is {total:.2f}s; target is {target_duration:.2f}s.")
            if retained_rejection_reasons:
                warnings.append(
                    "Rejected candidate summary: "
                    + self._summarize_rejection_reasons(retained_rejection_reasons)
                    + "."
                )
        return ClipSelectionResult(
            selected=selected,
            total_duration_seconds=total,
            target_met=target_met,
            rejected_clip_ids=rejected,
            rejection_reasons=retained_rejection_reasons,
            fallback_clip_ids=fallback_clip_ids,
            repaired_trim_clip_ids=repaired_trim_clip_ids,
            extended_trim_clip_ids=extended_trim_clip_ids,
            warnings=warnings,
        )

    @staticmethod
    def rejection_summary(result: ClipSelectionResult) -> str:
        return ClipSelectionPlanner._summarize_rejection_reasons(result.rejection_reasons)

    @staticmethod
    def _summarize_rejection_reasons(rejection_reasons: dict[str, list[str]]) -> str:
        counts: dict[str, int] = {}
        for reasons in rejection_reasons.values():
            for reason in reasons:
                counts[reason] = counts.get(reason, 0) + 1
        if not counts:
            return "no detailed rejection reason was recorded"
        ordered = sorted(counts.items(), key=lambda value: (-value[1], value[0]))
        return "; ".join(f"{reason}: {count}" for reason, count in ordered)

    @classmethod
    def _extend_selected_clips(
        cls,
        selected: list[SelectedClip],
        analyzed_by_clip: dict[str, AnalyzedCandidate],
        *,
        target_duration: float,
        thresholds: QualityThresholds,
    ) -> list[str]:
        """Use more original footage when short AI trims leave a safe selection under target."""
        remaining = max(0.0, target_duration - sum(clip.duration_seconds for clip in selected))
        extended: list[str] = []
        while remaining > 0.005:
            expandable: list[tuple[SelectedClip, AnalyzedCandidate, float]] = []
            for clip in selected:
                item = analyzed_by_clip.get(clip.clip_id)
                if item is None:
                    continue
                capacity = min(
                    item.media.duration_seconds,
                    thresholds.maximum_individual_clip_seconds,
                )
                available = capacity - clip.duration_seconds
                if available > 0.005:
                    expandable.append((clip, item, available))
            if not expandable:
                break

            fair_share = remaining / len(expandable)
            added_this_round = 0.0
            for clip, item, available in expandable:
                increment = min(available, fair_share)
                requested_duration = clip.duration_seconds + increment
                start, end = cls._window_for_duration(
                    item,
                    thresholds,
                    requested_duration,
                )
                actual_increment = end - start - clip.duration_seconds
                if actual_increment <= 0.0005:
                    continue
                clip.start_seconds = start
                clip.end_seconds = end
                added_this_round += actual_increment
                if clip.clip_id not in extended:
                    extended.append(clip.clip_id)
            if added_this_round <= 0.0005:
                break
            remaining = max(0.0, remaining - added_this_round)
        return extended

    @classmethod
    def _window_for_duration(
        cls,
        item: AnalyzedCandidate,
        thresholds: QualityThresholds,
        requested_duration: float,
    ) -> tuple[float, float]:
        """Expand around the AI-preferred moment while staying inside the source media."""
        preferred_start, preferred_end, _repaired = cls._trim_window(item, thresholds)
        media_duration = item.media.duration_seconds
        duration = min(
            requested_duration,
            media_duration,
            thresholds.maximum_individual_clip_seconds,
        )
        preferred_duration = preferred_end - preferred_start
        if preferred_duration >= duration:
            return preferred_start, preferred_start + duration

        extra = duration - preferred_duration
        before = min(preferred_start, extra / 2)
        after = min(media_duration - preferred_end, extra - before)
        still_needed = extra - before - after
        if still_needed > 0:
            additional_before = min(preferred_start - before, still_needed)
            before += additional_before
            still_needed -= additional_before
        if still_needed > 0:
            after += min(media_duration - preferred_end - after, still_needed)

        start = max(0.0, preferred_start - before)
        end = min(media_duration, preferred_end + after)
        if end - start < duration - 0.001:
            start = min(start, max(0.0, media_duration - duration))
            end = min(media_duration, start + duration)
        return start, end

    @staticmethod
    def _hard_policy_reasons(
        item: AnalyzedCandidate,
        thresholds: QualityThresholds,
    ) -> list[str]:
        analysis = item.analysis
        reasons: list[str] = []
        if item.source.rights_status == "restricted":
            reasons.append("restricted rights status")
        if not thresholds.allow_unknown_rights and item.source.rights_status != "cleared":
            reasons.append("rights status is not cleared")
        if thresholds.reject_sensitive_content and analysis.contains_sensitive_content:
            reasons.append("sensitive content")
        if thresholds.reject_watermark and analysis.contains_watermark:
            reasons.append("watermark")
        if thresholds.reject_embedded_text and analysis.contains_embedded_text:
            reasons.append("embedded text")
        if item.media.duration_seconds < thresholds.minimum_individual_clip_seconds:
            reasons.append("source media is shorter than the minimum clip duration")
        return reasons

    @staticmethod
    def _quality_reasons(
        item: AnalyzedCandidate,
        thresholds: QualityThresholds,
    ) -> list[str]:
        analysis = item.analysis
        reasons: list[str] = []
        if not analysis.usable:
            reasons.append("AI marked clip unusable")
        if analysis.topic_match_score < thresholds.minimum_topic_score:
            reasons.append(f"topic score below {thresholds.minimum_topic_score:g}")
        if analysis.quality_score < thresholds.minimum_quality_score:
            reasons.append(f"quality score below {thresholds.minimum_quality_score:g}")
        if analysis.hook_score < thresholds.minimum_hook_score:
            reasons.append(f"hook score below {thresholds.minimum_hook_score:g}")
        return reasons

    @staticmethod
    def _passes_fallback_floor(
        item: AnalyzedCandidate,
        thresholds: QualityThresholds,
    ) -> bool:
        analysis = item.analysis
        return (
            min(
                analysis.topic_match_score,
                analysis.quality_score,
                analysis.hook_score,
            )
            >= thresholds.minimum_fallback_score
        )

    @staticmethod
    def _trim_window(
        item: AnalyzedCandidate,
        thresholds: QualityThresholds,
    ) -> tuple[float, float, bool]:
        media_duration = item.media.duration_seconds
        start = min(
            max(0, item.analysis.suggested_trim_start_seconds),
            max(0, media_duration - 0.1),
        )
        requested_end = item.analysis.suggested_trim_end_seconds
        end = requested_end if requested_end is not None else media_duration
        end = min(media_duration, max(end, start + 0.1))
        if end - start >= thresholds.minimum_individual_clip_seconds:
            return start, end, False
        return 0.0, media_duration, True

    @staticmethod
    def _score(item: AnalyzedCandidate) -> float:
        analysis = item.analysis
        return round(
            analysis.topic_match_score * 0.35
            + analysis.quality_score * 0.35
            + analysis.hook_score * 0.30,
            4,
        )

    @staticmethod
    def normalize_text(value: str) -> str:
        return re.sub(r"[^a-z0-9]+", " ", value.casefold()).strip()
