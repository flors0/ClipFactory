"""Expand sources, presets, channels, counts, and schedule into persistent jobs."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from itertools import cycle
from uuid import uuid4

from app.models.channel_models import ChannelProfile
from app.models.preset_models import Preset
from app.models.project_models import QualityThresholds
from app.models.render_models import ProductionJob
from app.models.source_models import SourceProfile
from app.presets.design_profile_manager import DesignProfileManager


@dataclass(frozen=True, slots=True)
class PlannedBatchItem:
    project_id: str
    job: ProductionJob
    source_profile: SourceProfile
    preset: Preset
    channel: ChannelProfile | None

    @property
    def target_platform(self) -> str:
        return self.channel.platform if self.channel else self.preset.platform


@dataclass(frozen=True, slots=True)
class BatchPlan:
    id: str
    items: list[PlannedBatchItem]
    estimated_downloads: int
    estimated_ai_requests: int
    estimated_ai_cost_usd: float
    quality_thresholds: QualityThresholds


class BatchPlanner:
    def __init__(self, design_profiles: DesignProfileManager | None = None):
        self.design_profiles = design_profiles

    def build(
        self,
        *,
        sources: list[SourceProfile],
        presets: list[Preset],
        channels: list[ChannelProfile],
        video_count: int,
        schedule: list[datetime],
        videos_per_channel: int | None = None,
        estimated_cost_per_analysis: float = 0.03,
        analyses_per_video: int = 8,
        quality_thresholds: QualityThresholds | None = None,
        automatic_presets: bool = False,
    ) -> BatchPlan:
        if not sources or not presets:
            raise ValueError("At least one source and preset are required.")
        if video_count < 1 or len(schedule) != video_count:
            raise ValueError("Video count and schedule must match.")
        if videos_per_channel is not None:
            if videos_per_channel < 1 or not channels:
                raise ValueError("Videos per channel requires at least one selected channel.")
            if video_count != videos_per_channel * len(channels):
                raise ValueError("Videos per channel does not match the total video count.")
        preset_by_id = {preset.id: preset for preset in presets}
        if automatic_presets:
            if not channels:
                raise ValueError("Automatic preset selection requires a selected channel.")
            missing_defaults = [
                channel.display_name
                for channel in channels
                if not channel.default_preset_id or channel.default_preset_id not in preset_by_id
            ]
            if missing_defaults:
                raise ValueError("Set a valid default preset for: " + ", ".join(missing_defaults))
            incompatible_defaults = [
                channel.display_name
                for channel in channels
                if not self._compatible(preset_by_id[channel.default_preset_id], channel)
            ]
            if incompatible_defaults:
                raise ValueError(
                    "Default preset is incompatible with: " + ", ".join(incompatible_defaults)
                )
        elif channels:
            incompatible = [
                preset.name
                for preset in presets
                if not any(self._compatible(preset, channel) for channel in channels)
            ]
            if incompatible:
                raise ValueError(
                    f"No compatible channel exists for presets: {', '.join(incompatible)}"
                )
            unused_channels = [
                channel.display_name
                for channel in channels
                if not any(self._compatible(preset, channel) for preset in presets)
            ]
            if unused_channels:
                raise ValueError(
                    f"No compatible preset exists for channels: {', '.join(unused_channels)}"
                )
        batch_id = str(uuid4())
        source_cycle = cycle(sources)
        preset_cycle = cycle(presets)
        channel_cycle = cycle(channels) if channels else None
        platform_channel_offsets: dict[str, int] = {}
        channel_preset_offsets: dict[str, int] = {}
        channel_assignments = (
            [channel for _round in range(videos_per_channel) for channel in channels]
            if videos_per_channel is not None
            else None
        )
        items: list[PlannedBatchItem] = []
        for index in range(video_count):
            source = next(source_cycle)
            if automatic_presets:
                channel = (
                    channel_assignments[index]
                    if channel_assignments is not None
                    else next(channel_cycle)
                )
                preset = preset_by_id[channel.default_preset_id]
                if channel.default_design_profile_id:
                    if not self.design_profiles:
                        raise ValueError(
                            "Automatic design selection is unavailable in this application context."
                        )
                    preset = self.design_profiles.apply(
                        preset,
                        channel.default_design_profile_id,
                    )
            elif channel_assignments is not None:
                channel = channel_assignments[index]
                compatible_presets = [
                    preset for preset in presets if self._compatible(preset, channel)
                ]
                offset = channel_preset_offsets.get(channel.id, 0)
                preset = compatible_presets[offset % len(compatible_presets)]
                channel_preset_offsets[channel.id] = offset + 1
            else:
                preset = next(preset_cycle)
                compatible = [channel for channel in channels if self._compatible(preset, channel)]
                offset = platform_channel_offsets.get(preset.id, 0)
                channel = compatible[offset % len(compatible)] if compatible else None
                platform_channel_offsets[preset.id] = offset + 1
            project_id = str(uuid4())
            job = ProductionJob(
                project_id=project_id,
                preset_id=preset.id,
                design_profile_id=preset.style_profiles.design,
                channel_id=channel.id if channel else None,
                scheduled_at=schedule[index],
                log_messages=[f"Batch {batch_id} planned item {index + 1}."],
            )
            items.append(
                PlannedBatchItem(
                    project_id=project_id,
                    job=job,
                    source_profile=source,
                    preset=preset,
                    channel=channel,
                )
            )
        estimated_requests = video_count * (analyses_per_video + 2)
        return BatchPlan(
            id=batch_id,
            items=items,
            estimated_downloads=video_count * analyses_per_video,
            estimated_ai_requests=estimated_requests,
            estimated_ai_cost_usd=round(estimated_requests * estimated_cost_per_analysis, 4),
            quality_thresholds=(quality_thresholds or QualityThresholds()).model_copy(deep=True),
        )

    @staticmethod
    def _compatible(preset: Preset, channel: ChannelProfile) -> bool:
        return preset.platform == "generic" or preset.platform == channel.platform
