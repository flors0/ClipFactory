"""Range-based rich text styling independent of word indices."""

from __future__ import annotations

import re
from copy import deepcopy

from app.models.preset_models import RichTextDocument, RichTextSpan, TextStyle

_PLACEHOLDER = re.compile(r"\{([A-Za-z0-9_]+)\}")


def expand_placeholders(
    document: RichTextDocument, replacements: dict[str, object]
) -> RichTextDocument:
    """Expand dynamic fields while retaining styles on fixed and placeholder text."""
    source_styles = RichTextEditor.resolved_styles(document)
    output_text: list[str] = []
    output_styles: list[TextStyle] = []
    cursor = 0
    for match in _PLACEHOLDER.finditer(document.text):
        output_text.append(document.text[cursor : match.start()])
        output_styles.extend(deepcopy(source_styles[cursor : match.start()]))
        key = match.group(1)
        if key in replacements:
            replacement = str(replacements[key])
            inherited = (
                source_styles[match.start()]
                if match.start() < len(source_styles)
                else document.default_style
            )
            output_text.append(replacement)
            output_styles.extend(deepcopy(inherited) for _character in replacement)
        else:
            output_text.append(match.group(0))
            output_styles.extend(deepcopy(source_styles[match.start() : match.end()]))
        cursor = match.end()
    output_text.append(document.text[cursor:])
    output_styles.extend(deepcopy(source_styles[cursor:]))
    text = "".join(output_text)
    return RichTextEditor.from_character_styles(text, document.default_style, output_styles)


class RichTextEditor:
    @staticmethod
    def apply_style(
        document: RichTextDocument, start: int, end: int, style: TextStyle
    ) -> RichTextDocument:
        if start < 0 or end > len(document.text) or end <= start:
            raise ValueError("Selection range is outside the text document.")
        styles = RichTextEditor.resolved_styles(document)
        for index in range(start, end):
            styles[index] = deepcopy(style)
        return RichTextEditor.from_character_styles(document.text, document.default_style, styles)

    @staticmethod
    def replace_text(
        document: RichTextDocument, start: int, end: int, replacement: str
    ) -> RichTextDocument:
        if start < 0 or end > len(document.text) or end < start:
            raise ValueError("Replacement range is outside the text document.")
        styles = RichTextEditor.resolved_styles(document)
        if start < end and start < len(styles):
            inherited = styles[start]
        elif start > 0 and styles:
            inherited = styles[start - 1]
        else:
            inherited = document.default_style
        new_text = document.text[:start] + replacement + document.text[end:]
        new_styles = styles[:start] + [deepcopy(inherited) for _ in replacement] + styles[end:]
        return RichTextEditor.from_character_styles(new_text, document.default_style, new_styles)

    @staticmethod
    def resolved_styles(document: RichTextDocument) -> list[TextStyle]:
        styles = [deepcopy(document.default_style) for _ in document.text]
        for span in document.spans:
            for index in range(span.start, span.end):
                styles[index] = deepcopy(span.style)
        return styles

    @staticmethod
    def from_character_styles(
        text: str, default: TextStyle, styles: list[TextStyle]
    ) -> RichTextDocument:
        if len(text) != len(styles):
            raise ValueError("Text and character-style lengths must match.")
        spans: list[RichTextSpan] = []
        index = 0
        while index < len(text):
            style = styles[index]
            end = index + 1
            while end < len(text) and styles[end] == style:
                end += 1
            if style != default:
                spans.append(RichTextSpan(start=index, end=end, style=deepcopy(style)))
            index = end
        return RichTextDocument(text=text, default_style=deepcopy(default), spans=spans)

    @staticmethod
    def style_at(document: RichTextDocument, position: int) -> TextStyle:
        if position < 0 or position > len(document.text):
            raise ValueError("Text position is outside the document.")
        if not document.text:
            return deepcopy(document.default_style)
        index = min(position, len(document.text) - 1)
        return RichTextEditor.resolved_styles(document)[index]
