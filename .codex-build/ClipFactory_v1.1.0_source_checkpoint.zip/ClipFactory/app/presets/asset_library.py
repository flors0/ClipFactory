"""Scan and persist local transition, audio, font, image, and background assets."""

from __future__ import annotations

import hashlib
import json
import mimetypes
import subprocess
from datetime import UTC, datetime
from pathlib import Path

from pydantic import BaseModel, Field

from app.media.thumbnail_generator import ThumbnailGenerator
from app.storage.database import Database


class AssetMetadata(BaseModel):
    id: str
    asset_type: str
    file_path: str
    mime_type: str | None = None
    duration_seconds: float | None = None
    width: int | None = None
    height: int | None = None
    has_audio: bool = False
    tags: list[str] = Field(default_factory=list)
    thumbnail_path: str | None = None


class AssetLibrary:
    TYPES = {
        "transitions",
        "interstitials",
        "sounds",
        "music",
        "fonts",
        "images",
        "memes",
        "backgrounds",
        "subtitles",
    }

    def __init__(
        self,
        root: Path,
        database: Database,
        thumbnail_generator: ThumbnailGenerator,
        ffprobe_path: str = "ffprobe",
    ):
        self.root = root.resolve()
        self.database = database
        self.thumbnail_generator = thumbnail_generator
        self.ffprobe_path = ffprobe_path

    def scan(self) -> list[AssetMetadata]:
        results: list[AssetMetadata] = []
        for asset_type in sorted(self.TYPES):
            directory = self.root / asset_type
            directory.mkdir(parents=True, exist_ok=True)
            for path in sorted(item for item in directory.rglob("*") if item.is_file()):
                metadata = self._inspect(asset_type, path)
                self._save(metadata)
                results.append(metadata)
        known = {str(Path(item.file_path).resolve()) for item in results}
        for row in self.database.fetchall("SELECT id, file_path FROM assets"):
            if str(Path(row["file_path"]).resolve()) not in known:
                self.database.execute("DELETE FROM assets WHERE id = ?", (row["id"],))
        return results

    def list(self, asset_type: str | None = None) -> list[AssetMetadata]:
        if asset_type:
            rows = self.database.fetchall(
                "SELECT payload FROM assets WHERE asset_type = ? ORDER BY file_path", (asset_type,)
            )
        else:
            rows = self.database.fetchall(
                "SELECT payload FROM assets ORDER BY asset_type, file_path"
            )
        return [AssetMetadata.model_validate_json(row["payload"]) for row in rows]

    def path_map(self) -> dict[str, Path]:
        return {item.id: Path(item.file_path) for item in self.list()}

    def _inspect(self, asset_type: str, path: Path) -> AssetMetadata:
        resolved = path.resolve()
        identifier = hashlib.sha256(str(resolved).encode()).hexdigest()
        metadata = AssetMetadata(
            id=identifier,
            asset_type=asset_type,
            file_path=str(resolved),
            mime_type=mimetypes.guess_type(resolved.name)[0],
            tags=[part.lower() for part in resolved.stem.replace("_", "-").split("-") if part],
        )
        if asset_type in {
            "transitions",
            "interstitials",
            "sounds",
            "music",
            "images",
            "backgrounds",
            "memes",
            "subtitles",
        }:
            command = [
                self.ffprobe_path,
                "-v",
                "error",
                "-show_streams",
                "-show_format",
                "-of",
                "json",
                str(resolved),
            ]
            try:
                completed = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=60,
                )
            except (OSError, subprocess.TimeoutExpired):
                completed = None
            if completed and completed.returncode == 0:
                try:
                    data = json.loads(completed.stdout)
                except json.JSONDecodeError:
                    data = {}
                video = next(
                    (item for item in data.get("streams", []) if item.get("codec_type") == "video"),
                    None,
                )
                audio = next(
                    (item for item in data.get("streams", []) if item.get("codec_type") == "audio"),
                    None,
                )
                duration = data.get("format", {}).get("duration")
                metadata.duration_seconds = (
                    float(duration) if duration not in {None, "N/A"} else None
                )
                metadata.has_audio = audio is not None
                if video:
                    metadata.width = int(video.get("width", 0)) or None
                    metadata.height = int(video.get("height", 0)) or None
                    try:
                        metadata.thumbnail_path = str(
                            self.thumbnail_generator.generate(
                                resolved,
                                identifier,
                                at_seconds=0 if asset_type in {"images", "memes"} else 1.0,
                            )
                        )
                    except Exception:
                        metadata.thumbnail_path = None
        return metadata

    def _save(self, metadata: AssetMetadata) -> None:
        self.database.execute(
            "INSERT INTO assets(id, asset_type, file_path, payload, updated_at) VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET asset_type=excluded.asset_type, file_path=excluded.file_path, payload=excluded.payload, updated_at=excluded.updated_at",
            (
                metadata.id,
                metadata.asset_type,
                metadata.file_path,
                metadata.model_dump_json(),
                datetime.now(UTC).isoformat(),
            ),
        )
