"""Core/custom preset lifecycle and idempotent preset migrations."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from uuid import uuid4

from app.models.ai_models import AIFieldPermissions
from app.models.preset_models import (
    Color,
    ElementType,
    HeaderSettings,
    Preset,
    PresetLayer,
    PresetStyleProfiles,
    RankingSettings,
    Rect,
    RichTextDocument,
    TextStyle,
    TransitionSettings,
)
from app.presets.design_profile_manager import (
    DESIGN_CLEAN_BANNER_ID,
    DESIGN_COMPILATION_ID,
)
from app.presets.preset_validator import PresetValidator
from app.presets.style_profile_manager import (
    CAPTION_CLEAN_ID,
    HEADER_CLEAN_ID,
    RANKING_CLASSIC_ID,
    StyleProfileManager,
)
from app.storage.repositories.preset_repository import PresetRepository

CORE_RANKING_ID = "core-ranking"
CORE_COMPILATION_ID = "core-tiktok-core-compilation"
LEGACY_CORE_IDS = {
    "core-youtube-ranking",
    "core-tiktok-ranking",
    "core-youtube-meme",
    "core-tiktok-meme",
    "core-compilation",
}


class PresetManager:
    def __init__(
        self,
        repository: PresetRepository,
        style_profile_manager: StyleProfileManager | None = None,
    ):
        self.repository = repository
        self.style_profile_manager = style_profile_manager
        self.validator = PresetValidator()

    def ensure_core_presets(self) -> list[Preset]:
        self._migrate_v1_0_5_presets()
        self._migrate_v1_0_6_presets()
        self._migrate_v1_0_7_presets()
        existing = {preset.id: preset for preset in self.repository.list()}
        created: list[Preset] = []
        defaults = {preset.id: preset for preset in core_presets()}
        for preset in defaults.values():
            if preset.id not in existing:
                self.repository.save(preset)
                created.append(preset)
        for preset in self.repository.list():
            if preset.core and preset.id not in defaults:
                preset.core = False
                self.repository.save(preset)
        if self.style_profile_manager:
            for preset in self.repository.list():
                before = preset.style_profiles.model_dump(mode="json")
                self.style_profile_manager.reconcile_preset(preset)
                if preset.style_profiles.model_dump(mode="json") != before:
                    self.repository.save(preset)
        return created

    def duplicate(self, identifier: str, name: str | None = None) -> Preset:
        source = self._required(identifier)
        copy = source.model_copy(deep=True)
        copy.id = str(uuid4())
        copy.core = False
        copy.name = name or f"{source.name} Copy"
        return self.repository.save(copy)

    def rename(self, identifier: str, name: str) -> Preset:
        preset = self._required(identifier)
        if preset.core:
            raise ValueError(
                "Core presets keep their stable display identity; edit their settings instead."
            )
        preset.name = name
        return self.repository.save(preset)

    def delete(self, identifier: str) -> bool:
        return self.repository.delete(identifier)

    def save(self, preset: Preset) -> Preset:
        existing = self.repository.get(preset.id)
        if (
            existing
            and existing.core
            and preset.id
            not in {
                CORE_RANKING_ID,
                CORE_COMPILATION_ID,
            }
        ):
            raise ValueError("This legacy core preset must be migrated before it can be edited.")
        if existing and existing.core:
            preset.core = True
            preset.id = existing.id
            preset.name = existing.name
            preset.created_at = existing.created_at
        errors = self.validator.validate(preset)
        if errors:
            raise ValueError("; ".join(errors))
        if self.style_profile_manager:
            self.style_profile_manager.reconcile_preset(preset)
        return self.repository.save(preset)

    def reset_core(self, identifier: str) -> Preset:
        existing = self._required(identifier)
        if not existing.core:
            raise ValueError("Only a core preset can be reset to its shipped state.")
        shipped = next(
            (preset for preset in core_presets() if preset.id == identifier),
            None,
        )
        if shipped is None:
            raise ValueError("The selected core preset has no v1.1.0 shipped state.")
        shipped.created_at = existing.created_at
        return self.repository.save(shipped)

    def export_file(self, identifier: str, destination: Path) -> Path:
        preset = self._required(identifier)
        destination = destination.expanduser().resolve()
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        temporary.write_text(preset.model_dump_json(indent=2), encoding="utf-8")
        os.replace(temporary, destination)
        return destination

    def import_file(self, source: Path) -> Preset:
        raw = json.loads(source.expanduser().resolve().read_text(encoding="utf-8"))
        preset = Preset.model_validate(raw)
        preset.id = str(uuid4())
        preset.core = False
        preset.name = f"{preset.name} Imported"
        preset.ranking.order = "ascending"
        preset.transition.placement = "between_clips"
        return self.save(preset)

    def _migrate_v1_0_5_presets(self) -> None:
        existing = {preset.id: preset for preset in self.repository.list()}
        legacy_defaults = {preset.id: preset for preset in legacy_core_presets()}
        remap: dict[str, str] = {}
        for identifier in sorted(LEGACY_CORE_IDS):
            preset = existing.get(identifier)
            if preset is None:
                continue
            default = legacy_defaults[identifier]
            if self._comparable_payload(preset) != self._comparable_payload(default):
                migrated = preset.model_copy(deep=True)
                digest = hashlib.sha256(
                    json.dumps(
                        self._comparable_payload(preset),
                        sort_keys=True,
                        separators=(",", ":"),
                    ).encode("utf-8")
                ).hexdigest()[:12]
                migrated.id = f"migrated-{identifier}-{digest}"
                migrated.core = False
                migrated.name = f"{preset.name} (migrated v1.0.5 custom)"
                migrated.ranking.order = "ascending"
                migrated.transition.placement = "between_clips"
                if self.repository.get(migrated.id) is None:
                    self.repository.save(migrated)
                remap[identifier] = migrated.id
            elif "ranking" in identifier:
                remap[identifier] = CORE_RANKING_ID
            else:
                remap[identifier] = CORE_COMPILATION_ID
        if remap:
            self._remap_references(remap)
        for identifier in LEGACY_CORE_IDS:
            self.repository.delete_force(identifier)

        for preset in self.repository.list():
            changed = False
            if preset.ranking.order != "ascending":
                preset.ranking.order = "ascending"
                changed = True
            if preset.transition.placement != "between_clips":
                preset.transition.placement = "between_clips"
                changed = True
            if changed:
                self.repository.save(preset)

    def _migrate_v1_0_6_presets(self) -> None:
        """Remove only the shipped v1.0.6 caption box while preserving other styling."""
        v1_0_6_box = Color(red=0, green=0, blue=0, alpha=120)
        for preset in self.repository.list():
            if not preset.ranking.enabled:
                continue
            caption_layer = next(
                (
                    layer
                    for layer in preset.layers
                    if layer.element_type == ElementType.DYNAMIC_CAPTION
                ),
                None,
            )
            if caption_layer is None or caption_layer.background_color != v1_0_6_box:
                continue
            caption_layer.background_color = Color(red=0, green=0, blue=0, alpha=0)
            self.repository.save(preset)

    def _migrate_v1_0_7_presets(self) -> None:
        """Upgrade only untouched v1.0.7 core typography to the larger v1.0.8 defaults."""
        preset = self.repository.get(CORE_RANKING_ID)
        if preset is None:
            return
        changed = False
        shipped_styles = {
            "ranking_numbers": (
                TextStyle(font_size=58, bold=True),
                TextStyle(
                    font_size=88,
                    minimum_font_size=42,
                    bold=True,
                    foreground=Color(),
                    outline=Color(red=0, green=0, blue=0),
                    outline_width=5,
                    shadow_enabled=True,
                    shadow_color=Color(red=0, green=0, blue=0, alpha=190),
                    shadow_distance=3,
                ),
            ),
            "dynamic_caption": (
                TextStyle(
                    font_size=48,
                    minimum_font_size=24,
                    bold=True,
                    alignment="left",
                ),
                TextStyle(
                    font_size=60,
                    minimum_font_size=30,
                    bold=True,
                    foreground=Color(),
                    outline=Color(red=0, green=0, blue=0),
                    outline_width=4,
                    shadow_enabled=True,
                    shadow_distance=2,
                    alignment="left",
                ),
            ),
            "header": (
                TextStyle(font_size=72, bold=True),
                TextStyle(
                    font_size=78,
                    minimum_font_size=36,
                    bold=True,
                    foreground=Color(),
                    outline=Color(red=0, green=0, blue=0),
                    outline_width=3,
                    shadow_enabled=True,
                    shadow_distance=2,
                ),
            ),
        }
        for layer_id, (old_style, new_style) in shipped_styles.items():
            layer = next((value for value in preset.layers if value.id == layer_id), None)
            if layer and layer.rich_text and layer.rich_text.default_style == old_style:
                layer.rich_text.default_style = new_style
                changed = True
        default_ranking = RankingSettings()
        if (
            preset.ranking.active_color == default_ranking.active_color
            and preset.ranking.inactive_color == default_ranking.inactive_color
            and preset.ranking.active_opacity == default_ranking.active_opacity
            and preset.ranking.inactive_opacity == 0.45
            and not preset.ranking.item_overrides
        ):
            preset.ranking.inactive_opacity = 0.48
            changed = True
        if changed:
            self.repository.save(preset)

    def _remap_references(self, remap: dict[str, str]) -> None:
        database = self.repository.database
        for table in (
            "projects",
            "production_jobs",
            "review_items",
            "channel_profiles",
        ):
            for row in database.fetchall(f"SELECT id, payload FROM {table}"):
                payload = json.loads(row["payload"])
                if self._replace_preset_references(payload, remap):
                    database.execute(
                        f"UPDATE {table} SET payload = ? WHERE id = ?",
                        (
                            json.dumps(
                                payload,
                                ensure_ascii=False,
                                separators=(",", ":"),
                            ),
                            row["id"],
                        ),
                    )

    @classmethod
    def _replace_preset_references(
        cls,
        value: object,
        remap: dict[str, str],
    ) -> bool:
        changed = False
        if isinstance(value, dict):
            for key, child in list(value.items()):
                if (
                    key in {"preset_id", "default_preset_id"}
                    and isinstance(child, str)
                    and child in remap
                ):
                    value[key] = remap[child]
                    changed = True
                else:
                    changed = cls._replace_preset_references(child, remap) or changed
        elif isinstance(value, list):
            for child in value:
                changed = cls._replace_preset_references(child, remap) or changed
        return changed

    @staticmethod
    def _comparable_payload(preset: Preset) -> dict[str, object]:
        return preset.model_dump(
            mode="json",
            exclude={"created_at", "updated_at"},
        )

    def _required(self, identifier: str) -> Preset:
        preset = self.repository.get(identifier)
        if not preset:
            raise KeyError(f"Preset does not exist: {identifier}")
        return preset


def _base_layers(
    *,
    header_text: str,
    ranking: bool,
    compilation: bool = False,
) -> list[PresetLayer]:
    layers = [
        PresetLayer(
            id="background",
            name="Background",
            element_type=ElementType.BACKGROUND,
            bounds=Rect(x=0, y=0, width=1, height=1),
            z_index=0,
            locked=True,
            background_color=Color(red=10, green=10, blue=14),
        ),
        PresetLayer(
            id="video",
            name="Video",
            element_type=ElementType.VIDEO,
            bounds=Rect(
                x=0,
                y=0 if compilation else 0.18,
                width=1,
                height=1 if compilation else 0.82,
            ),
            z_index=10,
        ),
    ]
    if compilation:
        return layers
    layers.extend(
        [
            PresetLayer(
                id="header",
                name="AI Header",
                element_type=ElementType.HEADER,
                bounds=Rect(x=0.05, y=0.025, width=0.90, height=0.13),
                z_index=20,
                rich_text=RichTextDocument(
                    text=header_text,
                    default_style=TextStyle(
                        font_size=78,
                        minimum_font_size=36,
                        bold=True,
                        outline_width=3,
                        shadow_distance=2,
                    ),
                ),
            ),
            PresetLayer(
                id="ranking_numbers",
                name="Ranking Numbers",
                element_type=ElementType.RANKING_NUMBER,
                bounds=Rect(x=0.035, y=0.245, width=0.12, height=0.54),
                z_index=30,
                hidden=not ranking,
                rich_text=RichTextDocument(
                    text="1\n2\n3\n4\n5",
                    default_style=TextStyle(
                        font_size=88,
                        minimum_font_size=42,
                        bold=True,
                        outline_width=5,
                        shadow_color=Color(red=0, green=0, blue=0, alpha=190),
                        shadow_distance=3,
                    ),
                ),
            ),
            PresetLayer(
                id="dynamic_caption",
                name="Ranking Captions",
                element_type=ElementType.DYNAMIC_CAPTION,
                bounds=Rect(x=0.16, y=0.245, width=0.74, height=0.54),
                z_index=40,
                hidden=not ranking,
                rich_text=RichTextDocument(
                    text="{caption}",
                    default_style=TextStyle(
                        font_size=60,
                        minimum_font_size=30,
                        bold=True,
                        outline_width=4,
                        shadow_distance=2,
                        alignment="left",
                    ),
                ),
                background_color=Color(red=0, green=0, blue=0, alpha=0),
            ),
            PresetLayer(
                id="subtitles",
                name="Subtitles",
                element_type=ElementType.SUBTITLE,
                bounds=Rect(x=0.10, y=0.82, width=0.80, height=0.10),
                z_index=50,
                hidden=True,
                rich_text=RichTextDocument(
                    text="{subtitle}",
                    default_style=TextStyle(font_size=52, bold=True),
                ),
            ),
        ]
    )
    return layers


def core_presets() -> list[Preset]:
    return [
        Preset(
            id=CORE_RANKING_ID,
            name="Ranking",
            core=True,
            platform="generic",
            video_format="ranking",
            ranking=RankingSettings(
                enabled=True,
                count=5,
                order="ascending",
                playback_order="worst_to_best",
                horizontal_alignment="center",
                vertical_alignment="center",
                numbers_visible_from_start=True,
                captions_persist_after_reveal=True,
                spacing=0.012,
            ),
            transition=TransitionSettings(
                enabled=False,
                type="fixed_asset",
                duration_seconds=0.3,
                placement="between_clips",
            ),
            style_profiles=PresetStyleProfiles(
                design=DESIGN_CLEAN_BANNER_ID,
                ranking_numbers=RANKING_CLASSIC_ID,
                captions=CAPTION_CLEAN_ID,
                header=HEADER_CLEAN_ID,
            ),
            layers=_base_layers(header_text="{header}", ranking=True),
        ),
        Preset(
            id=CORE_COMPILATION_ID,
            name="TikTok Core Compilation",
            core=True,
            platform="generic",
            video_format="compilation",
            header=HeaderSettings(enabled=False),
            ranking=RankingSettings(enabled=False, order="ascending"),
            transition=TransitionSettings(
                enabled=False,
                type="fixed_asset",
                duration_seconds=0.3,
                placement="between_clips",
            ),
            subtitles_enabled=False,
            style_profiles=PresetStyleProfiles(design=DESIGN_COMPILATION_ID),
            ai_permissions=AIFieldPermissions(
                allow_header_text=False,
                allow_ranking_captions=False,
                allow_clip_reordering=True,
                allow_trim_suggestions=True,
                allow_upload_title=True,
                allow_upload_description=True,
                allow_upload_tags=True,
            ),
            layers=_base_layers(
                header_text="",
                ranking=False,
                compilation=True,
            ),
        ),
    ]


def _legacy_layers(*, meme: bool = False, compilation: bool = False) -> list[PresetLayer]:
    white = TextStyle(font_size=64, bold=True, foreground=Color(), outline_width=3)
    return [
        PresetLayer(
            id="background",
            name="Background",
            element_type=ElementType.BACKGROUND,
            bounds=Rect(x=0, y=0, width=1, height=1),
            z_index=0,
            locked=True,
            background_color=Color(red=10, green=10, blue=14),
        ),
        PresetLayer(
            id="video",
            name="Video",
            element_type=ElementType.VIDEO,
            bounds=Rect(x=0, y=0.18, width=1, height=0.82),
            z_index=10,
        ),
        PresetLayer(
            id="header",
            name="Header",
            element_type=ElementType.HEADER,
            bounds=Rect(x=0.05, y=0.025, width=0.90, height=0.13),
            z_index=20,
            rich_text=RichTextDocument(
                text="Top 5 {theme}",
                default_style=TextStyle(font_size=72, bold=True),
            ),
        ),
        PresetLayer(
            id="ranking_numbers",
            name="Ranking Numbers",
            element_type=ElementType.RANKING_NUMBER,
            bounds=Rect(x=0.025, y=0.23, width=0.14, height=0.58),
            z_index=30,
            hidden=meme or compilation,
            rich_text=RichTextDocument(
                text="5  4  3  2  1",
                default_style=TextStyle(font_size=58, bold=True),
            ),
        ),
        PresetLayer(
            id="dynamic_caption",
            name="Dynamic Caption",
            element_type=ElementType.DYNAMIC_CAPTION,
            bounds=Rect(x=0.12, y=0.78, width=0.76, height=0.13),
            z_index=40,
            hidden=compilation,
            rich_text=RichTextDocument(text="{caption}", default_style=white),
            background_color=Color(red=0, green=0, blue=0, alpha=165),
        ),
        PresetLayer(
            id="subtitles",
            name="Subtitles",
            element_type=ElementType.SUBTITLE,
            bounds=Rect(x=0.10, y=0.62, width=0.80, height=0.12),
            z_index=50,
            hidden=True,
            rich_text=RichTextDocument(
                text="{subtitle}",
                default_style=TextStyle(font_size=52, bold=True),
            ),
        ),
    ]


def legacy_core_presets() -> list[Preset]:
    return [
        Preset(
            id="core-youtube-ranking",
            name="YouTube Ranking",
            core=True,
            platform="youtube",
            video_format="ranking",
            ranking=RankingSettings(order="descending"),
            layers=_legacy_layers(),
        ),
        Preset(
            id="core-tiktok-ranking",
            name="TikTok Ranking",
            core=True,
            platform="tiktok",
            video_format="ranking",
            ranking=RankingSettings(order="descending"),
            layers=_legacy_layers(),
        ),
        Preset(
            id="core-youtube-meme",
            name="YouTube Meme",
            core=True,
            platform="youtube",
            video_format="meme",
            ranking=RankingSettings(enabled=False, order="descending"),
            layers=_legacy_layers(meme=True),
        ),
        Preset(
            id="core-tiktok-meme",
            name="TikTok Meme",
            core=True,
            platform="tiktok",
            video_format="meme",
            ranking=RankingSettings(enabled=False, order="descending"),
            layers=_legacy_layers(meme=True),
        ),
        Preset(
            id="core-compilation",
            name="Compilation",
            core=True,
            platform="generic",
            video_format="compilation",
            ranking=RankingSettings(enabled=False, order="descending"),
            layers=_legacy_layers(compilation=True),
        ),
    ]
