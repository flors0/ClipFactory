"""Reusable ranking-number, caption, and header style profiles."""

from __future__ import annotations

from copy import deepcopy
from uuid import uuid4

from app.models.preset_models import (
    Color,
    ElementType,
    Preset,
    RankingItemOverride,
    TextStyle,
)
from app.models.style_models import (
    HeaderStyleValues,
    RankingStyleValues,
    StyleProfile,
    StyleProfileKind,
)
from app.storage.repositories.style_profile_repository import StyleProfileRepository

RANKING_CLASSIC_ID = "core-style-ranking-clipfactory-classic"
RANKING_MULTICOLOR_ID = "core-style-ranking-classic-multicolor"
RANKING_PODIUM_ID = "core-style-ranking-podium-pop"
RANKING_VIOLET_ID = "core-style-ranking-violet-neon"
RANKING_GOLD_ID = "core-style-ranking-golden-glow"
RANKING_CYAN_ID = "core-style-ranking-electric-cyan"
RANKING_SUNSET_ID = "core-style-ranking-sunset-heat"
RANKING_SOCIAL_ID = "core-style-ranking-creator-stack"

CAPTION_CLEAN_ID = "core-style-caption-clean-reaction"
CAPTION_COMPACT_ID = "core-style-caption-compact-bold"
CAPTION_SOFT_ID = "core-style-caption-soft-shadow"
CAPTION_NEON_ID = "core-style-caption-neon-accent"
CAPTION_SOCIAL_ID = "core-style-caption-creator-stack"

HEADER_CLEAN_ID = "core-style-header-clean-banner"
HEADER_MINIMAL_ID = "core-style-header-minimal-floating"
HEADER_EDITORIAL_ID = "core-style-header-bold-editorial"
HEADER_NEON_ID = "core-style-header-neon-title"
HEADER_CREATOR_ID = "core-style-header-creator-accent"


class StyleProfileManager:
    def __init__(self, repository: StyleProfileRepository):
        self.repository = repository

    def ensure_core_profiles(self) -> list[StyleProfile]:
        existing = {profile.id: profile for profile in self.repository.list()}
        defaults = {profile.id: profile for profile in core_style_profiles()}
        created: list[StyleProfile] = []
        for profile in defaults.values():
            if profile.id not in existing:
                self.repository.save(profile)
                created.append(profile)
        return created

    def list(self, kind: StyleProfileKind | None = None) -> list[StyleProfile]:
        return self.repository.list(kind)

    def get(self, identifier: str) -> StyleProfile | None:
        return self.repository.get(identifier)

    def apply(self, preset: Preset, identifier: str) -> Preset:
        profile = self._required(identifier)
        target = preset.model_copy(deep=True)
        layer = self._layer(target, profile.kind)
        if layer.rich_text is None:
            raise ValueError(f"The {profile.kind.value} layer has no text-style contract.")
        layer.rich_text.default_style = profile.text_style.model_copy(deep=True)
        layer.rich_text.spans = []
        layer.background_color = profile.layer_background.model_copy(deep=True)
        layer.opacity = profile.layer_opacity
        if profile.kind == StyleProfileKind.RANKING_NUMBERS:
            assert profile.ranking is not None
            values = profile.ranking
            target.ranking.active_color = values.active_color.model_copy(deep=True)
            target.ranking.inactive_color = values.inactive_color.model_copy(deep=True)
            target.ranking.active_opacity = values.active_opacity
            target.ranking.inactive_opacity = values.inactive_opacity
            target.ranking.item_overrides = self._merge_ranking_overrides(
                values.item_overrides,
                target.ranking.item_overrides,
            )
            target.style_profiles.ranking_numbers = profile.id
        elif profile.kind == StyleProfileKind.CAPTIONS:
            target.style_profiles.captions = profile.id
        else:
            assert profile.header is not None
            values = profile.header
            target.header.background = values.background.model_copy(deep=True)
            target.header.border_color = values.border_color.model_copy(deep=True)
            target.header.border_width = values.border_width
            target.header.height_ratio = values.height_ratio
            target.header.padding_ratio = values.padding_ratio
            target.header.accent_color = (
                values.accent_color.model_copy(deep=True) if values.accent_color else None
            )
            target.header.accent_last_words = values.accent_last_words
            target.style_profiles.header = profile.id
        return target

    def create_from_preset(
        self,
        preset: Preset,
        kind: StyleProfileKind,
        name: str,
    ) -> StyleProfile:
        clean_name = name.strip()
        self._validate_name(clean_name, kind)
        profile = self._capture(preset, kind, clean_name)
        profile.id = str(uuid4())
        profile.core = False
        return self.repository.save(profile)

    def update_from_preset(self, identifier: str, preset: Preset) -> StyleProfile:
        existing = self._required(identifier)
        replacement = self._capture(preset, existing.kind, existing.name)
        replacement.id = existing.id
        replacement.core = existing.core
        replacement.created_at = existing.created_at
        return self.repository.save(replacement)

    def duplicate(self, identifier: str, name: str | None = None) -> StyleProfile:
        source = self._required(identifier)
        clean_name = (name or f"{source.name} Copy").strip()
        self._validate_name(clean_name, source.kind)
        duplicate = source.model_copy(deep=True)
        duplicate.id = str(uuid4())
        duplicate.name = clean_name
        duplicate.core = False
        return self.repository.save(duplicate)

    def rename(self, identifier: str, name: str) -> StyleProfile:
        profile = self._required(identifier)
        if profile.core:
            raise ValueError("Built-in style profile names stay stable.")
        clean_name = name.strip()
        self._validate_name(clean_name, profile.kind, exclude_id=profile.id)
        profile.name = clean_name
        return self.repository.save(profile)

    def delete(self, identifier: str) -> bool:
        return self.repository.delete(identifier)

    def reset_core(self, identifier: str) -> StyleProfile:
        existing = self._required(identifier)
        if not existing.core:
            raise ValueError("Only built-in style profiles can be reset.")
        shipped = next(
            (profile for profile in core_style_profiles() if profile.id == identifier),
            None,
        )
        if shipped is None:
            raise ValueError("The selected profile has no ClipFactory v1.1.0 default.")
        shipped.created_at = existing.created_at
        return self.repository.save(shipped)

    def reconcile_preset(self, preset: Preset) -> Preset:
        for kind, field_name in (
            (StyleProfileKind.RANKING_NUMBERS, "ranking_numbers"),
            (StyleProfileKind.CAPTIONS, "captions"),
            (StyleProfileKind.HEADER, "header"),
        ):
            if not self._has_layer(preset, kind):
                setattr(preset.style_profiles, field_name, None)
                continue
            current_id = getattr(preset.style_profiles, field_name)
            current = self.repository.get(current_id) if current_id else None
            if current and current.kind == kind and self.matches(preset, current):
                continue
            match = next(
                (
                    profile
                    for profile in self.repository.list(kind)
                    if self.matches(preset, profile)
                ),
                None,
            )
            setattr(preset.style_profiles, field_name, match.id if match else None)
        return preset

    def matches(self, preset: Preset, profile: StyleProfile) -> bool:
        captured = self._capture(preset, profile.kind, profile.name)
        return self._style_payload(captured) == self._style_payload(profile)

    def matching_profile(
        self,
        preset: Preset,
        kind: StyleProfileKind,
    ) -> StyleProfile | None:
        return next(
            (profile for profile in self.repository.list(kind) if self.matches(preset, profile)),
            None,
        )

    @staticmethod
    def _style_payload(profile: StyleProfile) -> dict[str, object]:
        return profile.model_dump(
            mode="json",
            exclude={"id", "name", "core", "created_at", "updated_at"},
        )

    @staticmethod
    def _merge_ranking_overrides(
        profile_values: dict[int, RankingItemOverride],
        current_values: dict[int, RankingItemOverride],
    ) -> dict[int, RankingItemOverride]:
        merged: dict[int, RankingItemOverride] = {}
        for rank in sorted(set(profile_values) | set(current_values)):
            profile_override = profile_values.get(rank)
            current_override = current_values.get(rank)
            value = (
                profile_override.model_copy(deep=True)
                if profile_override
                else RankingItemOverride()
            )
            if current_override and current_override.caption_style:
                value.caption_style = current_override.caption_style.model_copy(deep=True)
            if any(
                (
                    value.active_color,
                    value.inactive_color,
                    value.active_opacity is not None,
                    value.inactive_opacity is not None,
                    value.caption_style,
                )
            ):
                merged[rank] = value
        return merged

    def _capture(
        self,
        preset: Preset,
        kind: StyleProfileKind,
        name: str,
    ) -> StyleProfile:
        layer = self._layer(preset, kind)
        if layer.rich_text is None:
            raise ValueError(f"The {kind.value} layer has no text-style contract.")
        ranking = None
        header = None
        if kind == StyleProfileKind.RANKING_NUMBERS:
            ranking = RankingStyleValues(
                active_color=preset.ranking.active_color.model_copy(deep=True),
                inactive_color=preset.ranking.inactive_color.model_copy(deep=True),
                active_opacity=preset.ranking.active_opacity,
                inactive_opacity=preset.ranking.inactive_opacity,
                item_overrides={
                    rank: RankingItemOverride(
                        active_color=override.active_color.model_copy(deep=True)
                        if override.active_color
                        else None,
                        inactive_color=override.inactive_color.model_copy(deep=True)
                        if override.inactive_color
                        else None,
                        active_opacity=override.active_opacity,
                        inactive_opacity=override.inactive_opacity,
                    )
                    for rank, override in preset.ranking.item_overrides.items()
                    if any(
                        (
                            override.active_color,
                            override.inactive_color,
                            override.active_opacity is not None,
                            override.inactive_opacity is not None,
                        )
                    )
                },
            )
        elif kind == StyleProfileKind.HEADER:
            header = HeaderStyleValues(
                background=preset.header.background.model_copy(deep=True),
                border_color=preset.header.border_color.model_copy(deep=True),
                border_width=preset.header.border_width,
                height_ratio=preset.header.height_ratio,
                padding_ratio=preset.header.padding_ratio,
                accent_color=preset.header.accent_color.model_copy(deep=True)
                if preset.header.accent_color
                else None,
                accent_last_words=preset.header.accent_last_words,
            )
        return StyleProfile(
            name=name,
            kind=kind,
            text_style=layer.rich_text.default_style.model_copy(deep=True),
            layer_background=layer.background_color.model_copy(deep=True),
            layer_opacity=layer.opacity,
            ranking=ranking,
            header=header,
        )

    @staticmethod
    def _layer(preset: Preset, kind: StyleProfileKind):
        element_type = {
            StyleProfileKind.RANKING_NUMBERS: ElementType.RANKING_NUMBER,
            StyleProfileKind.CAPTIONS: ElementType.DYNAMIC_CAPTION,
            StyleProfileKind.HEADER: ElementType.HEADER,
        }[kind]
        layer = next(
            (
                value
                for value in preset.layers
                if value.element_type == element_type and not value.hidden
            ),
            None,
        )
        if layer is None:
            raise ValueError(f"Preset has no visible {kind.value} layer.")
        return layer

    @staticmethod
    def _has_layer(preset: Preset, kind: StyleProfileKind) -> bool:
        element_type = {
            StyleProfileKind.RANKING_NUMBERS: ElementType.RANKING_NUMBER,
            StyleProfileKind.CAPTIONS: ElementType.DYNAMIC_CAPTION,
            StyleProfileKind.HEADER: ElementType.HEADER,
        }[kind]
        return any(
            value.element_type == element_type and not value.hidden for value in preset.layers
        )

    def _required(self, identifier: str) -> StyleProfile:
        profile = self.repository.get(identifier)
        if profile is None:
            raise KeyError(f"Style profile does not exist: {identifier}")
        return profile

    def _validate_name(
        self,
        name: str,
        kind: StyleProfileKind,
        *,
        exclude_id: str | None = None,
    ) -> None:
        if not name:
            raise ValueError("Style profile name cannot be empty.")
        duplicate = next(
            (
                profile
                for profile in self.repository.list(kind)
                if profile.id != exclude_id and profile.name.casefold() == name.casefold()
            ),
            None,
        )
        if duplicate:
            raise ValueError(f"A {kind.value} style profile named '{name}' already exists.")


def _color(value: str, alpha: int | None = None) -> Color:
    result = Color.from_hex(value)
    if alpha is not None:
        result.alpha = alpha
    return result


def _rank_override(
    color: str,
    *,
    inactive_alpha: int = 255,
) -> RankingItemOverride:
    return RankingItemOverride(
        active_color=_color(color),
        inactive_color=_color(color, inactive_alpha),
    )


def _ranking_text(
    *,
    size: float = 92,
    foreground: str = "#FFFFFF",
    outline: str = "#000000",
    outline_width: float = 6,
    glow: str | None = None,
    glow_radius: float = 0,
    glow_intensity: float = 0.65,
) -> TextStyle:
    return TextStyle(
        font_size=size,
        minimum_font_size=42,
        bold=True,
        foreground=_color(foreground),
        outline=_color(outline),
        outline_width=outline_width,
        shadow_enabled=True,
        shadow_color=_color("#000000", 190),
        shadow_distance=3,
        glow_enabled=glow is not None,
        glow_color=_color(glow) if glow else None,
        glow_radius=glow_radius,
        glow_intensity=glow_intensity,
    )


def core_style_profiles() -> list[StyleProfile]:
    transparent = _color("#000000", 0)
    multicolor = {
        1: _rank_override("#FF4057"),
        2: _rank_override("#FFD43B"),
        3: _rank_override("#24E07A"),
        4: _rank_override("#2C9CFF"),
        5: _rank_override("#B64CFF"),
    }
    podium = {
        1: _rank_override("#FF4BB8"),
        2: _rank_override("#9B5CFF"),
        3: _rank_override("#35D9FF"),
        4: _rank_override("#F5F5F5"),
        5: _rank_override("#F5F5F5"),
    }
    sunset = {
        1: _rank_override("#FF3B4D"),
        2: _rank_override("#FF7A28"),
        3: _rank_override("#FFD43B"),
        4: _rank_override("#FF4FA3"),
        5: _rank_override("#8E5CFF"),
    }
    return [
        StyleProfile(
            id=RANKING_CLASSIC_ID,
            name="ClipFactory Classic",
            kind=StyleProfileKind.RANKING_NUMBERS,
            core=True,
            text_style=_ranking_text(size=88, outline_width=5),
            layer_background=transparent,
            ranking=RankingStyleValues(
                active_color=_color("#FF5050"),
                inactive_color=_color("#FFFFFF"),
                active_opacity=1,
                inactive_opacity=0.48,
            ),
        ),
        StyleProfile(
            id=RANKING_MULTICOLOR_ID,
            name="Classic Multicolor",
            kind=StyleProfileKind.RANKING_NUMBERS,
            core=True,
            text_style=_ranking_text(size=92),
            layer_background=transparent,
            ranking=RankingStyleValues(
                active_color=_color("#FFFFFF"),
                inactive_color=_color("#FFFFFF"),
                active_opacity=1,
                inactive_opacity=0.58,
                item_overrides=deepcopy(multicolor),
            ),
        ),
        StyleProfile(
            id=RANKING_PODIUM_ID,
            name="Podium Pop",
            kind=StyleProfileKind.RANKING_NUMBERS,
            core=True,
            text_style=_ranking_text(
                size=92,
                outline="#160F23",
                outline_width=5,
                glow=None,
            ),
            layer_background=transparent,
            ranking=RankingStyleValues(
                active_color=_color("#FFFFFF"),
                inactive_color=_color("#FFFFFF"),
                active_opacity=1,
                inactive_opacity=0.62,
                item_overrides=deepcopy(podium),
            ),
        ),
        StyleProfile(
            id=RANKING_VIOLET_ID,
            name="Violet Neon",
            kind=StyleProfileKind.RANKING_NUMBERS,
            core=True,
            text_style=_ranking_text(
                size=94,
                foreground="#FFFFFF",
                outline="#6D24E8",
                outline_width=7,
                glow="#9C43FF",
                glow_radius=12,
                glow_intensity=0.72,
            ),
            layer_background=transparent,
            ranking=RankingStyleValues(
                active_color=_color("#DB6CFF"),
                inactive_color=_color("#FFFFFF"),
                active_opacity=1,
                inactive_opacity=0.78,
            ),
        ),
        StyleProfile(
            id=RANKING_GOLD_ID,
            name="Golden Glow",
            kind=StyleProfileKind.RANKING_NUMBERS,
            core=True,
            text_style=_ranking_text(
                size=94,
                foreground="#FFE16A",
                outline="#724500",
                outline_width=7,
                glow="#FFB800",
                glow_radius=14,
                glow_intensity=0.78,
            ),
            layer_background=transparent,
            ranking=RankingStyleValues(
                active_color=_color("#FFF09A"),
                inactive_color=_color("#FFC928"),
                active_opacity=1,
                inactive_opacity=0.72,
            ),
        ),
        StyleProfile(
            id=RANKING_CYAN_ID,
            name="Electric Cyan",
            kind=StyleProfileKind.RANKING_NUMBERS,
            core=True,
            text_style=_ranking_text(
                size=92,
                foreground="#DFFFFF",
                outline="#003847",
                outline_width=6,
                glow="#00E7FF",
                glow_radius=10,
                glow_intensity=0.7,
            ),
            layer_background=transparent,
            ranking=RankingStyleValues(
                active_color=_color("#FFFFFF"),
                inactive_color=_color("#39E9FF"),
                active_opacity=1,
                inactive_opacity=0.7,
            ),
        ),
        StyleProfile(
            id=RANKING_SUNSET_ID,
            name="Sunset Heat",
            kind=StyleProfileKind.RANKING_NUMBERS,
            core=True,
            text_style=_ranking_text(
                size=92,
                outline="#2A0C12",
                outline_width=6,
            ),
            layer_background=transparent,
            ranking=RankingStyleValues(
                active_color=_color("#FFFFFF"),
                inactive_color=_color("#FFFFFF"),
                active_opacity=1,
                inactive_opacity=0.58,
                item_overrides=deepcopy(sunset),
            ),
        ),
        StyleProfile(
            id=RANKING_SOCIAL_ID,
            name="Creator Stack",
            kind=StyleProfileKind.RANKING_NUMBERS,
            core=True,
            text_style=_ranking_text(
                size=76,
                foreground="#FFFFFF",
                outline="#050505",
                outline_width=5,
            ),
            layer_background=transparent,
            ranking=RankingStyleValues(
                active_color=_color("#FFD737"),
                inactive_color=_color("#FFFFFF"),
                active_opacity=1,
                inactive_opacity=0.96,
                item_overrides={
                    1: _rank_override("#FFD737"),
                    2: _rank_override("#F4F4F4"),
                    3: _rank_override("#FF9E35"),
                    4: _rank_override("#FFFFFF"),
                    5: _rank_override("#FFFFFF"),
                },
            ),
        ),
        StyleProfile(
            id=CAPTION_CLEAN_ID,
            name="Clean Reaction",
            kind=StyleProfileKind.CAPTIONS,
            core=True,
            text_style=TextStyle(
                font_size=60,
                minimum_font_size=30,
                bold=True,
                foreground=_color("#FFFFFF"),
                outline=_color("#000000"),
                outline_width=4,
                shadow_enabled=True,
                shadow_distance=2,
                alignment="left",
            ),
            layer_background=transparent,
        ),
        StyleProfile(
            id=CAPTION_COMPACT_ID,
            name="Compact Bold",
            kind=StyleProfileKind.CAPTIONS,
            core=True,
            text_style=TextStyle(
                font_size=54,
                minimum_font_size=28,
                bold=True,
                foreground=_color("#FFFFFF"),
                outline=_color("#050505"),
                outline_width=5,
                shadow_enabled=False,
                alignment="left",
            ),
            layer_background=transparent,
        ),
        StyleProfile(
            id=CAPTION_SOFT_ID,
            name="Soft Shadow",
            kind=StyleProfileKind.CAPTIONS,
            core=True,
            text_style=TextStyle(
                font_size=58,
                minimum_font_size=29,
                bold=True,
                foreground=_color("#FFFFFF"),
                outline=_color("#101010", 220),
                outline_width=2,
                shadow_enabled=True,
                shadow_color=_color("#000000", 210),
                shadow_distance=4,
                shadow_blur=3,
                alignment="left",
            ),
            layer_background=transparent,
        ),
        StyleProfile(
            id=CAPTION_NEON_ID,
            name="Neon Accent",
            kind=StyleProfileKind.CAPTIONS,
            core=True,
            text_style=TextStyle(
                font_size=58,
                minimum_font_size=29,
                bold=True,
                foreground=_color("#E8FEFF"),
                outline=_color("#063B46"),
                outline_width=4,
                shadow_enabled=True,
                shadow_distance=2,
                glow_enabled=True,
                glow_color=_color("#00D9FF"),
                glow_radius=5,
                glow_intensity=0.45,
                alignment="left",
            ),
            layer_background=transparent,
        ),
        StyleProfile(
            id=CAPTION_SOCIAL_ID,
            name="Creator Stack",
            kind=StyleProfileKind.CAPTIONS,
            core=True,
            text_style=TextStyle(
                font_size=48,
                minimum_font_size=26,
                bold=False,
                foreground=_color("#FFFFFF"),
                outline=_color("#080808"),
                outline_width=4,
                shadow_enabled=True,
                shadow_color=_color("#000000", 210),
                shadow_distance=2,
                alignment="left",
            ),
            layer_background=transparent,
        ),
        StyleProfile(
            id=HEADER_CLEAN_ID,
            name="Clean Banner",
            kind=StyleProfileKind.HEADER,
            core=True,
            text_style=TextStyle(
                font_size=78,
                minimum_font_size=36,
                bold=True,
                foreground=_color("#FFFFFF"),
                outline=_color("#000000"),
                outline_width=3,
                shadow_enabled=True,
                shadow_distance=2,
            ),
            layer_background=transparent,
            header=HeaderStyleValues(),
        ),
        StyleProfile(
            id=HEADER_CREATOR_ID,
            name="Creator Accent",
            kind=StyleProfileKind.HEADER,
            core=True,
            text_style=TextStyle(
                font_size=54,
                minimum_font_size=28,
                bold=True,
                foreground=_color("#FFFFFF"),
                outline=_color("#050505"),
                outline_width=4,
                shadow_enabled=True,
                shadow_color=_color("#000000", 190),
                shadow_distance=2,
                alignment="center",
            ),
            layer_background=transparent,
            header=HeaderStyleValues(
                background=transparent,
                border_color=transparent,
                border_width=0,
                height_ratio=0.135,
                padding_ratio=0.012,
                accent_color=_color("#FF3232"),
                accent_last_words=2,
            ),
        ),
        StyleProfile(
            id=HEADER_MINIMAL_ID,
            name="Minimal Floating",
            kind=StyleProfileKind.HEADER,
            core=True,
            text_style=TextStyle(
                font_size=76,
                minimum_font_size=36,
                bold=True,
                foreground=_color("#FFFFFF"),
                outline=_color("#000000"),
                outline_width=5,
                shadow_enabled=True,
                shadow_distance=3,
            ),
            layer_background=transparent,
            header=HeaderStyleValues(
                background=transparent,
                border_color=transparent,
                border_width=0,
                height_ratio=0.16,
                padding_ratio=0.02,
            ),
        ),
        StyleProfile(
            id=HEADER_EDITORIAL_ID,
            name="Bold Editorial",
            kind=StyleProfileKind.HEADER,
            core=True,
            text_style=TextStyle(
                font_size=82,
                minimum_font_size=38,
                bold=True,
                foreground=_color("#FFF36A"),
                outline=_color("#000000"),
                outline_width=4,
                shadow_enabled=False,
            ),
            layer_background=transparent,
            header=HeaderStyleValues(
                background=_color("#101014"),
                border_color=_color("#FFF36A"),
                border_width=3,
                height_ratio=0.18,
                padding_ratio=0.026,
            ),
        ),
        StyleProfile(
            id=HEADER_NEON_ID,
            name="Neon Title",
            kind=StyleProfileKind.HEADER,
            core=True,
            text_style=TextStyle(
                font_size=78,
                minimum_font_size=36,
                bold=True,
                foreground=_color("#FFFFFF"),
                outline=_color("#5420A8"),
                outline_width=5,
                shadow_enabled=True,
                shadow_distance=2,
                glow_enabled=True,
                glow_color=_color("#A04BFF"),
                glow_radius=7,
                glow_intensity=0.5,
            ),
            layer_background=transparent,
            header=HeaderStyleValues(
                background=_color("#140D20"),
                border_color=_color("#7E35D8"),
                border_width=2,
                height_ratio=0.18,
                padding_ratio=0.025,
            ),
        ),
    ]
