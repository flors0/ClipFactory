"""Preset semantic validation beyond Pydantic shape checks."""

from __future__ import annotations

from pathlib import Path

from app.models.preset_models import ElementType, Preset


class PresetValidator:
    def validate(self, preset: Preset, *, asset_paths: dict[str, Path] | None = None) -> list[str]:
        errors: list[str] = []
        visible_types = {layer.element_type for layer in preset.layers if not layer.hidden}
        if ElementType.VIDEO not in visible_types:
            errors.append("Preset requires a visible video layer.")
        if preset.header.enabled and ElementType.HEADER not in visible_types:
            errors.append("Header is enabled but no visible header layer exists.")
        if preset.ranking.enabled:
            if ElementType.RANKING_NUMBER not in visible_types:
                errors.append("Ranking is enabled but no ranking-number layer exists.")
            if ElementType.DYNAMIC_CAPTION not in visible_types:
                errors.append("Ranking is enabled but no dynamic-caption layer exists.")
            if preset.ranking.order != "ascending":
                errors.append(
                    "Ranking must place rank 1 first and then increase from top to bottom."
                )
        if preset.transition.enabled:
            if preset.transition.type == "cut":
                errors.append("Disable transitions instead of enabling a cut transition.")
            if preset.transition.duration_seconds <= 0:
                errors.append("Enabled transitions require a duration greater than zero.")
            if preset.transition.placement != "between_clips":
                errors.append("Transitions may only be placed between clips.")
            if preset.transition.type == "fixed_asset" and not preset.transition.fixed_asset_id:
                errors.append("Fixed-asset transition requires an Asset Library item.")
        if preset.interstitial.enabled and not preset.interstitial.asset_id:
            errors.append("Enabled interstitial requires an asset identifier.")
        asset_required = {
            ElementType.IMAGE,
            ElementType.MEME,
            ElementType.INTERSTITIAL,
            ElementType.AUDIO,
            ElementType.MUSIC,
            ElementType.SOUND_EFFECT,
        }
        if preset.subtitles_enabled:
            asset_required.add(ElementType.SUBTITLE)
        for layer in preset.layers:
            if not layer.hidden and layer.element_type in asset_required and not layer.asset_id:
                errors.append(
                    f"Visible {layer.element_type.value} layer requires an asset: {layer.name}"
                )
        if asset_paths is not None:
            identifiers = [
                (
                    preset.transition.fixed_asset_id
                    if preset.transition.enabled and preset.transition.type == "fixed_asset"
                    else None
                ),
                (
                    preset.transition.sound_asset_id
                    if preset.transition.enabled and preset.transition.type != "cut"
                    else None
                ),
                preset.interstitial.asset_id if preset.interstitial.enabled else None,
                preset.audio.music_asset_id,
                *[layer.asset_id for layer in preset.layers if not layer.hidden],
            ]
            for identifier in {value for value in identifiers if value}:
                path = asset_paths.get(identifier)
                if path is None or not path.is_file():
                    errors.append(f"Preset references a missing asset: {identifier}")
        z_indices = [layer.z_index for layer in preset.layers]
        if len(z_indices) != len(set(z_indices)):
            errors.append("Each layer must have a unique z-index for deterministic rendering.")
        return errors
