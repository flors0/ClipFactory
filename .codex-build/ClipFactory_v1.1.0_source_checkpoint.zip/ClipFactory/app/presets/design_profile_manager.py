"""Lifecycle and application of coordinated visual design profiles."""

from __future__ import annotations

from uuid import uuid4

from app.models.design_models import DesignProfile
from app.models.preset_models import ElementType, Preset, Rect
from app.models.style_models import StyleProfileKind
from app.presets.style_profile_manager import (
    CAPTION_CLEAN_ID,
    CAPTION_NEON_ID,
    CAPTION_SOCIAL_ID,
    HEADER_CLEAN_ID,
    HEADER_CREATOR_ID,
    HEADER_MINIMAL_ID,
    HEADER_NEON_ID,
    RANKING_CLASSIC_ID,
    RANKING_SOCIAL_ID,
    RANKING_VIOLET_ID,
    StyleProfileManager,
)
from app.storage.repositories.design_profile_repository import DesignProfileRepository

DESIGN_CREATOR_STACK_ID = "core-design-ranking-creator-stack"
DESIGN_CLEAN_BANNER_ID = "core-design-ranking-clean-banner"
DESIGN_MINIMAL_OVERLAY_ID = "core-design-ranking-minimal-overlay"
DESIGN_NEON_ID = "core-design-ranking-neon"
DESIGN_COMPILATION_ID = "core-design-compilation-clean"


class DesignProfileManager:
    def __init__(
        self,
        repository: DesignProfileRepository,
        style_profiles: StyleProfileManager,
    ):
        self.repository = repository
        self.style_profiles = style_profiles

    def ensure_core_profiles(self) -> list[DesignProfile]:
        existing = {profile.id for profile in self.repository.list()}
        created: list[DesignProfile] = []
        for profile in core_design_profiles():
            if profile.id not in existing:
                self.repository.save(profile)
                created.append(profile)
        return created

    def list(self, video_format: str | None = None) -> list[DesignProfile]:
        return self.repository.list(video_format)

    def get(self, identifier: str) -> DesignProfile | None:
        return self.repository.get(identifier)

    def apply(self, preset: Preset, identifier: str) -> Preset:
        profile = self._required(identifier)
        if profile.video_format != preset.video_format:
            raise ValueError(
                f"Design '{profile.name}' is for {profile.video_format} videos, not "
                f"{preset.video_format}."
            )
        target = preset.model_copy(deep=True)
        for style_id in (
            profile.ranking_numbers_profile_id,
            profile.captions_profile_id,
            profile.header_profile_id,
        ):
            if style_id:
                target = self.style_profiles.apply(target, style_id)
        for layer in target.layers:
            if layer.id in profile.layer_bounds:
                layer.bounds = profile.layer_bounds[layer.id].model_copy(deep=True)
            if layer.id in profile.hidden_layers:
                layer.hidden = profile.hidden_layers[layer.id]
        if profile.header_enabled is not None:
            target.header.enabled = profile.header_enabled
        if profile.ranking_enabled is not None:
            target.ranking.enabled = profile.ranking_enabled
        if profile.ranking_spacing is not None:
            target.ranking.spacing = profile.ranking_spacing
        if profile.ranking_vertical_alignment is not None:
            target.ranking.vertical_alignment = profile.ranking_vertical_alignment
        target.style_profiles.design = profile.id
        return target

    def reconcile_preset(self, preset: Preset) -> Preset:
        current = self.repository.get(preset.style_profiles.design or "")
        if current and self.matches(preset, current):
            return preset
        matched = next(
            (
                profile
                for profile in self.repository.list(preset.video_format)
                if self.matches(preset, profile)
            ),
            None,
        )
        preset.style_profiles.design = matched.id if matched else None
        return preset

    def matches(self, preset: Preset, profile: DesignProfile) -> bool:
        if preset.video_format != profile.video_format:
            return False
        expected_profiles = (
            profile.ranking_numbers_profile_id,
            profile.captions_profile_id,
            profile.header_profile_id,
        )
        actual_profiles = (
            preset.style_profiles.ranking_numbers,
            preset.style_profiles.captions,
            preset.style_profiles.header,
        )
        if expected_profiles != actual_profiles:
            return False
        layers = {layer.id: layer for layer in preset.layers}
        if any(layers.get(identifier) is None for identifier in profile.layer_bounds):
            return False
        if any(
            layers[identifier].bounds != bounds
            for identifier, bounds in profile.layer_bounds.items()
        ):
            return False
        if any(
            layers.get(identifier) is None or layers[identifier].hidden != hidden
            for identifier, hidden in profile.hidden_layers.items()
        ):
            return False
        checks = (
            profile.header_enabled is None or preset.header.enabled == profile.header_enabled,
            profile.ranking_enabled is None or preset.ranking.enabled == profile.ranking_enabled,
            profile.ranking_spacing is None or preset.ranking.spacing == profile.ranking_spacing,
            profile.ranking_vertical_alignment is None
            or preset.ranking.vertical_alignment == profile.ranking_vertical_alignment,
        )
        return all(checks)

    def create_from_preset(self, preset: Preset, name: str) -> DesignProfile:
        clean_name = name.strip()
        if not clean_name:
            raise ValueError("Design name cannot be empty.")
        if any(
            profile.name.casefold() == clean_name.casefold()
            for profile in self.repository.list(preset.video_format)
        ):
            raise ValueError(f"A design named '{clean_name}' already exists.")
        relevant = {
            ElementType.VIDEO,
            ElementType.HEADER,
            ElementType.RANKING_NUMBER,
            ElementType.DYNAMIC_CAPTION,
        }
        component_ids = {
            "ranking_numbers_profile_id": self._capture_component(
                preset,
                StyleProfileKind.RANKING_NUMBERS,
                clean_name,
                "Numbers",
            ),
            "captions_profile_id": self._capture_component(
                preset,
                StyleProfileKind.CAPTIONS,
                clean_name,
                "Captions",
            ),
            "header_profile_id": self._capture_component(
                preset,
                StyleProfileKind.HEADER,
                clean_name,
                "Header",
            ),
        }
        profile = DesignProfile(
            id=str(uuid4()),
            name=clean_name,
            description="Saved from a per-video Review configuration.",
            video_format=preset.video_format,
            **component_ids,
            layer_bounds={
                layer.id: layer.bounds.model_copy(deep=True)
                for layer in preset.layers
                if layer.element_type in relevant
            },
            hidden_layers={
                layer.id: layer.hidden for layer in preset.layers if layer.element_type in relevant
            },
            header_enabled=preset.header.enabled,
            ranking_enabled=preset.ranking.enabled,
            ranking_spacing=preset.ranking.spacing,
            ranking_vertical_alignment=preset.ranking.vertical_alignment,
        )
        return self.repository.save(profile)

    def _capture_component(
        self,
        preset: Preset,
        kind: StyleProfileKind,
        design_name: str,
        label: str,
    ) -> str | None:
        try:
            matched = self.style_profiles.matching_profile(preset, kind)
        except ValueError:
            return None
        if matched:
            return matched.id
        base_name = f"{design_name} · {label}"
        try:
            return self.style_profiles.create_from_preset(preset, kind, base_name).id
        except ValueError as error:
            if "already exists" not in str(error):
                raise
            unique_name = f"{base_name} {uuid4().hex[:6]}"
            return self.style_profiles.create_from_preset(preset, kind, unique_name).id

    def delete(self, identifier: str) -> bool:
        return self.repository.delete(identifier)

    def _required(self, identifier: str) -> DesignProfile:
        profile = self.repository.get(identifier)
        if not profile:
            raise KeyError(f"Design profile does not exist: {identifier}")
        return profile


def core_design_profiles() -> list[DesignProfile]:
    return [
        DesignProfile(
            id=DESIGN_CREATOR_STACK_ID,
            name="Creator Stack",
            description=(
                "Reference-inspired full-frame video with a compact accented header and a "
                "persistent lower-left ranking stack."
            ),
            core=True,
            video_format="ranking",
            ranking_numbers_profile_id=RANKING_SOCIAL_ID,
            captions_profile_id=CAPTION_SOCIAL_ID,
            header_profile_id=HEADER_CREATOR_ID,
            layer_bounds={
                "video": Rect(x=0, y=0, width=1, height=1),
                "header": Rect(x=0.035, y=0.018, width=0.93, height=0.125),
                "ranking_numbers": Rect(x=0.035, y=0.49, width=0.11, height=0.38),
                "dynamic_caption": Rect(x=0.14, y=0.49, width=0.72, height=0.38),
            },
            hidden_layers={"header": False, "ranking_numbers": False, "dynamic_caption": False},
            header_enabled=True,
            ranking_enabled=True,
            ranking_spacing=0.004,
            ranking_vertical_alignment="bottom",
        ),
        DesignProfile(
            id=DESIGN_CLEAN_BANNER_ID,
            name="Clean Banner",
            description="Separated header band with a clean central ranking list.",
            core=True,
            video_format="ranking",
            ranking_numbers_profile_id=RANKING_CLASSIC_ID,
            captions_profile_id=CAPTION_CLEAN_ID,
            header_profile_id=HEADER_CLEAN_ID,
            layer_bounds={
                "video": Rect(x=0, y=0.18, width=1, height=0.82),
                "header": Rect(x=0.05, y=0.025, width=0.9, height=0.13),
                "ranking_numbers": Rect(x=0.035, y=0.245, width=0.12, height=0.54),
                "dynamic_caption": Rect(x=0.16, y=0.245, width=0.74, height=0.54),
            },
            hidden_layers={"header": False, "ranking_numbers": False, "dynamic_caption": False},
            header_enabled=True,
            ranking_enabled=True,
            ranking_spacing=0.012,
            ranking_vertical_alignment="center",
        ),
        DesignProfile(
            id=DESIGN_MINIMAL_OVERLAY_ID,
            name="Minimal Overlay",
            description="Full-frame video with floating text and no header panel.",
            core=True,
            video_format="ranking",
            ranking_numbers_profile_id=RANKING_CLASSIC_ID,
            captions_profile_id=CAPTION_CLEAN_ID,
            header_profile_id=HEADER_MINIMAL_ID,
            layer_bounds={
                "video": Rect(x=0, y=0, width=1, height=1),
                "header": Rect(x=0.055, y=0.025, width=0.89, height=0.14),
                "ranking_numbers": Rect(x=0.04, y=0.48, width=0.12, height=0.4),
                "dynamic_caption": Rect(x=0.16, y=0.48, width=0.72, height=0.4),
            },
            hidden_layers={"header": False, "ranking_numbers": False, "dynamic_caption": False},
            header_enabled=True,
            ranking_enabled=True,
            ranking_spacing=0.006,
            ranking_vertical_alignment="bottom",
        ),
        DesignProfile(
            id=DESIGN_NEON_ID,
            name="Neon Countdown",
            description="Full-frame violet/cyan countdown with a dark translucent title panel.",
            core=True,
            video_format="ranking",
            ranking_numbers_profile_id=RANKING_VIOLET_ID,
            captions_profile_id=CAPTION_NEON_ID,
            header_profile_id=HEADER_NEON_ID,
            layer_bounds={
                "video": Rect(x=0, y=0, width=1, height=1),
                "header": Rect(x=0.045, y=0.025, width=0.91, height=0.14),
                "ranking_numbers": Rect(x=0.04, y=0.43, width=0.13, height=0.43),
                "dynamic_caption": Rect(x=0.17, y=0.43, width=0.7, height=0.43),
            },
            hidden_layers={"header": False, "ranking_numbers": False, "dynamic_caption": False},
            header_enabled=True,
            ranking_enabled=True,
            ranking_spacing=0.007,
            ranking_vertical_alignment="bottom",
        ),
        DesignProfile(
            id=DESIGN_COMPILATION_ID,
            name="Clean Compilation",
            description="Text-free full-frame compilation design.",
            core=True,
            video_format="compilation",
            layer_bounds={"video": Rect(x=0, y=0, width=1, height=1)},
            header_enabled=False,
            ranking_enabled=False,
        ),
    ]
