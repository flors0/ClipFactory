"""Shared normalized layout math for editor preview and final renderer."""

from __future__ import annotations

from dataclasses import dataclass

from app.models.preset_models import Preset, PresetLayer, Rect, TextStyle


@dataclass(frozen=True, slots=True)
class PixelRect:
    x: int
    y: int
    width: int
    height: int


class LayoutEngine:
    @staticmethod
    def resolved_text_style(preset: Preset, style: TextStyle) -> TextStyle:
        value = style.model_copy(deep=True)
        if not value.scale_with_canvas:
            return value
        scale = preset.height / value.reference_height
        value.font_size *= scale
        value.minimum_font_size *= scale
        value.outline_width *= scale
        value.shadow_distance *= scale
        value.shadow_blur *= scale
        value.glow_radius *= scale
        value.letter_spacing *= scale
        return value

    @staticmethod
    def to_pixels(bounds: Rect, width: int, height: int) -> PixelRect:
        return PixelRect(
            x=round(bounds.x * width),
            y=round(bounds.y * height),
            width=max(1, round(bounds.width * width)),
            height=max(1, round(bounds.height * height)),
        )

    @staticmethod
    def layer_rect(preset: Preset, layer: PresetLayer) -> PixelRect:
        return LayoutEngine.to_pixels(layer.bounds, preset.width, preset.height)

    @staticmethod
    def header_text_rect(preset: Preset, layer: PresetLayer) -> PixelRect:
        rect = LayoutEngine.safe_text_rect(preset, layer)
        requested_padding = round(preset.header.padding_ratio * preset.width)
        horizontal_padding = min(requested_padding, max(0, (rect.width - 1) // 2))
        vertical_padding = min(requested_padding, max(0, (rect.height - 1) // 2))
        return PixelRect(
            x=rect.x + horizontal_padding,
            y=rect.y + vertical_padding,
            width=max(1, rect.width - horizontal_padding * 2),
            height=max(1, rect.height - vertical_padding * 2),
        )

    @staticmethod
    def ranking_item_rects(
        preset: Preset,
        layer: PresetLayer,
        count: int,
        *,
        font_size: float,
    ) -> list[PixelRect]:
        if count <= 0:
            return []
        bounds = LayoutEngine.safe_text_rect(preset, layer)
        requested_gap = round(preset.ranking.spacing * preset.height)
        maximum_gap = max(0, (bounds.height - count) // (count - 1)) if count > 1 else 0
        gap = min(requested_gap, maximum_gap)
        preferred_row_height = max(1, round(font_size * 1.35))
        available_rows = max(1, bounds.height - gap * (count - 1))
        row_height = min(preferred_row_height, max(1, available_rows // count))
        content_height = row_height * count + gap * (count - 1)
        offset = {
            "top": 0,
            "center": max(0, (bounds.height - content_height) // 2),
            "bottom": max(0, bounds.height - content_height),
        }[preset.ranking.vertical_alignment]
        return [
            PixelRect(
                x=bounds.x,
                y=bounds.y + offset + index * (row_height + gap),
                width=bounds.width,
                height=row_height,
            )
            for index in range(count)
        ]

    @staticmethod
    def safe_zone_rect(preset: Preset) -> PixelRect:
        zones = preset.safe_zones
        return PixelRect(
            x=round(zones.left * preset.width),
            y=round(zones.top * preset.height),
            width=round((1 - zones.left - zones.right) * preset.width),
            height=round((1 - zones.top - zones.bottom) * preset.height),
        )

    @staticmethod
    def safe_text_rect(preset: Preset, layer: PresetLayer) -> PixelRect:
        rect = LayoutEngine.layer_rect(preset, layer)
        safe = LayoutEngine.safe_zone_rect(preset)
        left = max(rect.x, safe.x)
        top = max(rect.y, safe.y)
        right = min(rect.x + rect.width, safe.x + safe.width)
        bottom = min(rect.y + rect.height, safe.y + safe.height)
        if right <= left or bottom <= top:
            return rect
        return PixelRect(
            x=left,
            y=top,
            width=max(1, right - left),
            height=max(1, bottom - top),
        )

    @staticmethod
    def platform_ui_safe_zone_rect(preset: Preset) -> PixelRect:
        if preset.platform == "tiktok":
            top, right, bottom, left = 0.08, 0.18, 0.20, 0.05
        elif preset.platform == "youtube":
            top, right, bottom, left = 0.08, 0.10, 0.14, 0.05
        else:
            top, right, bottom, left = 0.06, 0.10, 0.14, 0.05
        return PixelRect(
            x=round(left * preset.width),
            y=round(top * preset.height),
            width=round((1 - left - right) * preset.width),
            height=round((1 - top - bottom) * preset.height),
        )

    @staticmethod
    def video_rect(preset: Preset) -> PixelRect:
        layer = next(
            (
                item
                for item in preset.layers
                if item.element_type.value == "video" and not item.hidden
            ),
            None,
        )
        if layer:
            return LayoutEngine.layer_rect(preset, layer)
        header_height = (
            round(preset.header.height_ratio * preset.height) if preset.header.enabled else 0
        )
        return PixelRect(0, header_height, preset.width, preset.height - header_height)
