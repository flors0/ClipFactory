"""Static preview renderer using the same normalized layout engine as FFmpeg."""

from __future__ import annotations

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen

from app.models.preset_models import ElementType, Preset
from app.presets.layout import LayoutEngine


class PreviewRenderer:
    def render(self, preset: Preset, dynamic_text: dict[str, str] | None = None) -> QImage:
        dynamic_text = dynamic_text or {}
        image = QImage(preset.width, preset.height, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(QColor(10, 10, 14))
        painter = QPainter(image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        for layer in sorted(preset.layers, key=lambda item: item.z_index):
            if layer.hidden:
                continue
            rect = LayoutEngine.layer_rect(preset, layer)
            target = QRectF(rect.x, rect.y, rect.width, rect.height)
            color = layer.background_color
            if color.alpha:
                painter.fillRect(
                    target,
                    QColor(color.red, color.green, color.blue, round(color.alpha * layer.opacity)),
                )
            if layer.element_type == ElementType.VIDEO:
                painter.fillRect(target, QColor(35, 39, 48))
                painter.setPen(QPen(QColor(86, 92, 108), 4))
                painter.drawRect(target)
                painter.setPen(QColor(190, 195, 205))
                painter.drawText(target, Qt.AlignmentFlag.AlignCenter, "VIDEO PREVIEW")
            elif layer.rich_text:
                document = layer.rich_text
                text = document.text
                for key, value in dynamic_text.items():
                    text = text.replace("{" + key + "}", value)
                style = document.default_style
                painter.setPen(
                    QColor(
                        style.foreground.red,
                        style.foreground.green,
                        style.foreground.blue,
                        style.foreground.alpha,
                    )
                )
                font = QFont(style.font_family)
                font.setPointSizeF(style.font_size)
                font.setBold(style.bold)
                font.setItalic(style.italic)
                font.setUnderline(style.underline)
                painter.setFont(font)
                alignment = (
                    {
                        "left": Qt.AlignmentFlag.AlignLeft,
                        "center": Qt.AlignmentFlag.AlignHCenter,
                        "right": Qt.AlignmentFlag.AlignRight,
                    }[style.alignment]
                    | Qt.AlignmentFlag.AlignVCenter
                    | Qt.TextFlag.TextWordWrap
                )
                painter.drawText(target, alignment, text)
        safe = LayoutEngine.safe_zone_rect(preset)
        painter.setPen(QPen(QColor(90, 180, 255, 130), 2, Qt.PenStyle.DashLine))
        painter.drawRect(QRectF(safe.x, safe.y, safe.width, safe.height))
        painter.end()
        return image
