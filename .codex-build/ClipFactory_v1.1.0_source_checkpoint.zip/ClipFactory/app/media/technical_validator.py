"""Deterministic video checks performed before optional AI review."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

from app.media.media_probe import MediaProbe
from app.models.media_models import TechnicalCheck, TechnicalValidationResult


class TechnicalValidator:
    def __init__(self, media_probe: MediaProbe, ffmpeg_path: str = "ffmpeg"):
        self.media_probe = media_probe
        self.ffmpeg_path = ffmpeg_path

    def validate(
        self,
        path: Path,
        *,
        expected_width: int,
        expected_height: int,
        expected_fps: int,
        minimum_duration: float,
        maximum_duration: float,
        duration_blocking: bool = True,
        expect_audio: bool = True,
        deep_scan: bool = True,
        expected_video_codec: str = "h264",
        expected_audio_codec: str = "aac",
    ) -> TechnicalValidationResult:
        checks: list[TechnicalCheck] = []
        if not path.is_file() or path.stat().st_size <= 0:
            return TechnicalValidationResult(
                passed=False,
                checks=[
                    TechnicalCheck(
                        name="File exists and is non-empty", passed=False, details=str(path)
                    )
                ],
            )
        checks.append(
            TechnicalCheck(
                name="File exists and is non-empty",
                passed=True,
                details=f"{path.stat().st_size} bytes",
            )
        )
        try:
            info = self.media_probe.probe(path)
        except Exception as error:
            checks.append(
                TechnicalCheck(name="Streams are readable", passed=False, details=str(error))
            )
            return TechnicalValidationResult(passed=False, checks=checks)
        duration_passed = minimum_duration <= info.duration_seconds <= maximum_duration
        duration_details = (
            f"{info.duration_seconds:.3f}s; allowed {minimum_duration:.3f}-{maximum_duration:.3f}s"
        )
        checks.extend(
            [
                TechnicalCheck(name="Video stream present", passed=True, details=info.video_codec),
                TechnicalCheck(
                    name="Audio stream present",
                    passed=info.has_audio or not expect_audio,
                    details=info.audio_codec or "No audio stream",
                ),
                TechnicalCheck(
                    name="Resolution",
                    passed=(info.width, info.height) == (expected_width, expected_height),
                    details=f"{info.width}x{info.height}; expected {expected_width}x{expected_height}",
                ),
                TechnicalCheck(
                    name="Frame rate",
                    passed=abs(info.fps - expected_fps) <= 0.15,
                    details=f"{info.fps:.3f}; expected {expected_fps}",
                ),
                TechnicalCheck(
                    name="Duration",
                    passed=duration_passed,
                    details=duration_details,
                    blocking=duration_blocking,
                ),
                TechnicalCheck(
                    name="Container and codecs",
                    passed="mp4" in (info.container or "")
                    and info.video_codec == expected_video_codec
                    and (not expect_audio or info.audio_codec == expected_audio_codec),
                    details=(
                        f"{info.container}; {info.video_codec}/{info.audio_codec}; expected "
                        f"mp4, {expected_video_codec}/{expected_audio_codec}"
                    ),
                ),
            ]
        )
        warnings: list[str] = []
        if not duration_passed and not duration_blocking:
            warnings.append(
                "Duration is outside the preset range but is non-blocking because duration "
                f"enforcement is set to warn: {duration_details}."
            )
        if deep_scan:
            scan_checks, scan_warnings = self._deep_scan(
                path, info.duration_seconds, info.has_audio
            )
            checks.extend(scan_checks)
            warnings.extend(scan_warnings)
        return TechnicalValidationResult(
            passed=all(check.passed for check in checks if check.blocking),
            checks=checks,
            warnings=warnings,
        )

    def _deep_scan(
        self, path: Path, duration: float, has_audio: bool
    ) -> tuple[list[TechnicalCheck], list[str]]:
        filters = "blackdetect=d=2:pix_th=0.10,freezedetect=n=-50dB:d=2"
        command = [
            self.ffmpeg_path,
            "-v",
            "info",
            "-i",
            str(path),
            "-vf",
            filters,
            "-an",
            "-f",
            "null",
            "-",
        ]
        timeout = max(60.0, min(1800.0, duration * 6))
        try:
            completed = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=False,
                timeout=timeout,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            return [
                TechnicalCheck(
                    name="Deep video scan completed",
                    passed=False,
                    details=str(error),
                )
            ], []
        if completed.returncode != 0:
            return [
                TechnicalCheck(
                    name="Deep video scan completed",
                    passed=False,
                    details=completed.stderr[-2000:],
                )
            ], []
        stderr = completed.stderr
        black_durations = [
            float(value) for value in re.findall(r"black_duration:([0-9.]+)", stderr)
        ]
        freeze_starts = re.findall(r"freeze_start", stderr)
        checks = [
            TechnicalCheck(
                name="No long black segments",
                passed=not any(value >= max(3.0, duration * 0.2) for value in black_durations),
                details=f"Detected durations: {black_durations or 'none'}",
            ),
            TechnicalCheck(
                name="No long freeze segments",
                passed=len(freeze_starts) == 0,
                details=f"Detected segments: {len(freeze_starts)}",
                blocking=False,
            ),
        ]
        warnings: list[str] = []
        if freeze_starts:
            warnings.append("Potential freeze segments require manual review.")
        if has_audio:
            silence_command = [
                self.ffmpeg_path,
                "-v",
                "info",
                "-i",
                str(path),
                "-af",
                "silencedetect=noise=-45dB:d=3",
                "-vn",
                "-f",
                "null",
                "-",
            ]
            try:
                silence_run = subprocess.run(
                    silence_command,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=timeout,
                )
                silence = silence_run.stderr
            except (OSError, subprocess.TimeoutExpired) as error:
                checks.append(
                    TechnicalCheck(
                        name="Audio silence scan completed",
                        passed=False,
                        details=str(error),
                        blocking=False,
                    )
                )
                warnings.append("Audio silence scan could not complete and requires manual review.")
                return checks, warnings
            silence_durations = [
                float(value) for value in re.findall(r"silence_duration: ([0-9.]+)", silence)
            ]
            checks.append(
                TechnicalCheck(
                    name="No unexpected long silence",
                    passed=not any(
                        value >= max(5.0, duration * 0.3) for value in silence_durations
                    ),
                    details=f"Detected durations: {silence_durations or 'none'}",
                    blocking=False,
                )
            )
            if silence_durations:
                warnings.append("Detected silence should be reviewed against the preset intent.")
        return checks, warnings
