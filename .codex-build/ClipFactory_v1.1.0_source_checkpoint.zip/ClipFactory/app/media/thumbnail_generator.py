"""Generate deterministic media thumbnails with FFmpeg."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from uuid import uuid4

from app.core.exceptions import MediaProbeError


class ThumbnailGenerator:
    def __init__(self, output_directory: Path, ffmpeg_path: str = "ffmpeg"):
        self.output_directory = output_directory.resolve()
        self.output_directory.mkdir(parents=True, exist_ok=True)
        self.ffmpeg_path = ffmpeg_path

    def generate(self, media_path: Path, fingerprint: str, at_seconds: float = 1.0) -> Path:
        destination = self.output_directory / f"{fingerprint}.jpg"
        if destination.is_file() and destination.stat().st_size > 0:
            return destination
        temporary = self.output_directory / f".{fingerprint}-{uuid4().hex}.tmp.jpg"
        command = [
            self.ffmpeg_path,
            "-v",
            "error",
            "-ss",
            f"{max(0, at_seconds):.3f}",
            "-i",
            str(media_path.resolve()),
            "-frames:v",
            "1",
            "-vf",
            "scale=360:-2",
            "-q:v",
            "3",
            "-y",
            str(temporary),
        ]
        try:
            completed = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=False,
                timeout=60,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            temporary.unlink(missing_ok=True)
            raise MediaProbeError(f"Thumbnail generation could not run: {error}") from error
        if completed.returncode != 0 or not temporary.is_file():
            temporary.unlink(missing_ok=True)
            raise MediaProbeError(f"Thumbnail generation failed: {completed.stderr.strip()}")
        os.replace(temporary, destination)
        return destination
