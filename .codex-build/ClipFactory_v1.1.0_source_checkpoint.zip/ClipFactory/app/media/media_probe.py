"""ffprobe-backed media metadata extraction."""

from __future__ import annotations

import json
import subprocess
from fractions import Fraction
from pathlib import Path

from app.core.exceptions import MediaProbeError
from app.download.download_cache import file_sha256
from app.models.media_models import MediaInfo


def parse_fraction(value: str | None) -> float:
    if not value or value in {"0/0", "N/A"}:
        return 0.0
    try:
        return float(Fraction(value))
    except (ValueError, ZeroDivisionError):
        return float(value)


class MediaProbe:
    def __init__(self, ffprobe_path: str = "ffprobe", timeout_seconds: float = 30):
        self.ffprobe_path = ffprobe_path
        self.timeout_seconds = timeout_seconds

    def probe(self, file_path: str | Path) -> MediaInfo:
        path = Path(file_path).resolve()
        if not path.is_file() or path.stat().st_size <= 0:
            raise MediaProbeError(f"Media file is missing or empty: {path}")
        command = [
            self.ffprobe_path,
            "-v",
            "error",
            "-show_format",
            "-show_streams",
            "-of",
            "json",
            str(path),
        ]
        try:
            completed = subprocess.run(
                command, capture_output=True, text=True, timeout=self.timeout_seconds, check=False
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise MediaProbeError(f"ffprobe could not run: {error}") from error
        if completed.returncode != 0:
            raise MediaProbeError(f"ffprobe rejected the media: {completed.stderr.strip()}")
        try:
            data = json.loads(completed.stdout)
        except json.JSONDecodeError as error:
            raise MediaProbeError("ffprobe returned invalid JSON.") from error
        video = next(
            (stream for stream in data.get("streams", []) if stream.get("codec_type") == "video"),
            None,
        )
        audio = next(
            (stream for stream in data.get("streams", []) if stream.get("codec_type") == "audio"),
            None,
        )
        if not video:
            raise MediaProbeError("Media has no video stream.")
        format_data = data.get("format", {})
        duration = _positive_float(video.get("duration") or format_data.get("duration"), "duration")
        width = int(video.get("width") or 0)
        height = int(video.get("height") or 0)
        fps = parse_fraction(video.get("avg_frame_rate") or video.get("r_frame_rate"))
        if width <= 0 or height <= 0 or fps <= 0:
            raise MediaProbeError("Media has invalid dimensions or frame rate.")
        bitrate_value = format_data.get("bit_rate") or video.get("bit_rate")
        return MediaInfo(
            file_path=str(path),
            file_fingerprint=file_sha256(path),
            duration_seconds=duration,
            width=width,
            height=height,
            aspect_ratio=width / height,
            fps=fps,
            video_codec=str(video.get("codec_name") or "unknown"),
            audio_codec=str(audio.get("codec_name")) if audio else None,
            has_audio=audio is not None,
            file_size_bytes=path.stat().st_size,
            bitrate=int(bitrate_value) if bitrate_value not in {None, "N/A"} else None,
            container=str(format_data.get("format_name"))
            if format_data.get("format_name")
            else None,
        )


def _positive_float(value: object, name: str) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError) as error:
        raise MediaProbeError(f"Media has no valid {name}.") from error
    if result <= 0:
        raise MediaProbeError(f"Media has non-positive {name}.")
    return result
