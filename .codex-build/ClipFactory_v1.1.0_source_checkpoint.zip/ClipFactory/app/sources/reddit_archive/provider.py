"""Automatic Reddit-video discovery through the documented Arctic Shift API."""

from __future__ import annotations

import hashlib
import logging
import math
from datetime import UTC, datetime, timedelta
from threading import Event, Lock
from urllib.parse import urlparse

import httpx
from tenacity import Retrying, retry_if_exception_type, stop_after_attempt, wait_exponential

from app.core.config import SourceSettings
from app.core.exceptions import CancelledError, SourceAccessError
from app.models.source_models import (
    DiscoveryResult,
    MediaType,
    SourceCandidate,
    SourceHealth,
    SourceProfile,
)
from app.sources.reddit_public.cache import SourceCache
from app.sources.source_provider import CandidateFilter, SourceProvider

logger = logging.getLogger(__name__)

_TIME_FILTER_HOURS = {
    "hour": 1,
    "day": 24,
    "week": 24 * 7,
    "month": 24 * 31,
    "year": 24 * 365,
}
_TRANSIENT_STATUS_CODES = {429, 500, 502, 503, 504}


class ArcticShiftSourceProvider(SourceProvider):
    """Discover current Reddit-hosted videos without reading Reddit listing pages."""

    name = "reddit_archive_arctic_shift"

    def __init__(
        self,
        settings: SourceSettings,
        cache: SourceCache,
        client: httpx.Client | None = None,
    ):
        self.settings = settings
        self.cache = cache
        self.base_url = settings.archive_base_url.rstrip("/")
        self.base_host = (urlparse(self.base_url).hostname or "").casefold()
        if urlparse(self.base_url).scheme != "https" or not self.base_host:
            raise ValueError("Arctic Shift base URL must be a public HTTPS URL.")
        self.client = client or httpx.Client(
            timeout=settings.timeout_seconds,
            follow_redirects=True,
            headers={
                "Accept": "application/json",
                "User-Agent": settings.user_agent,
            },
        )
        self.filter = CandidateFilter()
        self._discovery_lock = Lock()

    def discover(
        self,
        profile: SourceProfile,
        *,
        cancel_event: Event | None = None,
    ) -> DiscoveryResult:
        # One shared provider is used by parallel batch workers. Serializing cache misses keeps a
        # six-video batch from issuing the same free-service query six times simultaneously.
        with self._discovery_lock:
            return self._discover(profile, cancel_event=cancel_event)

    def _discover(
        self,
        profile: SourceProfile,
        *,
        cancel_event: Event | None = None,
    ) -> DiscoveryResult:
        cancel_event = cancel_event or Event()
        cache_key = self._cache_key(profile)
        cached = self.cache.get(cache_key)
        if cached:
            result = DiscoveryResult.model_validate(cached)
            result.health.cache_hit = True
            return result
        if cancel_event.is_set():
            raise CancelledError("Source discovery was cancelled.")

        raw_posts, warnings = self._fetch_posts(profile, cancel_event)
        candidates = [
            candidate
            for value in raw_posts
            if (candidate := self._candidate(value, profile.community)) is not None
        ]
        candidates = self._sort_candidates(profile, candidates)
        filtered = self.filter.apply(profile, candidates)
        if not filtered:
            audio_rule = " with original audio" if self.settings.archive_require_audio else ""
            quality_rule = (
                f" and a {self.settings.archive_min_short_edge}px short edge"
                if self.settings.archive_min_short_edge
                else ""
            )
            raise SourceAccessError(
                "Arctic Shift was reachable, but no production-ready Reddit videos"
                f"{audio_rule}{quality_rule} passed this source profile."
            )

        maturity_cutoff = datetime.now(UTC) - timedelta(
            hours=self.settings.archive_score_maturity_hours
        )
        provisional = sum(candidate.published_at > maturity_cutoff for candidate in filtered)
        if profile.sort in {"top", "hot"} and provisional:
            warnings.append(
                f"{provisional} candidate score(s) are younger than "
                f"{self.settings.archive_score_maturity_hours} hours and may still be provisional."
            )
        result = DiscoveryResult(
            profile_id=profile.id,
            community_description=None,
            candidates=filtered,
            warnings=warnings,
            health=SourceHealth(
                provider=self.name,
                reachable=True,
                checked_at=datetime.now(UTC),
                candidate_count=len(filtered),
                message=(
                    f"Found {len(filtered)} production-ready Reddit videos from "
                    f"{len(raw_posts)} indexed posts."
                ),
            ),
        )
        self.cache.put(cache_key, result.model_dump(mode="json"), self.settings.cache_ttl_seconds)
        return result

    def _fetch_posts(
        self,
        profile: SourceProfile,
        cancel_event: Event,
    ) -> tuple[list[dict[str, object]], list[str]]:
        now = datetime.now(UTC)
        configured_window = _TIME_FILTER_HOURS.get(profile.time_filter, profile.max_post_age_hours)
        window_hours = min(profile.max_post_age_hours, configured_window)
        cutoff = now - timedelta(hours=window_hours)
        before: int | None = None
        posts: list[dict[str, object]] = []
        seen_ids: set[str] = set()
        warnings: list[str] = []

        for page in range(self.settings.archive_max_pages):
            if cancel_event.is_set():
                raise CancelledError("Source discovery was cancelled.")
            if page and cancel_event.wait(self.settings.request_interval_seconds):
                raise CancelledError("Source discovery was cancelled.")
            params: dict[str, str | int] = {
                "subreddit": profile.community,
                "after": round(cutoff.timestamp()),
                "sort": "desc",
                "limit": 100,
            }
            if before is not None:
                params["before"] = before
            response = self._get("/api/posts/search", params, cancel_event)
            remaining = response.headers.get("X-RateLimit-Remaining")
            if remaining:
                try:
                    if float(remaining) < 25:
                        warnings.append(
                            f"Arctic Shift rate-limit remaining is low ({remaining}); cached discovery will be reused."
                        )
                except ValueError:
                    pass
            try:
                payload = response.json()
            except ValueError as error:
                raise SourceAccessError("Arctic Shift returned invalid JSON.") from error
            values = payload.get("data") if isinstance(payload, dict) else None
            if not isinstance(values, list):
                raise SourceAccessError("Arctic Shift response did not contain a post list.")
            page_times: list[int] = []
            for value in values:
                if not isinstance(value, dict):
                    continue
                identifier = str(value.get("id") or "")
                created = self._integer(value.get("created_utc"))
                if created:
                    page_times.append(created)
                if identifier and identifier not in seen_ids:
                    seen_ids.add(identifier)
                    posts.append(value)
            if len(values) < 100 or not page_times:
                break
            next_before = min(page_times) - 1
            if next_before <= round(cutoff.timestamp()) or next_before == before:
                break
            before = next_before

        if not posts:
            raise SourceAccessError(
                "Arctic Shift returned no indexed posts for this subreddit and time window."
            )
        if len(posts) >= self.settings.archive_max_pages * 100:
            warnings.append(
                "Discovery reached the configured Arctic Shift page limit; increase it in Settings for very active subreddits."
            )
        return posts, warnings

    def _get(
        self,
        path: str,
        params: dict[str, str | int],
        cancel_event: Event,
    ) -> httpx.Response:
        retryer = Retrying(
            stop=stop_after_attempt(self.settings.retry_count + 1),
            wait=wait_exponential(multiplier=1, min=1, max=12),
            retry=retry_if_exception_type(
                (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError)
            ),
            reraise=True,
        )
        try:
            for attempt in retryer:
                with attempt:
                    if cancel_event.is_set():
                        raise CancelledError("Source discovery was cancelled.")
                    response = self.client.get(f"{self.base_url}{path}", params=params)
                    if response.status_code in _TRANSIENT_STATUS_CODES:
                        response.raise_for_status()
                    if response.status_code >= 400:
                        raise SourceAccessError(
                            f"Arctic Shift returned HTTP {response.status_code}."
                        )
                    if (response.url.host or "").casefold() != self.base_host:
                        raise SourceAccessError(
                            "Arctic Shift redirected outside its configured API host."
                        )
                    return response
        except (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError) as error:
            status = getattr(getattr(error, "response", None), "status_code", None)
            detail = f"HTTP {status}" if status else type(error).__name__
            raise SourceAccessError(
                f"Arctic Shift discovery failed after retries ({detail})."
            ) from error
        raise SourceAccessError("Arctic Shift discovery failed.")

    def _candidate(self, value: dict[str, object], community: str) -> SourceCandidate | None:
        if value.get("removed_by_category") or str(value.get("author") or "") == "[deleted]":
            return None
        post_id = str(value.get("id") or "")
        permalink = str(value.get("permalink") or "")
        created = self._integer(value.get("created_utc"))
        if not post_id or not permalink or not created:
            return None

        media_owner = value
        reddit_video = self._reddit_video(media_owner)
        crosspost_values = value.get("crosspost_parent_list")
        if not reddit_video and isinstance(crosspost_values, list) and crosspost_values:
            parent = crosspost_values[0]
            if isinstance(parent, dict):
                media_owner = parent
                reddit_video = self._reddit_video(parent)
        if not reddit_video:
            return None
        if str(reddit_video.get("transcoding_status") or "").casefold() != "completed":
            return None
        has_audio = bool(reddit_video.get("has_audio"))
        if self.settings.archive_require_audio and not has_audio:
            return None
        width = self._integer(reddit_video.get("width"))
        height = self._integer(reddit_video.get("height"))
        if self.settings.archive_min_short_edge and (
            not width or not height or min(width, height) < self.settings.archive_min_short_edge
        ):
            return None

        fallback_url = self._safe_media_url(reddit_video.get("fallback_url"))
        dash_url = self._safe_media_url(reddit_video.get("dash_url"))
        hls_url = self._safe_media_url(reddit_video.get("hls_url"))
        root_url = self._safe_media_url(
            media_owner.get("url_overridden_by_dest") or media_owner.get("url")
        )
        asset_id = self._asset_id(fallback_url or dash_url or hls_url or root_url)
        media_url = fallback_url or dash_url or hls_url
        if not media_url or not asset_id:
            return None

        is_crosspost = bool(value.get("crosspost_parent") or crosspost_values)
        parent_id = str(value.get("crosspost_parent") or "").removeprefix("t3_") or None
        post_url = f"https://www.reddit.com{permalink}"
        fingerprint = hashlib.sha256(f"reddit-media\0{asset_id}".encode()).hexdigest()
        return SourceCandidate(
            post_id=post_id,
            title=str(value.get("title") or "Untitled Reddit video"),
            post_url=post_url,
            community=str(value.get("subreddit") or community),
            published_at=datetime.fromtimestamp(created, tz=UTC),
            score=self._integer(value.get("score")),
            comment_count=self._integer(value.get("num_comments")),
            flair=str(value.get("link_flair_text")) if value.get("link_flair_text") else None,
            nsfw=bool(value.get("over_18")),
            is_crosspost=is_crosspost,
            crosspost_parent_id=parent_id,
            media_type=MediaType.GIF if bool(reddit_video.get("is_gif")) else MediaType.VIDEO,
            thumbnail_url=self._safe_thumbnail(value.get("thumbnail")),
            media_url=media_url,
            author=str(value.get("author")) if value.get("author") else None,
            rights_status="unknown",
            source_fingerprint=fingerprint,
            raw_metadata={
                "source": "arctic_shift",
                "archive_backend": self.base_host,
                "retrieved_on": self._integer(value.get("retrieved_on")),
                "reddit_media": {
                    "asset_id": asset_id,
                    "cache_key": f"https://v.redd.it/{asset_id}",
                    "fallback_url": fallback_url,
                    "dash_url": dash_url,
                    "hls_url": hls_url,
                    "has_audio": has_audio,
                    "width": width,
                    "height": height,
                    "duration": self._number(reddit_video.get("duration")),
                    "transcoding_status": "completed",
                },
            },
        )

    def _sort_candidates(
        self,
        profile: SourceProfile,
        candidates: list[SourceCandidate],
    ) -> list[SourceCandidate]:
        now = datetime.now(UTC)
        maturity_cutoff = now - timedelta(hours=self.settings.archive_score_maturity_hours)
        if profile.sort == "new":
            return sorted(candidates, key=lambda value: value.published_at, reverse=True)
        if profile.sort == "hot":
            return sorted(
                candidates,
                key=lambda value: (
                    value.published_at <= maturity_cutoff,
                    math.log10(max(1, value.score or 0))
                    - math.log10(max(2.0, (now - value.published_at).total_seconds() / 3600 + 2)),
                    value.comment_count or 0,
                ),
                reverse=True,
            )
        return sorted(
            candidates,
            key=lambda value: (
                value.published_at <= maturity_cutoff,
                value.score or 0,
                value.comment_count or 0,
                value.published_at,
            ),
            reverse=True,
        )

    def _cache_key(self, profile: SourceProfile) -> str:
        material = (
            "arctic-shift-v1\0"
            f"{self.base_url}\0{self.settings.archive_max_pages}\0"
            f"{self.settings.archive_min_short_edge}\0{self.settings.archive_require_audio}\0"
            f"{self.settings.archive_score_maturity_hours}\0{profile.model_dump_json()}"
        )
        return hashlib.sha256(material.encode()).hexdigest()

    @staticmethod
    def _reddit_video(value: dict[str, object]) -> dict[str, object] | None:
        for key in ("secure_media", "media"):
            media = value.get(key)
            if not isinstance(media, dict):
                continue
            reddit_video = media.get("reddit_video")
            if isinstance(reddit_video, dict):
                return reddit_video
        return None

    @staticmethod
    def _integer(value: object) -> int | None:
        try:
            return int(float(value)) if value is not None else None
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _number(value: object) -> float | None:
        try:
            return float(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _safe_media_url(value: object) -> str | None:
        if not value:
            return None
        url = str(value).replace("&amp;", "&")
        parsed = urlparse(url)
        hostname = (parsed.hostname or "").casefold()
        if parsed.scheme != "https" or not (
            hostname == "v.redd.it"
            or hostname == "packaged-media.redd.it"
            or hostname.endswith(".redditmedia.com")
        ):
            return None
        return url

    @staticmethod
    def _safe_thumbnail(value: object) -> str | None:
        if not value:
            return None
        url = str(value).replace("&amp;", "&")
        parsed = urlparse(url)
        return url if parsed.scheme == "https" and parsed.hostname else None

    @staticmethod
    def _asset_id(url: str | None) -> str | None:
        if not url:
            return None
        parts = [part for part in urlparse(url).path.split("/") if part]
        if not parts:
            return None
        identifier = parts[0]
        if not all(character.isalnum() or character in "_-" for character in identifier):
            return None
        return identifier
