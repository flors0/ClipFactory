"""Reddit discovery through an independent public metadata index."""

from app.sources.reddit_archive.provider import ArcticShiftSourceProvider

__all__ = ["ArcticShiftSourceProvider"]
