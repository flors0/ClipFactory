"""Select source providers without changing downstream services."""

from __future__ import annotations

from app.core.config import SourceSettings
from app.core.credentials import CredentialStore
from app.sources.mock.provider import MockRedditSourceProvider
from app.sources.reddit_archive.provider import ArcticShiftSourceProvider
from app.sources.reddit_oauth.provider import RedditOAuthSourceProvider
from app.sources.reddit_public.cache import SourceCache
from app.sources.source_provider import SourceProvider
from app.storage.database import Database


def create_source_provider(
    settings: SourceSettings,
    database: Database,
    credential_store: CredentialStore | None = None,
) -> SourceProvider:
    # `public` is retained as a persisted v1.0.x compatibility alias. It deliberately routes
    # to the archive backend because direct Reddit listings are no longer production-stable.
    if settings.reddit_provider in {"archive", "public"}:
        return ArcticShiftSourceProvider(settings, SourceCache(database))
    if settings.reddit_provider == "oauth":
        return RedditOAuthSourceProvider(settings, credential_store=credential_store)
    return MockRedditSourceProvider()
