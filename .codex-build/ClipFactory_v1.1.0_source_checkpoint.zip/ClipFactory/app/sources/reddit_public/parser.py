"""Parse public Reddit RSS and HTML without login or bypass behavior."""

from __future__ import annotations

import hashlib
import json
import re
from datetime import UTC, datetime
from html import unescape
from urllib.parse import urljoin

import feedparser
from bs4 import BeautifulSoup

from app.models.source_models import MediaType, SourceCandidate

POST_ID_PATTERN = re.compile(r"/comments/([a-z0-9]+)/", re.IGNORECASE)
MEDIA_EXTENSIONS = (".mp4", ".webm", ".mov", ".m3u8")
GIF_EXTENSIONS = (".gif", ".gifv")


def fingerprint_for(post_id: str, post_url: str, media_url: str | None) -> str:
    material = f"reddit\0{post_id}\0{post_url}\0{media_url or ''}".encode()
    return hashlib.sha256(material).hexdigest()


def post_id_from_url(url: str) -> str:
    match = POST_ID_PATTERN.search(url)
    if match:
        return match.group(1)
    return hashlib.sha256(url.encode()).hexdigest()[:16]


def infer_media_type(url: str | None, html: str = "") -> MediaType:
    lowered = (url or "").lower().split("?")[0]
    content = html.lower()
    if (
        lowered.endswith(GIF_EXTENSIONS)
        or "preview.redd.it" in lowered
        and "format=mp4" in (url or "").lower()
    ):
        return MediaType.GIF
    if lowered.endswith(MEDIA_EXTENSIONS) or "v.redd.it" in lowered:
        return MediaType.VIDEO
    if any(
        host in lowered
        for host in ("youtube.com", "youtu.be", "streamable.com", "vimeo.com", "tiktok.com")
    ):
        return MediaType.EXTERNAL
    if "<video" in content or "v.redd.it" in content:
        return MediaType.VIDEO
    if lowered.endswith((".jpg", ".jpeg", ".png", ".webp")):
        return MediaType.IMAGE
    return MediaType.UNKNOWN


def _entry_media_url(entry: object, content_html: str) -> str | None:
    for attribute in ("media_content", "enclosures", "links"):
        values = getattr(entry, attribute, None) or []
        for value in values:
            url = value.get("url") or value.get("href")
            media_type = value.get("type", "")
            if url and (
                media_type.startswith("video/")
                or infer_media_type(url) in {MediaType.VIDEO, MediaType.GIF, MediaType.EXTERNAL}
            ):
                return unescape(url)
    soup = BeautifulSoup(content_html, "html.parser")
    for node in soup.select("video[src], video source[src], a[href]"):
        url = node.get("src") or node.get("href")
        if url and infer_media_type(url) in {MediaType.VIDEO, MediaType.GIF, MediaType.EXTERNAL}:
            return unescape(url)
    return None


def parse_rss(payload: bytes | str, community: str) -> tuple[list[SourceCandidate], str | None]:
    feed = feedparser.parse(payload)
    if getattr(feed, "bozo", False) and not feed.entries:
        raise ValueError(f"Invalid Reddit feed: {feed.bozo_exception}")
    description = None
    feed_info = getattr(feed, "feed", {})
    if feed_info:
        description = feed_info.get("subtitle") or feed_info.get("description")
    candidates: list[SourceCandidate] = []
    for entry in feed.entries:
        link = str(entry.get("link", ""))
        if not link:
            continue
        title = unescape(str(entry.get("title", "Untitled")))
        content_values = entry.get("content", [])
        content_html = " ".join(str(value.get("value", "")) for value in content_values)
        if not content_html:
            content_html = str(entry.get("summary", ""))
        media_url = _entry_media_url(entry, content_html)
        post_id = post_id_from_url(link)
        parsed_time = entry.get("published_parsed") or entry.get("updated_parsed")
        published = datetime(*parsed_time[:6], tzinfo=UTC) if parsed_time else datetime.now(UTC)
        author = str(entry.get("author", "")).removeprefix("/u/") or None
        flair_match = re.search(
            r"class=[\"']linkflairlabel[\"'][^>]*>(.*?)<", content_html, re.I | re.S
        )
        flair = (
            BeautifulSoup(flair_match.group(1), "html.parser").get_text(strip=True)
            if flair_match
            else None
        )
        lowered = content_html.lower()
        nsfw = "over 18" in lowered or "nsfw" in lowered
        candidates.append(
            SourceCandidate(
                post_id=post_id,
                title=title,
                post_url=link,
                community=community,
                published_at=published,
                flair=flair,
                nsfw=nsfw,
                is_crosspost="crosspost" in lowered,
                media_type=infer_media_type(media_url or link, content_html),
                thumbnail_url=_find_first_image(content_html),
                media_url=media_url,
                author=author,
                source_fingerprint=fingerprint_for(post_id, link, media_url),
                raw_metadata={"source": "rss"},
            )
        )
    return candidates, description


def _find_first_image(html: str) -> str | None:
    soup = BeautifulSoup(html, "html.parser")
    image = soup.find("img")
    return unescape(image.get("src")) if image and image.get("src") else None


def parse_listing_html(
    payload: str, community: str, base_url: str
) -> tuple[list[SourceCandidate], str | None, str | None]:
    soup = BeautifulSoup(payload, "html.parser")
    description_node = soup.select_one('meta[name="description"]')
    description = description_node.get("content") if description_node else None
    candidates: list[SourceCandidate] = []
    for post in soup.select("shreddit-post"):
        post_id = str(post.get("id", "")).removeprefix("t3_")
        permalink = str(post.get("permalink", "")).strip()
        if not post_id or not permalink:
            continue
        post_url = urljoin(base_url, permalink)
        title = unescape(str(post.get("post-title", "Untitled")))
        media_url = post.get("content-href") or post.get("url")
        timestamp = post.get("created-timestamp")
        try:
            published = datetime.fromisoformat(str(timestamp).replace("Z", "+00:00"))
        except (TypeError, ValueError):
            published = datetime.now(UTC)
        score = _parse_int(post.get("score"))
        comments = _parse_int(post.get("comment-count"))
        nsfw = str(post.get("nsfw", "false")).lower() == "true"
        candidates.append(
            SourceCandidate(
                post_id=post_id,
                title=title,
                post_url=post_url,
                community=community,
                published_at=published,
                score=score,
                comment_count=comments,
                flair=post.get("post-flair"),
                nsfw=nsfw,
                is_crosspost=bool(post.get("crosspost-root-id")),
                crosspost_parent_id=post.get("crosspost-root-id"),
                media_type=infer_media_type(str(media_url or post_url), str(post)),
                thumbnail_url=post.get("thumbnail"),
                media_url=str(media_url) if media_url else None,
                author=post.get("author"),
                source_fingerprint=fingerprint_for(post_id, post_url, str(media_url or "")),
                raw_metadata={"source": "html"},
            )
        )
    if not candidates:
        candidates.extend(_parse_json_ld(soup, community, base_url))
    next_url = _listing_next_url(soup, base_url)
    return candidates, description, next_url


def _listing_next_url(soup: BeautifulSoup, base_url: str) -> str | None:
    """Find only Reddit-advertised HTML pagination targets.

    Reddit's logged-out page can now ship an application shell and declare the
    server-rendered feed URL in ``shreddit-feed[reload-url]``. Subsequent HTML
    fragments expose their cursor on a ``faceplate-partial`` element instead
    of a traditional ``rel=next`` link.
    """

    next_link = soup.select_one('a[rel="next"][href]')
    if next_link:
        return urljoin(base_url, str(next_link.get("href")))

    feed = soup.select_one("shreddit-feed[reload-url]")
    if feed:
        return urljoin(base_url, str(feed.get("reload-url")))

    partial = soup.select_one(
        'faceplate-partial[src*="/svc/shreddit/community-more-posts/"][src*="after="]'
    )
    if partial:
        return urljoin(base_url, str(partial.get("src")))
    return None


def _parse_json_ld(soup: BeautifulSoup, community: str, base_url: str) -> list[SourceCandidate]:
    results: list[SourceCandidate] = []
    for script in soup.select('script[type="application/ld+json"]'):
        try:
            data = json.loads(script.string or "{}")
        except json.JSONDecodeError:
            continue
        values = data if isinstance(data, list) else [data]
        for value in values:
            if not isinstance(value, dict) or value.get("@type") not in {
                "SocialMediaPosting",
                "VideoObject",
            }:
                continue
            post_url = urljoin(
                base_url, str(value.get("url") or value.get("mainEntityOfPage") or "")
            )
            if not post_url:
                continue
            media_url = value.get("contentUrl") or value.get("embedUrl")
            post_id = post_id_from_url(post_url)
            date_text = value.get("datePublished")
            try:
                published = datetime.fromisoformat(str(date_text).replace("Z", "+00:00"))
            except (TypeError, ValueError):
                published = datetime.now(UTC)
            results.append(
                SourceCandidate(
                    post_id=post_id,
                    title=str(value.get("headline") or value.get("name") or "Untitled"),
                    post_url=post_url,
                    community=community,
                    published_at=published,
                    media_type=infer_media_type(str(media_url or post_url)),
                    thumbnail_url=value.get("thumbnailUrl"),
                    media_url=str(media_url) if media_url else None,
                    source_fingerprint=fingerprint_for(post_id, post_url, str(media_url or "")),
                    raw_metadata={"source": "json_ld"},
                )
            )
    return results


def _parse_int(value: object) -> int | None:
    if value is None:
        return None
    text = str(value).replace(",", "").strip().lower()
    multiplier = 1
    if text.endswith("k"):
        multiplier, text = 1000, text[:-1]
    try:
        return int(float(text) * multiplier)
    except ValueError:
        return None
