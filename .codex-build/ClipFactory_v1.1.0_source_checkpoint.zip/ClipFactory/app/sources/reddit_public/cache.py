"""TTL cache for low-rate public source requests."""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta

from app.storage.database import Database


class SourceCache:
    def __init__(self, database: Database):
        self.database = database

    def get(self, key: str) -> dict[str, object] | None:
        row = self.database.fetchone(
            "SELECT payload, expires_at FROM source_cache WHERE cache_key = ?", (key,)
        )
        if not row:
            return None
        if datetime.fromisoformat(row["expires_at"]) <= datetime.now(UTC):
            self.database.execute("DELETE FROM source_cache WHERE cache_key = ?", (key,))
            return None
        return json.loads(row["payload"])

    def put(self, key: str, value: dict[str, object], ttl_seconds: int) -> None:
        now = datetime.now(UTC)
        self.database.execute(
            "INSERT INTO source_cache(cache_key, payload, expires_at, created_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(cache_key) DO UPDATE SET payload=excluded.payload, expires_at=excluded.expires_at, created_at=excluded.created_at",
            (
                key,
                json.dumps(value, default=str),
                (now + timedelta(seconds=ttl_seconds)).isoformat(),
                now.isoformat(),
            ),
        )
