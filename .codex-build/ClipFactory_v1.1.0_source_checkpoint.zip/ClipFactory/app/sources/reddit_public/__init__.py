"""Public Reddit provider."""

from app.sources.reddit_public.provider import PublicRedditSourceProvider

__all__ = ["PublicRedditSourceProvider"]
