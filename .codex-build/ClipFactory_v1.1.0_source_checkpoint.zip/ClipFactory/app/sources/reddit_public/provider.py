"""Low-rate public Reddit provider using RSS and public HTML fallbacks."""

from __future__ import annotations

import hashlib
import logging
from datetime import UTC, datetime
from threading import Event
from urllib.parse import parse_qsl, urlencode, urlparse

import httpx
from tenacity import Retrying, retry_if_exception_type, stop_after_attempt, wait_exponential

from app.core.config import SourceSettings
from app.core.exceptions import CancelledError, SourceAccessError
from app.models.source_models import DiscoveryResult, SourceHealth, SourceProfile
from app.sources.reddit_public.cache import SourceCache
from app.sources.reddit_public.parser import parse_listing_html, parse_rss
from app.sources.source_provider import CandidateFilter, SourceProvider

logger = logging.getLogger(__name__)


class PublicRedditSourceProvider(SourceProvider):
    name = "public_reddit"

    def __init__(
        self, settings: SourceSettings, cache: SourceCache, client: httpx.Client | None = None
    ):
        self.settings = settings
        self.cache = cache
        self.client = client or httpx.Client(
            timeout=settings.timeout_seconds,
            follow_redirects=True,
            headers={
                "User-Agent": settings.user_agent,
                "Accept": "application/atom+xml,text/html;q=0.9",
            },
        )
        self.filter = CandidateFilter()

    def discover(
        self, profile: SourceProfile, *, cancel_event: Event | None = None
    ) -> DiscoveryResult:
        cancel_event = cancel_event or Event()
        cache_key = hashlib.sha256(profile.model_dump_json().encode()).hexdigest()
        cached = self.cache.get(cache_key)
        if cached:
            result = DiscoveryResult.model_validate(cached)
            result.health.cache_hit = True
            return result
        if cancel_event.is_set():
            raise CancelledError("Source discovery was cancelled.")
        warnings: list[str] = []
        feed_url = self._feed_url(profile)
        candidates = []
        description = None
        try:
            response = self._get(feed_url, cancel_event)
            candidates, description = parse_rss(response.content, profile.community)
        except (httpx.HTTPError, ValueError, SourceAccessError) as error:
            warnings.append(f"Public RSS was unavailable: {error}")
        if len(candidates) < profile.candidate_limit:
            next_url: str | None = self._listing_url(profile)
            server_feed_url = self._server_feed_url(profile)
            visited_urls: set[tuple[str, str, tuple[tuple[str, str], ...]]] = set()
            pages = 0
            try:
                while next_url and len(candidates) < profile.candidate_limit and pages < 10:
                    if not self._is_reddit_url(next_url):
                        warnings.append(
                            "Reddit pagination returned a non-Reddit URL and was stopped."
                        )
                        break
                    next_url_key = self._url_key(next_url)
                    if next_url_key in visited_urls:
                        warnings.append("Reddit pagination repeated a URL and was stopped.")
                        break
                    visited_urls.add(next_url_key)
                    if cancel_event.wait(self.settings.request_interval_seconds):
                        raise CancelledError("Source discovery was cancelled.")
                    html_response = self._get(next_url, cancel_event, accept_html=True)
                    html_candidates, html_description, advertised_next_url = parse_listing_html(
                        html_response.text,
                        profile.community,
                        str(html_response.url),
                    )
                    existing = {candidate.post_id for candidate in candidates}
                    candidates.extend(
                        candidate
                        for candidate in html_candidates
                        if candidate.post_id not in existing
                    )
                    description = description or html_description
                    pages += 1
                    next_url = advertised_next_url
                    if not next_url and self._url_key(server_feed_url) not in visited_urls:
                        next_url = server_feed_url
                        if not html_candidates:
                            warnings.append(
                                "Reddit's standard page contained no server-rendered posts; "
                                "the public HTML feed declared by the site was used."
                            )
                    if not html_candidates and not next_url:
                        break
            except (httpx.HTTPError, ValueError, SourceAccessError) as error:
                warnings.append(f"Public HTML fallback was unavailable: {error}")
        filtered = self.filter.apply(profile, candidates)
        if not candidates:
            raise SourceAccessError(
                "Reddit returned no accessible public listing. ClipFactory will not bypass a block; retry later or switch to the OAuth provider."
            )
        result = DiscoveryResult(
            profile_id=profile.id,
            community_description=description,
            candidates=filtered,
            warnings=warnings,
            health=SourceHealth(
                provider=self.name,
                reachable=True,
                checked_at=datetime.now(UTC),
                candidate_count=len(filtered),
                message=f"Found {len(filtered)} candidates after profile filtering.",
            ),
        )
        self.cache.put(cache_key, result.model_dump(mode="json"), self.settings.cache_ttl_seconds)
        return result

    def _feed_url(self, profile: SourceProfile) -> str:
        sort_path = {"new": "new", "hot": "hot", "top": "top"}[profile.sort]
        query = {"limit": min(profile.candidate_limit, 100)}
        if profile.sort == "top":
            query["t"] = profile.time_filter
        return f"https://www.reddit.com/r/{profile.community}/{sort_path}/.rss?{urlencode(query)}"

    def _listing_url(self, profile: SourceProfile) -> str:
        query = {"limit": min(profile.candidate_limit, 100)}
        if profile.sort == "top":
            query["t"] = profile.time_filter
        return f"https://www.reddit.com/r/{profile.community}/{profile.sort}/?{urlencode(query)}"

    def _server_feed_url(self, profile: SourceProfile) -> str:
        query = {"name": profile.community}
        if profile.sort == "top":
            query["t"] = profile.time_filter.upper()
        return (
            "https://www.reddit.com/svc/shreddit/community-more-posts/"
            f"{profile.sort}/?{urlencode(query)}"
        )

    def _get(self, url: str, cancel_event: Event, *, accept_html: bool = False) -> httpx.Response:
        headers = {
            "Accept": "text/html"
            if accept_html
            else "application/atom+xml,application/rss+xml;q=0.9"
        }
        retryer = Retrying(
            stop=stop_after_attempt(self.settings.retry_count + 1),
            wait=wait_exponential(multiplier=1, min=1, max=12),
            retry=retry_if_exception_type(
                (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError)
            ),
            reraise=True,
        )
        for attempt in retryer:
            with attempt:
                if cancel_event.is_set():
                    raise CancelledError("Source discovery was cancelled.")
                response = self.client.get(url, headers=headers)
                if response.status_code in {403, 429}:
                    raise SourceAccessError(
                        f"Public Reddit access returned HTTP {response.status_code}; no bypass was attempted."
                    )
                response.raise_for_status()
                if not self._is_reddit_url(str(response.url)):
                    raise SourceAccessError(
                        "Reddit listing redirected outside reddit.com; discovery stopped safely."
                    )
                return response
        raise SourceAccessError("Public Reddit request failed.")

    @staticmethod
    def _is_reddit_url(url: str) -> bool:
        return urlparse(url).hostname in {
            "reddit.com",
            "www.reddit.com",
            "old.reddit.com",
            "new.reddit.com",
        }

    @staticmethod
    def _url_key(url: str) -> tuple[str, str, tuple[tuple[str, str], ...]]:
        parsed = urlparse(url)
        return (
            (parsed.hostname or "").lower(),
            parsed.path.rstrip("/") or "/",
            tuple(sorted(parse_qsl(parsed.query, keep_blank_values=True))),
        )
