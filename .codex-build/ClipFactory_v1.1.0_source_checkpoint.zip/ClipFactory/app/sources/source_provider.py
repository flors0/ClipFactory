"""Source provider interface and candidate filtering."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import UTC, datetime, timedelta
from threading import Event

from app.models.source_models import DiscoveryResult, MediaType, SourceCandidate, SourceProfile


class SourceProvider(ABC):
    name: str

    @abstractmethod
    def discover(
        self,
        profile: SourceProfile,
        *,
        cancel_event: Event | None = None,
    ) -> DiscoveryResult:
        """Return candidates using the common source contract."""


class CandidateFilter:
    """Apply profile policy without mixing rights and content quality decisions."""

    def apply(
        self, profile: SourceProfile, candidates: list[SourceCandidate]
    ) -> list[SourceCandidate]:
        oldest = datetime.now(UTC) - timedelta(hours=profile.max_post_age_hours)
        allowed = {value.casefold() for value in profile.allowed_flairs}
        blocked = {value.casefold() for value in profile.blocked_flairs}
        accepted: list[SourceCandidate] = []
        seen_posts: set[str] = set()
        seen_fingerprints: set[str] = set()
        for candidate in candidates:
            if candidate.post_id in seen_posts or candidate.source_fingerprint in seen_fingerprints:
                continue
            if candidate.published_at < oldest:
                continue
            if candidate.score is not None and candidate.score < profile.min_score:
                continue
            if (
                candidate.comment_count is not None
                and candidate.comment_count < profile.min_comment_count
            ):
                continue
            if candidate.nsfw and not profile.allow_nsfw:
                continue
            if candidate.is_crosspost and not profile.allow_crossposts:
                continue
            flair = (candidate.flair or "").casefold()
            if allowed and flair not in allowed:
                continue
            if flair and flair in blocked:
                continue
            if profile.require_video:
                if candidate.media_type == MediaType.GIF and not profile.allow_gifs:
                    continue
                if candidate.media_type not in {
                    MediaType.VIDEO,
                    MediaType.GIF,
                    MediaType.EXTERNAL,
                    MediaType.UNKNOWN,
                }:
                    continue
            seen_posts.add(candidate.post_id)
            seen_fingerprints.add(candidate.source_fingerprint)
            accepted.append(candidate)
            if len(accepted) >= profile.candidate_limit:
                break
        return accepted
