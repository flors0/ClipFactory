"""Deterministic mock source provider."""

from app.sources.mock.provider import MockRedditSourceProvider

__all__ = ["MockRedditSourceProvider"]
