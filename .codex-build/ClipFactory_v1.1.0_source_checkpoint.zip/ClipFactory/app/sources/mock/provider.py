"""Mock source provider for safe tests and offline demonstrations."""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime, timedelta
from pathlib import Path
from threading import Event

from app.models.source_models import (
    DiscoveryResult,
    MediaType,
    SourceCandidate,
    SourceHealth,
    SourceProfile,
)
from app.sources.source_provider import CandidateFilter, SourceProvider

MOCK_TITLES = (
    "An unexpected leap across the window",
    "A playful chase through the cardboard maze",
    "The quiet observer finally joins the action",
    "A perfectly timed reaction near the doorway",
    "The curious explorer discovers a hidden toy",
    "A dramatic entrance interrupts the calm room",
    "The smallest participant solves the puzzle",
    "A sleepy afternoon turns into sudden chaos",
    "The patient hunter misses an obvious target",
    "A new friendship starts beside the sofa",
    "The cautious climber reaches the top shelf",
    "An ordinary snack creates a surprising contest",
)


class MockRedditSourceProvider(SourceProvider):
    name = "mock_reddit"

    def __init__(self, media_paths: list[Path] | None = None):
        self.media_paths = media_paths or []
        self.filter = CandidateFilter()

    def discover(
        self, profile: SourceProfile, *, cancel_event: Event | None = None
    ) -> DiscoveryResult:
        candidates: list[SourceCandidate] = []
        count = len(self.media_paths) if self.media_paths else min(profile.candidate_limit, 12)
        for index in range(count):
            path = self.media_paths[index] if index < len(self.media_paths) else None
            post_id = f"mock-{index + 1}"
            url = (
                path.resolve().as_uri()
                if path
                else f"https://example.invalid/video-{index + 1}.mp4"
            )
            fingerprint = hashlib.sha256(url.encode()).hexdigest()
            candidates.append(
                SourceCandidate(
                    post_id=post_id,
                    title=f"{profile.community}: {MOCK_TITLES[index % len(MOCK_TITLES)]}",
                    post_url=f"https://www.reddit.com/r/{profile.community}/comments/{post_id}/sample/",
                    community=profile.community,
                    published_at=datetime.now(UTC) - timedelta(hours=index),
                    score=1000 - index * 20,
                    comment_count=100 - index,
                    media_type=MediaType.VIDEO,
                    media_url=url,
                    source_fingerprint=fingerprint,
                    raw_metadata={"source": "mock"},
                )
            )
        filtered = self.filter.apply(profile, candidates)
        return DiscoveryResult(
            profile_id=profile.id,
            community_description=f"Mock community about {profile.community}",
            candidates=filtered,
            health=SourceHealth(
                provider=self.name,
                reachable=True,
                checked_at=datetime.now(UTC),
                candidate_count=len(filtered),
                message="Deterministic mock discovery completed.",
            ),
        )
