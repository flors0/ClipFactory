"""Normalize subreddit input into source profiles."""

from __future__ import annotations

import re
from urllib.parse import urlparse

from app.models.source_models import RightsMode, SourceProfile

COMMUNITY_PATTERN = re.compile(r"^[A-Za-z0-9_]{1,100}$")


def normalize_subreddit(value: str) -> str:
    candidate = value.strip()
    if not candidate:
        raise ValueError("Subreddit input cannot be empty.")
    if "://" in candidate:
        parsed = urlparse(candidate)
        if parsed.scheme not in {"http", "https"} or parsed.hostname not in {
            "reddit.com",
            "www.reddit.com",
            "old.reddit.com",
            "new.reddit.com",
        }:
            raise ValueError("Only public reddit.com subreddit URLs are accepted.")
        parts = [part for part in parsed.path.split("/") if part]
        try:
            marker = next(index for index, part in enumerate(parts) if part.lower() == "r")
            candidate = parts[marker + 1]
        except (StopIteration, IndexError) as error:
            raise ValueError("URL does not identify a subreddit.") from error
    else:
        candidate = candidate.strip("/")
        if candidate.lower().startswith("r/"):
            candidate = candidate[2:].strip("/")
    if not COMMUNITY_PATTERN.fullmatch(candidate):
        raise ValueError("Subreddit contains unsupported characters.")
    return candidate


class SourceProfileFactory:
    def create(
        self,
        subreddit: str,
        *,
        name: str | None = None,
        sort: str = "top",
        time_filter: str = "week",
        candidate_limit: int = 50,
        min_score: int = 0,
        min_comment_count: int = 0,
        max_post_age_hours: int = 168,
        require_video: bool = True,
        allow_nsfw: bool = False,
        allow_gifs: bool = True,
        allow_crossposts: bool = True,
        allowed_flairs: list[str] | None = None,
        blocked_flairs: list[str] | None = None,
        language: str = "en",
        theme_hint: str | None = None,
        rights_mode: RightsMode = RightsMode.MANUAL_REVIEW,
    ) -> SourceProfile:
        community = normalize_subreddit(subreddit)
        return SourceProfile(
            name=name or community,
            community=community,
            source_url=f"https://www.reddit.com/r/{community}/",
            sort=sort,
            time_filter=time_filter,
            candidate_limit=candidate_limit,
            min_score=min_score,
            min_comment_count=min_comment_count,
            max_post_age_hours=max_post_age_hours,
            require_video=require_video,
            allow_nsfw=allow_nsfw,
            allow_gifs=allow_gifs,
            allow_crossposts=allow_crossposts,
            allowed_flairs=allowed_flairs or [],
            blocked_flairs=blocked_flairs or [],
            language=language,
            theme_hint=theme_hint,
            rights_mode=rights_mode,
        )
