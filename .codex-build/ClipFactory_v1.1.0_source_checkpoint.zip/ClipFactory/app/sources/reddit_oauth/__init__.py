"""Official Reddit OAuth provider."""

from app.sources.reddit_oauth.provider import RedditOAuthSourceProvider

__all__ = ["RedditOAuthSourceProvider"]
