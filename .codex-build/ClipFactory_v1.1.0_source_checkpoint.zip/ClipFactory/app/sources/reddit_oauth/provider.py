"""Reddit OAuth listing provider with the same candidate contract as public discovery."""

from __future__ import annotations

from datetime import UTC, datetime
from threading import Event

import httpx

from app.core.config import SourceSettings
from app.core.credentials import (
    REDDIT_CLIENT_ID,
    REDDIT_CLIENT_SECRET,
    REDDIT_REFRESH_TOKEN,
    CredentialStore,
    resolve_credential,
)
from app.core.exceptions import CancelledError, OAuthError, SourceAccessError
from app.models.source_models import (
    DiscoveryResult,
    MediaType,
    SourceCandidate,
    SourceHealth,
    SourceProfile,
)
from app.sources.reddit_public.parser import fingerprint_for, infer_media_type
from app.sources.source_provider import CandidateFilter, SourceProvider


class RedditOAuthSourceProvider(SourceProvider):
    name = "reddit_oauth"

    def __init__(
        self,
        settings: SourceSettings,
        client: httpx.Client | None = None,
        credential_store: CredentialStore | None = None,
    ):
        self.settings = settings
        self.client = client or httpx.Client(timeout=settings.timeout_seconds)
        self.credential_store = credential_store
        self.filter = CandidateFilter()

    def discover(
        self, profile: SourceProfile, *, cancel_event: Event | None = None
    ) -> DiscoveryResult:
        cancel_event = cancel_event or Event()
        token = self._access_token()
        if cancel_event.is_set():
            raise CancelledError("Source discovery was cancelled.")
        params = {"limit": min(profile.candidate_limit, 100), "raw_json": 1}
        if profile.sort == "top":
            params["t"] = profile.time_filter
        response = self.client.get(
            f"https://oauth.reddit.com/r/{profile.community}/{profile.sort}",
            params=params,
            headers={"Authorization": f"Bearer {token}", "User-Agent": self.settings.user_agent},
        )
        if response.status_code in {401, 403}:
            raise OAuthError("Reddit OAuth credentials were rejected or lack access.")
        if response.status_code == 429:
            raise SourceAccessError("Reddit OAuth rate limit reached; retry later.")
        response.raise_for_status()
        data = response.json().get("data", {})
        candidates = [
            self._candidate(child.get("data", {}), profile.community)
            for child in data.get("children", [])
        ]
        candidates = [candidate for candidate in candidates if candidate is not None]
        filtered = self.filter.apply(profile, candidates)
        return DiscoveryResult(
            profile_id=profile.id,
            community_description=None,
            candidates=filtered,
            health=SourceHealth(
                provider=self.name,
                reachable=True,
                checked_at=datetime.now(UTC),
                candidate_count=len(filtered),
                message="Official OAuth listing completed.",
            ),
        )

    def _access_token(self) -> str:
        client_id = resolve_credential(
            self.credential_store, REDDIT_CLIENT_ID, self.settings.oauth_client_id_env
        )
        client_secret = resolve_credential(
            self.credential_store,
            REDDIT_CLIENT_SECRET,
            self.settings.oauth_client_secret_env,
        )
        refresh_token = resolve_credential(
            self.credential_store,
            REDDIT_REFRESH_TOKEN,
            self.settings.oauth_refresh_token_env,
        )
        if not all((client_id, client_secret, refresh_token)):
            raise OAuthError("Reddit OAuth credentials are incomplete in Settings.")
        response = self.client.post(
            "https://www.reddit.com/api/v1/access_token",
            data={"grant_type": "refresh_token", "refresh_token": refresh_token},
            auth=(client_id, client_secret),
            headers={"User-Agent": self.settings.user_agent},
        )
        response.raise_for_status()
        token = response.json().get("access_token")
        if not token:
            raise OAuthError("Reddit OAuth response did not contain an access token.")
        return str(token)

    def _candidate(self, value: dict[str, object], community: str) -> SourceCandidate | None:
        post_id = str(value.get("id", ""))
        permalink = str(value.get("permalink", ""))
        if not post_id or not permalink:
            return None
        post_url = f"https://www.reddit.com{permalink}"
        media = value.get("secure_media") or value.get("media") or {}
        reddit_video = media.get("reddit_video", {}) if isinstance(media, dict) else {}
        media_url = reddit_video.get("fallback_url") if isinstance(reddit_video, dict) else None
        media_url = media_url or value.get("url_overridden_by_dest")
        created = datetime.fromtimestamp(float(value.get("created_utc", 0)), tz=UTC)
        is_video = bool(value.get("is_video"))
        hint = str(value.get("post_hint", ""))
        media_type = MediaType.VIDEO if is_video else infer_media_type(str(media_url or post_url))
        if hint == "rich:video" and media_type == MediaType.UNKNOWN:
            media_type = MediaType.EXTERNAL
        return SourceCandidate(
            post_id=post_id,
            title=str(value.get("title", "Untitled")),
            post_url=post_url,
            community=community,
            published_at=created,
            score=int(value.get("score", 0)),
            comment_count=int(value.get("num_comments", 0)),
            flair=value.get("link_flair_text"),
            nsfw=bool(value.get("over_18")),
            is_crosspost=bool(value.get("crosspost_parent")),
            crosspost_parent_id=value.get("crosspost_parent"),
            media_type=media_type,
            thumbnail_url=value.get("thumbnail")
            if str(value.get("thumbnail", "")).startswith("http")
            else None,
            media_url=str(media_url) if media_url else None,
            author=str(value.get("author", "")) or None,
            source_fingerprint=fingerprint_for(post_id, post_url, str(media_url or "")),
            raw_metadata={"source": "reddit_oauth", "domain": value.get("domain")},
        )
