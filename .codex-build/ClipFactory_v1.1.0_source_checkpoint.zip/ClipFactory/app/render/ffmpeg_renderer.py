"""Cancelable, atomic vertical FFmpeg renderer."""

from __future__ import annotations

import math
import os
import shutil
import subprocess
import sys
import time
from collections.abc import Callable
from pathlib import Path
from threading import Event

from app.core.config import RenderSettings
from app.core.exceptions import CancelledError, RenderError
from app.media.media_probe import MediaProbe
from app.models.preset_models import DurationEnforcement, Preset
from app.models.render_models import RenderPlan, TimelineSegment
from app.planning.duration_rules import evaluate_duration
from app.presets.layout import LayoutEngine
from app.render.audio_mixer import AudioMixer
from app.render.overlay_renderer import OverlayRenderer
from app.render.subtitle_renderer import SubtitleRenderer


class FFmpegRenderer:
    def __init__(
        self,
        temporary_root: Path,
        *,
        ffmpeg_path: str = "ffmpeg",
        ffprobe_path: str = "ffprobe",
        cleanup: bool = True,
        runtime_settings: RenderSettings | None = None,
    ):
        self.temporary_root = temporary_root.resolve()
        self.temporary_root.mkdir(parents=True, exist_ok=True)
        self.ffmpeg_path = ffmpeg_path
        self.probe = MediaProbe(ffprobe_path)
        self.cleanup = cleanup
        self.runtime_settings = runtime_settings or RenderSettings()
        self.overlays = OverlayRenderer()
        self.audio_mixer = AudioMixer()
        self.subtitles = SubtitleRenderer()

    def render(
        self,
        plan: RenderPlan,
        preset: Preset,
        *,
        cancel_event: Event | None = None,
        progress_callback: Callable[[int, str], None] | None = None,
    ) -> Path:
        cancel_event = cancel_event or Event()
        progress_callback = progress_callback or (lambda _value, _message: None)
        allowed, warnings = evaluate_duration(
            plan.target_duration_seconds,
            preset.duration,
            additional_clips_available=False,
        )
        if not allowed and preset.duration.enforcement != DurationEnforcement.WARN:
            raise RenderError(" ".join(warnings))
        staging = self.temporary_root / f"render-{plan.job_id}"
        if staging.exists():
            shutil.rmtree(staging)
        staging.mkdir(parents=True)
        output = Path(plan.output_path).resolve()
        if output == Path(output.anchor):
            raise RenderError("A filesystem root cannot be used as a render output.")
        output.parent.mkdir(parents=True, exist_ok=True)
        temporary_output = staging / "final.part.mp4"
        try:
            segments = self._normalize_timeline(
                plan,
                preset,
                staging,
                cancel_event,
                progress_callback,
            )
            concat_file = staging / "segments.txt"
            concat_file.write_text(
                "\n".join(f"file '{self._concat_escape(path)}'" for path in segments) + "\n",
                encoding="utf-8",
            )
            joined = staging / "joined.mp4"
            self._run(
                [
                    self.ffmpeg_path,
                    "-v",
                    "error",
                    "-f",
                    "concat",
                    "-safe",
                    "0",
                    "-i",
                    str(concat_file),
                    "-c",
                    "copy",
                    "-y",
                    str(joined),
                ],
                cancel_event,
            )
            progress_callback(72, "Joined normalized segments")
            has_shapes = any(
                not layer.hidden and layer.element_type.value == "shape" for layer in preset.layers
            )
            ass_path = (
                self.overlays.create_ass(plan, preset, staging / "overlays.ass")
                if plan.text_overlays_enabled or has_shapes
                else None
            )
            self._finalize(joined, temporary_output, ass_path, plan, preset, cancel_event)
            progress_callback(95, "Encoded overlays and mixed audio")
            if not temporary_output.is_file() or temporary_output.stat().st_size <= 0:
                raise RenderError("FFmpeg completed without a non-empty output file.")
            os.replace(temporary_output, output)
            progress_callback(100, "Render completed")
            return output
        finally:
            if self.cleanup and staging.exists():
                shutil.rmtree(staging, ignore_errors=True)

    def _normalize_timeline(
        self,
        plan: RenderPlan,
        preset: Preset,
        staging: Path,
        cancel_event: Event,
        progress_callback: Callable[[int, str], None],
    ) -> list[Path]:
        timeline = plan.timeline or self._legacy_timeline(plan, preset)
        if not timeline:
            raise RenderError("The render timeline contains no segments.")
        clip_segments = [segment for segment in timeline if segment.kind == "clip"]
        clip_ordinal = 0
        normalized: list[Path] = []
        for index, segment in enumerate(timeline):
            destination = staging / f"timeline-{index:03d}-{segment.kind}.mp4"
            if segment.kind == "clip":
                boundary_audio_fade = (
                    preset.transition.original_audio_fade_seconds
                    if preset.transition.enabled
                    and preset.transition.type != "cut"
                    and plan.transition_count > 0
                    else 0
                )
                visual_fade = (
                    preset.transition.duration_seconds
                    if preset.transition.enabled
                    and preset.transition.type == "fade"
                    and plan.transition_count > 0
                    else 0
                )
                if visual_fade:
                    boundary_audio_fade = visual_fade
                self._normalize_segment(
                    Path(segment.path),
                    segment.source_start_seconds,
                    segment.duration_seconds,
                    destination,
                    preset,
                    cancel_event,
                    background_path=Path(plan.background_path) if plan.background_path else None,
                    video_fade_in_seconds=visual_fade if clip_ordinal > 0 else 0,
                    video_fade_out_seconds=visual_fade
                    if clip_ordinal < len(clip_segments) - 1
                    else 0,
                    audio_fade_in_seconds=boundary_audio_fade if clip_ordinal > 0 else 0,
                    audio_fade_out_seconds=boundary_audio_fade
                    if clip_ordinal < len(clip_segments) - 1
                    else 0,
                )
                clip_ordinal += 1
            elif segment.kind == "transition":
                self._normalize_segment(
                    Path(segment.path),
                    segment.source_start_seconds,
                    segment.duration_seconds,
                    destination,
                    preset,
                    cancel_event,
                    full_canvas=True,
                    audio_volume=(
                        preset.audio.transition_volume if preset.transition.use_asset_audio else 0
                    ),
                    audio_fade_in_seconds=preset.transition.sound_fade_seconds,
                    audio_fade_out_seconds=preset.transition.sound_fade_seconds,
                )
            else:
                self._normalize_segment(
                    Path(segment.path),
                    segment.source_start_seconds,
                    segment.duration_seconds,
                    destination,
                    preset,
                    cancel_event,
                    full_canvas=True,
                    audio_volume=(
                        preset.interstitial.volume if preset.interstitial.use_asset_audio else 0
                    ),
                    fade_seconds=preset.interstitial.fade_seconds,
                )
            normalized.append(destination)
            progress_callback(
                10 + round(55 * (index + 1) / len(timeline)),
                f"Normalized timeline segment {index + 1} of {len(timeline)}",
            )
        return normalized

    @staticmethod
    def _legacy_timeline(plan: RenderPlan, preset: Preset) -> list[TimelineSegment]:
        """Reconstruct v1.0.5 plans so existing review items remain re-renderable."""
        values: list[TimelineSegment] = []
        cursor = 0.0

        def append_asset(kind: str, path: str | None, duration: float) -> None:
            nonlocal cursor
            if not path:
                return
            values.append(
                TimelineSegment(
                    kind=kind,
                    start_seconds=cursor,
                    end_seconds=cursor + duration,
                    path=path,
                )
            )
            cursor += duration

        if (
            plan.transition_path
            and preset.transition.enabled
            and preset.transition.type == "fixed_asset"
            and preset.transition.placement in {"intro", "all"}
        ):
            append_asset("transition", plan.transition_path, preset.transition.duration_seconds)
        if plan.interstitial_path and preset.interstitial.placement in {"intro", "all"}:
            append_asset(
                "interstitial",
                plan.interstitial_path,
                preset.interstitial.duration_seconds,
            )
        for index, clip in enumerate(plan.clips):
            values.append(
                TimelineSegment(
                    kind="clip",
                    start_seconds=cursor,
                    end_seconds=cursor + clip.duration_seconds,
                    path=clip.media_path,
                    source_start_seconds=clip.start_seconds,
                    clip_id=clip.clip_id,
                    rank=clip.rank,
                )
            )
            cursor += clip.duration_seconds
            if index >= len(plan.clips) - 1:
                continue
            if (
                plan.transition_path
                and preset.transition.enabled
                and preset.transition.type == "fixed_asset"
                and preset.transition.placement in {"between_clips", "all"}
            ):
                append_asset(
                    "transition",
                    plan.transition_path,
                    preset.transition.duration_seconds,
                )
            if plan.interstitial_path and preset.interstitial.placement in {
                "between_clips",
                "all",
            }:
                append_asset(
                    "interstitial",
                    plan.interstitial_path,
                    preset.interstitial.duration_seconds,
                )
        if plan.interstitial_path and preset.interstitial.placement in {"outro", "all"}:
            append_asset(
                "interstitial",
                plan.interstitial_path,
                preset.interstitial.duration_seconds,
            )
        if (
            plan.transition_path
            and preset.transition.enabled
            and preset.transition.type == "fixed_asset"
            and preset.transition.placement in {"outro", "all"}
        ):
            append_asset("transition", plan.transition_path, preset.transition.duration_seconds)
        return values

    def _normalize_segment(
        self,
        source: Path,
        start: float,
        duration: float,
        destination: Path,
        preset: Preset,
        cancel_event: Event,
        *,
        full_canvas: bool = False,
        audio_volume: float | None = None,
        fade_seconds: float | None = None,
        background_path: Path | None = None,
        video_fade_in_seconds: float = 0,
        video_fade_out_seconds: float = 0,
        audio_fade_in_seconds: float = 0,
        audio_fade_out_seconds: float = 0,
    ) -> None:
        info = self.probe.probe(source)
        if not info.has_audio and preset.audio.silence_handling == "reject":
            raise RenderError(f"Preset rejects silent source media: {source.name}")
        rect = LayoutEngine.video_rect(preset)
        if full_canvas:
            rect = type(rect)(0, 0, preset.width, preset.height)
        background_layer = next(
            (
                layer
                for layer in preset.layers
                if layer.element_type.value == "background" and not layer.hidden
            ),
            None,
        )
        background_color = (
            background_layer.background_color
            if background_layer and background_layer.background_color.alpha
            else preset.header.background
        )
        background = background_color.to_hex(include_alpha=False).replace("#", "0x")
        video_fade_in = min(
            fade_seconds if fade_seconds is not None else video_fade_in_seconds,
            duration / 3,
        )
        video_fade_out = min(
            fade_seconds if fade_seconds is not None else video_fade_out_seconds,
            duration / 3,
        )
        source_filters = [
            f"scale={rect.width}:{rect.height}:force_original_aspect_ratio=increase",
            f"crop={rect.width}:{rect.height}",
            "setsar=1",
            f"fps={preset.fps}",
        ]
        filters = [
            *source_filters,
            f"pad={preset.width}:{preset.height}:{rect.x}:{rect.y}:color={background}",
            "format=yuv420p",
        ]
        if video_fade_in > 0:
            filters.append(f"fade=t=in:st=0:d={video_fade_in:.3f}")
        if video_fade_out > 0:
            filters.append(
                f"fade=t=out:st={max(0, duration - video_fade_out):.3f}:d={video_fade_out:.3f}"
            )
        command = [
            self.ffmpeg_path,
            "-v",
            "error",
            *self._hardware_input_args(),
            "-ss",
            f"{start:.6f}",
            "-t",
            f"{duration:.6f}",
            "-i",
            str(source),
        ]
        has_background_asset = bool(
            background_path and background_path.is_file() and not full_canvas
        )
        if has_background_asset:
            assert background_path is not None
            if background_path.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp", ".bmp"}:
                command.extend(["-loop", "1", "-t", f"{duration:.6f}", "-i", str(background_path)])
            else:
                command.extend(
                    ["-stream_loop", "-1", "-t", f"{duration:.6f}", "-i", str(background_path)]
                )
        audio_input = "0:a:0"
        if not info.has_audio:
            command.extend(
                ["-f", "lavfi", "-t", f"{duration:.6f}", "-i", "anullsrc=r=48000:cl=stereo"]
            )
            audio_input = f"{2 if has_background_asset else 1}:a:0"
        audio_filters = [
            "aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo",
            f"volume={preset.audio.original_volume if audio_volume is None else audio_volume:.4f}",
        ]
        audio_fade_in = min(
            fade_seconds if fade_seconds is not None else audio_fade_in_seconds,
            duration / 3,
        )
        audio_fade_out = min(
            fade_seconds if fade_seconds is not None else audio_fade_out_seconds,
            duration / 3,
        )
        if audio_fade_in > 0:
            audio_filters.append(f"afade=t=in:st=0:d={audio_fade_in:.3f}")
        if audio_fade_out > 0:
            audio_filters.append(
                f"afade=t=out:st={max(0, duration - audio_fade_out):.3f}:d={audio_fade_out:.3f}"
            )
        command.extend(["-map", "[vout]" if has_background_asset else "0:v:0", "-map", audio_input])
        if has_background_asset:
            final_filters = []
            if video_fade_in > 0:
                final_filters.append(f"fade=t=in:st=0:d={video_fade_in:.3f}")
            if video_fade_out > 0:
                final_filters.append(
                    f"fade=t=out:st={max(0, duration - video_fade_out):.3f}:d={video_fade_out:.3f}"
                )
            final_filters.append("format=yuv420p")
            graph = (
                f"[0:v]{','.join(source_filters)},format=rgba[foreground];"
                f"[1:v]scale={preset.width}:{preset.height}:force_original_aspect_ratio=increase,"
                f"crop={preset.width}:{preset.height},setsar=1,fps={preset.fps},format=rgba[background];"
                f"[background][foreground]overlay={rect.x}:{rect.y}:shortest=1,"
                f"{','.join(final_filters)}[vout]"
            )
            command.extend(["-filter_complex", graph])
        else:
            command.extend(["-vf", ",".join(filters)])
        command.extend(
            [
                "-af",
                ",".join(audio_filters),
                "-c:v",
                self.video_codec_for(preset),
                "-preset",
                self.runtime_settings.preset,
                "-crf",
                str(self.crf_for(preset)),
                "-pix_fmt",
                preset.encoding.pixel_format,
                "-c:a",
                preset.encoding.audio_codec,
                "-b:a",
                self.audio_bitrate_for(preset),
                "-ar",
                "48000",
                "-ac",
                "2",
                "-t",
                f"{duration:.6f}",
                "-y",
                str(destination),
            ]
        )
        self._run(command, cancel_event)

    def _finalize(
        self,
        joined: Path,
        output: Path,
        ass_path: Path | None,
        plan: RenderPlan,
        preset: Preset,
        cancel_event: Event,
    ) -> None:
        command = [self.ffmpeg_path, "-v", "error", "-i", str(joined)]
        has_music = bool(plan.music_path)
        if has_music:
            command.extend(["-stream_loop", "-1", "-i", str(Path(plan.music_path).resolve())])
        for audio in plan.audio_overlays:
            command.extend(["-i", str(Path(audio.path).resolve())])
        visual_input_start = 1 + int(has_music) + len(plan.audio_overlays)
        for visual in plan.visual_overlays:
            path = Path(visual.path).resolve()
            if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp", ".bmp"}:
                command.extend(
                    ["-loop", "1", "-t", f"{plan.target_duration_seconds:.6f}", "-i", str(path)]
                )
            else:
                command.extend(["-stream_loop", "-1", "-i", str(path)])
        video_graph: list[str] = []
        current_video = "0:v"
        for index, visual in enumerate(plan.visual_overlays):
            input_index = visual_input_start + index
            image_label = f"visual{index}"
            next_video = f"video{index}"
            rotation = visual.rotation_degrees * math.pi / 180
            video_graph.append(
                f"[{input_index}:v]scale={visual.width}:{visual.height},format=rgba,"
                f"colorchannelmixer=aa={visual.opacity:.4f},"
                f"rotate={rotation:.8f}:ow=rotw(iw):oh=roth(ih):c=none[{image_label}]"
            )
            video_graph.append(
                f"[{current_video}][{image_label}]overlay="
                f"{visual.x}-(overlay_w-{visual.width})/2:"
                f"{visual.y}-(overlay_h-{visual.height})/2:"
                f"enable='between(t,{visual.start_seconds:.6f},{visual.end_seconds:.6f})'"
                f"[{next_video}]"
            )
            current_video = next_video
        fonts_option = (
            f":fontsdir='{self._filter_escape(Path(plan.font_directory))}'"
            if plan.font_directory
            else ""
        )
        video_filters: list[str] = []
        if ass_path:
            video_filters.append(f"ass='{self._filter_escape(ass_path)}'{fonts_option}")
        if plan.subtitle_path:
            subtitle = self.subtitles.validate(Path(plan.subtitle_path))
            video_filters.append(f"subtitles='{self._filter_escape(subtitle)}'{fonts_option}")
        video_graph.append(
            f"[{current_video}]{','.join(video_filters) if video_filters else 'null'}[vout]"
        )
        audio_graph, audio_map = self.audio_mixer.final_filter(
            preset.audio,
            has_music=has_music,
            duration=plan.target_duration_seconds,
            audio_overlays=plan.audio_overlays,
        )
        command.extend(
            [
                "-filter_complex",
                f"{';'.join(video_graph)};{audio_graph}",
                "-map",
                "[vout]",
                "-map",
                audio_map,
                "-c:v",
                self.video_codec_for(preset),
                "-preset",
                self.runtime_settings.preset,
                "-crf",
                str(self.crf_for(preset)),
                "-pix_fmt",
                preset.encoding.pixel_format,
                "-c:a",
                preset.encoding.audio_codec,
                "-b:a",
                self.audio_bitrate_for(preset),
                "-r",
                str(preset.fps),
                "-t",
                f"{plan.target_duration_seconds:.6f}",
            ]
        )
        if preset.encoding.fast_start:
            command.extend(["-movflags", "+faststart"])
        if self.runtime_settings.video_bitrate:
            command.extend(["-b:v", self.runtime_settings.video_bitrate])
        command.extend(["-metadata", f"title={plan.header_text}", "-y", str(output)])
        self._run(command, cancel_event)

    def _run(self, command: list[str], cancel_event: Event, timeout: float = 3600) -> None:
        creation_flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        process = subprocess.Popen(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creation_flags,
        )
        started = time.monotonic()
        while process.poll() is None:
            if cancel_event.wait(0.2):
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                raise CancelledError("FFmpeg render was cancelled.")
            if time.monotonic() - started > timeout:
                process.kill()
                process.wait()
                raise RenderError("FFmpeg operation timed out.")
        stderr = process.stderr.read() if process.stderr else ""
        if process.returncode != 0:
            raise RenderError(f"FFmpeg exited with code {process.returncode}: {stderr[-4000:]}")

    def video_codec_for(self, preset: Preset) -> str:
        return (
            self.runtime_settings.codec
            if preset.encoding.video_codec == "libx264"
            else preset.encoding.video_codec
        )

    def crf_for(self, preset: Preset) -> int:
        return self.runtime_settings.crf if preset.encoding.crf == 20 else preset.encoding.crf

    def audio_bitrate_for(self, preset: Preset) -> str:
        return (
            self.runtime_settings.audio_bitrate
            if preset.encoding.audio_bitrate == "192k"
            else preset.encoding.audio_bitrate
        )

    def _hardware_input_args(self) -> list[str]:
        value = (self.runtime_settings.hardware_acceleration or "").strip()
        return ["-hwaccel", value] if value else []

    @staticmethod
    def _filter_escape(path: Path) -> str:
        return str(path.resolve()).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")

    @staticmethod
    def _concat_escape(path: Path) -> str:
        return str(path.resolve()).replace("'", "'\\''")
