"""Create ASS overlays from the same preset layer geometry used by the preview."""

from __future__ import annotations

import math
from pathlib import Path

from app.models.preset_models import Color, ElementType, Preset, RichTextDocument, TextStyle
from app.models.render_models import RankingTimelineItem, RenderPlan
from app.presets.layout import LayoutEngine


def _ass_color(color: Color) -> str:
    alpha = 255 - color.alpha
    return f"&H{alpha:02X}{color.blue:02X}{color.green:02X}{color.red:02X}"


def _ass_rgb(color: Color) -> str:
    return f"&H{color.blue:02X}{color.green:02X}{color.red:02X}&"


def _ass_alpha(color: Color) -> str:
    return f"&H{255 - color.alpha:02X}&"


def _ass_override_color(color: Color, channel: int) -> str:
    return f"\\{channel}c{_ass_rgb(color)}\\{channel}a{_ass_alpha(color)}"


def _escape(value: str) -> str:
    return value.replace("\\", r"\\").replace("{", r"\{").replace("}", r"\}").replace("\n", r"\N")


def _time(seconds: float) -> str:
    centiseconds = max(0, round(seconds * 100))
    hours, remainder = divmod(centiseconds, 360_000)
    minutes, remainder = divmod(remainder, 6_000)
    whole_seconds, fraction = divmod(remainder, 100)
    return f"{hours}:{minutes:02d}:{whole_seconds:02d}.{fraction:02d}"


def _alignment(style: TextStyle) -> int:
    return {"left": 4, "center": 5, "right": 6}[style.alignment]


def _style_line(name: str, style: TextStyle, box_color: Color | None = None) -> str:
    background = box_color if box_color and box_color.alpha else style.background
    border_style = 3 if background.alpha else 1
    back_color = (
        background
        if background.alpha
        else (
            style.shadow_color if style.shadow_enabled else Color(red=0, green=0, blue=0, alpha=0)
        )
    )
    return (
        f"Style: {name},{style.font_family},{style.font_size},{_ass_color(style.foreground)},"
        f"{_ass_color(style.foreground)},{_ass_color(style.outline)},{_ass_color(back_color)},"
        f"{-1 if style.bold else 0},{-1 if style.italic else 0},{-1 if style.underline else 0},0,100,100,"
        f"{style.letter_spacing},0,{border_style},{style.outline_width},"
        f"{style.shadow_distance if style.shadow_enabled else 0},"
        f"{_alignment(style)},10,10,10,1"
    )


def _inline_style(style: TextStyle) -> str:
    back_color = style.background if style.background.alpha else style.shadow_color
    return (
        f"{{\\fn{style.font_family}\\fs{style.font_size:.1f}\\b{1 if style.bold else 0}"
        f"\\i{1 if style.italic else 0}\\u{1 if style.underline else 0}"
        f"{_ass_override_color(style.foreground, 1)}"
        f"{_ass_override_color(style.outline, 3)}"
        f"{_ass_override_color(back_color, 4)}\\fsp{style.letter_spacing:.1f}"
        f"\\bord{style.outline_width:.1f}"
        f"\\shad{style.shadow_distance if style.shadow_enabled else 0:.1f}"
        f"\\blur{style.shadow_blur:.1f}}}"
    )


def _glow_text(
    style: TextStyle,
    text: str,
    *,
    color_override: Color | None = None,
) -> str:
    color = (style.glow_color or color_override or style.foreground).model_copy(deep=True)
    state_opacity = color_override.alpha / 255 if color_override else 1
    color.alpha = round(color.alpha * state_opacity * style.glow_intensity)
    border = max(style.outline_width, style.glow_radius * 0.55)
    blur = max(0.1, style.glow_radius * 0.55)
    return (
        f"{{\\1a&HFF&{_ass_override_color(color, 3)}"
        f"\\bord{border:.1f}\\blur{blur:.1f}\\shad0}}{text}"
    )


def _transform(value: str, style: TextStyle) -> str:
    if style.transform == "uppercase":
        return value.upper()
    if style.transform == "lowercase":
        return value.lower()
    if style.transform == "title":
        return value.title()
    return value


def _style_opacity(style: TextStyle, opacity: float) -> TextStyle:
    value = style.model_copy(deep=True)
    for field_name in ("foreground", "outline", "shadow_color", "background"):
        color = getattr(value, field_name)
        setattr(
            value,
            field_name,
            color.model_copy(update={"alpha": round(color.alpha * opacity)}),
        )
    if value.glow_color:
        value.glow_color = value.glow_color.model_copy(
            update={"alpha": round(value.glow_color.alpha * opacity)}
        )
    return value


def _fit_text_style(
    style: TextStyle,
    text: str,
    *,
    width: int,
    height: int,
    maximum_lines: int,
) -> TextStyle:
    value = style.model_copy(deep=True)
    if not text or width <= 0 or height <= 0:
        return value
    characters_per_line = max(1, width / max(1, value.font_size * 0.55))
    estimated_lines = max(1, math.ceil(len(text) / characters_per_line))
    line_limit = max(1, min(maximum_lines, estimated_lines))
    width_scale = min(1.0, maximum_lines * characters_per_line / len(text))
    height_scale = min(
        1.0,
        height / max(1, line_limit * value.font_size * value.line_spacing),
    )
    value.font_size = max(
        value.minimum_font_size,
        value.font_size * min(width_scale, height_scale),
    )
    return value


def rich_ass_text(
    document: RichTextDocument,
    actual_text: str | None = None,
    *,
    preset: Preset | None = None,
) -> str:
    text = actual_text if actual_text is not None else document.text
    if actual_text is not None and actual_text != document.text:
        return _escape(_transform(text, document.default_style))
    styles = [document.default_style for _character in text]
    for span in document.spans:
        for index in range(span.start, min(span.end, len(styles))):
            styles[index] = span.style
    transformed: list[str] = []
    for index, character in enumerate(text):
        style = styles[index]
        if style.transform == "title":
            previous = text[index - 1] if index else " "
            transformed.append(character.upper() if not previous.isalnum() else character.lower())
        else:
            transformed.append(_transform(character, style))
    text = "".join(transformed)
    boundaries: dict[int, list[str]] = {}
    for span in document.spans:
        span_style = LayoutEngine.resolved_text_style(preset, span.style) if preset else span.style
        boundaries.setdefault(span.start, []).append(_inline_style(span_style))
        boundaries.setdefault(span.end, []).append(r"{\r}")
    parts: list[str] = []
    for index, character in enumerate(text):
        parts.extend(boundaries.get(index, []))
        parts.append(_escape(character))
    parts.extend(boundaries.get(len(text), []))
    return "".join(parts)


class OverlayRenderer:
    def create_ass(self, plan: RenderPlan, preset: Preset, destination: Path) -> Path:
        header_layer = next(
            (layer for layer in preset.layers if layer.element_type == ElementType.HEADER), None
        )
        caption_layer = next(
            (layer for layer in preset.layers if layer.element_type == ElementType.DYNAMIC_CAPTION),
            None,
        )
        number_layer = next(
            (layer for layer in preset.layers if layer.element_type == ElementType.RANKING_NUMBER),
            None,
        )
        default = TextStyle()
        header_style = (
            header_layer.rich_text.default_style
            if header_layer and header_layer.rich_text
            else default
        )
        caption_style = (
            caption_layer.rich_text.default_style
            if caption_layer and caption_layer.rich_text
            else default
        )
        number_style = (
            number_layer.rich_text.default_style
            if number_layer and number_layer.rich_text
            else default
        )
        header_style = LayoutEngine.resolved_text_style(preset, header_style)
        caption_style = LayoutEngine.resolved_text_style(preset, caption_style)
        number_style = LayoutEngine.resolved_text_style(preset, number_style)
        if header_layer:
            header_style = _style_opacity(header_style, header_layer.opacity)
        if caption_layer:
            caption_style = _style_opacity(caption_style, caption_layer.opacity)
        if number_layer:
            number_style = _style_opacity(number_style, number_layer.opacity)
        rich_layers = [
            layer
            for layer in sorted(preset.layers, key=lambda value: value.z_index)
            if layer.element_type == ElementType.RICH_TEXT and not layer.hidden and layer.rich_text
        ]
        rich_styles = {
            layer.id: _style_opacity(
                LayoutEngine.resolved_text_style(
                    preset,
                    layer.rich_text.default_style,
                ),
                layer.opacity,
            )
            for layer in rich_layers
            if layer.rich_text
        }
        if preset.header.automatic_fit and header_layer:
            header_rect = LayoutEngine.header_text_rect(preset, header_layer)
            header_style = _fit_text_style(
                header_style,
                plan.header_text,
                width=header_rect.width,
                height=header_rect.height,
                maximum_lines=preset.header.maximum_lines,
            )
        lines = [
            "[Script Info]",
            "ScriptType: v4.00+",
            f"PlayResX: {preset.width}",
            f"PlayResY: {preset.height}",
            "WrapStyle: 0",
            "ScaledBorderAndShadow: yes",
            "",
            "[V4+ Styles]",
            "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
            _style_line(
                "Header",
                header_style,
                header_layer.background_color if header_layer else None,
            ),
            _style_line(
                "Caption",
                caption_style,
                caption_layer.background_color if caption_layer else None,
            ),
            _style_line(
                "Rank",
                number_style,
                number_layer.background_color if number_layer else None,
            ),
        ]
        rich_style_names: dict[str, str] = {}
        for index, layer in enumerate(rich_layers):
            name = f"RichText{index}"
            rich_style_names[layer.id] = name
            lines.append(
                _style_line(
                    name,
                    rich_styles[layer.id],
                    layer.background_color,
                )
            )
        lines.extend(
            [
                "",
                "[Events]",
                "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text",
            ]
        )
        duration = plan.target_duration_seconds
        for layer in sorted(preset.layers, key=lambda value: value.z_index):
            if layer.hidden or layer.element_type != ElementType.SHAPE:
                continue
            rect = LayoutEngine.layer_rect(preset, layer)
            color = layer.background_color.model_copy(
                update={"alpha": round(layer.background_color.alpha * layer.opacity)}
            )
            drawing = (
                f"{{\\an7\\pos({rect.x},{rect.y})\\p1\\bord0\\shad0"
                f"{_ass_override_color(color, 1)}\\frz{layer.rotation_degrees:.2f}}}"
                f"m 0 0 l {rect.width} 0 l {rect.width} {rect.height} l 0 {rect.height}"
            )
            end = min(duration, layer.start_seconds + (layer.duration_seconds or duration))
            if end > layer.start_seconds:
                lines.append(
                    f"Dialogue: {layer.z_index},{_time(layer.start_seconds)},{_time(end)},"
                    f"Caption,,0,0,0,,{drawing}"
                )
        for layer in rich_layers:
            if not layer.rich_text:
                continue
            start = layer.start_seconds
            end = min(duration, start + (layer.duration_seconds or duration))
            if end <= start:
                continue
            lines.append(
                self._dialogue(
                    layer.z_index,
                    start,
                    end,
                    rich_style_names[layer.id],
                    LayoutEngine.safe_text_rect(preset, layer),
                    rich_ass_text(layer.rich_text, preset=preset),
                    rich_styles[layer.id],
                    layer.rotation_degrees,
                    layer.enter_animation,
                    layer.exit_animation,
                )
            )
        if preset.header.enabled and header_layer and not header_layer.hidden:
            rect = LayoutEngine.header_text_rect(preset, header_layer)
            document_data = plan.metadata.get("header_document")
            document = (
                RichTextDocument.model_validate(document_data)
                if document_data
                else header_layer.rich_text
            )
            text = (
                rich_ass_text(document, preset=preset)
                if document_data
                else (
                    rich_ass_text(document, plan.header_text, preset=preset)
                    if document
                    else _escape(plan.header_text)
                )
            )
            header_start = header_layer.start_seconds
            configured_header_duration = (
                preset.header.duration_seconds
                if preset.header.visibility == "fixed" and preset.header.duration_seconds
                else header_layer.duration_seconds
            )
            header_end = min(
                duration,
                header_start + (configured_header_duration or duration),
            )
            if header_end > header_start:
                header_height = round(preset.header.height_ratio * preset.height)
                header_box = (
                    f"{{\\an7\\pos(0,0)\\p1\\shad0\\bord{preset.header.border_width:.1f}"
                    f"{_ass_override_color(preset.header.background, 1)}"
                    f"{_ass_override_color(preset.header.border_color, 3)}}}"
                    f"m 0 0 l {preset.width} 0 l {preset.width} {header_height} l 0 {header_height}"
                )
                lines.append(
                    f"Dialogue: {header_layer.z_index - 1},{_time(header_start)},"
                    f"{_time(header_end)},Header,,0,0,0,,{header_box}"
                )
                if header_style.glow_enabled and header_style.glow_radius > 0:
                    lines.append(
                        self._dialogue(
                            max(0, header_layer.z_index - 1),
                            header_start,
                            header_end,
                            "Header",
                            rect,
                            _glow_text(header_style, text),
                            header_style,
                            header_layer.rotation_degrees,
                            header_layer.enter_animation,
                            header_layer.exit_animation,
                            wrap=preset.header.line_wrapping,
                        )
                    )
                lines.append(
                    self._dialogue(
                        header_layer.z_index,
                        header_start,
                        header_end,
                        "Header",
                        rect,
                        text,
                        header_style,
                        header_layer.rotation_degrees,
                        header_layer.enter_animation,
                        header_layer.exit_animation,
                        wrap=preset.header.line_wrapping,
                    )
                )
        if preset.ranking.enabled and number_layer and not number_layer.hidden:
            ranking_items = sorted(plan.ranking_items, key=lambda item: item.rank)
            if not ranking_items:
                cursor = 0.0
                for clip in plan.clips:
                    ranking_items.append(
                        RankingTimelineItem(
                            rank=clip.rank,
                            clip_id=clip.clip_id,
                            caption=clip.caption,
                            clip_start_seconds=cursor,
                            clip_end_seconds=cursor + clip.duration_seconds,
                            caption_start_seconds=cursor,
                            caption_end_seconds=cursor + clip.duration_seconds,
                        )
                    )
                    cursor += clip.duration_seconds
            count = len(ranking_items)
            row_rects = LayoutEngine.ranking_item_rects(
                preset,
                number_layer,
                count,
                font_size=number_style.font_size,
            )
            rank_style = number_style.model_copy(
                update={"alignment": preset.ranking.horizontal_alignment}
            )
            boundaries = {0.0, duration}
            for item in ranking_items:
                boundaries.add(max(0.0, min(duration, item.clip_start_seconds)))
                boundaries.add(max(0.0, min(duration, item.clip_end_seconds)))
            ordered_boundaries = sorted(boundaries)
            for interval_index in range(len(ordered_boundaries) - 1):
                interval_start = ordered_boundaries[interval_index]
                interval_end = ordered_boundaries[interval_index + 1]
                if interval_end <= interval_start:
                    continue
                midpoint = (interval_start + interval_end) / 2
                active_rank = next(
                    (
                        item.rank
                        for item in ranking_items
                        if item.clip_start_seconds <= midpoint < item.clip_end_seconds
                    ),
                    None,
                )
                for item, rect in zip(ranking_items, row_rects, strict=True):
                    if (
                        not preset.ranking.numbers_visible_from_start
                        and interval_start < item.clip_start_seconds
                    ):
                        continue
                    override = preset.ranking.item_overrides.get(item.rank)
                    if item.rank == active_rank:
                        color = (
                            override.active_color
                            if override and override.active_color
                            else preset.ranking.active_color
                        )
                        opacity = (
                            override.active_opacity
                            if override and override.active_opacity is not None
                            else preset.ranking.active_opacity
                        )
                    else:
                        color = (
                            override.inactive_color
                            if override and override.inactive_color
                            else preset.ranking.inactive_color
                        )
                        opacity = (
                            override.inactive_opacity
                            if override and override.inactive_opacity is not None
                            else preset.ranking.inactive_opacity
                        )
                    adjusted = color.model_copy(
                        update={"alpha": round(color.alpha * opacity * number_layer.opacity)}
                    )
                    text = f"{{{_ass_override_color(adjusted, 1)}}}{item.rank}"
                    if rank_style.glow_enabled and rank_style.glow_radius > 0:
                        lines.append(
                            self._dialogue(
                                max(0, number_layer.z_index - 1),
                                interval_start,
                                interval_end,
                                "Rank",
                                rect,
                                _glow_text(
                                    rank_style,
                                    str(item.rank),
                                    color_override=adjusted,
                                ),
                                rank_style,
                                number_layer.rotation_degrees,
                                number_layer.enter_animation,
                                number_layer.exit_animation,
                            )
                        )
                    lines.append(
                        self._dialogue(
                            number_layer.z_index,
                            interval_start,
                            interval_end,
                            "Rank",
                            rect,
                            text,
                            rank_style,
                            number_layer.rotation_degrees,
                            number_layer.enter_animation,
                            number_layer.exit_animation,
                        )
                    )
        if caption_layer and not caption_layer.hidden:
            default_caption_rect = LayoutEngine.safe_text_rect(preset, caption_layer)
            caption_rects: dict[int, object] = {}
            if (
                preset.ranking.enabled
                and number_layer
                and not number_layer.hidden
                and plan.ranking_items
            ):
                number_rows = LayoutEngine.ranking_item_rects(
                    preset,
                    number_layer,
                    len(plan.ranking_items),
                    font_size=number_style.font_size,
                )
                caption_bounds = LayoutEngine.safe_text_rect(preset, caption_layer)
                caption_rects = {
                    item.rank: type(row)(
                        x=caption_bounds.x,
                        y=row.y,
                        width=caption_bounds.width,
                        height=row.height,
                    )
                    for item, row in zip(
                        sorted(plan.ranking_items, key=lambda value: value.rank),
                        number_rows,
                        strict=True,
                    )
                }
            for caption_index, caption in enumerate(plan.captions):
                if caption.end_seconds <= caption.start_seconds:
                    continue
                if caption.rich_text_override:
                    document = RichTextDocument.model_validate(caption.rich_text_override)
                    text = rich_ass_text(document, preset=preset)
                else:
                    text = _escape(caption.text)
                rank = caption.rank or (
                    plan.clips[caption_index].rank if caption_index < len(plan.clips) else 0
                )
                rank_override = preset.ranking.item_overrides.get(rank)
                effective_caption_style = caption_style
                if rank_override and rank_override.caption_style:
                    effective_caption_style = LayoutEngine.resolved_text_style(
                        preset,
                        rank_override.caption_style,
                    )
                    text = f"{_inline_style(effective_caption_style)}{text}"
                rect = caption_rects.get(rank, default_caption_rect)
                visible_start = max(caption.start_seconds, caption_layer.start_seconds)
                visible_end = min(
                    caption.end_seconds,
                    caption_layer.start_seconds
                    + (caption_layer.duration_seconds or plan.target_duration_seconds),
                )
                if visible_end <= visible_start:
                    continue
                if effective_caption_style.glow_enabled and effective_caption_style.glow_radius > 0:
                    lines.append(
                        self._dialogue(
                            max(0, caption_layer.z_index - 1),
                            visible_start,
                            visible_end,
                            "Caption",
                            rect,
                            _glow_text(effective_caption_style, text),
                            effective_caption_style,
                            caption_layer.rotation_degrees,
                            caption_layer.enter_animation,
                            caption_layer.exit_animation,
                        )
                    )
                lines.append(
                    self._dialogue(
                        caption_layer.z_index,
                        visible_start,
                        visible_end,
                        "Caption",
                        rect,
                        text,
                        caption_style,
                        caption_layer.rotation_degrees,
                        caption_layer.enter_animation,
                        caption_layer.exit_animation,
                    )
                )
        destination.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")
        return destination

    def _dialogue(
        self,
        layer: int,
        start: float,
        end: float,
        style_name: str,
        rect: object,
        text: str,
        style: TextStyle,
        rotation_degrees: float = 0,
        enter_animation: str = "none",
        exit_animation: str = "none",
        *,
        wrap: bool = True,
    ) -> str:
        alignment = {"left": 4, "center": 5, "right": 6}[style.alignment]
        x = {
            "left": rect.x,
            "center": rect.x + rect.width / 2,
            "right": rect.x + rect.width,
        }[style.alignment]
        y = rect.y + rect.height / 2
        position = f"\\pos({x:.1f},{y:.1f})"
        if enter_animation == "slide":
            position = f"\\move({x - 50:.1f},{y:.1f},{x:.1f},{y:.1f},0,250)"
        effects = ""
        if style.shadow_blur > 0:
            effects += f"\\blur{style.shadow_blur:.1f}"
        if enter_animation == "fade" or exit_animation == "fade":
            effects += (
                f"\\fad({200 if enter_animation == 'fade' else 0},"
                f"{200 if exit_animation == 'fade' else 0})"
            )
        if enter_animation == "zoom":
            effects += r"\fscx70\fscy70\t(0,250,\fscx100\fscy100)"
        if exit_animation == "zoom":
            event_duration_ms = max(1, round((end - start) * 1000))
            effects += (
                f"\\t({max(0, event_duration_ms - 250)},{event_duration_ms},"
                r"\fscx70\fscy70)"
            )
        override = (
            f"{{\\an{alignment}{position}\\frz{rotation_degrees:.2f}{effects}"
            f"\\q{2 if wrap else 1}}}"
        )
        return (
            f"Dialogue: {layer},{_time(start)},{_time(end)},{style_name},,0,0,0,,{override}{text}"
        )
