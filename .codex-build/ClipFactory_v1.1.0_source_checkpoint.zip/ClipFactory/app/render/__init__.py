"""FFmpeg render pipeline."""
