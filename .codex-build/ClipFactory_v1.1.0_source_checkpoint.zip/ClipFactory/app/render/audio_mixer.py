"""Build safe FFmpeg audio graphs for voice, music, ducking, and limiting."""

from __future__ import annotations

from app.models.preset_models import AudioSettings
from app.models.render_models import TimedAudioAsset


class AudioMixer:
    def final_filter(
        self,
        settings: AudioSettings,
        *,
        has_music: bool,
        duration: float,
        audio_overlays: list[TimedAudioAsset] | None = None,
    ) -> tuple[str, str]:
        audio_overlays = audio_overlays or []
        base = (
            f"[0:a]volume={settings.original_volume:.4f},"
            "aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo[voicebase]"
        )
        if has_music:
            music = (
                f"[1:a]atrim=0:{duration:.6f},asetpts=PTS-STARTPTS,volume={settings.music_volume:.4f},"
                f"afade=t=in:st=0:d={settings.fade_in_seconds:.3f},"
                f"afade=t=out:st={max(0, duration - settings.fade_out_seconds):.3f}:d={settings.fade_out_seconds:.3f}[music]"
            )
            if settings.ducking_enabled:
                threshold = max(0.005, 0.08 * (1 - settings.ducking_strength))
                music_mix = (
                    "[voicebase]asplit=2[voice][sidechain];"
                    f"[music][sidechain]sidechaincompress=threshold={threshold:.4f}:"
                    "ratio=8:attack=20:release=500[ducked]"
                )
                sources = ["[voice]", "[ducked]"]
            else:
                music_mix = "[voicebase]anull[voice]"
                sources = ["[voice]", "[music]"]
            parts = [base, music]
            if music_mix:
                parts.append(music_mix)
        else:
            parts = [base, "[voicebase]anull[voice]"]
            sources = ["[voice]"]
        first_overlay_input = 2 if has_music else 1
        for index, overlay in enumerate(audio_overlays):
            input_index = first_overlay_input + index
            available = max(0.001, duration - overlay.start_seconds)
            overlay_duration = min(overlay.duration_seconds or available, available)
            delay = round(overlay.start_seconds * 1000)
            label = f"sfx{index}"
            filters = [
                f"atrim=start={overlay.source_start_seconds:.6f}:duration={overlay_duration:.6f}",
                "asetpts=PTS-STARTPTS",
                f"volume={overlay.volume:.4f}",
            ]
            fade_in = min(overlay.fade_in_seconds, overlay_duration / 2)
            fade_out = min(overlay.fade_out_seconds, overlay_duration / 2)
            if fade_in > 0:
                filters.append(f"afade=t=in:st=0:d={fade_in:.3f}")
            if fade_out > 0:
                filters.append(
                    f"afade=t=out:st={max(0, overlay_duration - fade_out):.3f}:d={fade_out:.3f}"
                )
            filters.append(f"adelay={delay}|{delay}")
            parts.append(f"[{input_index}:a]{','.join(filters)}[{label}]")
            sources.append(f"[{label}]")
        if len(sources) == 1:
            parts.append(f"{sources[0]}anull[mix]")
        else:
            parts.append(
                f"{''.join(sources)}amix=inputs={len(sources)}:duration=first:normalize=0[mix]"
            )
        suffix = f"[mix]loudnorm=I={settings.target_loudness_lufs}:TP=-1.0:LRA=11"
        if settings.limiter_enabled:
            suffix += ",alimiter=limit=0.95"
        suffix += "[aout]"
        parts.append(suffix)
        return ";".join(parts), "[aout]"
