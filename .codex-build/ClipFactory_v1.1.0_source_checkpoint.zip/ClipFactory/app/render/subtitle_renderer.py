"""Validated subtitle-file support."""

from __future__ import annotations

from pathlib import Path


class SubtitleRenderer:
    SUPPORTED = {".srt", ".ass", ".ssa", ".vtt"}

    def validate(self, path: Path) -> Path:
        resolved = path.expanduser().resolve()
        if resolved.suffix.lower() not in self.SUPPORTED:
            raise ValueError("Subtitle file type is not supported by the renderer.")
        if not resolved.is_file() or resolved.stat().st_size <= 0:
            raise ValueError("Subtitle file is missing or empty.")
        resolved.read_text(encoding="utf-8-sig")
        return resolved
