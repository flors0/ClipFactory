"""Build immutable, centrally timed render plans."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from app.models.ai_models import ProjectCreativeResult
from app.models.preset_models import ElementType, Preset, RichTextDocument, RichTextSpan
from app.models.project_models import ClipSelectionResult, SelectedClip
from app.models.render_models import (
    RankingTimelineItem,
    RenderPlan,
    TimedAudioAsset,
    TimedText,
    TimedVisualAsset,
    TimelineSegment,
)
from app.presets.layout import LayoutEngine
from app.presets.rich_text import expand_placeholders


class RenderPlanBuilder:
    def build(
        self,
        *,
        project_id: str,
        job_id: str,
        preset: Preset,
        selection: ClipSelectionResult,
        creative: ProjectCreativeResult,
        output_path: Path,
        asset_paths: dict[str, Path] | None = None,
        project_overrides: dict[str, object] | None = None,
    ) -> RenderPlan:
        if not selection.selected:
            raise ValueError("A render plan requires at least one selected clip.")
        asset_paths = asset_paths or {}
        project_overrides = project_overrides or {}
        ranked_clips = self._ranked_clips(selection, creative)
        clips = self._playback_clips(ranked_clips, preset)
        transition_path = self._asset_path(
            preset.transition.fixed_asset_id,
            asset_paths,
            enabled=(
                preset.transition.enabled
                and preset.transition.type == "fixed_asset"
                and preset.transition.placement == "between_clips"
            ),
        )
        interstitial_path = self._asset_path(
            preset.interstitial.asset_id,
            asset_paths,
            enabled=preset.interstitial.enabled,
        )
        transition_sound_path = self._asset_path(
            preset.transition.sound_asset_id,
            asset_paths,
            enabled=preset.transition.enabled and preset.transition.type != "cut",
        )

        caption_layer = next(
            (
                layer
                for layer in preset.layers
                if layer.element_type == ElementType.DYNAMIC_CAPTION and not layer.hidden
            ),
            None,
        )
        captions: list[TimedText] = []
        ranking_items: list[RankingTimelineItem] = []
        timeline: list[TimelineSegment] = []
        transition_sounds: list[TimedAudioAsset] = []
        cursor = 0.0

        if interstitial_path and preset.interstitial.placement in {"intro", "all"}:
            cursor = self._append_asset_segment(
                timeline,
                kind="interstitial",
                path=interstitial_path,
                cursor=cursor,
                duration=preset.interstitial.duration_seconds,
            )

        transition_count = 0
        for index, clip in enumerate(clips):
            clip_start = cursor
            clip_end = clip_start + clip.duration_seconds
            timeline.append(
                TimelineSegment(
                    kind="clip",
                    start_seconds=clip_start,
                    end_seconds=clip_end,
                    path=str(Path(clip.media_path).expanduser().resolve()),
                    source_start_seconds=clip.start_seconds,
                    clip_id=clip.clip_id,
                    rank=clip.rank,
                )
            )
            reveal_start = min(
                max(clip_start, clip_start + preset.ranking.reveal_offset_seconds),
                max(clip_start, clip_end - 0.001),
            )
            if preset.ranking.enabled:
                ranking_items.append(
                    RankingTimelineItem(
                        rank=clip.rank,
                        clip_id=clip.clip_id,
                        caption=clip.caption,
                        clip_start_seconds=clip_start,
                        clip_end_seconds=clip_end,
                        caption_start_seconds=reveal_start,
                        caption_end_seconds=clip_end,
                    )
                )
            if caption_layer and clip.caption:
                captions.append(
                    TimedText(
                        text=clip.caption,
                        start_seconds=reveal_start,
                        end_seconds=clip_end,
                        layer_id=caption_layer.id,
                        clip_id=clip.clip_id,
                        rank=clip.rank,
                        rich_text_override=(project_overrides.get("caption_documents") or {}).get(
                            clip.clip_id
                        )
                        if isinstance(project_overrides.get("caption_documents"), dict)
                        else None,
                    )
                )
            cursor = clip_end

            if index >= len(clips) - 1:
                continue
            transition_start = cursor
            transition_is_configured = (
                preset.transition.enabled
                and preset.transition.type != "cut"
                and (
                    preset.transition.type == "fade"
                    or (preset.transition.type == "fixed_asset" and transition_path is not None)
                )
            )
            if transition_is_configured:
                transition_count += 1
                if preset.transition.type == "fixed_asset" and transition_path:
                    cursor = self._append_asset_segment(
                        timeline,
                        kind="transition",
                        path=transition_path,
                        cursor=cursor,
                        duration=preset.transition.duration_seconds,
                    )
                if transition_sound_path:
                    event_start = (
                        transition_start
                        if preset.transition.type == "fixed_asset"
                        else max(
                            clip_start,
                            transition_start - preset.transition.duration_seconds / 2,
                        )
                    )
                    transition_sounds.append(
                        TimedAudioAsset(
                            path=transition_sound_path,
                            start_seconds=event_start,
                            duration_seconds=preset.transition.sound_duration_seconds,
                            source_start_seconds=preset.transition.sound_start_offset_seconds,
                            fade_in_seconds=preset.transition.sound_fade_seconds,
                            fade_out_seconds=preset.transition.sound_fade_seconds,
                            volume=preset.audio.transition_volume,
                        )
                    )
            if interstitial_path and preset.interstitial.placement in {"between_clips", "all"}:
                cursor = self._append_asset_segment(
                    timeline,
                    kind="interstitial",
                    path=interstitial_path,
                    cursor=cursor,
                    duration=preset.interstitial.duration_seconds,
                )

        if interstitial_path and preset.interstitial.placement in {"outro", "all"}:
            cursor = self._append_asset_segment(
                timeline,
                kind="interstitial",
                path=interstitial_path,
                cursor=cursor,
                duration=preset.interstitial.duration_seconds,
            )

        if preset.ranking.enabled and preset.ranking.captions_persist_after_reveal:
            for caption in captions:
                caption.end_seconds = cursor
            for item in ranking_items:
                item.caption_end_seconds = cursor
        captions.sort(key=lambda caption: caption.rank or 0)
        ranking_items.sort(key=lambda item: item.rank)

        music_path = self._music_path(preset, asset_paths)
        audio_overlays = [
            TimedAudioAsset(
                path=str(asset_paths[layer.asset_id]),
                start_seconds=layer.start_seconds,
                duration_seconds=layer.duration_seconds,
                volume=layer.volume * preset.audio.sfx_volume,
            )
            for layer in preset.layers
            if layer.element_type in {ElementType.AUDIO, ElementType.SOUND_EFFECT}
            and not layer.hidden
            and layer.asset_id in asset_paths
        ]
        audio_overlays.extend(transition_sounds)
        background_path = self._background_path(preset, asset_paths)
        subtitle_path = self._subtitle_path(preset, asset_paths, project_overrides)
        font_paths = [
            path
            for path in asset_paths.values()
            if path.suffix.lower() in {".ttf", ".otf", ".ttc", ".woff", ".woff2"}
        ]
        visual_overlays = self._visual_overlays(preset, asset_paths, cursor)
        header, header_document = self._header(
            preset,
            creative,
            clips,
            captions,
            project_overrides,
        )
        metadata = {
            "overall_theme": creative.overall_theme,
            "header_document": header_document.model_dump(mode="json") if header_document else None,
            "youtube_description": creative.youtube_description,
            "youtube_tags": creative.youtube_tags,
            "youtube_hashtags": creative.youtube_hashtags,
            "tiktok_caption": creative.tiktok_caption,
            "tiktok_hashtags": creative.tiktok_hashtags,
            "timeline_transition_count": transition_count,
            "ranking_playback_order": (
                preset.ranking.playback_order if preset.ranking.enabled else "selection_order"
            ),
            "style_selection": self.style_selection_metadata(preset),
        }
        text_overlays_enabled = any(
            not layer.hidden
            and (
                (layer.element_type == ElementType.HEADER and preset.header.enabled)
                or (layer.element_type == ElementType.RANKING_NUMBER and preset.ranking.enabled)
                or layer.element_type
                in {
                    ElementType.DYNAMIC_CAPTION,
                    ElementType.RICH_TEXT,
                    ElementType.SUBTITLE,
                }
            )
            for layer in preset.layers
        )
        return RenderPlan(
            project_id=project_id,
            job_id=job_id,
            preset_id=preset.id,
            output_path=str(output_path.resolve()),
            clips=clips,
            header_text=header,
            captions=captions,
            width=preset.width,
            height=preset.height,
            fps=preset.fps,
            target_duration_seconds=cursor,
            background_path=background_path,
            music_path=music_path,
            transition_path=transition_path,
            interstitial_path=interstitial_path,
            subtitle_path=subtitle_path,
            font_directory=str(font_paths[0].parent) if font_paths else None,
            audio_overlays=audio_overlays,
            visual_overlays=visual_overlays,
            timeline=timeline,
            ranking_items=ranking_items,
            transition_count=transition_count,
            text_overlays_enabled=text_overlays_enabled,
            metadata=metadata,
        )

    @staticmethod
    def apply_current_caption_visibility(plan: RenderPlan, preset: Preset) -> RenderPlan:
        """Apply current ranking-caption visibility to persisted render plans."""
        if not preset.ranking.enabled or not preset.ranking.captions_persist_after_reveal:
            return plan
        for caption in plan.captions:
            caption.end_seconds = plan.target_duration_seconds
        for item in plan.ranking_items:
            item.caption_end_seconds = plan.target_duration_seconds
        return plan

    @classmethod
    def apply_current_ranking_playback(
        cls,
        plan: RenderPlan,
        preset: Preset,
    ) -> RenderPlan:
        """Upgrade plain persisted Ranking timelines to the current countdown order."""
        if (
            not preset.ranking.enabled
            or preset.ranking.playback_order != "worst_to_best"
            or not plan.timeline
            or any(segment.kind != "clip" for segment in plan.timeline)
        ):
            return plan
        desired = sorted(plan.clips, key=lambda clip: clip.rank, reverse=True)
        if [clip.clip_id for clip in desired] == [segment.clip_id for segment in plan.timeline]:
            return plan
        cursor = 0.0
        rebuilt: list[TimelineSegment] = []
        item_by_clip = {item.clip_id: item for item in plan.ranking_items}
        caption_by_clip = {caption.clip_id: caption for caption in plan.captions if caption.clip_id}
        for clip in desired:
            start = cursor
            end = start + clip.duration_seconds
            rebuilt.append(
                TimelineSegment(
                    kind="clip",
                    start_seconds=start,
                    end_seconds=end,
                    path=str(Path(clip.media_path).expanduser().resolve()),
                    source_start_seconds=clip.start_seconds,
                    clip_id=clip.clip_id,
                    rank=clip.rank,
                )
            )
            reveal = min(
                max(start, start + preset.ranking.reveal_offset_seconds),
                max(start, end - 0.001),
            )
            item = item_by_clip.get(clip.clip_id)
            if item:
                item.clip_start_seconds = start
                item.clip_end_seconds = end
                item.caption_start_seconds = reveal
            caption = caption_by_clip.get(clip.clip_id)
            if caption:
                caption.start_seconds = reveal
            cursor = end
        plan.timeline = rebuilt
        plan.clips = desired
        plan.target_duration_seconds = cursor
        for item in plan.ranking_items:
            item.caption_end_seconds = (
                cursor if preset.ranking.captions_persist_after_reveal else item.clip_end_seconds
            )
        for caption in plan.captions:
            item = item_by_clip.get(caption.clip_id or "")
            caption.end_seconds = (
                cursor
                if preset.ranking.captions_persist_after_reveal
                else item.clip_end_seconds
                if item
                else caption.end_seconds
            )
        plan.metadata["ranking_playback_order"] = preset.ranking.playback_order
        plan.metadata["style_selection"] = cls.style_selection_metadata(preset)
        return plan

    @staticmethod
    def _ranked_clips(
        selection: ClipSelectionResult,
        creative: ProjectCreativeResult,
    ) -> list[SelectedClip]:
        selected_by_id = {clip.clip_id: clip for clip in selection.selected}
        ordered_ids = [
            clip_id for clip_id in creative.recommended_clip_order if clip_id in selected_by_id
        ]
        ordered_ids.extend(
            clip.clip_id for clip in selection.selected if clip.clip_id not in ordered_ids
        )
        caption_by_clip = {
            clip_id: creative.ranking_captions[index]
            for index, clip_id in enumerate(creative.recommended_clip_order)
            if index < len(creative.ranking_captions)
        }
        ranked: list[SelectedClip] = []
        for rank, clip_id in enumerate(ordered_ids, start=1):
            clip = selected_by_id[clip_id].model_copy(deep=True)
            clip.rank = rank
            clip.caption = caption_by_clip.get(clip_id, clip.caption).strip()
            ranked.append(clip)
        return ranked

    @staticmethod
    def _playback_clips(
        ranked_clips: list[SelectedClip],
        preset: Preset,
    ) -> list[SelectedClip]:
        if preset.ranking.enabled and preset.ranking.playback_order == "worst_to_best":
            return sorted(
                ranked_clips,
                key=lambda clip: clip.rank,
                reverse=True,
            )
        return sorted(ranked_clips, key=lambda clip: clip.rank)

    @staticmethod
    def style_selection_metadata(preset: Preset) -> dict[str, object]:
        layers = {layer.element_type: layer for layer in preset.layers if layer.rich_text}
        number_layer = layers.get(ElementType.RANKING_NUMBER)
        caption_layer = layers.get(ElementType.DYNAMIC_CAPTION)
        header_layer = layers.get(ElementType.HEADER)

        def fingerprint(payload: dict[str, object] | None) -> str | None:
            if payload is None:
                return None
            encoded = json.dumps(
                payload,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
            return hashlib.sha256(encoded).hexdigest()

        number_payload = (
            {
                "text_style": number_layer.rich_text.default_style.model_dump(mode="json"),
                "layer_background": number_layer.background_color.model_dump(mode="json"),
                "layer_opacity": number_layer.opacity,
                "active_color": preset.ranking.active_color.model_dump(mode="json"),
                "inactive_color": preset.ranking.inactive_color.model_dump(mode="json"),
                "active_opacity": preset.ranking.active_opacity,
                "inactive_opacity": preset.ranking.inactive_opacity,
                "item_overrides": {
                    str(rank): override.model_dump(
                        mode="json",
                        exclude={"caption_style"},
                    )
                    for rank, override in preset.ranking.item_overrides.items()
                },
            }
            if number_layer and number_layer.rich_text
            else None
        )
        caption_payload = (
            {
                "text_style": caption_layer.rich_text.default_style.model_dump(mode="json"),
                "layer_background": caption_layer.background_color.model_dump(mode="json"),
                "layer_opacity": caption_layer.opacity,
            }
            if caption_layer and caption_layer.rich_text
            else None
        )
        header_payload = (
            {
                "text_style": header_layer.rich_text.default_style.model_dump(mode="json"),
                "layer_background": header_layer.background_color.model_dump(mode="json"),
                "layer_opacity": header_layer.opacity,
                "header": {
                    "background": preset.header.background.model_dump(mode="json"),
                    "border_color": preset.header.border_color.model_dump(mode="json"),
                    "border_width": preset.header.border_width,
                    "height_ratio": preset.header.height_ratio,
                    "padding_ratio": preset.header.padding_ratio,
                    "accent_color": preset.header.accent_color.model_dump(mode="json")
                    if preset.header.accent_color
                    else None,
                    "accent_last_words": preset.header.accent_last_words,
                },
            }
            if header_layer and header_layer.rich_text
            else None
        )
        return {
            "mode": "preset",
            "profile_ids": preset.style_profiles.model_dump(mode="json"),
            "fingerprints": {
                "ranking_numbers": fingerprint(number_payload),
                "captions": fingerprint(caption_payload),
                "header": fingerprint(header_payload),
            },
        }

    @staticmethod
    def _asset_path(
        identifier: str | None,
        asset_paths: dict[str, Path],
        *,
        enabled: bool,
    ) -> str | None:
        if not enabled or not identifier or identifier not in asset_paths:
            return None
        return str(asset_paths[identifier].expanduser().resolve())

    @staticmethod
    def _append_asset_segment(
        timeline: list[TimelineSegment],
        *,
        kind: str,
        path: str,
        cursor: float,
        duration: float,
    ) -> float:
        end = cursor + duration
        timeline.append(
            TimelineSegment(
                kind=kind,
                start_seconds=cursor,
                end_seconds=end,
                path=path,
            )
        )
        return end

    @staticmethod
    def _music_path(preset: Preset, asset_paths: dict[str, Path]) -> str | None:
        direct = RenderPlanBuilder._asset_path(
            preset.audio.music_asset_id,
            asset_paths,
            enabled=True,
        )
        if direct:
            return direct
        music_layer = next(
            (
                layer
                for layer in preset.layers
                if layer.element_type == ElementType.MUSIC
                and not layer.hidden
                and layer.asset_id in asset_paths
            ),
            None,
        )
        return (
            str(asset_paths[music_layer.asset_id]) if music_layer and music_layer.asset_id else None
        )

    @staticmethod
    def _background_path(preset: Preset, asset_paths: dict[str, Path]) -> str | None:
        background_layer = next(
            (
                layer
                for layer in sorted(
                    preset.layers,
                    key=lambda value: value.z_index,
                    reverse=True,
                )
                if layer.element_type == ElementType.BACKGROUND
                and not layer.hidden
                and layer.asset_id in asset_paths
            ),
            None,
        )
        return (
            str(asset_paths[background_layer.asset_id])
            if background_layer and background_layer.asset_id
            else None
        )

    @staticmethod
    def _subtitle_path(
        preset: Preset,
        asset_paths: dict[str, Path],
        project_overrides: dict[str, object],
    ) -> str | None:
        if not preset.subtitles_enabled:
            return None
        subtitle_override = project_overrides.get("subtitle_path")
        if subtitle_override:
            return str(Path(str(subtitle_override)).expanduser().resolve())
        subtitle_layer = next(
            (
                layer
                for layer in preset.layers
                if layer.element_type == ElementType.SUBTITLE
                and not layer.hidden
                and layer.asset_id in asset_paths
            ),
            None,
        )
        return (
            str(asset_paths[subtitle_layer.asset_id])
            if subtitle_layer and subtitle_layer.asset_id
            else None
        )

    @staticmethod
    def _visual_overlays(
        preset: Preset,
        asset_paths: dict[str, Path],
        duration: float,
    ) -> list[TimedVisualAsset]:
        values: list[TimedVisualAsset] = []
        for layer in preset.layers:
            if (
                layer.element_type not in {ElementType.IMAGE, ElementType.MEME}
                or layer.hidden
                or layer.asset_id not in asset_paths
                or layer.start_seconds >= duration
            ):
                continue
            bounds = LayoutEngine.layer_rect(preset, layer)
            values.append(
                TimedVisualAsset(
                    path=str(asset_paths[layer.asset_id]),
                    x=bounds.x,
                    y=bounds.y,
                    width=bounds.width,
                    height=bounds.height,
                    start_seconds=layer.start_seconds,
                    end_seconds=min(
                        duration,
                        layer.start_seconds + (layer.duration_seconds or duration),
                    ),
                    opacity=layer.opacity,
                    rotation_degrees=layer.rotation_degrees,
                )
            )
        return values

    @staticmethod
    def _header(
        preset: Preset,
        creative: ProjectCreativeResult,
        clips: list[SelectedClip],
        captions: list[TimedText],
        project_overrides: dict[str, object],
    ) -> tuple[str, RichTextDocument | None]:
        header_layer = next(
            (
                layer
                for layer in preset.layers
                if layer.element_type == ElementType.HEADER and not layer.hidden
            ),
            None,
        )
        if not preset.header.enabled or not header_layer:
            return "", None
        explicit_document = project_overrides.get("header_document")
        explicit_text = project_overrides.get("header_text")
        if explicit_document:
            document = RichTextDocument.model_validate(explicit_document)
            document.text = " ".join(document.text.split())
            return document.text, document
        if isinstance(explicit_text, str) and explicit_text.strip():
            header = " ".join(explicit_text.split())
            return header, RenderPlanBuilder._accented_header_document(
                preset,
                header_layer.rich_text,
                header,
            )
        if preset.header.locked_text and header_layer.rich_text:
            document = header_layer.rich_text.model_copy(deep=True)
            document.text = " ".join(document.text.split())
            return document.text, RenderPlanBuilder._apply_header_accent(preset, document)
        header = " ".join(creative.header_text.split())
        if header_layer.rich_text and "{" in header_layer.rich_text.text:
            document = expand_placeholders(
                header_layer.rich_text,
                {
                    "header": header,
                    "theme": creative.overall_theme,
                    "caption": captions[0].text if captions else "",
                    "rank": clips[0].rank if clips else 1,
                },
            )
            document.text = " ".join(document.text.split())
            return document.text, RenderPlanBuilder._apply_header_accent(preset, document)
        return header, RenderPlanBuilder._accented_header_document(
            preset,
            header_layer.rich_text,
            header,
        )

    @staticmethod
    def _accented_header_document(
        preset: Preset,
        template: RichTextDocument | None,
        header: str,
    ) -> RichTextDocument | None:
        if not template or not header:
            return None
        document = RichTextDocument(
            text=header,
            default_style=template.default_style.model_copy(deep=True),
            spans=(
                [span.model_copy(deep=True) for span in template.spans]
                if template.text == header
                else []
            ),
        )
        return RenderPlanBuilder._apply_header_accent(preset, document)

    @staticmethod
    def _apply_header_accent(
        preset: Preset,
        document: RichTextDocument,
    ) -> RichTextDocument:
        if not preset.header.accent_color or preset.header.accent_last_words <= 0:
            return document
        words = document.text.split()
        if not words:
            return document
        accent_count = min(len(words), preset.header.accent_last_words)
        accented_text = " ".join(words[-accent_count:])
        start = document.text.rfind(accented_text)
        if start < 0:
            return document
        accent_style = document.default_style.model_copy(deep=True)
        accent_style.foreground = preset.header.accent_color.model_copy(deep=True)
        document.spans.append(
            RichTextSpan(
                start=start,
                end=len(document.text),
                style=accent_style,
            )
        )
        return document
