"""One-way cleanup for credentials accidentally persisted in diagnostic payloads."""

from __future__ import annotations

from app.core.logging import redact_text
from app.storage.database import Database

_DIAGNOSTIC_TABLES = ("production_jobs", "review_items", "upload_jobs")


def scrub_persisted_diagnostics(database: Database) -> int:
    """Redact known credential patterns from persisted job and review payloads."""
    scrubbed = 0
    with database.transaction(immediate=True) as connection:
        for table in _DIAGNOSTIC_TABLES:
            rows = connection.execute(f"SELECT id, payload FROM {table}").fetchall()
            for row in rows:
                redacted = redact_text(row["payload"])
                if redacted == row["payload"]:
                    continue
                connection.execute(
                    f"UPDATE {table} SET payload = ? WHERE id = ?",
                    (redacted, row["id"]),
                )
                scrubbed += 1
    return scrubbed
