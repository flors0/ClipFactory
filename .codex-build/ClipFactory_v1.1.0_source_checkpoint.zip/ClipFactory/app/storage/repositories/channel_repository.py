"""Channel profile repository."""

from __future__ import annotations

from datetime import UTC, datetime

from app.models.channel_models import ChannelProfile
from app.storage.database import Database


class ChannelRepository:
    def __init__(self, database: Database):
        self.database = database

    def save(self, channel: ChannelProfile) -> ChannelProfile:
        channel.updated_at = datetime.now(UTC)
        self.database.execute(
            "INSERT INTO channel_profiles(id, platform, payload, created_at, updated_at) VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET platform=excluded.platform, payload=excluded.payload, updated_at=excluded.updated_at",
            (
                channel.id,
                channel.platform,
                channel.model_dump_json(),
                channel.created_at.isoformat(),
                channel.updated_at.isoformat(),
            ),
        )
        return channel

    def get(self, identifier: str) -> ChannelProfile | None:
        row = self.database.fetchone(
            "SELECT payload FROM channel_profiles WHERE id = ?", (identifier,)
        )
        return ChannelProfile.model_validate_json(row["payload"]) if row else None

    def list(self) -> list[ChannelProfile]:
        rows = self.database.fetchall(
            "SELECT payload FROM channel_profiles ORDER BY platform, updated_at DESC"
        )
        return [ChannelProfile.model_validate_json(row["payload"]) for row in rows]

    def delete(self, identifier: str) -> bool:
        return (
            self.database.execute(
                "DELETE FROM channel_profiles WHERE id = ?", (identifier,)
            ).rowcount
            > 0
        )
