"""Small validated JSON repositories for Pydantic entities."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Generic, TypeVar

from pydantic import BaseModel

from app.storage.database import Database

ModelT = TypeVar("ModelT", bound=BaseModel)


class JsonRepository(Generic[ModelT]):
    _allowed_tables = {
        "source_profiles",
        "projects",
        "schedule_templates",
    }

    def __init__(self, database: Database, table: str, model_type: type[ModelT]):
        if table not in self._allowed_tables:
            raise ValueError(f"Unsupported repository table: {table}")
        self.database = database
        self.table = table
        self.model_type = model_type

    def save(self, model: ModelT) -> ModelT:
        now = datetime.now(UTC).isoformat()
        if hasattr(model, "updated_at"):
            model.updated_at = datetime.now(UTC)
        payload = model.model_dump_json()
        self.database.execute(
            f"INSERT INTO {self.table}(id, payload, created_at, updated_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at",
            (str(model.id), payload, getattr(model, "created_at", now).isoformat(), now),
        )
        return model

    def get(self, identifier: str) -> ModelT | None:
        row = self.database.fetchone(
            f"SELECT payload FROM {self.table} WHERE id = ?", (identifier,)
        )
        return self.model_type.model_validate_json(row["payload"]) if row else None

    def list(self) -> list[ModelT]:
        rows = self.database.fetchall(f"SELECT payload FROM {self.table} ORDER BY updated_at DESC")
        return [self.model_type.model_validate_json(row["payload"]) for row in rows]

    def delete(self, identifier: str) -> bool:
        cursor = self.database.execute(f"DELETE FROM {self.table} WHERE id = ?", (identifier,))
        return cursor.rowcount > 0


def canonical_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
