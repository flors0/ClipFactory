"""Preset persistence with core-preset protection."""

from __future__ import annotations

from datetime import UTC, datetime

from app.models.preset_models import Preset
from app.storage.database import Database


class PresetRepository:
    def __init__(self, database: Database):
        self.database = database

    def save(self, preset: Preset) -> Preset:
        preset.updated_at = datetime.now(UTC)
        self.database.execute(
            "INSERT INTO presets(id, name, core, payload, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET name=excluded.name, core=excluded.core, payload=excluded.payload, updated_at=excluded.updated_at",
            (
                preset.id,
                preset.name,
                int(preset.core),
                preset.model_dump_json(),
                preset.created_at.isoformat(),
                preset.updated_at.isoformat(),
            ),
        )
        return preset

    def get(self, identifier: str) -> Preset | None:
        row = self.database.fetchone("SELECT payload FROM presets WHERE id = ?", (identifier,))
        return Preset.model_validate_json(row["payload"]) if row else None

    def list(self) -> list[Preset]:
        return [
            Preset.model_validate_json(row["payload"])
            for row in self.database.fetchall(
                "SELECT payload FROM presets ORDER BY core DESC, name"
            )
        ]

    def delete(self, identifier: str) -> bool:
        row = self.database.fetchone("SELECT core FROM presets WHERE id = ?", (identifier,))
        if not row:
            return False
        if row["core"]:
            raise ValueError("Core presets cannot be deleted. Duplicate the preset first.")
        return self.database.execute("DELETE FROM presets WHERE id = ?", (identifier,)).rowcount > 0

    def delete_force(self, identifier: str) -> bool:
        """Internal migration primitive; UI code must use the protected delete method."""
        return self.database.execute("DELETE FROM presets WHERE id = ?", (identifier,)).rowcount > 0
