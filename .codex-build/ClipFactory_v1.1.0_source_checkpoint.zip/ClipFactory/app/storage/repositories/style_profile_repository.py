"""SQLite persistence for reusable style profiles."""

from __future__ import annotations

from datetime import UTC, datetime

from app.models.style_models import StyleProfile, StyleProfileKind
from app.storage.database import Database


class StyleProfileRepository:
    def __init__(self, database: Database):
        self.database = database

    def save(self, profile: StyleProfile) -> StyleProfile:
        profile.updated_at = datetime.now(UTC)
        self.database.execute(
            "INSERT INTO style_profiles(id, name, kind, core, payload, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET "
            "name=excluded.name, kind=excluded.kind, core=excluded.core, "
            "payload=excluded.payload, updated_at=excluded.updated_at",
            (
                profile.id,
                profile.name,
                profile.kind.value,
                int(profile.core),
                profile.model_dump_json(),
                profile.created_at.isoformat(),
                profile.updated_at.isoformat(),
            ),
        )
        return profile

    def get(self, identifier: str) -> StyleProfile | None:
        row = self.database.fetchone(
            "SELECT payload FROM style_profiles WHERE id = ?",
            (identifier,),
        )
        return StyleProfile.model_validate_json(row["payload"]) if row else None

    def list(self, kind: StyleProfileKind | None = None) -> list[StyleProfile]:
        if kind is None:
            rows = self.database.fetchall(
                "SELECT payload FROM style_profiles ORDER BY kind, core DESC, name"
            )
        else:
            rows = self.database.fetchall(
                "SELECT payload FROM style_profiles WHERE kind = ? ORDER BY core DESC, name",
                (kind.value,),
            )
        return [StyleProfile.model_validate_json(row["payload"]) for row in rows]

    def delete(self, identifier: str) -> bool:
        row = self.database.fetchone(
            "SELECT core FROM style_profiles WHERE id = ?",
            (identifier,),
        )
        if not row:
            return False
        if row["core"]:
            raise ValueError(
                "Built-in style profiles cannot be deleted. Duplicate the profile first."
            )
        return (
            self.database.execute(
                "DELETE FROM style_profiles WHERE id = ?",
                (identifier,),
            ).rowcount
            > 0
        )
