"""Persistence for coordinated visual design profiles."""

from __future__ import annotations

from datetime import UTC, datetime

from app.models.design_models import DesignProfile
from app.storage.database import Database


class DesignProfileRepository:
    def __init__(self, database: Database):
        self.database = database

    def save(self, profile: DesignProfile) -> DesignProfile:
        profile.updated_at = datetime.now(UTC)
        self.database.execute(
            "INSERT INTO design_profiles(id, name, video_format, core, payload, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET "
            "name=excluded.name, video_format=excluded.video_format, core=excluded.core, "
            "payload=excluded.payload, updated_at=excluded.updated_at",
            (
                profile.id,
                profile.name,
                profile.video_format,
                int(profile.core),
                profile.model_dump_json(),
                profile.created_at.isoformat(),
                profile.updated_at.isoformat(),
            ),
        )
        return profile

    def get(self, identifier: str) -> DesignProfile | None:
        row = self.database.fetchone(
            "SELECT payload FROM design_profiles WHERE id = ?", (identifier,)
        )
        return DesignProfile.model_validate_json(row["payload"]) if row else None

    def list(self, video_format: str | None = None) -> list[DesignProfile]:
        if video_format:
            rows = self.database.fetchall(
                "SELECT payload FROM design_profiles WHERE video_format = ? "
                "ORDER BY core DESC, name",
                (video_format,),
            )
        else:
            rows = self.database.fetchall(
                "SELECT payload FROM design_profiles ORDER BY video_format, core DESC, name"
            )
        return [DesignProfile.model_validate_json(row["payload"]) for row in rows]

    def delete(self, identifier: str) -> bool:
        row = self.database.fetchone("SELECT core FROM design_profiles WHERE id = ?", (identifier,))
        if not row:
            return False
        if row["core"]:
            raise ValueError("Built-in design profiles cannot be deleted.")
        return (
            self.database.execute(
                "DELETE FROM design_profiles WHERE id = ?", (identifier,)
            ).rowcount
            > 0
        )
