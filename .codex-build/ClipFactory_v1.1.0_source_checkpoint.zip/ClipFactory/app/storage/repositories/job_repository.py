"""Production, review, and upload job repositories."""

from __future__ import annotations

from datetime import UTC, datetime

from app.core.state_machine import require_transition
from app.models.render_models import ProductionJob, ProductionStatus
from app.models.review_models import ReviewItem
from app.models.upload_models import UploadJob, UploadStatus
from app.storage.database import Database


class ProductionJobRepository:
    def __init__(self, database: Database):
        self.database = database

    def save(self, job: ProductionJob, *, validate_transition: bool = True) -> ProductionJob:
        existing = self.get(job.id)
        if existing and validate_transition:
            require_transition(existing.status, job.status)
        job.updated_at = datetime.now(UTC)
        self.database.execute(
            "INSERT INTO production_jobs(id, project_id, status, progress, scheduled_at, payload, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET status=excluded.status, "
            "progress=excluded.progress, scheduled_at=excluded.scheduled_at, payload=excluded.payload, updated_at=excluded.updated_at",
            (
                job.id,
                job.project_id,
                job.status.value,
                job.progress,
                job.scheduled_at.isoformat() if job.scheduled_at else None,
                job.model_dump_json(),
                job.created_at.isoformat(),
                job.updated_at.isoformat(),
            ),
        )
        return job

    def get(self, identifier: str) -> ProductionJob | None:
        row = self.database.fetchone(
            "SELECT payload FROM production_jobs WHERE id = ?", (identifier,)
        )
        return ProductionJob.model_validate_json(row["payload"]) if row else None

    def list(self, status: ProductionStatus | None = None) -> list[ProductionJob]:
        if status:
            rows = self.database.fetchall(
                "SELECT payload FROM production_jobs WHERE status = ? ORDER BY created_at DESC",
                (status.value,),
            )
        else:
            rows = self.database.fetchall(
                "SELECT payload FROM production_jobs ORDER BY created_at DESC"
            )
        return [ProductionJob.model_validate_json(row["payload"]) for row in rows]


class ReviewRepository:
    def __init__(self, database: Database):
        self.database = database

    def save(self, item: ReviewItem) -> ReviewItem:
        item.updated_at = datetime.now(UTC)
        self.database.execute(
            "INSERT INTO review_items(id, production_job_id, status, payload, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET status=excluded.status, payload=excluded.payload, updated_at=excluded.updated_at",
            (
                item.id,
                item.production_job_id,
                item.status.value,
                item.model_dump_json(),
                item.created_at.isoformat(),
                item.updated_at.isoformat(),
            ),
        )
        return item

    def get(self, identifier: str) -> ReviewItem | None:
        row = self.database.fetchone("SELECT payload FROM review_items WHERE id = ?", (identifier,))
        return ReviewItem.model_validate_json(row["payload"]) if row else None

    def list(self, status: str | None = None) -> list[ReviewItem]:
        if status:
            rows = self.database.fetchall(
                "SELECT payload FROM review_items WHERE status = ? ORDER BY created_at DESC",
                (status,),
            )
        else:
            rows = self.database.fetchall(
                "SELECT payload FROM review_items ORDER BY created_at DESC"
            )
        return [ReviewItem.model_validate_json(row["payload"]) for row in rows]

    def get_by_production_job(self, production_job_id: str) -> ReviewItem | None:
        row = self.database.fetchone(
            "SELECT payload FROM review_items WHERE production_job_id = ?", (production_job_id,)
        )
        return ReviewItem.model_validate_json(row["payload"]) if row else None


class UploadJobRepository:
    def __init__(self, database: Database):
        self.database = database

    def save(self, job: UploadJob) -> UploadJob:
        job.updated_at = datetime.now(UTC)
        self.database.execute(
            "INSERT INTO upload_jobs(id, production_job_id, channel_id, platform, status, scheduled_at, execution_at, batch_approved, payload, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET status=excluded.status, "
            "scheduled_at=excluded.scheduled_at, execution_at=excluded.execution_at, batch_approved=excluded.batch_approved, payload=excluded.payload, updated_at=excluded.updated_at",
            (
                job.id,
                job.production_job_id,
                job.channel_id,
                job.platform,
                job.status.value,
                job.scheduled_at.isoformat(),
                job.execution_at.isoformat() if job.execution_at else job.scheduled_at.isoformat(),
                int(job.batch_approved),
                job.model_dump_json(),
                job.created_at.isoformat(),
                job.updated_at.isoformat(),
            ),
        )
        return job

    def get(self, identifier: str) -> UploadJob | None:
        row = self.database.fetchone("SELECT payload FROM upload_jobs WHERE id = ?", (identifier,))
        return UploadJob.model_validate_json(row["payload"]) if row else None

    def list(self, status: UploadStatus | None = None) -> list[UploadJob]:
        if status:
            rows = self.database.fetchall(
                "SELECT payload FROM upload_jobs WHERE status = ? ORDER BY scheduled_at",
                (status.value,),
            )
        else:
            rows = self.database.fetchall("SELECT payload FROM upload_jobs ORDER BY scheduled_at")
        return [UploadJob.model_validate_json(row["payload"]) for row in rows]

    def due(self, now: datetime, limit: int = 1) -> list[UploadJob]:
        rows = self.database.fetchall(
            "SELECT payload FROM upload_jobs WHERE batch_approved = 1 AND status IN (?, ?, ?) AND execution_at <= ? ORDER BY execution_at LIMIT ?",
            (
                UploadStatus.QUEUED.value,
                UploadStatus.SCHEDULED.value,
                UploadStatus.PROCESSING.value,
                now.isoformat(),
                limit,
            ),
        )
        return [UploadJob.model_validate_json(row["payload"]) for row in rows]

    def claim_due(self, now: datetime, limit: int = 1) -> list[UploadJob]:
        """Atomically lease due jobs so concurrent scheduler processes cannot duplicate uploads."""
        claimed_jobs: list[UploadJob] = []
        with self.database.transaction(immediate=True) as connection:
            rows = connection.execute(
                "SELECT id, status, payload FROM upload_jobs WHERE batch_approved = 1 "
                "AND status IN (?, ?, ?) AND execution_at <= ? ORDER BY execution_at LIMIT ?",
                (
                    UploadStatus.QUEUED.value,
                    UploadStatus.SCHEDULED.value,
                    UploadStatus.PROCESSING.value,
                    now.isoformat(),
                    max(1, limit),
                ),
            ).fetchall()
            for row in rows:
                original = UploadJob.model_validate_json(row["payload"])
                persisted = original.model_copy(deep=True)
                persisted.status = UploadStatus.UPLOADING
                persisted.updated_at = datetime.now(UTC)
                persisted.log_messages.append("Scheduler atomically claimed this upload job.")
                cursor = connection.execute(
                    "UPDATE upload_jobs SET status = ?, payload = ?, updated_at = ? "
                    "WHERE id = ? AND status = ? AND batch_approved = 1 AND execution_at <= ?",
                    (
                        UploadStatus.UPLOADING.value,
                        persisted.model_dump_json(),
                        persisted.updated_at.isoformat(),
                        row["id"],
                        row["status"],
                        now.isoformat(),
                    ),
                )
                if cursor.rowcount == 1:
                    original.updated_at = persisted.updated_at
                    original.log_messages = persisted.log_messages
                    claimed_jobs.append(original)
        return claimed_jobs
