"""Persistence for adaptive editorial feedback."""

from __future__ import annotations

from datetime import UTC, datetime

from app.models.feedback_models import AIEditFeedback, EditorialFieldKind
from app.storage.database import Database


class AIEditFeedbackRepository:
    def __init__(self, database: Database):
        self.database = database

    def save(self, feedback: AIEditFeedback) -> AIEditFeedback:
        feedback.updated_at = datetime.now(UTC)
        self.database.execute(
            "INSERT INTO ai_edit_feedback("
            "id, review_item_id, production_job_id, project_id, channel_id, preset_id, "
            "platform, language, theme, field_kind, field_key, original_text, edited_text, "
            "edit_signature, payload, created_at, updated_at"
            ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(review_item_id, field_kind, field_key) DO UPDATE SET "
            "original_text=excluded.original_text, edited_text=excluded.edited_text, "
            "edit_signature=excluded.edit_signature, payload=excluded.payload, "
            "updated_at=excluded.updated_at",
            (
                feedback.id,
                feedback.review_item_id,
                feedback.production_job_id,
                feedback.project_id,
                feedback.channel_id,
                feedback.preset_id,
                feedback.platform,
                feedback.language,
                feedback.theme,
                feedback.field_kind.value,
                feedback.field_key,
                feedback.original_text,
                feedback.edited_text,
                feedback.edit_signature,
                feedback.model_dump_json(),
                feedback.created_at.isoformat(),
                feedback.updated_at.isoformat(),
            ),
        )
        return feedback

    def delete_field(
        self,
        review_item_id: str,
        field_kind: EditorialFieldKind,
        field_key: str,
    ) -> bool:
        return (
            self.database.execute(
                "DELETE FROM ai_edit_feedback WHERE review_item_id = ? AND field_kind = ? "
                "AND field_key = ?",
                (review_item_id, field_kind.value, field_key),
            ).rowcount
            > 0
        )

    def list(
        self,
        field_kinds: set[EditorialFieldKind] | None = None,
        *,
        limit: int = 500,
    ) -> list[AIEditFeedback]:
        bounded_limit = max(1, min(5000, limit))
        if field_kinds:
            values = sorted(value.value for value in field_kinds)
            placeholders = ",".join("?" for _value in values)
            rows = self.database.fetchall(
                f"SELECT payload FROM ai_edit_feedback WHERE field_kind IN ({placeholders}) "
                "ORDER BY updated_at DESC LIMIT ?",
                (*values, bounded_limit),
            )
        else:
            rows = self.database.fetchall(
                "SELECT payload FROM ai_edit_feedback ORDER BY updated_at DESC LIMIT ?",
                (bounded_limit,),
            )
        return [AIEditFeedback.model_validate_json(row["payload"]) for row in rows]

    def count(self) -> int:
        row = self.database.fetchone("SELECT COUNT(*) AS amount FROM ai_edit_feedback")
        return int(row["amount"]) if row else 0

    def clear(self) -> int:
        return self.database.execute("DELETE FROM ai_edit_feedback").rowcount
