CREATE TABLE IF NOT EXISTS design_profiles (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    video_format TEXT NOT NULL,
    core INTEGER NOT NULL DEFAULT 0,
    payload TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_design_profiles_format_name
ON design_profiles(video_format, core DESC, name);

CREATE TABLE IF NOT EXISTS ai_edit_feedback (
    id TEXT PRIMARY KEY,
    review_item_id TEXT NOT NULL,
    production_job_id TEXT NOT NULL,
    project_id TEXT NOT NULL,
    channel_id TEXT,
    preset_id TEXT NOT NULL,
    platform TEXT NOT NULL,
    language TEXT NOT NULL,
    theme TEXT NOT NULL,
    field_kind TEXT NOT NULL,
    field_key TEXT NOT NULL,
    original_text TEXT NOT NULL,
    edited_text TEXT NOT NULL,
    edit_signature TEXT NOT NULL,
    payload TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(review_item_id, field_kind, field_key)
);

CREATE INDEX IF NOT EXISTS idx_ai_edit_feedback_scope
ON ai_edit_feedback(field_kind, channel_id, preset_id, platform, updated_at DESC);
