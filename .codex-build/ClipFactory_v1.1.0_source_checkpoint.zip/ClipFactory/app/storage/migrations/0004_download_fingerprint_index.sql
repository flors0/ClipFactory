CREATE INDEX IF NOT EXISTS idx_download_cache_fingerprint
ON download_cache(file_fingerprint);
