ALTER TABLE upload_jobs ADD COLUMN execution_at TEXT;
UPDATE upload_jobs SET execution_at = scheduled_at WHERE execution_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_upload_jobs_execution ON upload_jobs(status, execution_at);
