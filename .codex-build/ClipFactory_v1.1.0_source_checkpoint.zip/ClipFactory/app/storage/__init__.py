"""Persistent storage services."""
