"""Qt background-worker primitives with cancellation and typed signals."""

from __future__ import annotations

import traceback
from collections.abc import Callable
from threading import Event
from typing import Any

from PySide6.QtCore import QObject, QRunnable, Signal, Slot

from app.core.logging import redact_text


class WorkerSignals(QObject):
    started = Signal()
    progress = Signal(int, str)
    result = Signal(object)
    error = Signal(str)
    cancelled = Signal()
    finished = Signal()


class BackgroundWorker(QRunnable):
    """Run a callable off the UI thread with cooperative cancellation."""

    def __init__(self, function: Callable[..., Any], *args: Any, **kwargs: Any):
        super().__init__()
        self.function = function
        self.args = args
        self.kwargs = kwargs
        self.signals = WorkerSignals()
        self.cancel_event = Event()

    def cancel(self) -> None:
        self.cancel_event.set()

    @Slot()
    def run(self) -> None:
        self.signals.started.emit()
        try:
            result = self.function(
                *self.args,
                cancel_event=self.cancel_event,
                progress_callback=lambda value, text: self.signals.progress.emit(value, text),
                **self.kwargs,
            )
            if self.cancel_event.is_set():
                self.signals.cancelled.emit()
            else:
                self.signals.result.emit(result)
        except Exception:
            self.signals.error.emit(redact_text(traceback.format_exc()))
        finally:
            self.signals.finished.emit()
