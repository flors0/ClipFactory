"""Validated application paths."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

from app.core.exceptions import ConfigurationError


def _default_root() -> Path:
    override = os.getenv("CLIPFACTORY_HOME")
    if override:
        return Path(override).expanduser().resolve()
    if getattr(sys, "frozen", False) and sys.platform == "win32":
        local_app_data = os.getenv("LOCALAPPDATA")
        base = Path(local_app_data) if local_app_data else Path.home() / "AppData" / "Local"
        return (base / "ClipFactory").resolve()
    return Path(__file__).resolve().parents[2]


@dataclass(frozen=True, slots=True)
class AppPaths:
    """Centralized filesystem locations with containment checks."""

    root: Path
    data: Path
    database: Path
    cache: Path
    downloads: Path
    previews: Path
    renders: Path
    outputs: Path
    logs: Path
    thumbnails: Path
    ai: Path
    temp: Path
    assets: Path
    config: Path

    @classmethod
    def build(cls, root: Path | None = None) -> AppPaths:
        root = (root or _default_root()).expanduser().resolve()
        data = root / "data"
        return cls(
            root=root,
            data=data,
            database=data / "clipfactory.db",
            cache=data / "cache",
            downloads=data / "downloads",
            previews=data / "previews",
            renders=data / "renders",
            outputs=data / "outputs",
            logs=data / "logs",
            thumbnails=data / "thumbnails",
            ai=data / "ai",
            temp=data / "temp",
            assets=root / "assets",
            config=root / "config",
        )

    def ensure(self) -> None:
        for directory in (
            self.data,
            self.cache,
            self.downloads,
            self.previews,
            self.renders,
            self.outputs,
            self.logs,
            self.thumbnails,
            self.ai,
            self.temp,
            self.assets,
            self.config,
        ):
            directory.mkdir(parents=True, exist_ok=True)

    def validate_user_directory(self, candidate: str | Path, *, create: bool = False) -> Path:
        path = Path(candidate).expanduser().resolve()
        if path == Path(path.anchor):
            raise ConfigurationError(
                "A filesystem root cannot be used as an application directory."
            )
        if create:
            path.mkdir(parents=True, exist_ok=True)
        if not path.is_dir():
            raise ConfigurationError(f"Directory does not exist: {path}")
        return path

    def contained_temp_path(self, name: str) -> Path:
        safe = Path(name).name
        if safe != name or safe in {"", ".", ".."}:
            raise ConfigurationError("Unsafe temporary filename.")
        target = (self.temp / safe).resolve()
        if self.temp.resolve() not in target.parents:
            raise ConfigurationError("Temporary path escaped the configured directory.")
        return target
