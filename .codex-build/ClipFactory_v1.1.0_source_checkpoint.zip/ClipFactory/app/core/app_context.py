"""Application dependency graph with lazy external credential use."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from app.ai.adaptive_preferences import AdaptivePreferenceService
from app.ai.analysis_cache import AnalysisCache
from app.ai.analysis_provider import TwelveLabsAnalysisProvider
from app.ai.analysis_service import AnalysisService
from app.ai.budget_guard import AIBudgetGuard
from app.ai.gemini_analysis_provider import GeminiAnalysisProvider
from app.ai.mock_analysis_provider import MockAIAnalysisProvider
from app.ai.pricing import PricingCatalog
from app.ai.prompt_builder import PromptBuilder
from app.ai.request_estimator import RequestEstimator
from app.ai.usage_ledger import AIUsageLedger
from app.core.config import AppSettings, SettingsStore
from app.core.credentials import (
    GEMINI_API_KEY,
    CredentialStore,
    KeyringCredentialStore,
    resolve_credential,
)
from app.core.paths import AppPaths
from app.download.download_cache import DownloadCache
from app.download.media_downloader import MediaDownloader
from app.media.media_probe import MediaProbe
from app.media.technical_validator import TechnicalValidator
from app.media.thumbnail_generator import ThumbnailGenerator
from app.models.project_models import SourceProjectPlan
from app.models.render_models import ProductionStatus
from app.models.schedule_models import MissedJobPolicy, ScheduleTemplate
from app.models.source_models import SourceProfile
from app.planning.clip_selection_planner import ClipSelectionPlanner, UsedMediaHistory
from app.planning.source_project_planner import SourceProjectPlanner
from app.presets.asset_library import AssetLibrary
from app.presets.design_profile_manager import DesignProfileManager
from app.presets.preset_manager import PresetManager
from app.presets.style_profile_manager import StyleProfileManager
from app.render.ffmpeg_renderer import FFmpegRenderer
from app.render.render_plan import RenderPlanBuilder
from app.review.final_review_service import FinalReviewService
from app.review.review_queue import ReviewQueue
from app.scheduling.job_store import PersistentJobStore
from app.scheduling.missed_job_policy import reconcile_missed_jobs
from app.scheduling.scheduler import PersistentUploadScheduler
from app.services.production_service import BatchProductionService
from app.sources.mock.provider import MockRedditSourceProvider
from app.sources.provider_factory import create_source_provider
from app.storage.database import Database
from app.storage.diagnostic_scrubber import scrub_persisted_diagnostics
from app.storage.repositories.channel_repository import ChannelRepository
from app.storage.repositories.design_profile_repository import DesignProfileRepository
from app.storage.repositories.feedback_repository import AIEditFeedbackRepository
from app.storage.repositories.job_repository import (
    ProductionJobRepository,
    ReviewRepository,
    UploadJobRepository,
)
from app.storage.repositories.json_repository import JsonRepository
from app.storage.repositories.preset_repository import PresetRepository
from app.storage.repositories.style_profile_repository import StyleProfileRepository
from app.uploads.oauth_manager import OAuthManager
from app.uploads.tiktok_uploader import TikTokUploader
from app.uploads.upload_queue import UploadQueue
from app.uploads.youtube_uploader import YouTubeUploader


@dataclass(slots=True)
class AppContext:
    paths: AppPaths
    settings_store: SettingsStore
    settings: AppSettings
    database: Database
    source_profiles: JsonRepository
    projects: JsonRepository
    schedule_templates: JsonRepository
    presets: PresetRepository
    preset_manager: PresetManager
    style_profiles: StyleProfileRepository
    style_profile_manager: StyleProfileManager
    design_profiles: DesignProfileRepository
    design_profile_manager: DesignProfileManager
    edit_feedback: AIEditFeedbackRepository
    adaptive_preferences: AdaptivePreferenceService
    channels: ChannelRepository
    production_jobs: ProductionJobRepository
    reviews: ReviewRepository
    upload_jobs: UploadJobRepository
    review_queue: ReviewQueue
    upload_queue: UploadQueue
    prompt_builder: PromptBuilder
    pricing: PricingCatalog
    ledger: AIUsageLedger
    probe: MediaProbe
    asset_library: AssetLibrary
    oauth: OAuthManager
    credentials: CredentialStore
    scheduler: PersistentUploadScheduler
    production: BatchProductionService
    mock_media_paths: list[Path] = field(default_factory=list)

    @classmethod
    def build(
        cls,
        root: Path | None = None,
        *,
        recover_interrupted_production: bool = True,
        credential_store: CredentialStore | None = None,
    ) -> AppContext:
        paths = AppPaths.build(root)
        paths.ensure()
        database = Database(paths.database)
        database.migrate()
        scrub_persisted_diagnostics(database)
        settings_store = SettingsStore(paths, database)
        settings = settings_store.load()
        credentials = credential_store or KeyringCredentialStore()
        source_profiles = JsonRepository(database, "source_profiles", SourceProfile)
        projects = JsonRepository(database, "projects", SourceProjectPlan)
        schedule_templates = JsonRepository(database, "schedule_templates", ScheduleTemplate)
        presets = PresetRepository(database)
        style_profiles = StyleProfileRepository(database)
        style_profile_manager = StyleProfileManager(style_profiles)
        style_profile_manager.ensure_core_profiles()
        preset_manager = PresetManager(presets, style_profile_manager)
        preset_manager.ensure_core_presets()
        design_profiles = DesignProfileRepository(database)
        design_profile_manager = DesignProfileManager(design_profiles, style_profile_manager)
        design_profile_manager.ensure_core_profiles()
        for preset in presets.list():
            previous_design = preset.style_profiles.design
            design_profile_manager.reconcile_preset(preset)
            if preset.style_profiles.design != previous_design:
                presets.save(preset)
        channels = ChannelRepository(database)
        production_jobs = ProductionJobRepository(database)
        interrupted_states = {
            ProductionStatus.DISCOVERING,
            ProductionStatus.DOWNLOADING,
            ProductionStatus.PROBING,
            ProductionStatus.ANALYZING,
            ProductionStatus.SELECTING,
            ProductionStatus.GENERATING_COPY,
            ProductionStatus.RENDERING,
            ProductionStatus.VALIDATING,
            ProductionStatus.UPLOADING,
        }
        if recover_interrupted_production:
            for interrupted in production_jobs.list():
                if interrupted.status in interrupted_states:
                    interrupted.status = ProductionStatus.FAILED
                    interrupted.last_error = "ClipFactory stopped during this operation. Retry uses persisted planning and resumable upload state."
                    interrupted.current_step = "Interrupted operation recovered for retry"
                    interrupted.log_messages.append(interrupted.last_error)
                    production_jobs.save(interrupted, validate_transition=False)
        reviews = ReviewRepository(database)
        edit_feedback = AIEditFeedbackRepository(database)
        adaptive_preferences = AdaptivePreferenceService(
            edit_feedback,
            enabled=settings.ai.adaptive_prompt_enabled,
            maximum_examples=settings.ai.adaptive_prompt_maximum_examples,
            minimum_pattern_occurrences=(settings.ai.adaptive_prompt_minimum_pattern_occurrences),
        )
        upload_jobs = UploadJobRepository(database)
        for recovered_job in reconcile_missed_jobs(
            upload_jobs.list(),
            policy=MissedJobPolicy(settings.upload.missed_job_policy),
        ):
            upload_jobs.save(recovered_job)
        review_queue = ReviewQueue(reviews, production_jobs, adaptive_preferences)
        upload_queue = UploadQueue(upload_jobs, production_jobs)
        prompt_builder = PromptBuilder(
            settings.ai.clip_prompt_version,
            settings.ai.creative_prompt_version,
            settings.ai.review_prompt_version,
        )
        pricing_path = paths.config / "defaults" / "ai_pricing.json"
        if not pricing_path.is_file():
            pricing_path = (
                Path(__file__).resolve().parents[2] / "config" / "defaults" / "ai_pricing.json"
            )
        pricing = PricingCatalog(pricing_path)
        ledger = AIUsageLedger(database)
        ffprobe = settings.resolve_binary(settings.ffprobe_path)
        ffmpeg = settings.resolve_binary(settings.ffmpeg_path)
        probe = MediaProbe(ffprobe)
        thumbnails = ThumbnailGenerator(paths.thumbnails, ffmpeg)
        asset_library = AssetLibrary(paths.assets, database, thumbnails, ffprobe)
        asset_library.scan()
        download_cache = DownloadCache(database)
        downloads = (
            Path(settings.cache_directory).expanduser().resolve()
            if settings.cache_directory
            else paths.downloads
        )
        temporary = (
            Path(settings.temporary_directory).expanduser().resolve()
            if settings.temporary_directory
            else paths.temp
        )
        downloader = MediaDownloader(
            download_cache,
            downloads,
            temporary,
            ytdlp_path=settings.ytdlp_path,
            ffmpeg_path=ffmpeg,
            retry_count=settings.source.retry_count,
            max_height=settings.source.max_download_height,
        )
        renderer = FFmpegRenderer(
            temporary,
            ffmpeg_path=ffmpeg,
            ffprobe_path=ffprobe,
            cleanup=settings.render.cleanup_temporary_files,
            runtime_settings=settings.render,
        )
        history = UsedMediaHistory(database)
        selection_planner = ClipSelectionPlanner(history)
        oauth = OAuthManager(database, credentials)
        youtube = YouTubeUploader(oauth, retry_count=settings.upload.retry_count)
        tiktok = TikTokUploader(oauth, probe, retry_count=settings.upload.retry_count)
        upload_job_store = PersistentJobStore(upload_jobs)
        upload_job_store.recover_interrupted()
        scheduler = PersistentUploadScheduler(
            upload_job_store,
            upload_jobs,
            channels,
            production_jobs,
            {"youtube": youtube, "tiktok": tiktok},
            used_media_history=history,
            max_concurrency=settings.upload.concurrency,
        )

        def analysis_service_factory(use_mock: bool) -> AnalysisService:
            provider_name = "mock" if use_mock else settings.ai.provider
            if provider_name == "mock":
                provider = MockAIAnalysisProvider()
            elif provider_name == "twelvelabs":
                provider = TwelveLabsAnalysisProvider()
            else:
                provider = GeminiAnalysisProvider(
                    model=settings.ai.model,
                    api_key_env=settings.ai.api_key_env,
                    api_key=resolve_credential(
                        credentials, GEMINI_API_KEY, settings.ai.api_key_env
                    ),
                    prompt_builder=prompt_builder,
                    media_resolution=settings.ai.media_resolution,
                    request_timeout_seconds=settings.ai.request_timeout_seconds,
                    processing_timeout_seconds=settings.ai.processing_timeout_seconds,
                )
            cache = AnalysisCache(database)
            guard = AIBudgetGuard(settings.ai.budget, ledger)
            estimator = RequestEstimator(pricing)
            return AnalysisService(
                provider,
                cache,
                ledger,
                guard,
                estimator,
                pricing,
                prompt_version=settings.ai.clip_prompt_version,
                media_resolution=settings.ai.media_resolution,
                cache_enabled=settings.ai.cache_enabled,
                clip_output_token_estimate=settings.ai.clip_output_token_estimate,
                creative_output_token_estimate=settings.ai.creative_output_token_estimate,
                review_output_token_estimate=settings.ai.review_output_token_estimate,
            )

        context_box: dict[str, AppContext] = {}
        real_source_provider = create_source_provider(settings.source, database, credentials)

        def source_provider_factory(use_mock: bool):
            if use_mock:
                return MockRedditSourceProvider(context_box["context"].mock_media_paths)
            return real_source_provider

        validator = TechnicalValidator(probe, ffmpeg)

        def final_review_factory(analysis_service: AnalysisService) -> FinalReviewService:
            return FinalReviewService(
                probe,
                validator,
                analysis_service,
                prompt_builder,
                ai_enabled=settings.ai.final_review_enabled,
                expected_video_codec=renderer.video_codec_for,
            )

        output_directory = (
            Path(settings.output_directory).expanduser().resolve()
            if settings.output_directory
            else paths.outputs
        )
        production = BatchProductionService(
            source_provider_factory=source_provider_factory,
            analysis_service_factory=analysis_service_factory,
            prompt_builder=prompt_builder,
            downloader=downloader,
            probe=probe,
            source_planner=SourceProjectPlanner(),
            selection_planner=selection_planner,
            history=history,
            renderer=renderer,
            render_plan_builder=RenderPlanBuilder(),
            final_review_factory=final_review_factory,
            review_queue=review_queue,
            review_repository=reviews,
            job_repository=production_jobs,
            project_repository=projects,
            preset_repository=presets,
            asset_library=asset_library,
            output_directory=output_directory,
            adaptive_preferences=adaptive_preferences,
        )
        context = cls(
            paths=paths,
            settings_store=settings_store,
            settings=settings,
            database=database,
            source_profiles=source_profiles,
            projects=projects,
            schedule_templates=schedule_templates,
            presets=presets,
            preset_manager=preset_manager,
            style_profiles=style_profiles,
            style_profile_manager=style_profile_manager,
            design_profiles=design_profiles,
            design_profile_manager=design_profile_manager,
            edit_feedback=edit_feedback,
            adaptive_preferences=adaptive_preferences,
            channels=channels,
            production_jobs=production_jobs,
            reviews=reviews,
            upload_jobs=upload_jobs,
            review_queue=review_queue,
            upload_queue=upload_queue,
            prompt_builder=prompt_builder,
            pricing=pricing,
            ledger=ledger,
            probe=probe,
            asset_library=asset_library,
            oauth=oauth,
            credentials=credentials,
            scheduler=scheduler,
            production=production,
        )
        context_box["context"] = context
        return context
