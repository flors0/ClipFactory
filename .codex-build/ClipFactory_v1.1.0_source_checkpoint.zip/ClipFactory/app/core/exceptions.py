"""Application-specific exceptions."""


class ClipFactoryError(Exception):
    """Base exception for expected application errors."""


class ConfigurationError(ClipFactoryError):
    """Raised when configuration is invalid or incomplete."""


class SourceAccessError(ClipFactoryError):
    """Raised when a source cannot be accessed without bypassing restrictions."""


class DownloadError(ClipFactoryError):
    """Raised when media resolution or download fails."""


class MediaProbeError(ClipFactoryError):
    """Raised when ffprobe cannot inspect a file."""


class AIProviderError(ClipFactoryError):
    """Raised for invalid or failed AI provider operations."""


class AIProviderFatalError(AIProviderError):
    """Raised when retrying the same provider configuration cannot succeed."""


class BudgetExceededError(ClipFactoryError):
    """Raised before an AI request that would exceed a configured limit."""


class RenderError(ClipFactoryError):
    """Raised when a render cannot be completed."""


class ValidationError(ClipFactoryError):
    """Raised when deterministic validation fails."""


class UploadError(ClipFactoryError):
    """Raised when an upload operation fails."""


class OAuthError(ClipFactoryError):
    """Raised when OAuth authorization is missing, expired, or rejected."""


class CancelledError(ClipFactoryError):
    """Raised when a cooperative operation is cancelled."""
