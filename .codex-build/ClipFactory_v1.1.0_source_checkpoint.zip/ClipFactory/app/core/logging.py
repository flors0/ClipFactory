"""Structured logging with secret redaction and per-production-attempt routing."""

from __future__ import annotations

import logging
import os
import re
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from logging.handlers import RotatingFileHandler
from pathlib import Path

_LABELED_SECRET = re.compile(
    r"(?i)([\"']?(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password)"
    r"[\"']?\s*[:=]\s*[\"']?)([^\"'\s,;&}]+)"
)
_BEARER_SECRET = re.compile(r"(?i)(authorization\s*:\s*bearer\s+)([^\s,;]+)")
_QUERY_SECRET = re.compile(
    r"(?i)([?&](?:access_token|refresh_token|token|api_key|key|signature|sig|auth)=)([^&#\s]+)"
)
_KNOWN_PROVIDER_SECRET = re.compile(
    r"(?<![A-Za-z0-9_-])(?:AIza[0-9A-Za-z_-]{20,}|AQ\.[0-9A-Za-z_-]{20,})(?![A-Za-z0-9_-])"
)
_REGISTERED_SECRETS: set[str] = set()
_REGISTERED_SECRETS_LOCK = threading.Lock()
_JOB_ID: ContextVar[str] = ContextVar("clipfactory_job_id", default="-")
_ATTEMPT: ContextVar[str] = ContextVar("clipfactory_attempt", default="-")
_BATCH_ID: ContextVar[str] = ContextVar("clipfactory_batch_id", default="-")


def register_secret_value(value: str | None) -> None:
    """Register a runtime-only credential so exceptions cannot leak it into diagnostics."""
    if not value or len(value) < 6:
        return
    with _REGISTERED_SECRETS_LOCK:
        _REGISTERED_SECRETS.add(value)


@contextmanager
def production_log_context(job_id: str, attempt: int, batch_id: str) -> Iterator[None]:
    """Tag all logs produced by the current worker, including dependency logs."""
    job_token = _JOB_ID.set(job_id)
    attempt_token = _ATTEMPT.set(str(attempt))
    batch_token = _BATCH_ID.set(batch_id)
    try:
        yield
    finally:
        _BATCH_ID.reset(batch_token)
        _ATTEMPT.reset(attempt_token)
        _JOB_ID.reset(job_token)


def redact_text(value: object) -> str:
    """Remove common credential forms from text before display or persistence."""
    message = str(value)
    message = _LABELED_SECRET.sub(r"\1[REDACTED]", message)
    message = _BEARER_SECRET.sub(r"\1[REDACTED]", message)
    message = _QUERY_SECRET.sub(r"\1[REDACTED]", message)
    message = _KNOWN_PROVIDER_SECRET.sub("[REDACTED]", message)
    with _REGISTERED_SECRETS_LOCK:
        registered = tuple(_REGISTERED_SECRETS)
    for secret in registered:
        message = message.replace(secret, "[REDACTED]")
    for name, secret in os.environ.items():
        upper_name = name.upper()
        if (
            secret
            and len(secret) >= 6
            and any(marker in upper_name for marker in ("API_KEY", "TOKEN", "SECRET", "PASSWORD"))
        ):
            message = message.replace(secret, "[REDACTED]")
    return message


def scrub_log_files(log_directory: Path) -> int:
    """Redact credential patterns already present in active or rotated text logs."""
    scrubbed = 0
    for path in [*log_directory.glob("clipfactory.log*"), *log_directory.glob("attempts/*.log")]:
        if not path.is_file():
            continue
        original = path.read_text(encoding="utf-8", errors="replace")
        redacted = redact_text(original)
        if redacted == original:
            continue
        temporary = path.with_name(f".{path.name}.redacting")
        try:
            temporary.write_text(redacted, encoding="utf-8")
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)
        scrubbed += 1
    return scrubbed


class SecretRedactionFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.job_id = _JOB_ID.get()
        record.attempt = _ATTEMPT.get()
        record.batch_id = _BATCH_ID.get()
        record.msg = redact_text(record.getMessage())
        record.args = ()
        return True


class RedactingFormatter(logging.Formatter):
    """Redact the fully formatted record, including exception tracebacks."""

    def format(self, record: logging.LogRecord) -> str:
        return redact_text(super().format(record))


class ProductionAttemptFileHandler(logging.Handler):
    """Write each job attempt to its own file so parallel jobs never become one visual block."""

    def __init__(self, directory: Path):
        super().__init__()
        self.directory = directory
        self.directory.mkdir(parents=True, exist_ok=True)

    def emit(self, record: logging.LogRecord) -> None:
        job_id = str(getattr(record, "job_id", "-"))
        attempt = str(getattr(record, "attempt", "-"))
        if job_id == "-" or attempt == "-":
            return
        safe_job_id = re.sub(r"[^A-Za-z0-9_-]+", "-", job_id)[:80]
        safe_attempt = re.sub(r"[^0-9]+", "", attempt) or "0"
        path = self.directory / f"job-{safe_job_id}-attempt-{safe_attempt}.log"
        try:
            with path.open("a", encoding="utf-8") as stream:
                stream.write(self.format(record))
                stream.write("\n")
        except Exception:
            self.handleError(record)


def configure_logging(log_directory: Path, level: str = "INFO") -> logging.Logger:
    log_directory.mkdir(parents=True, exist_ok=True)
    scrub_log_files(log_directory)
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    root.handlers.clear()
    formatter = RedactingFormatter(
        "%(asctime)s | %(levelname)s | job=%(job_id)s | attempt=%(attempt)s | "
        "batch=%(batch_id)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    )
    redaction = SecretRedactionFilter()
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    stream.addFilter(redaction)
    file_handler = RotatingFileHandler(
        log_directory / "clipfactory.log",
        maxBytes=5_000_000,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    file_handler.addFilter(redaction)
    attempt_handler = ProductionAttemptFileHandler(log_directory / "attempts")
    attempt_handler.setFormatter(formatter)
    attempt_handler.addFilter(redaction)
    root.addHandler(stream)
    root.addHandler(file_handler)
    root.addHandler(attempt_handler)
    return logging.getLogger("clipfactory")
