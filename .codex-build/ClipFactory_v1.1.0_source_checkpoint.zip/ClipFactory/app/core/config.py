"""Typed, non-secret application configuration."""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.core.paths import AppPaths
from app.storage.database import Database

_ENVIRONMENT_VARIABLE_NAME = re.compile(r"[A-Z][A-Z0-9_]{1,100}")


def _validate_environment_variable_name(value: str) -> str:
    candidate = value.strip()
    if not _ENVIRONMENT_VARIABLE_NAME.fullmatch(candidate):
        raise ValueError(
            "Enter an environment variable name such as GEMINI_API_KEY, using only uppercase "
            "letters, digits, and underscores. Do not paste the secret value into Settings."
        )
    return candidate


class BudgetSettings(BaseModel):
    request_limit_usd: float = Field(0.25, ge=0)
    job_limit_usd: float = Field(2.0, ge=0)
    daily_limit_usd: float = Field(2.0, ge=0)
    monthly_limit_usd: float = Field(20.0, ge=0)
    warning_threshold_percent: int = Field(80, ge=1, le=100)
    max_tokens_per_request: int = Field(64_000, ge=1)
    max_video_seconds_per_request: float = Field(120.0, gt=0)


class SourceSettings(BaseModel):
    model_config = ConfigDict(validate_assignment=True)

    reddit_provider: Literal["archive", "public", "oauth", "mock"] = "archive"
    request_interval_seconds: float = Field(1.5, ge=0.5)
    timeout_seconds: float = Field(25.0, gt=0)
    retry_count: int = Field(3, ge=0, le=10)
    cache_ttl_seconds: int = Field(900, ge=0)
    default_candidate_limit: int = Field(50, ge=1, le=200)
    max_download_height: int = Field(1080, ge=240, le=4320)
    archive_base_url: str = "https://arctic-shift.photon-reddit.com"
    archive_max_pages: int = Field(5, ge=1, le=10)
    archive_min_short_edge: int = Field(720, ge=0, le=2160)
    archive_require_audio: bool = True
    archive_score_maturity_hours: int = Field(36, ge=0, le=168)
    user_agent: str = "ClipFactory/1.1.0 (+desktop content planning; contact: local-user)"
    oauth_client_id_env: str = "REDDIT_CLIENT_ID"
    oauth_client_secret_env: str = "REDDIT_CLIENT_SECRET"
    oauth_refresh_token_env: str = "REDDIT_REFRESH_TOKEN"

    @field_validator(
        "oauth_client_id_env",
        "oauth_client_secret_env",
        "oauth_refresh_token_env",
    )
    @classmethod
    def validate_environment_variable_names(cls, value: str) -> str:
        return _validate_environment_variable_name(value)


class AISettings(BaseModel):
    model_config = ConfigDict(validate_assignment=True)

    provider: Literal["gemini", "mock", "twelvelabs"] = "gemini"
    model: str = "gemini-3.1-flash-lite"
    media_resolution: Literal["low", "medium", "high"] = "low"
    api_key_env: str = "GEMINI_API_KEY"
    request_timeout_seconds: float = Field(120.0, gt=0)
    processing_timeout_seconds: float = Field(600.0, gt=0)
    cache_enabled: bool = True
    final_review_enabled: bool = True
    clip_prompt_version: str = "clip-v2"
    creative_prompt_version: str = "creative-v3"
    review_prompt_version: str = "review-v1"
    adaptive_prompt_enabled: bool = True
    adaptive_prompt_maximum_examples: int = Field(8, ge=1, le=20)
    adaptive_prompt_minimum_pattern_occurrences: int = Field(3, ge=2, le=20)
    clip_output_token_estimate: int = Field(1200, ge=100, le=32_000)
    creative_output_token_estimate: int = Field(1800, ge=100, le=32_000)
    review_output_token_estimate: int = Field(1200, ge=100, le=32_000)
    budget: BudgetSettings = Field(default_factory=BudgetSettings)

    @field_validator("api_key_env")
    @classmethod
    def validate_api_key_environment_variable_name(cls, value: str) -> str:
        return _validate_environment_variable_name(value)


class RenderSettings(BaseModel):
    parallel_renders: int = Field(1, ge=1, le=4)
    hardware_acceleration: str | None = None
    codec: str = Field("libx264", min_length=1)
    crf: int = Field(20, ge=0, le=51)
    video_bitrate: str | None = None
    preset: str = Field("medium", min_length=1)
    audio_bitrate: str = Field("192k", min_length=1)
    cleanup_temporary_files: bool = True
    preview_quality: Literal["low", "medium", "high"] = "medium"


class UploadSettings(BaseModel):
    concurrency: int = Field(1, ge=1, le=4)
    retry_count: int = Field(5, ge=0, le=10)
    default_privacy: str = "private"
    metadata_language: str = "en"
    scheduler_auto_start: bool = True
    missed_job_policy: Literal["skip", "upload_immediately", "shift_remaining", "ask"] = "ask"


class UISettings(BaseModel):
    log_scroll_positions: dict[str, int] = Field(default_factory=dict)
    log_follow_tail: dict[str, bool] = Field(default_factory=dict)
    review_queue_horizontal_sizes: tuple[int, int] = (620, 900)
    review_queue_vertical_sizes: tuple[int, int] = (560, 340)


class AppSettings(BaseModel):
    theme: Literal["light", "dark", "system"] = "dark"
    language: str = "en"
    timezone: str = "Europe/Berlin"
    log_level: str = "INFO"
    auto_update_checks: bool = False
    output_directory: str | None = None
    cache_directory: str | None = None
    temporary_directory: str | None = None
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"
    ytdlp_path: str | None = None
    source: SourceSettings = Field(default_factory=SourceSettings)
    ai: AISettings = Field(default_factory=AISettings)
    render: RenderSettings = Field(default_factory=RenderSettings)
    upload: UploadSettings = Field(default_factory=UploadSettings)
    ui: UISettings = Field(default_factory=UISettings)

    @field_validator("ffmpeg_path", "ffprobe_path")
    @classmethod
    def validate_binary_name(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Executable path cannot be empty.")
        return value

    def resolve_binary(self, configured: str) -> str:
        explicit = Path(configured).expanduser()
        if explicit.parent != Path(".") and explicit.exists():
            return str(explicit.resolve())
        return shutil.which(configured) or configured


class SettingsStore:
    """SQLite settings store that rejects secret values and imports legacy JSON once."""

    _secret_suffixes = ("secret", "password", "token", "api_key", "apikey")

    def __init__(self, paths: AppPaths, database: Database):
        self.legacy_path = paths.data / "settings.json"
        self.database = database

    def load(self) -> AppSettings:
        row = self.database.fetchone(
            "SELECT value_json FROM app_settings WHERE key = ?", ("settings",)
        )
        if row:
            raw = json.loads(row["value_json"])
        elif self.legacy_path.exists():
            raw = json.loads(self.legacy_path.read_text(encoding="utf-8"))
            self._reject_secrets(raw)
            self._migrate_v1_0_6_defaults(raw)
            settings = AppSettings.model_validate(raw)
            self.save(settings)
            return settings
        else:
            return AppSettings()
        self._reject_secrets(raw)
        migrated = self._migrate_v1_0_6_defaults(raw)
        settings = AppSettings.model_validate(raw)
        if migrated:
            self.save(settings)
        return settings

    def save(self, settings: AppSettings) -> None:
        payload = settings.model_dump(mode="json")
        self._reject_secrets(payload)
        self.database.execute(
            "INSERT INTO app_settings(key, value_json, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP) "
            "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, updated_at=excluded.updated_at",
            ("settings", json.dumps(payload, separators=(",", ":"), ensure_ascii=False)),
        )

    def _reject_secrets(self, value: object, prefix: str = "") -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                lowered = key.lower()
                is_environment_reference = lowered.endswith("_env")
                secret_candidate = lowered[:-4] if is_environment_reference else lowered
                looks_secret = any(
                    secret_candidate == suffix or secret_candidate.endswith(f"_{suffix}")
                    for suffix in self._secret_suffixes
                )
                if looks_secret and is_environment_reference:
                    if not isinstance(child, str) or not _ENVIRONMENT_VARIABLE_NAME.fullmatch(
                        child
                    ):
                        raise ValueError(f"Secret environment reference is invalid: {prefix}{key}")
                elif looks_secret:
                    raise ValueError(f"Secret-like setting cannot be persisted: {prefix}{key}")
                self._reject_secrets(child, f"{prefix}{key}.")
        elif isinstance(value, list):
            for child in value:
                self._reject_secrets(child, prefix)

    @staticmethod
    def _migrate_v1_0_6_defaults(raw: object) -> bool:
        if not isinstance(raw, dict):
            return False
        changed = False
        ai = raw.get("ai")
        if isinstance(ai, dict):
            if ai.get("clip_prompt_version") == "clip-v1":
                ai["clip_prompt_version"] = "clip-v2"
                changed = True
            if ai.get("creative_prompt_version") in {"creative-v1", "creative-v2"}:
                ai["creative_prompt_version"] = "creative-v3"
                changed = True
        source = raw.get("source")
        if isinstance(source, dict) and source.get("user_agent") in {
            "ClipFactory/1.0.6 (+desktop content planning; contact: local-user)",
            "ClipFactory/1.0.7 (+desktop content planning; contact: local-user)",
            "ClipFactory/1.0.8 (+desktop content planning; contact: local-user)",
            "ClipFactory/1.0.9 (+desktop content planning; contact: local-user)",
            "ClipFactory/1.0.10 (+desktop content planning; contact: local-user)",
        }:
            source["user_agent"] = (
                "ClipFactory/1.1.0 (+desktop content planning; contact: local-user)"
            )
            changed = True
        return changed
