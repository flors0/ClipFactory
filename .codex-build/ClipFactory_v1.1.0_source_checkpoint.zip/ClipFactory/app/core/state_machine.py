"""Persistable production and upload state transitions."""

from __future__ import annotations

from collections.abc import Mapping

from app.models.render_models import ProductionStatus

ALLOWED_TRANSITIONS: Mapping[ProductionStatus, set[ProductionStatus]] = {
    ProductionStatus.PLANNED: {ProductionStatus.DISCOVERING, ProductionStatus.CANCELLED},
    ProductionStatus.DISCOVERING: {
        ProductionStatus.DOWNLOADING,
        ProductionStatus.FAILED,
        ProductionStatus.CANCELLED,
    },
    ProductionStatus.DOWNLOADING: {
        ProductionStatus.PROBING,
        ProductionStatus.FAILED,
        ProductionStatus.CANCELLED,
    },
    ProductionStatus.PROBING: {
        ProductionStatus.ANALYZING,
        ProductionStatus.FAILED,
        ProductionStatus.CANCELLED,
    },
    ProductionStatus.ANALYZING: {
        ProductionStatus.SELECTING,
        ProductionStatus.FAILED,
        ProductionStatus.CANCELLED,
    },
    ProductionStatus.SELECTING: {
        ProductionStatus.GENERATING_COPY,
        ProductionStatus.FAILED,
        ProductionStatus.CANCELLED,
    },
    ProductionStatus.GENERATING_COPY: {
        ProductionStatus.RENDERING,
        ProductionStatus.FAILED,
        ProductionStatus.CANCELLED,
    },
    ProductionStatus.RENDERING: {
        ProductionStatus.VALIDATING,
        ProductionStatus.FAILED,
        ProductionStatus.CANCELLED,
    },
    ProductionStatus.VALIDATING: {
        ProductionStatus.AWAITING_REVIEW,
        ProductionStatus.FAILED,
        ProductionStatus.CANCELLED,
    },
    ProductionStatus.AWAITING_REVIEW: {
        ProductionStatus.APPROVED,
        ProductionStatus.REJECTED,
        ProductionStatus.RENDERING,
    },
    ProductionStatus.APPROVED: {ProductionStatus.QUEUED_FOR_UPLOAD, ProductionStatus.REJECTED},
    ProductionStatus.QUEUED_FOR_UPLOAD: {ProductionStatus.UPLOADING, ProductionStatus.CANCELLED},
    ProductionStatus.UPLOADING: {
        ProductionStatus.SCHEDULED,
        ProductionStatus.PUBLISHED,
        ProductionStatus.FAILED,
    },
    ProductionStatus.SCHEDULED: {
        ProductionStatus.UPLOADING,
        ProductionStatus.PUBLISHED,
        ProductionStatus.FAILED,
        ProductionStatus.CANCELLED,
    },
    ProductionStatus.FAILED: {
        ProductionStatus.PLANNED,
        ProductionStatus.DISCOVERING,
        ProductionStatus.DOWNLOADING,
        ProductionStatus.ANALYZING,
        ProductionStatus.RENDERING,
        ProductionStatus.UPLOADING,
        ProductionStatus.CANCELLED,
    },
    ProductionStatus.REJECTED: {ProductionStatus.RENDERING, ProductionStatus.CANCELLED},
    ProductionStatus.CANCELLED: set(),
    ProductionStatus.PUBLISHED: set(),
}


def require_transition(current: ProductionStatus, target: ProductionStatus) -> None:
    if current == target:
        return
    if target not in ALLOWED_TRANSITIONS[current]:
        raise ValueError(f"Invalid state transition: {current.value} -> {target.value}")
