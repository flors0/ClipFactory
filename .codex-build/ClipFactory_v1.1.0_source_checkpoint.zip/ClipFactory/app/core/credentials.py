"""OS-backed application credentials with environment-variable compatibility."""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from contextlib import suppress

import keyring

from app.core.exceptions import ConfigurationError
from app.core.logging import register_secret_value

GEMINI_API_KEY = "settings:gemini_api_key"
REDDIT_CLIENT_ID = "settings:reddit_client_id"
REDDIT_CLIENT_SECRET = "settings:reddit_client_secret"
REDDIT_REFRESH_TOKEN = "settings:reddit_refresh_token"
TIKTOK_CLIENT_KEY = "settings:tiktok_client_key"
TIKTOK_CLIENT_SECRET = "settings:tiktok_client_secret"
TIKTOK_REDIRECT_URI = "settings:tiktok_redirect_uri"
TIKTOK_SCOPES = "settings:tiktok_scopes"


class CredentialStore(ABC):
    @abstractmethod
    def get(self, reference: str) -> str | None: ...

    @abstractmethod
    def set(self, reference: str, value: str) -> None: ...

    @abstractmethod
    def delete(self, reference: str) -> None: ...


class KeyringCredentialStore(CredentialStore):
    """Store credentials in Windows Credential Manager (or the platform keyring)."""

    service_name = "ClipFactory"

    def get(self, reference: str) -> str | None:
        try:
            value = keyring.get_password(self.service_name, reference)
        except keyring.errors.KeyringError as error:
            raise ConfigurationError(
                "The operating-system credential store is unavailable."
            ) from error
        register_secret_value(value)
        return value

    def set(self, reference: str, value: str) -> None:
        if not reference or not value.strip():
            raise ConfigurationError("Credential name and value cannot be empty.")
        try:
            keyring.set_password(self.service_name, reference, value.strip())
        except keyring.errors.KeyringError as error:
            raise ConfigurationError(
                "The credential could not be saved in the operating-system credential store."
            ) from error
        register_secret_value(value.strip())

    def delete(self, reference: str) -> None:
        with suppress(keyring.errors.PasswordDeleteError):
            try:
                keyring.delete_password(self.service_name, reference)
            except keyring.errors.KeyringError as error:
                raise ConfigurationError(
                    "The credential could not be removed from the operating-system credential store."
                ) from error


class InMemoryCredentialStore(CredentialStore):
    """Test-only credential store; never selected by the desktop application."""

    def __init__(self):
        self.values: dict[str, str] = {}

    def get(self, reference: str) -> str | None:
        value = self.values.get(reference)
        register_secret_value(value)
        return value

    def set(self, reference: str, value: str) -> None:
        self.values[reference] = value
        register_secret_value(value)

    def delete(self, reference: str) -> None:
        self.values.pop(reference, None)


def resolve_credential(
    store: CredentialStore | None,
    reference: str,
    environment_name: str,
) -> str | None:
    """Prefer the GUI-managed OS credential and retain `.env` as a migration fallback."""
    stored = store.get(reference) if store else None
    value = stored or os.getenv(environment_name)
    register_secret_value(value)
    return value
