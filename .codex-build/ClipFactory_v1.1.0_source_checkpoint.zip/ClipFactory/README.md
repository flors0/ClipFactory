# ClipFactory

ClipFactory is a Windows-focused PySide6 desktop application that discovers media automatically from one or more subreddit source profiles, downloads and inspects candidates, performs structured AI analysis, selects clips, renders vertical videos with FFmpeg, presents every result for manual review, and uploads only after a separate explicit upload-batch approval.

The normal production workflow never asks the user to select local source clips. Local files are accepted only by the clearly labelled mock source used by tests and development.

## Implementation status

The repository contains the complete application path, two editable core presets, all twelve
specified UI areas, SQLite persistence and migrations, mock providers, upload integrations,
scheduling, tests, and Windows packaging configuration.

- Offline test status: 125 tests passing; one Qt-only wheel-event test is environment-skipped when
  the host has no EGL runtime.
- Static quality status: Ruff lint and formatting checks passing.
- Vertical slice: automatic Reddit discovery → direct video/original-audio acquisition → probe →
  AI/cache/ledger/budget → selection → FFmpeg render → technical validation → Review Queue.
- Ranking captions reveal only with their own clips, remain visible after reveal, use transparent
  backgrounds by default, and are generated through the short-reaction `clip-v2`/`creative-v3`
  prompt contract.
- Ranking playback counts down from rank `N` to rank `1`, keeping the strongest AI selection for
  the finale while rank `1` remains the top overlay row. Larger responsive typography and active
  rank coloring are enabled by default.
- The Preset editor includes 18 reusable component styles and five complete visual designs across
  Ranking Numbers, Captions, Headers, and layouts. Render plans retain stable profile IDs and style
  fingerprints.
- Clip selection reports concrete rejection counts and can visibly fill a ranking from the
  strongest safe candidates when strict AI quality gates leave too few. Rights/content/watermark,
  duplicate, history, and minimum-duration rules are never silently relaxed.
- Short AI trim suggestions are expanded within their original source clips when that can reach
  the preset target without loops. If the available safe pool remains short, `warn` produces a
  reviewable video with a non-blocking duration warning, while `block` and `auto_extend` stop
  before rendering with exact duration, clip-count, and rejection diagnostics.
- Review Queue gives the table/player most of the page, supports horizontal table/player resizing
  and vertical player/details resizing, and restores both splitter sizes. It also supports
  per-video design changes, full advanced layout editing, direct upload-copy fields, and re-rendering
  from cached project data.
- Saved Review corrections are retained as AI-original → user-preferred examples. Later Gemini
  copy requests receive a small channel-aware, versioned preference context; one-off edits do not
  become global rules. Cross-channel transfer requires the same field-level pattern in at least
  three distinct Reviews with matching language and platform. The memory can be disabled or erased
  in Settings.
- Live source smoke test: current Arctic Shift metadata and `v.redd.it` media were downloaded and
  muxed successfully at 720×1280 and 1080×1920 with AAC original audio.
- Live Gemini, YouTube, and TikTok calls are intentionally not executed by the normal test suite.
- The target UI is Windows. The GUI could not be launched in the Linux build container because its system image does not provide `libEGL.so.1`; non-UI application imports, services, rendering, and tests were verified there. Perform the Windows checklist in [docs/LIVE_TEST_CHECKLIST.md](docs/LIVE_TEST_CHECKLIST.md) before production use.

## Requirements

- Windows 10 or Windows 11.
- Python 3.11–3.14.
- [uv](https://docs.astral.sh/uv/).
- FFmpeg and ffprobe available on `PATH`, or explicit executable paths configured in **Settings**. FFmpeg's official download page links to Windows builds because the FFmpeg project itself publishes source code.
- Internet access for Reddit discovery, media downloads, Gemini, and platform APIs.
- A working OS credential backend. On Windows, `keyring` uses Windows Credential Manager.

Confirm prerequisites in PowerShell:

```powershell
uv --version
ffmpeg -version
ffprobe -version
```

## Start the packaged Windows application

Extract the release ZIP and double-click `ClipFactory\ClipFactory.exe`. Python, uv and a PowerShell
launch command are not required for the packaged build. Keep the complete `ClipFactory` directory
together because the executable uses the adjacent bundled runtime files.

## Install and start from source (developers)

From the project directory:

```powershell
uv sync --group dev --frozen
uv run python -m app.main
```

The required start command is:

```powershell
uv run python -m app.main
```

For a scheduler-only process:

```powershell
uv run python -m app.main --scheduler-only
```

Application data is stored under the project `data/` directory when running from source. A packaged Windows build uses `%LOCALAPPDATA%\ClipFactory` by default. Set `CLIPFACTORY_HOME` to an explicit non-root directory to override that location.

## External credentials and approvals

### Gemini

Open **Settings**, paste the key into **Gemini API key**, and select **Save Settings**. The value is
stored by the operating-system credential store (Windows Credential Manager on Windows), not in
SQLite or a project file. Leave the field blank on later saves to keep the stored key. A legacy
`GEMINI_API_KEY` environment variable or `.env` entry remains an optional migration fallback; it is
not required. A newly saved Gemini key is available to new production jobs immediately.

The default model is `gemini-3.1-flash-lite`. Verified alternatives in the bundled price catalog are
`gemini-2.5-flash-lite`, `gemini-3.1-flash-lite`, and `gemini-3.5-flash`. Model prices are read
from `config/defaults/ai_pricing.json`; its values were checked against the official pricing page
on 2026-07-21. Unknown models are blocked from paid calls until a verified pricing entry is added.

Before downloading media, ClipFactory checks that the configured model is visible to the current
API key and supports `generateContent`. Media up to 14 MiB is sent inline. Larger media uses the
Gemini Files API, waits for ACTIVE state, retries temporary file-reference failures, and is deleted
immediately with retries. Responses use Gemini's native JSON Schema field and are validated with
strict Pydantic models before reported usage is recorded.

### YouTube

1. Create a Google Cloud project and enable YouTube Data API v3.
2. Configure an OAuth consent screen.
3. Create an **OAuth client ID → Desktop app** and download its JSON file.
4. In **Channels**, create a YouTube profile, save it, select it, and choose **Connect OAuth**.
5. Select the downloaded JSON only in the file dialog. Do not copy it into this repository.

OAuth access and refresh data are stored in the OS credential store. SQLite contains only a reference. Uploads use the official resumable protocol, persist the resumable-session reference, record the video ID as soon as the API returns it, and poll `status.uploadStatus` plus `processingDetails.processingStatus` before marking processing complete.

For public scheduled videos, YouTube receives a private video with `status.publishAt`. Private and unlisted videos are uploaded at the local execution time so their requested privacy is preserved. YouTube states that uploads from certain unverified API projects are restricted to private viewing until the project completes its audit.

### TikTok

Register an app in TikTok for Developers, add the Content Posting API product, register the exact loopback redirect URI, and obtain approval for the scopes you need:

Enter the client key, client secret, redirect URI, and scopes in **Settings**. ClipFactory stores
them in the OS credential store. Environment variables with the corresponding `TIKTOK_*` names
remain optional compatibility fallbacks.

- `video.publish` enables direct posting and creator-capability queries.
- `video.upload` enables draft delivery to the user's TikTok inbox without requiring direct-post capability.
- Either scope can be requested alone by changing `TIKTOK_SCOPES`.

TikTok direct-post availability, privacy options, duration, comments, duet, and stitch capabilities are queried immediately before a direct post. Draft-only authorization does not call the `creator_info` endpoint. Uploads use sequential official chunks: 5–64 MB, a final chunk up to 128 MB, one whole chunk below 5 MB, and no more than 1000 chunks. TikTok does not accept a future publication time through this integration, so ClipFactory starts the upload locally at the planned time.

TikTok documents that posts from unaudited API clients are restricted to private viewing. Draft delivery also requires the user to continue the flow from the TikTok inbox. Do not present either state as a public automated publication.

### Reddit discovery

The default `archive` provider requires no Reddit API key and does not use Reddit listing pages.
It searches the documented Arctic Shift index by subreddit and time window, filters indexed posts
for completed Reddit-hosted video, original audio, minimum resolution, NSFW state, age, flair,
score, comments, and duplicates, then downloads only the selected `v.redd.it` media. Reddit's
separate DASH video and highest-bitrate audio tracks are losslessly muxed before the existing
probe/AI/selection/render pipeline continues. Existing profiles and persisted `public` provider
settings migrate to this provider automatically.

Arctic Shift is a third-party service with documented rate limits and no uptime guarantee.
ClipFactory therefore applies bounded retries, request pacing, a local metadata cache, and one
shared discovery result for parallel batch jobs. OAuth remains an optional provider: select
`oauth` and enter the Reddit client ID, client secret, and refresh token directly in **Settings**.

## Normal workflow

1. Open **Sources**, enter a subreddit name, `r/name`, or full subreddit URL, configure filters and rights mode, save the profile, and use **Test Discovery**.
2. Open **Presets**. Edit either core preset directly, use the active layer's **Style profile**
   dropdown or **Style Profiles…**, duplicate one for a custom variant, or create a custom preset.
   Add optional visual/audio media to the asset folders and scan **Asset Library**.
3. Open **Channels**, create target profiles, choose a default Core preset and default visual
   design, and connect OAuth when uploads are required.
4. Open **Batch Planner**, select sources and target channels. The default mode automatically uses
   each channel's preset/design; disable it only for a manual override. Choose total videos or
   **videos per selected channel**, schedule mode, analysis limit, budget, and concurrency.
5. Select **Generate Batch** and confirm the first paid-work gate. Discovery, download, probing, AI analysis, selection, rendering, and validation then run automatically.
6. Monitor **Production Queue**. Failed jobs can be retried; active work supports cooperative cancellation.
7. In **Review Queue**, play and seek the result, inspect technical and AI checks, review source
   rights, edit title/header/captions, change a complete design or individual style, use the advanced
   layout editor when needed, and re-render from the existing project. Saved corrections can
   automatically improve later Gemini copy.
8. Approval creates an upload job in `blocked_approval`; it still cannot transfer media.
9. In **Upload Queue**, select reviewed jobs and choose **Approve Upload Batch**. This is the second and final upload authorization gate.
10. Keep ClipFactory or scheduler-only mode running for local execution times, especially TikTok and private/unlisted YouTube jobs. Remote IDs and status checks are persisted.

## Presets and assets

Exactly two core presets are installed:

- **Ranking** – AI-authored header, ranks `1` through `N` from top to bottom, best-last media
  playback `N → 1`, active-rank color changes, and cumulative captions coupled to the same ranked
  clip.
- **TikTok Core Compilation** – original clips and original audio only; all on-video text is off.

Core settings can be edited and saved. A core preset can also be duplicated or reset to its shipped
state. Custom presets can be created, renamed, duplicated, and deleted. Stable internal IDs do not
change when a custom preset is renamed. The preset contract and property panels are vertically
scrollable, including in smaller/DPI-scaled windows.

Choose **Style Profiles…** for reusable component templates. ClipFactory ships eight Ranking-number
styles and five styles each for Captions and Headers. Profiles have stable IDs and can be applied,
captured from manual settings, duplicated, updated, renamed/deleted when custom, and reset when
built in. Manual changes remain available; a style that no longer matches a saved profile is
labelled `Custom (unsaved)`.

Selecting the Ranking Numbers, Ranking Captions, or Header layer exposes the same category directly
in the right-hand properties panel. Choose a saved profile from the dropdown or use **Save as
New…** to capture the current manual design without leaving the layer editor.

Complete visual designs combine those components with real layer geometry and visibility. The
built-in designs are **Creator Stack**, **Clean Banner**, **Minimal Overlay**, **Neon Countdown**,
and **Clean Compilation**. They can be selected per channel or changed for one video in Review.

The editor supports layer order, visibility, locking, duplication, movement, resize, rotation,
grid/snap, safe zones, platform UI safe zones, timeline visibility, direct text editing,
selection-based font/color/outline/background/glow formatting, QColorDialog, automatic fit, and
project-specific rich-text documents. Responsive font, outline, shadow, blur, glow, and spacing
values use a configurable output-height reference. Every displayed contract field is persisted and
consumed by the renderer.

No transition or transition sound is bundled or preselected. Both core presets ship with
transitions disabled. To add one later, place media in `assets/transitions` and/or `assets/sounds`,
run **Scan Asset Folders**, and select the scanned entries in the preset. ClipFactory stores the
Asset Library ID, not a fragile source-file path.

The source ZIP includes the complete empty `assets/` directory tree so every supported destination
is visible immediately; the placeholder files are not render assets.

Other user assets belong in the matching directories under `assets/`: `interstitials`, `music`,
`fonts`, `images`, `memes`, `backgrounds`, or `subtitles`. Media metadata and visual thumbnails are
generated with ffprobe/FFmpeg.

Dynamic rich-text placeholders include `{header}`, `{theme}`, `{caption}`, and `{rank}`. The
Ranking header uses the AI result without adding a hard-coded `Top N` prefix. Styles on fixed
template text and on a placeholder are preserved when actual text is expanded. Final ASS overlay
geometry uses the same normalized layout engine as the editor preview.

## Scheduling behavior

ClipFactory supports explicit times, interval schedules, saved recurring weekly templates, time zones, persisted queues, restart recovery, pause/resume, and missed-job policies (`ask`, `skip`, `upload_immediately`, `shift_remaining`). Due jobs are claimed with a SQLite `BEGIN IMMEDIATE` transaction before workers start, which prevents two ClipFactory scheduler processes from claiming the same upload. Stale `uploading` jobs become recoverable only after the lease has been inactive for 30 minutes.

The optional Windows helper registers scheduler-only mode at logon. Run from source:

```powershell
uv run python -c "from pathlib import Path; from app.scheduling.windows_task_scheduler import WindowsTaskSchedulerHelper; WindowsTaskSchedulerHelper().register(Path.cwd())"
```

Registering a Windows task changes operating-system state; inspect the generated command before using it in managed environments.

## Data and cache

SQLite uses foreign keys, WAL mode, migrations, bounded busy waits, and explicit transactions. It stores profiles, presets, projects, production/review/upload state, schedule templates, AI usage, cache records, history, non-secret settings, and OAuth credential references. Large media remains in the filesystem.

Runtime directories include:

```text
data/
  clipfactory.db
  cache/ downloads/ previews/ renders/ outputs/
  logs/ (including logs/attempts/) thumbnails/ ai/ temp/
```

The **Logs** page offers the combined application log and one separate, clearly labelled block for
every production attempt. It persists the last vertical position per selected log. New lines follow
the tail only when the user was already at the bottom; reading farther up never causes an
unrequested jump. Numeric fields throughout the application ignore mouse-wheel edits; a wheel
gesture over such a field continues scrolling its enclosing page.

Deleting cached media may require re-downloading or re-analysis. Back up `clipfactory.db` together with referenced output files only while ClipFactory is stopped.

## Security model

- No API key, OAuth token, upload URL, client-secret JSON, `.env`, database, log, downloaded media, or rendered media belongs in source control or the release ZIP.
- API keys, app credentials, OAuth tokens, and resumable upload session values use the OS
  credential store; SQLite stores only non-secret configuration or opaque references.
- Logs, persisted job errors, worker tracebacks, bearer headers, credential-shaped JSON, sensitive URL query parameters, and matching secret environment values are redacted.
- On startup, known credential patterns in existing ClipFactory logs and persisted job/review/upload
  diagnostics are scrubbed as a one-way cleanup for earlier diagnostic output.
- AI budget limits exist per request, production job, day, and month. Concurrent requests reserve projected cost before the paid call.
- The two explicit approval gates prevent generation costs and uploads from starting implicitly.
- FFmpeg, ffprobe, and yt-dlp are invoked with argument lists and no shell expansion.
- Download targets are sanitized and atomically moved; non-global literal IPs, local hostnames, URL credentials, and non-HTTP(S) production URLs are rejected.
- Local source files are accepted only from the explicit mock provider.
- Pydantic validates provider results, presets, settings, metadata, and persistent payloads. Pickle is not used.
- Rights metadata is separate from technical eligibility. The default manual-review mode blocks approval until the user confirms publication rights.

See [docs/SECURITY.md](docs/SECURITY.md) for the full security and trust-boundary description.

## Tests

The normal suite uses deterministic providers and stored fixtures and does not make paid API calls:

```powershell
uv sync --group dev --frozen
uv run ruff format --check .
uv run ruff check .
uv run pytest -q
uv run python -m compileall -q app tests
```

Run only the offline end-to-end slice:

```powershell
uv run pytest -q tests/test_vertical_slice.py
```

Test coverage includes Arctic Shift filtering/ranking/cache, direct Reddit DASH video/audio muxing,
source normalization/parsing/filtering, download cache, probe/thumbnail/render/validation, AI
schemas/cache/usage/estimates/budgets, parallel budget reservations, two-core seeding and v1.0.5
migration, preset persistence, central rank/clip/caption coupling, final-timeline reveal timing,
text-free compilation, optional Asset Library transitions/audio, responsive scroll containers,
log-position persistence, selection/duplicates/history, exact videos-per-channel planning,
schedules/missed jobs, approval gates, metadata mappings, atomic upload claims, TikTok chunk
math/scopes, YouTube remote processing states, GUI-managed credentials, per-attempt logs,
mouse-wheel protection, per-video design snapshots/re-rendering, bounded adaptive prompt memory,
and secret redaction.

## Windows package

Build a PyInstaller one-folder distribution on Windows:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/build_windows.ps1
```

Output: `dist\ClipFactory\ClipFactory.exe`.

The package embeds the Python application, Qt, yt-dlp modules, and verified price configuration. FFmpeg/ffprobe remain explicit external prerequisites. Build and smoke-test the Windows executable on Windows; a Linux PyInstaller result is not a Windows binary.

## Troubleshooting

- **Application initialization failed:** inspect `data/logs/clipfactory.log`; confirm ffprobe can run and configured directories are writable.
- **No Reddit candidates:** use **Test Discovery**, reduce score/comment/age/flair filters, and
  inspect Source Health. If necessary, reduce the Arctic Shift minimum short edge or disable the
  original-audio requirement in **Settings**. A third-party index outage is reported as an error,
  never as a successful empty result.
- **Reddit media download failure:** confirm FFmpeg is reachable and retry the failed job. The
  primary path directly downloads and muxes `v.redd.it` DASH streams; HLS/yt-dlp is retained only
  as a bounded fallback.
- **Gemini blocked before discovery/download:** paste the key into **Settings → Gemini API key**
  and save. Provider creation intentionally happens before network discovery so a missing key
  cannot leave a partially downloaded job.
- **Gemini reports `Unknown name "additional_properties"`:** update to ClipFactory 1.0.2 or
  newer. Version 1.0.1 passed strict Pydantic models through the legacy SDK schema field; 1.0.2
  uses Gemini's native JSON Schema field and retains strict local validation.
- **Gemini returns HTTP 404:** update to ClipFactory 1.0.3 or newer. It checks model visibility
  before discovery or upload and lists the `generateContent` models visible to the current key when
  the configured model is unavailable. Small videos are sent inline; larger ACTIVE file references
  receive bounded retries. A permanent provider-level 4xx stops the job after the first candidate.
- **Open Output Folder with an empty Review Queue:** the button opens the configured output
  directory even before the first successful render. The default source path is `data/outputs/`.
- **YouTube remains private:** confirm requested privacy and schedule, API-project verification/audit status, and the remote `uploadStatus`/processing status.
- **TikTok direct post unavailable:** refresh capabilities, confirm `video.publish` authorization and app audit. Use `draft_upload` with `video.upload` when appropriate.
- **Scheduled TikTok job did not run:** TikTok scheduling is local; keep ClipFactory/scheduler-only mode running or register the optional Windows logon task.
- **OAuth token missing:** reconnect the channel. Copying the database to another Windows account does not copy its OS credential-store values.

## Official references used

- [Arctic Shift API documentation](https://github.com/ArthurHeitmann/arctic_shift/tree/master/api)
- [Gemini structured output](https://ai.google.dev/gemini-api/docs/structured-output)
- [Gemini Files API and deletion](https://ai.google.dev/gemini-api/docs/files)
- [Gemini API pricing](https://ai.google.dev/gemini-api/docs/pricing)
- [YouTube video resource and processing status](https://developers.google.com/youtube/v3/docs/videos)
- [YouTube videos.insert](https://developers.google.com/youtube/v3/docs/videos/insert)
- [YouTube resumable upload protocol](https://developers.google.com/youtube/v3/guides/using_resumable_upload_protocol)
- [TikTok Content Posting API](https://developers.tiktok.com/doc/content-posting-api-get-started)
- [TikTok draft upload](https://developers.tiktok.com/doc/content-posting-api-get-started-upload-content/)
- [TikTok media transfer and chunk restrictions](https://developers.tiktok.com/doc/content-posting-api-media-transfer-guide)
- [Qt for Python](https://doc.qt.io/qtforpython-6/)
- [FFmpeg documentation](https://ffmpeg.org/documentation.html)
- [FFmpeg downloads](https://ffmpeg.org/download.html)
- [yt-dlp project](https://github.com/yt-dlp/yt-dlp)
