$ErrorActionPreference = "Stop"

$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $ProjectRoot

uv sync --group dev --frozen
uv run pyinstaller --clean --noconfirm packaging/ClipFactory.spec

$Executable = Join-Path $ProjectRoot "dist\ClipFactory\ClipFactory.exe"
if (-not (Test-Path $Executable)) {
    throw "PyInstaller completed without creating ClipFactory.exe"
}

$MigrationDirectory = Join-Path $ProjectRoot "dist\ClipFactory\_internal\app\storage\migrations"
if (-not (Test-Path $MigrationDirectory)) {
    throw "Packaged database migrations are missing"
}

$VersionOutput = Join-Path $ProjectRoot "build\clipfactory-version.txt"
$VersionProcess = Start-Process -FilePath $Executable `
    -ArgumentList @("--version-file", "`"$VersionOutput`"") -Wait -PassThru
if ($VersionProcess.ExitCode -ne 0) {
    throw "ClipFactory.exe command-line smoke test failed"
}
if ((Get-Content $VersionOutput -Raw).Trim() -ne "ClipFactory 1.1.0") {
    throw "ClipFactory.exe reported an unexpected packaged version"
}

Write-Host "Windows build created at dist/ClipFactory/ClipFactory.exe"
