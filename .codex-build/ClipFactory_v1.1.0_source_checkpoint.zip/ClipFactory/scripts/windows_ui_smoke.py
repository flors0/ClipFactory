"""Short source-level Qt composition smoke test for a real Windows runner."""

from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

from app.core.app_context import AppContext
from app.ui.main_window import MainWindow


def main() -> int:
    application = QApplication.instance() or QApplication([])
    application.setApplicationName("ClipFactory Windows UI Smoke")
    with TemporaryDirectory(prefix="clipfactory-ui-smoke-") as directory:
        context = AppContext.build(Path(directory))
        window = MainWindow(context)
        if window.stack.count() != 12:
            raise RuntimeError(f"Expected 12 pages, found {window.stack.count()}")
        if window.review.details_scroll.widget() is None:
            raise RuntimeError("Review Queue scroll content was not constructed")
        if window.review.design.count() < 1:
            raise RuntimeError("Review Queue design selector was not constructed")
        window.show()
        QTimer.singleShot(1500, application.quit)
        exit_code = application.exec()
        window.refresh_timer.stop()
        window.close()
        context.scheduler.stop()
    if exit_code:
        raise RuntimeError(f"Qt event loop returned {exit_code}")
    print("Windows Qt composition smoke test passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
