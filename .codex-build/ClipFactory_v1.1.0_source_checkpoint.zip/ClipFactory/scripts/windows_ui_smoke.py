"""Short source-level Qt composition smoke test for a real Windows runner."""

from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication

from app.core.app_context import AppContext
from app.presets.preset_manager import CORE_RANKING_ID
from app.ui.main_window import MainWindow


def main() -> int:
    application = QApplication.instance() or QApplication([])
    application.setApplicationName("ClipFactory Windows UI Smoke")
    with TemporaryDirectory(prefix="clipfactory-ui-smoke-") as directory:
        context = AppContext.build(Path(directory))
        window = MainWindow(context)
        try:
            if window.stack.count() != 12:
                raise RuntimeError(f"Expected 12 pages, found {window.stack.count()}")
            if window.review.details_scroll.widget() is None:
                raise RuntimeError("Review Queue scroll content was not constructed")
            window.review.review_preset = context.presets.get(CORE_RANKING_ID)
            window.review._populate_visual_options()
            if window.review.design.count() < 2:
                raise RuntimeError("Review Queue design selector was not populated")
            window.show()
            QTimer.singleShot(1500, application.quit)
            exit_code = application.exec()
        finally:
            window.refresh_timer.stop()
            window.player.stop()
            window.close()
            context.scheduler.stop()
            context.database.close_thread_connection()
            application.processEvents()
    if exit_code:
        raise RuntimeError(f"Qt event loop returned {exit_code}")
    print("Windows Qt composition smoke test passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
