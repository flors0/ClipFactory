from __future__ import annotations

import json
import logging
from pathlib import Path

import pytest

from app.core.config import AppSettings, SettingsStore
from app.core.credentials import GEMINI_API_KEY, InMemoryCredentialStore, resolve_credential
from app.core.exceptions import ConfigurationError
from app.core.logging import (
    ProductionAttemptFileHandler,
    RedactingFormatter,
    SecretRedactionFilter,
    production_log_context,
    redact_text,
    register_secret_value,
    scrub_log_files,
)
from app.core.paths import AppPaths
from app.download.media_downloader import safe_stem
from app.storage.database import Database
from app.storage.diagnostic_scrubber import scrub_persisted_diagnostics


def test_settings_are_stored_in_sqlite_without_secret_values(tmp_path: Path) -> None:
    paths = AppPaths.build(tmp_path / "home")
    paths.ensure()
    database = Database(paths.database)
    database.migrate()
    store = SettingsStore(paths, database)
    settings = AppSettings()
    settings.ai.api_key_env = "CUSTOM_GEMINI_KEY"
    settings.source.oauth_client_secret_env = "CUSTOM_REDDIT_SECRET"
    store.save(settings)
    assert not (paths.data / "settings.json").exists()
    row = database.fetchone("SELECT value_json FROM app_settings WHERE key = ?", ("settings",))
    assert row and "CUSTOM_GEMINI_KEY" in row["value_json"]
    assert store.load() == settings
    with pytest.raises(ValueError, match="Secret-like"):
        store._reject_secrets({"access_token": "must-not-persist"})
    with pytest.raises(ValueError, match="environment reference"):
        store._reject_secrets({"api_key_env": "actual-secret-value"})


def test_environment_reference_rejects_pasted_secret_without_mutating_settings() -> None:
    settings = AppSettings()
    original = settings.ai.api_key_env
    with pytest.raises(ValueError, match="Do not paste the secret value"):
        settings.ai.api_key_env = "AQ." + "ExampleSecretValue1234567890"
    assert settings.ai.api_key_env == original


def test_gui_managed_credential_takes_priority_over_environment_fallback(monkeypatch) -> None:
    store = InMemoryCredentialStore()
    monkeypatch.setenv("GEMINI_API_KEY", "legacy-environment-key")
    store.set(GEMINI_API_KEY, "gui-managed-key")

    assert resolve_credential(store, GEMINI_API_KEY, "GEMINI_API_KEY") == "gui-managed-key"

    store.delete(GEMINI_API_KEY)
    assert resolve_credential(store, GEMINI_API_KEY, "GEMINI_API_KEY") == "legacy-environment-key"


def test_log_filter_redacts_common_credentials() -> None:
    record = logging.LogRecord(
        "test",
        logging.INFO,
        __file__,
        1,
        "api_key=abc123 Authorization: Bearer token456 refresh_token: secret789",
        (),
        None,
    )
    assert SecretRedactionFilter().filter(record)
    message = record.getMessage()
    assert "abc123" not in message
    assert "token456" not in message
    assert "secret789" not in message
    assert message.count("[REDACTED]") == 3


def test_production_attempt_logs_are_routed_to_separate_files(tmp_path: Path) -> None:
    handler = ProductionAttemptFileHandler(tmp_path / "attempts")
    handler.setFormatter(RedactingFormatter("%(message)s"))
    handler.addFilter(SecretRedactionFilter())
    record = logging.LogRecord(
        "httpx",
        logging.INFO,
        __file__,
        1,
        "HTTP Request: GET https://example.test",
        (),
        None,
    )

    with production_log_context("job-123", 2, "batch-456"):
        handler.handle(record)

    path = tmp_path / "attempts" / "job-job-123-attempt-2.log"
    assert path.read_text(encoding="utf-8").strip() == record.getMessage()


def test_redaction_covers_json_urls_environment_values_and_tracebacks(monkeypatch) -> None:
    monkeypatch.setenv("CUSTOM_API_KEY", "environment-secret")
    message = redact_text(
        '{"access_token": "json-secret", "password": "pass-secret"} '
        "https://example.test/upload?signature=signed-value&part=1 environment-secret"
    )
    assert "json-secret" not in message
    assert "pass-secret" not in message
    assert "signed-value" not in message
    assert "environment-secret" not in message

    provider_key = "AQ." + "ExampleSecretValue1234567890"
    assert provider_key not in redact_text(f"Gemini lookup failed for {provider_key}")

    runtime_secret = "runtime-keyring-secret-123"
    register_secret_value(runtime_secret)
    assert runtime_secret not in redact_text(f"provider failed with {runtime_secret}")

    formatter = RedactingFormatter("%(message)s")
    try:
        raise RuntimeError("client_secret=traceback-secret")
    except RuntimeError:
        record = logging.LogRecord(
            "test",
            logging.ERROR,
            __file__,
            1,
            "Failed",
            (),
            __import__("sys").exc_info(),
        )
    rendered = formatter.format(record)
    assert "traceback-secret" not in rendered


def test_existing_logs_and_job_diagnostics_are_scrubbed(tmp_path: Path) -> None:
    provider_key = "AQ." + "PersistedSecretValue1234567890"
    paths = AppPaths.build(tmp_path / "home")
    paths.ensure()
    log_path = paths.logs / "clipfactory.log"
    log_path.write_text(f"Gemini lookup failed for {provider_key}\n", encoding="utf-8")

    database = Database(paths.database)
    database.migrate()
    payload = json.dumps(
        {
            "last_error": f"Gemini lookup failed for {provider_key}",
            "log_messages": [provider_key],
        }
    )
    database.execute(
        "INSERT INTO production_jobs(id, project_id, status, progress, payload, created_at, "
        "updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        ("job-1", "project-1", "failed", 0, payload, "now", "now"),
    )

    assert scrub_log_files(paths.logs) == 1
    assert scrub_persisted_diagnostics(database) == 1
    persisted = database.fetchone("SELECT payload FROM production_jobs WHERE id = ?", ("job-1",))

    assert provider_key not in log_path.read_text(encoding="utf-8")
    assert persisted and provider_key not in persisted["payload"]
    assert persisted and persisted["payload"].count("[REDACTED]") == 2


def test_path_and_filename_safety(tmp_path: Path) -> None:
    paths = AppPaths.build(tmp_path / "home")
    paths.ensure()
    with pytest.raises(ConfigurationError, match="root"):
        paths.validate_user_directory(Path("/"))
    with pytest.raises(ConfigurationError, match="Unsafe"):
        paths.contained_temp_path("../escape")
    assert safe_stem("../../bad name;$(command).mp4") == "bad-name-command-.mp4"
