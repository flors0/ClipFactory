from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

from app.ui.path_helpers import resolve_output_folder


def test_empty_review_queue_resolves_configured_output_folder(tmp_path: Path) -> None:
    output_directory = tmp_path / "custom-output"

    assert resolve_output_folder(None, output_directory) == output_directory


def test_numeric_wheel_guard_consumes_wheel_edits() -> None:
    try:
        from PySide6.QtCore import QPoint, QPointF, Qt
        from PySide6.QtGui import QWheelEvent
        from PySide6.QtWidgets import QApplication, QSpinBox

        from app.ui.input_guard import NumericWheelGuard
    except ImportError as error:
        pytest.skip(f"Qt runtime libraries are unavailable: {error}")
    application = QApplication.instance() or QApplication([])
    spin = QSpinBox()
    spin.setValue(5)
    event = QWheelEvent(
        QPointF(2, 2),
        QPointF(2, 2),
        QPoint(),
        QPoint(0, 120),
        Qt.MouseButton.NoButton,
        Qt.KeyboardModifier.NoModifier,
        Qt.ScrollPhase.ScrollUpdate,
        False,
    )

    assert NumericWheelGuard(application).eventFilter(spin, event)
    assert spin.value() == 5
