from __future__ import annotations

import shutil
import subprocess
from collections.abc import Callable
from pathlib import Path

import pytest

from app.storage.database import Database


@pytest.fixture
def database(tmp_path: Path) -> Database:
    value = Database(tmp_path / "clipfactory.db")
    value.migrate()
    yield value
    value.close_thread_connection()


@pytest.fixture
def media_factory(tmp_path: Path) -> Callable[..., Path]:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        pytest.skip("FFmpeg is required for media integration tests.")

    def create(
        name: str,
        *,
        duration: float = 1.7,
        width: int = 320,
        height: int = 240,
        frequency: int = 440,
    ) -> Path:
        output = tmp_path / name
        command = [
            ffmpeg,
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            f"testsrc2=size={width}x{height}:rate=30:duration={duration}",
            "-f",
            "lavfi",
            "-i",
            f"sine=frequency={frequency}:sample_rate=48000:duration={duration}",
            "-shortest",
            "-c:v",
            "libx264",
            "-preset",
            "ultrafast",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-movflags",
            "+faststart",
            "-y",
            str(output),
        ]
        completed = subprocess.run(command, capture_output=True, text=True, check=False)
        if completed.returncode:
            pytest.skip(f"FFmpeg test fixture encoding is unavailable: {completed.stderr[-500:]}")
        return output

    return create
