from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from app.core.app_context import AppContext
from app.models.channel_models import ChannelProfile
from app.models.preset_models import DurationEnforcement, DurationRule
from app.models.render_models import ProductionStatus
from app.models.review_models import ReviewStatus
from app.models.upload_models import UploadStatus
from app.planning.batch_planner import BatchPlanner
from app.presets.preset_manager import core_presets
from app.services.production_service import ProductionOptions
from app.sources.source_profile_factory import SourceProfileFactory


def test_offline_vertical_slice_reaches_approved_upload_queue(
    media_factory: Callable[..., Path],
    tmp_path: Path,
) -> None:
    first = media_factory("vertical-first.mp4", duration=2.2, frequency=430)
    second = media_factory("vertical-second.mp4", duration=2.2, frequency=710)
    context = AppContext.build(tmp_path / "clipfactory-home")
    context.mock_media_paths.extend([first, second])

    source = SourceProfileFactory().create(
        "SillyCats",
        name="Offline integration source",
        candidate_limit=2,
    )
    context.source_profiles.save(source)
    preset = core_presets()[0].model_copy(deep=True)
    preset.id = "integration-small-youtube"
    preset.name = "Integration Small YouTube"
    preset.core = False
    preset.width = 360
    preset.height = 640
    preset.duration = DurationRule(
        minimum_seconds=4.0,
        target_seconds=4.2,
        maximum_seconds=4.4,
        enforcement=DurationEnforcement.BLOCK,
    )
    preset.ranking.count = 2
    for layer in preset.layers:
        if layer.rich_text:
            layer.rich_text.default_style.font_size = min(
                layer.rich_text.default_style.font_size, 28
            )
            layer.rich_text.default_style.minimum_font_size = 18
    context.presets.save(preset)
    channel = ChannelProfile(
        display_name="Offline YouTube channel",
        platform="youtube",
        default_privacy="private",
    )
    context.channels.save(channel)
    batch = BatchPlanner().build(
        sources=[source],
        presets=[preset],
        channels=[channel],
        video_count=1,
        schedule=[datetime.now(UTC) + timedelta(hours=2)],
        analyses_per_video=2,
    )

    with pytest.raises(PermissionError, match="confirmation"):
        context.production.generate_batch(
            batch,
            confirmed=False,
            use_mock_ai=True,
            use_mock_source=True,
        )

    jobs = context.production.generate_batch(
        batch,
        confirmed=True,
        use_mock_ai=True,
        use_mock_source=True,
        options=ProductionOptions(
            maximum_analyses_per_video=2,
            render_parallelism=1,
            deep_technical_scan=False,
        ),
    )
    assert len(jobs) == 1
    job = jobs[0]
    assert job.status == ProductionStatus.AWAITING_REVIEW, job.last_error
    assert job.output_path and Path(job.output_path).is_file()
    assert job.render_plan_payload
    assert context.database.fetchone("SELECT COUNT(*) AS count FROM ai_cache")["count"] >= 3

    review = context.reviews.get_by_production_job(job.id)
    assert review is not None
    assert review.status == ReviewStatus.PENDING
    assert review.technical_validation.passed
    assert review.ai_review and review.ai_review.approved
    with pytest.raises(ValueError, match="rights"):
        context.review_queue.approve(review.id)
    context.review_queue.confirm_rights_review(review.id, confirmed=True)
    review = context.review_queue.approve(review.id)
    assert review.status == ReviewStatus.APPROVED

    upload = context.upload_queue.create_from_review(review, channel)
    assert upload.status == UploadStatus.BLOCKED_APPROVAL
    upload = context.upload_queue.approve_upload_batch([upload.id])[0]
    assert upload.batch_approved
    assert upload.status == UploadStatus.SCHEDULED
    assert context.production_jobs.get(job.id).status == ProductionStatus.QUEUED_FOR_UPLOAD
