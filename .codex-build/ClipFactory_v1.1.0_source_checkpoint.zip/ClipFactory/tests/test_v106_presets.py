from __future__ import annotations

import ast
import json
from pathlib import Path

import pytest

from app.core.config import AppSettings, SettingsStore, UISettings
from app.core.paths import AppPaths
from app.models.ai_models import ProjectCreativeResult
from app.models.project_models import ClipSelectionResult, SelectedClip
from app.presets.layout import LayoutEngine
from app.presets.preset_manager import (
    CORE_COMPILATION_ID,
    CORE_RANKING_ID,
    PresetManager,
    core_presets,
    legacy_core_presets,
)
from app.presets.preset_validator import PresetValidator
from app.render.overlay_renderer import OverlayRenderer
from app.render.render_plan import RenderPlanBuilder
from app.storage.database import Database
from app.storage.repositories.preset_repository import PresetRepository
from app.ui.log_scroll_state import LogScrollState


def _selected(identifier: str, duration: float = 2.0) -> SelectedClip:
    return SelectedClip(
        clip_id=identifier,
        candidate_id=f"post-{identifier}",
        media_path=f"/tmp/{identifier}.mp4",
        media_fingerprint=f"fingerprint-{identifier}",
        source_url=f"https://reddit.com/{identifier}",
        start_seconds=0,
        end_seconds=duration,
        caption=f"Source {identifier}",
        rank=1,
        analysis_score=90,
    )


def _creative(order: list[str], captions: list[str]) -> ProjectCreativeResult:
    return ProjectCreativeResult(
        header_text="The brightest cat moments today",
        ranking_captions=captions,
        recommended_clip_order=order,
        overall_theme="cats",
    )


def test_rank_clip_caption_and_timeline_use_one_mapping(tmp_path: Path) -> None:
    preset = next(value for value in core_presets() if value.id == CORE_RANKING_ID)
    selection = ClipSelectionResult(
        selected=[_selected("a"), _selected("b"), _selected("c")],
        total_duration_seconds=6,
        target_met=True,
    )
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="job",
        preset=preset,
        selection=selection,
        creative=_creative(["c", "a", "b"], ["Caption C", "Caption A", "Caption B"]),
        output_path=tmp_path / "ranking.mp4",
    )

    assert [(item.rank, item.clip_id, item.caption) for item in plan.ranking_items] == [
        (1, "c", "Caption C"),
        (2, "a", "Caption A"),
        (3, "b", "Caption B"),
    ]
    assert [(caption.rank, caption.clip_id, caption.text) for caption in plan.captions] == [
        (1, "c", "Caption C"),
        (2, "a", "Caption A"),
        (3, "b", "Caption B"),
    ]
    assert [segment.clip_id for segment in plan.timeline] == ["b", "a", "c"]
    assert [item.clip_start_seconds for item in plan.ranking_items] == [4, 2, 0]


def test_ranking_rows_are_one_to_n_from_top_to_bottom() -> None:
    preset = next(value for value in core_presets() if value.id == CORE_RANKING_ID)
    layer = next(value for value in preset.layers if value.id == "ranking_numbers")
    rows = LayoutEngine.ranking_item_rects(
        preset,
        layer,
        5,
        font_size=layer.rich_text.default_style.font_size,
    )

    assert len(rows) == 5
    assert [row.y for row in rows] == sorted(row.y for row in rows)
    assert all(
        first.y + first.height <= second.y for first, second in zip(rows, rows[1:], strict=False)
    )


def test_ai_header_is_used_without_top_n_rewrite(tmp_path: Path) -> None:
    preset = next(value for value in core_presets() if value.id == CORE_RANKING_ID)
    phrase = "The cutest cats to brighten your day"
    creative = _creative(["a"], ["A tiny surprise"])
    creative.header_text = phrase
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="job",
        preset=preset,
        selection=ClipSelectionResult(
            selected=[_selected("a")],
            total_duration_seconds=2,
            target_met=True,
        ),
        creative=creative,
        output_path=tmp_path / "ranking.mp4",
    )

    assert plan.header_text == phrase
    assert not plan.header_text.startswith("Top ")


def test_compilation_has_no_text_overlay_events(tmp_path: Path) -> None:
    preset = next(value for value in core_presets() if value.id == CORE_COMPILATION_ID)
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="job",
        preset=preset,
        selection=ClipSelectionResult(
            selected=[_selected("a"), _selected("b")],
            total_duration_seconds=4,
            target_met=True,
        ),
        creative=_creative(["a", "b"], ["Ignored A", "Ignored B"]),
        output_path=tmp_path / "compilation.mp4",
    )
    ass = OverlayRenderer().create_ass(plan, preset, tmp_path / "compilation.ass")

    assert plan.header_text == ""
    assert plan.captions == []
    assert plan.ranking_items == []
    assert not plan.text_overlays_enabled
    assert "Dialogue:" not in ass.read_text(encoding="utf-8-sig")


def test_three_clips_create_exactly_two_asset_transitions_and_sounds(
    tmp_path: Path,
) -> None:
    preset = next(value for value in core_presets() if value.id == CORE_COMPILATION_ID)
    preset = preset.model_copy(deep=True)
    preset.core = False
    preset.transition.enabled = True
    preset.transition.type = "fixed_asset"
    preset.transition.fixed_asset_id = "transition"
    preset.transition.sound_asset_id = "sound"
    preset.transition.duration_seconds = 0.3
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="job",
        preset=preset,
        selection=ClipSelectionResult(
            selected=[_selected("a"), _selected("b"), _selected("c")],
            total_duration_seconds=6,
            target_met=True,
        ),
        creative=_creative(["a", "b", "c"], ["", "", ""]),
        output_path=tmp_path / "compilation.mp4",
        asset_paths={
            "transition": tmp_path / "transition.mp4",
            "sound": tmp_path / "sound.wav",
        },
    )

    assert [segment.kind for segment in plan.timeline] == [
        "clip",
        "transition",
        "clip",
        "transition",
        "clip",
    ]
    assert plan.transition_count == 2
    assert len(plan.audio_overlays) == 2
    assert plan.target_duration_seconds == pytest.approx(6.6)
    assert plan.timeline[0].kind == "clip"
    assert plan.timeline[-1].kind == "clip"


def test_disabled_transition_does_not_require_an_asset_library_item() -> None:
    preset = next(value for value in core_presets() if value.id == CORE_COMPILATION_ID)
    preset = preset.model_copy(deep=True)
    preset.transition.fixed_asset_id = "missing-transition"
    preset.transition.sound_asset_id = "missing-sound"

    assert PresetValidator().validate(preset, asset_paths={}) == []

    preset.transition.enabled = True
    errors = PresetValidator().validate(preset, asset_paths={})
    assert any("missing asset: missing-transition" in error for error in errors)
    assert any("missing asset: missing-sound" in error for error in errors)


def test_preset_render_settings_round_trip_through_repository(database: Database) -> None:
    repository = PresetRepository(database)
    manager = PresetManager(repository)
    manager.ensure_core_presets()
    custom = manager.duplicate(CORE_RANKING_ID, "Round-trip Ranking")
    custom.header.padding_ratio = 0.041
    custom.ranking.horizontal_alignment = "right"
    custom.ranking.vertical_alignment = "bottom"
    custom.ranking.spacing = 0.027
    custom.ranking.reveal_offset_seconds = 0.35
    custom.ranking.captions_persist_after_reveal = False
    custom.safe_zones.left = 0.09
    custom.transition.enabled = True
    custom.transition.type = "fixed_asset"
    custom.transition.fixed_asset_id = "library-transition"
    custom.transition.sound_asset_id = "library-sound"
    custom.transition.duration_seconds = 0.42
    custom.transition.sound_start_offset_seconds = 0.13
    custom.transition.sound_duration_seconds = 0.21
    custom.transition.sound_fade_seconds = 0.04
    custom.transition.original_audio_fade_seconds = 0.06
    custom.audio.transition_volume = 0.55
    caption = next(layer for layer in custom.layers if layer.id == "dynamic_caption")
    caption.bounds.x = 0.20
    caption.bounds.width = 0.65
    caption.rich_text.default_style.font_size = 43
    caption.rich_text.default_style.foreground.red = 230
    manager.save(custom)

    loaded = repository.get(custom.id)

    assert loaded is not None
    assert loaded.header.padding_ratio == 0.041
    assert loaded.ranking.horizontal_alignment == "right"
    assert loaded.ranking.vertical_alignment == "bottom"
    assert loaded.ranking.spacing == 0.027
    assert loaded.ranking.reveal_offset_seconds == 0.35
    assert not loaded.ranking.captions_persist_after_reveal
    assert loaded.safe_zones.left == 0.09
    assert loaded.transition.fixed_asset_id == "library-transition"
    assert loaded.transition.sound_asset_id == "library-sound"
    assert loaded.transition.duration_seconds == 0.42
    assert loaded.transition.sound_start_offset_seconds == 0.13
    assert loaded.transition.sound_duration_seconds == 0.21
    assert loaded.transition.sound_fade_seconds == 0.04
    assert loaded.transition.original_audio_fade_seconds == 0.06
    assert loaded.audio.transition_volume == 0.55
    loaded_caption = next(layer for layer in loaded.layers if layer.id == "dynamic_caption")
    assert loaded_caption.bounds.x == 0.20
    assert loaded_caption.bounds.width == 0.65
    assert loaded_caption.rich_text.default_style.font_size == 43
    assert loaded_caption.rich_text.default_style.foreground.red == 230


def test_modified_legacy_core_is_preserved_once_as_custom(database: Database) -> None:
    repository = PresetRepository(database)
    modified = legacy_core_presets()[0]
    modified.header.padding_ratio = 0.04
    repository.save(modified)
    manager = PresetManager(repository)

    manager.ensure_core_presets()
    first = repository.list()
    manager.ensure_core_presets()
    second = repository.list()

    migrated = [
        preset
        for preset in first
        if not preset.core and preset.name.endswith("(migrated v1.0.5 custom)")
    ]
    assert len(migrated) == 1
    assert migrated[0].header.padding_ratio == 0.04
    assert [preset.id for preset in first] == [preset.id for preset in second]


def test_migration_preserves_records_and_remaps_existing_references(database: Database) -> None:
    repository = PresetRepository(database)
    repository.save(
        next(preset for preset in legacy_core_presets() if preset.id == "core-youtube-ranking")
    )
    timestamp = "2026-07-23T12:00:00+00:00"
    rows = (
        (
            "projects",
            "project-existing",
            {
                "preset_id": "core-youtube-ranking",
                "user_marker": "project survives",
            },
        ),
        (
            "production_jobs",
            "job-existing",
            {
                "preset_id": "core-youtube-ranking",
                "log_messages": ["existing log survives"],
            },
        ),
        (
            "review_items",
            "review-existing",
            {
                "preset_id": "core-youtube-ranking",
                "header": "existing review survives",
            },
        ),
        (
            "channel_profiles",
            "channel-existing",
            {
                "default_preset_id": "core-youtube-ranking",
                "user_marker": "channel survives",
            },
        ),
    )
    database.execute(
        "INSERT INTO projects(id, payload, created_at, updated_at) VALUES (?, ?, ?, ?)",
        (rows[0][1], json.dumps(rows[0][2]), timestamp, timestamp),
    )
    database.execute(
        """
        INSERT INTO production_jobs(
            id, project_id, status, progress, payload, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            rows[1][1],
            rows[0][1],
            "awaiting_review",
            100,
            json.dumps(rows[1][2]),
            timestamp,
            timestamp,
        ),
    )
    database.execute(
        """
        INSERT INTO review_items(
            id, production_job_id, status, payload, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            rows[2][1],
            rows[1][1],
            "pending",
            json.dumps(rows[2][2]),
            timestamp,
            timestamp,
        ),
    )
    database.execute(
        """
        INSERT INTO channel_profiles(
            id, platform, payload, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?)
        """,
        (
            rows[3][1],
            "youtube",
            json.dumps(rows[3][2]),
            timestamp,
            timestamp,
        ),
    )
    database.execute(
        """
        INSERT INTO oauth_references(channel_id, provider, credential_reference, updated_at)
        VALUES (?, ?, ?, ?)
        """,
        ("channel-existing", "youtube", "keyring-reference", timestamp),
    )
    database.execute(
        "INSERT INTO app_settings(key, value_json, updated_at) VALUES (?, ?, ?)",
        ("ui.theme", '"dark"', timestamp),
    )

    manager = PresetManager(repository)
    manager.ensure_core_presets()
    manager.ensure_core_presets()

    for table, identifier, original in rows:
        payload = json.loads(
            database.fetchone(f"SELECT payload FROM {table} WHERE id = ?", (identifier,))["payload"]
        )
        reference_key = "default_preset_id" if table == "channel_profiles" else "preset_id"
        assert payload[reference_key] == CORE_RANKING_ID
        for key, value in original.items():
            if key not in {"preset_id", "default_preset_id"}:
                assert payload[key] == value
    oauth = database.fetchone(
        "SELECT credential_reference FROM oauth_references WHERE channel_id = ?",
        ("channel-existing",),
    )
    assert oauth["credential_reference"] == "keyring-reference"
    assert (
        database.fetchone(
            "SELECT value_json FROM app_settings WHERE key = ?",
            ("ui.theme",),
        )["value_json"]
        == '"dark"'
    )


def test_ui_scroll_state_persists_and_restores(database: Database, tmp_path: Path) -> None:
    paths = AppPaths.build(tmp_path)
    paths.ensure()
    store = SettingsStore(paths, database)
    settings = AppSettings(
        ui=UISettings(
            log_scroll_positions={"job-a.log": 41},
            log_follow_tail={"job-a.log": False},
        )
    )
    store.save(settings)
    loaded = store.load()
    state = LogScrollState(
        positions=dict(loaded.ui.log_scroll_positions),
        follow_tail=dict(loaded.ui.log_follow_tail),
    )

    assert state.restored_value("job-a.log", 100) == 41
    assert state.remember("job-a.log", 100, 100)
    assert state.restored_value("job-a.log", 140) == 140
    assert not state.remember("job-a.log", 25, 140)
    assert state.restored_value("job-a.log", 150) == 25


def test_preset_and_review_detail_areas_declare_scroll_areas() -> None:
    root = Path(__file__).resolve().parents[1]
    sources = {
        "preset editor": root / "app/ui/widgets/preset_editor.py",
        "preset contract": root / "app/ui/preset_contract_dialog.py",
        "review queue": root / "app/ui/pages/review_queue.py",
    }
    expected_names = {
        "preset editor": "presetEditorScrollArea",
        "preset contract": "presetContractScrollArea",
        "review queue": "reviewQueueDetailsScrollArea",
    }
    for label, path in sources.items():
        source = path.read_text(encoding="utf-8")
        ast.parse(source)
        assert "QScrollArea" in source, label
        assert expected_names[label] in source, label
