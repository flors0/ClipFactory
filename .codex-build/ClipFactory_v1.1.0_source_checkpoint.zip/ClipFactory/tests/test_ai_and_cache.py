from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest
from google.genai import errors as genai_errors
from google.genai import models as genai_models
from google.genai import types as genai_types

from app.ai.analysis_cache import AnalysisCache
from app.ai.budget_guard import AIBudgetGuard
from app.ai.gemini_analysis_provider import GeminiAnalysisProvider
from app.ai.pricing import PricingCatalog
from app.ai.prompt_builder import PromptBuilder
from app.ai.request_estimator import RequestEstimator
from app.ai.usage_ledger import AIUsageLedger
from app.core.config import BudgetSettings
from app.core.exceptions import AIProviderFatalError, BudgetExceededError, ConfigurationError
from app.download.download_cache import DownloadCache
from app.models.ai_models import AIFieldPermissions, AIRequestEstimate, ClipAnalysisResult
from app.models.media_models import MediaInfo
from app.storage.database import Database

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_download_cache_validates_size_and_content(database: Database, tmp_path: Path) -> None:
    cache = DownloadCache(database)
    media = tmp_path / "media.mp4"
    media.write_bytes(b"verified-content")
    fingerprint = cache.put("https://example.invalid/video", media)
    assert cache.get("https://example.invalid/video") == (media.resolve(), fingerprint)

    media.write_bytes(b"modified-content")
    assert cache.get("https://example.invalid/video") is None


def test_download_cache_rejects_empty_file(database: Database, tmp_path: Path) -> None:
    empty = tmp_path / "empty.mp4"
    empty.touch()
    with pytest.raises(ValueError):
        DownloadCache(database).put("https://example.invalid/empty", empty)


def _analysis() -> ClipAnalysisResult:
    return ClipAnalysisResult(
        clip_id="clip-1",
        summary="A cat jumps onto a cardboard box.",
        detected_theme="cats",
        usable=True,
        topic_match_score=90,
        quality_score=85,
        hook_score=80,
        ranking_caption="A perfectly timed box jump",
    )


def test_analysis_cache_key_covers_context_and_round_trips(database: Database) -> None:
    cache = AnalysisCache(database)
    permissions = AIFieldPermissions()
    arguments = {
        "file_fingerprint": "abc",
        "provider": "gemini",
        "model": "gemini-2.5-flash",
        "prompt_version": "clip-v1",
        "theme": "cats",
        "platform": "youtube",
        "video_format": "ranking",
        "preset_id": "preset-1",
        "permissions": permissions,
        "options": {"media_resolution": "low"},
    }
    key = cache.build_key(**arguments)
    changed = cache.build_key(**(arguments | {"theme": "dogs"}))
    restricted = cache.build_key(
        **(arguments | {"permissions": permissions.model_copy(update={"allow_header_text": False})})
    )
    assert len({key, changed, restricted}) == 3
    cache.put(key, "gemini", "gemini-2.5-flash", _analysis())
    assert cache.get(key, ClipAnalysisResult) == _analysis()


def test_usage_ledger_records_only_explicit_successes(database: Database) -> None:
    ledger = AIUsageLedger(database)
    ledger.record_success(
        provider="gemini",
        model="gemini-2.5-flash",
        operation="clip_analysis",
        job_id="job-1",
        input_tokens=1_000,
        output_tokens=200,
        cached_tokens=0,
        video_seconds=12,
        cost_usd=0.0042,
    )
    assert ledger.total_since(datetime.now(UTC) - timedelta(minutes=1)) == pytest.approx(0.0042)
    assert ledger.total_since(datetime.min.replace(tzinfo=UTC), job_id="job-1") == pytest.approx(
        0.0042
    )
    assert ledger.total_since(datetime.min.replace(tzinfo=UTC), job_id="other") == 0
    assert ledger.list_recent()[0].operation == "clip_analysis"


def test_budget_guard_warns_and_blocks_before_request(database: Database) -> None:
    ledger = AIUsageLedger(database)
    settings = BudgetSettings(
        request_limit_usd=1,
        job_limit_usd=2,
        daily_limit_usd=2,
        monthly_limit_usd=3,
        warning_threshold_percent=80,
        max_tokens_per_request=5_000,
        max_video_seconds_per_request=30,
    )
    guard = AIBudgetGuard(settings, ledger)
    warning_estimate = AIRequestEstimate(
        provider="gemini",
        model="gemini-2.5-flash",
        input_tokens=1_000,
        output_tokens=500,
        video_seconds=10,
        estimated_cost_usd=0.81,
    )
    assert any("request" in warning for warning in guard.check(warning_estimate, job_id="job-1"))

    blocked = warning_estimate.model_copy(update={"estimated_cost_usd": 1.01})
    with pytest.raises(BudgetExceededError, match="per-request"):
        guard.check(blocked, job_id="job-1")
    too_long = warning_estimate.model_copy(update={"video_seconds": 31})
    with pytest.raises(BudgetExceededError, match="duration"):
        guard.check(too_long)


def test_request_estimator_uses_verified_pricing_and_resolution() -> None:
    pricing = PricingCatalog(PROJECT_ROOT / "config" / "defaults" / "ai_pricing.json")
    estimator = RequestEstimator(pricing)
    low = estimator.estimate(
        provider="gemini",
        model="gemini-2.5-flash",
        prompt="Analyze this actual video.",
        video_seconds=10,
        media_resolution="low",
        expected_output_tokens=500,
    )
    high = estimator.estimate(
        provider="gemini",
        model="gemini-2.5-flash",
        prompt="Analyze this actual video.",
        video_seconds=10,
        media_resolution="high",
        expected_output_tokens=500,
    )
    assert low.input_tokens < high.input_tokens
    assert low.estimated_cost_usd > 0
    with pytest.raises(ValueError, match="No verified pricing"):
        pricing.price_for("unverified-model")


def test_prompt_builder_keeps_ai_inside_preset_permissions() -> None:
    builder = PromptBuilder("clip-v1", "creative-v1", "review-v1")
    permissions = AIFieldPermissions(allow_clip_reordering=False, allow_style_changes=False)
    clip_prompt = builder.clip_analysis(
        clip_id="clip-1",
        theme="cats",
        platform="youtube",
        video_format="ranking",
        duration_seconds=12,
        permissions=permissions,
    )
    creative_prompt = builder.project_creative(
        [_analysis()],
        theme="cats",
        platform="youtube",
        video_format="ranking",
        permissions=permissions,
    )
    assert "attached video itself" in clip_prompt
    assert "Rights ownership is not a content-quality signal" in clip_prompt
    assert "Do not propose fonts, colors, layout" in clip_prompt
    assert "Never invent events" in creative_prompt
    assert "preserve input order" in creative_prompt


def test_gemini_strict_model_uses_native_json_schema_wire_field() -> None:
    config = GeminiAnalysisProvider._structured_config(
        ClipAnalysisResult,
        temperature=0.15,
    )

    assert config.response_schema is None
    assert config.response_json_schema["additionalProperties"] is False

    wire_config = genai_models._GenerateContentConfig_to_mldev(None, config)
    assert "responseSchema" not in wire_config
    assert wire_config["responseJsonSchema"]["additionalProperties"] is False
    assert "additional_properties" not in str(wire_config)


class _FakeGeminiModels:
    def __init__(self, *, generate_response: object | None = None, generate_error=None):
        self.generate_response = generate_response
        self.generate_error = generate_error
        self.generate_calls: list[dict[str, object]] = []

    def get(self, *, model: str) -> genai_types.Model:
        return genai_types.Model(
            name=f"models/{model}",
            supported_actions=["generateContent"],
        )

    def list(self):
        return []

    def generate_content(self, **kwargs):
        self.generate_calls.append(kwargs)
        if self.generate_error is not None:
            raise self.generate_error
        return self.generate_response


class _FakeGeminiFiles:
    def __init__(self):
        self.upload_calls: list[str] = []
        self.deleted: list[str] = []

    def upload(self, *, file: str):
        self.upload_calls.append(file)
        return genai_types.File(
            name="files/test-video",
            uri="https://generativelanguage.googleapis.com/v1beta/files/test-video",
            mime_type="video/mp4",
            state=genai_types.FileState.ACTIVE,
        )

    def delete(self, *, name: str) -> None:
        self.deleted.append(name)


def _media_info(path: Path) -> MediaInfo:
    return MediaInfo(
        file_path=str(path),
        file_fingerprint="fingerprint",
        duration_seconds=3,
        width=320,
        height=240,
        aspect_ratio=4 / 3,
        fps=30,
        video_codec="h264",
        has_audio=False,
        file_size_bytes=path.stat().st_size,
        container="mp4",
    )


def _gemini_provider(client: object) -> GeminiAnalysisProvider:
    return GeminiAnalysisProvider(
        model="gemini-2.5-flash",
        api_key_env="GEMINI_API_KEY",
        prompt_builder=PromptBuilder("clip-v1", "creative-v1", "review-v1"),
        client=client,
    )


def test_gemini_preflight_reports_models_visible_to_api_key() -> None:
    not_found = genai_errors.ClientError(
        404,
        {"error": {"code": 404, "status": "NOT_FOUND", "message": "Model not found"}},
    )

    class MissingConfiguredModel(_FakeGeminiModels):
        def get(self, *, model: str):
            raise not_found

        def list(self):
            return [
                genai_types.Model(
                    name="models/gemini-3.1-flash-lite",
                    supported_actions=["generateContent"],
                )
            ]

    provider = _gemini_provider(
        SimpleNamespace(models=MissingConfiguredModel(), files=_FakeGeminiFiles())
    )

    with pytest.raises(ConfigurationError, match="gemini-3.1-flash-lite"):
        provider.validate_ready()


def test_gemini_small_video_uses_inline_media_without_file_upload(tmp_path: Path) -> None:
    media = tmp_path / "clip.mp4"
    media.write_bytes(b"small-video")
    models = _FakeGeminiModels(
        generate_response=SimpleNamespace(parsed=_analysis(), usage_metadata=None)
    )
    files = _FakeGeminiFiles()
    provider = _gemini_provider(SimpleNamespace(models=models, files=files))

    response = provider.analyze_clip(
        media,
        _media_info(media),
        clip_id="clip-1",
        theme="cats",
        platform="youtube",
        video_format="ranking",
        permissions=AIFieldPermissions(),
    )

    assert response.result.clip_id == "clip-1"
    assert files.upload_calls == []
    media_part = models.generate_calls[0]["contents"][0]
    assert media_part.inline_data.mime_type == "video/mp4"
    assert media_part.inline_data.data == b"small-video"


def test_gemini_active_file_404_retries_then_stops_as_fatal(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    media = tmp_path / "clip.mp4"
    media.write_bytes(b"large-path")
    not_found = genai_errors.ClientError(
        404,
        {
            "error": {
                "code": 404,
                "status": "NOT_FOUND",
                "message": "Referenced file was not found",
            }
        },
    )
    models = _FakeGeminiModels(generate_error=not_found)
    files = _FakeGeminiFiles()
    provider = _gemini_provider(SimpleNamespace(models=models, files=files))
    monkeypatch.setattr("app.ai.gemini_analysis_provider._INLINE_MEDIA_LIMIT_BYTES", 0)
    monkeypatch.setattr("app.ai.gemini_analysis_provider.time.sleep", lambda _seconds: None)

    with pytest.raises(AIProviderFatalError, match="reported ACTIVE"):
        provider.analyze_clip(
            media,
            _media_info(media),
            clip_id="clip-1",
            theme="cats",
            platform="youtube",
            video_format="ranking",
            permissions=AIFieldPermissions(),
        )

    assert len(models.generate_calls) == 4
    assert files.deleted == ["files/test-video"]
