from __future__ import annotations

import ast
import json
from pathlib import Path

from app.ai.prompt_builder import PromptBuilder
from app.core.config import AISettings, AppSettings, SettingsStore, SourceSettings
from app.core.paths import AppPaths
from app.models.ai_models import AIFieldPermissions, ProjectCreativeResult
from app.models.preset_models import Color
from app.models.project_models import ClipSelectionResult, SelectedClip
from app.presets.preset_manager import CORE_RANKING_ID, PresetManager, core_presets
from app.render.overlay_renderer import OverlayRenderer
from app.render.render_plan import RenderPlanBuilder
from app.storage.database import Database
from app.storage.repositories.preset_repository import PresetRepository


def _clip(identifier: str, duration: float = 2.0) -> SelectedClip:
    return SelectedClip(
        clip_id=identifier,
        candidate_id=f"post-{identifier}",
        media_path=f"/tmp/{identifier}.mp4",
        media_fingerprint=f"fingerprint-{identifier}",
        source_url=f"https://reddit.com/{identifier}",
        start_seconds=0,
        end_seconds=duration,
        caption=f"Source {identifier}",
        rank=1,
        analysis_score=90,
    )


def _creative() -> ProjectCreativeResult:
    return ProjectCreativeResult(
        header_text="Cats with unfinished business",
        ranking_captions=["tiny lawsuit", "gravity resigned", "zero supervision"],
        recommended_clip_order=["a", "b", "c"],
        overall_theme="cats",
    )


def _ranking_plan(tmp_path: Path, *, persist: bool = True):
    preset = next(value for value in core_presets() if value.id == CORE_RANKING_ID)
    preset.ranking.captions_persist_after_reveal = persist
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="job",
        preset=preset,
        selection=ClipSelectionResult(
            selected=[_clip("a"), _clip("b"), _clip("c")],
            total_duration_seconds=6,
            target_met=True,
        ),
        creative=_creative(),
        output_path=tmp_path / "ranking.mp4",
    )
    return preset, plan


def test_revealed_ranking_captions_remain_visible_to_video_end(tmp_path: Path) -> None:
    preset, plan = _ranking_plan(tmp_path)

    assert [caption.start_seconds for caption in plan.captions] == [4, 2, 0]
    assert [caption.end_seconds for caption in plan.captions] == [6, 6, 6]
    assert [item.caption_end_seconds for item in plan.ranking_items] == [6, 6, 6]

    ass = OverlayRenderer().create_ass(plan, preset, tmp_path / "ranking.ass")
    caption_events = [
        line
        for line in ass.read_text(encoding="utf-8-sig").splitlines()
        if ",Caption," in line
        and any(text in line for text in ("tiny lawsuit", "gravity resigned", "zero supervision"))
    ]
    assert any(",0:00:00.00,0:00:06.00,Caption," in line for line in caption_events)
    assert any(",0:00:02.00,0:00:06.00,Caption," in line for line in caption_events)
    assert any(",0:00:04.00,0:00:06.00,Caption," in line for line in caption_events)


def test_unrevealed_captions_stay_hidden_and_persistence_can_be_disabled(
    tmp_path: Path,
) -> None:
    _preset, plan = _ranking_plan(tmp_path, persist=False)

    assert [caption.start_seconds for caption in plan.captions] == [4, 2, 0]
    assert [caption.end_seconds for caption in plan.captions] == [6, 4, 2]


def test_current_caption_visibility_upgrades_a_persisted_render_plan(tmp_path: Path) -> None:
    preset, plan = _ranking_plan(tmp_path, persist=False)
    preset.ranking.captions_persist_after_reveal = True

    RenderPlanBuilder.apply_current_caption_visibility(plan, preset)

    assert all(caption.end_seconds == plan.target_duration_seconds for caption in plan.captions)
    assert all(
        item.caption_end_seconds == plan.target_duration_seconds for item in plan.ranking_items
    )


def test_core_ranking_caption_background_is_transparent() -> None:
    preset = next(value for value in core_presets() if value.id == CORE_RANKING_ID)
    caption_layer = next(value for value in preset.layers if value.id == "dynamic_caption")

    assert caption_layer.background_color.alpha == 0
    assert caption_layer.rich_text.default_style.background.alpha == 0


def test_v106_caption_box_migration_preserves_other_core_edits(database: Database) -> None:
    repository = PresetRepository(database)
    preset = next(value for value in core_presets() if value.id == CORE_RANKING_ID)
    caption_layer = next(value for value in preset.layers if value.id == "dynamic_caption")
    caption_layer.background_color = Color(red=0, green=0, blue=0, alpha=120)
    caption_layer.rich_text.default_style.font_size = 43
    repository.save(preset)
    custom = preset.model_copy(deep=True)
    custom.id = "custom-ranking"
    custom.name = "Custom Ranking"
    custom.core = False
    custom_caption = next(value for value in custom.layers if value.id == "dynamic_caption")
    custom_caption.background_color = Color(red=0, green=0, blue=0, alpha=121)
    repository.save(custom)
    manager = PresetManager(repository)

    manager.ensure_core_presets()
    manager.ensure_core_presets()

    loaded = repository.get(CORE_RANKING_ID)
    assert loaded is not None
    migrated_caption = next(value for value in loaded.layers if value.id == "dynamic_caption")
    assert migrated_caption.background_color.alpha == 0
    assert migrated_caption.rich_text.default_style.font_size == 43
    loaded_custom = repository.get(custom.id)
    assert loaded_custom is not None
    preserved_caption = next(
        value for value in loaded_custom.layers if value.id == "dynamic_caption"
    )
    assert preserved_caption.background_color.alpha == 121


def test_caption_prompts_require_short_natural_meme_reactions() -> None:
    builder = PromptBuilder("clip-v2", "creative-v2", "review-v1")
    permissions = AIFieldPermissions()
    clip_prompt = builder.clip_analysis(
        clip_id="clip-a",
        theme="cats",
        platform="youtube",
        video_format="ranking",
        duration_seconds=8,
        permissions=permissions,
    )
    creative_prompt = builder.project_creative(
        [],
        theme="cats",
        platform="youtube",
        video_format="ranking",
        permissions=permissions,
    )

    assert "Prefer 2 to 6 words" in clip_prompt
    assert "never exceed 8 words" in clip_prompt
    assert "group-chat reaction" in clip_prompt
    assert "never more than 8 words" in creative_prompt
    assert "dry, casual, goofy, and current" in creative_prompt
    assert "Do not repeat the same joke structure" in creative_prompt


def test_v106_default_prompt_versions_migrate_and_invalidate_old_cache(
    database: Database,
    tmp_path: Path,
) -> None:
    paths = AppPaths.build(tmp_path)
    paths.ensure()
    settings = AppSettings(
        ai=AISettings(
            clip_prompt_version="clip-v1",
            creative_prompt_version="creative-v1",
        ),
        source=SourceSettings(
            user_agent="ClipFactory/1.0.6 (+desktop content planning; contact: local-user)"
        ),
    )
    database.execute(
        "INSERT INTO app_settings(key, value_json, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)",
        ("settings", json.dumps(settings.model_dump(mode="json"))),
    )

    loaded = SettingsStore(paths, database).load()

    assert loaded.ai.clip_prompt_version == "clip-v2"
    assert loaded.ai.creative_prompt_version == "creative-v3"
    assert loaded.source.user_agent.startswith("ClipFactory/1.1.0")


def test_review_queue_declares_compact_title_and_two_resizable_axes() -> None:
    source_path = Path(__file__).resolve().parents[1] / "app/ui/pages/review_queue.py"
    source = source_path.read_text(encoding="utf-8")
    ast.parse(source)

    assert 'setObjectName("reviewQueueMainSplitter")' in source
    assert 'setObjectName("reviewQueueDetailSplitter")' in source
    assert "QSplitter(Qt.Orientation.Horizontal)" in source
    assert "QSplitter(Qt.Orientation.Vertical)" in source
    assert "QSizePolicy.Policy.Fixed" in source
    assert "root.addWidget(self.main_splitter, 1)" in source
    assert "review_queue_horizontal_sizes" in source
    assert "review_queue_vertical_sizes" in source


def test_preset_contract_exposes_caption_persistence_setting() -> None:
    source_path = Path(__file__).resolve().parents[1] / "app/ui/preset_contract_dialog.py"
    source = source_path.read_text(encoding="utf-8")
    ast.parse(source)

    assert "Keep revealed captions visible" in source
    assert "captions_persist_after_reveal" in source
