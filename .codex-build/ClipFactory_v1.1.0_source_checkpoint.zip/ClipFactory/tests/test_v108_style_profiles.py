from __future__ import annotations

import ast
from pathlib import Path

import pytest

from app.models.ai_models import ProjectCreativeResult
from app.models.preset_models import (
    PresetStyleProfiles,
    TextStyle,
)
from app.models.project_models import ClipSelectionResult, SelectedClip
from app.models.style_models import StyleProfileKind
from app.presets.layout import LayoutEngine
from app.presets.preset_manager import (
    CORE_RANKING_ID,
    PresetManager,
    core_presets,
)
from app.presets.style_profile_manager import (
    CAPTION_CLEAN_ID,
    HEADER_CLEAN_ID,
    RANKING_CLASSIC_ID,
    RANKING_GOLD_ID,
    StyleProfileManager,
)
from app.render.overlay_renderer import OverlayRenderer
from app.render.render_plan import RenderPlanBuilder
from app.storage.database import Database
from app.storage.repositories.preset_repository import PresetRepository
from app.storage.repositories.style_profile_repository import StyleProfileRepository


def _selected(identifier: str, duration: float = 2.0) -> SelectedClip:
    return SelectedClip(
        clip_id=identifier,
        candidate_id=f"post-{identifier}",
        media_path=f"/tmp/{identifier}.mp4",
        media_fingerprint=f"fingerprint-{identifier}",
        source_url=f"https://reddit.com/{identifier}",
        start_seconds=0,
        end_seconds=duration,
        caption=f"Source {identifier}",
        rank=1,
        analysis_score=90,
    )


def _plan(tmp_path: Path, count: int = 5):
    identifiers = [chr(ord("a") + index) for index in range(count)]
    preset = next(value for value in core_presets() if value.id == CORE_RANKING_ID)
    selection = ClipSelectionResult(
        selected=[_selected(identifier) for identifier in identifiers],
        total_duration_seconds=count * 2,
        target_met=True,
    )
    creative = ProjectCreativeResult(
        header_text="Countdown test",
        ranking_captions=[f"Caption {identifier.upper()}" for identifier in identifiers],
        recommended_clip_order=identifiers,
        overall_theme="test",
    )
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="job",
        preset=preset,
        selection=selection,
        creative=creative,
        output_path=tmp_path / "ranking.mp4",
    )
    return preset, plan


def _style_manager(database: Database) -> StyleProfileManager:
    manager = StyleProfileManager(StyleProfileRepository(database))
    manager.ensure_core_profiles()
    return manager


def test_builtin_style_profiles_seed_once_with_stable_categories(database: Database) -> None:
    manager = _style_manager(database)
    first = manager.list()
    manager.ensure_core_profiles()
    second = manager.list()

    assert len(first) == 18
    assert [profile.id for profile in first] == [profile.id for profile in second]
    assert len(manager.list(StyleProfileKind.RANKING_NUMBERS)) == 8
    assert len(manager.list(StyleProfileKind.CAPTIONS)) == 5
    assert len(manager.list(StyleProfileKind.HEADER)) == 5
    assert manager.get(RANKING_CLASSIC_ID).name == "ClipFactory Classic"
    assert manager.get(RANKING_GOLD_ID).name == "Golden Glow"
    modified_classic = manager.get(RANKING_CLASSIC_ID)
    assert modified_classic is not None
    modified_classic.text_style.font_size = 111
    manager.repository.save(modified_classic)
    assert manager.reset_core(RANKING_CLASSIC_ID).text_style.font_size == 88


def test_custom_style_profile_crud_and_preset_application_round_trip(
    database: Database,
) -> None:
    styles = _style_manager(database)
    presets = PresetRepository(database)
    preset_manager = PresetManager(presets, styles)
    preset_manager.ensure_core_presets()
    preset = preset_manager.duplicate(CORE_RANKING_ID, "Styled Ranking")
    number_layer = next(layer for layer in preset.layers if layer.id == "ranking_numbers")
    number_layer.rich_text.default_style.font_size = 101
    number_layer.rich_text.default_style.glow_enabled = True
    number_layer.rich_text.default_style.glow_radius = 8

    created = styles.create_from_preset(
        preset,
        StyleProfileKind.RANKING_NUMBERS,
        "My Ranking",
    )
    duplicate = styles.duplicate(created.id, "My Ranking Copy")
    renamed = styles.rename(duplicate.id, "My Ranking Alternate")
    applied = styles.apply(preset, renamed.id)
    preset_manager.save(applied)
    loaded = presets.get(applied.id)

    assert loaded is not None
    assert loaded.style_profiles.ranking_numbers == renamed.id
    loaded_number = next(layer for layer in loaded.layers if layer.id == "ranking_numbers")
    assert loaded_number.rich_text.default_style.font_size == 101
    assert loaded_number.rich_text.default_style.glow_radius == 8
    assert styles.delete(renamed.id)
    assert styles.get(renamed.id) is None
    with pytest.raises(ValueError, match="cannot be deleted"):
        styles.delete(RANKING_CLASSIC_ID)


def test_builtin_ranking_profiles_preserve_active_state_and_add_per_rank_colors(
    database: Database,
) -> None:
    styles = _style_manager(database)
    preset = next(value for value in core_presets() if value.id == CORE_RANKING_ID)
    multicolor = styles.get("core-style-ranking-classic-multicolor")
    golden = styles.get(RANKING_GOLD_ID)

    assert multicolor is not None and multicolor.ranking is not None
    assert len(multicolor.ranking.item_overrides) == 5
    assert all(
        override.active_color != override.inactive_color
        or multicolor.ranking.active_opacity != multicolor.ranking.inactive_opacity
        for override in multicolor.ranking.item_overrides.values()
    )
    assert golden is not None
    applied = styles.apply(preset, golden.id)
    number_layer = next(layer for layer in applied.layers if layer.id == "ranking_numbers")
    assert applied.ranking.active_color != applied.ranking.inactive_color
    assert number_layer.rich_text.default_style.glow_enabled
    assert number_layer.rich_text.default_style.glow_radius == 14


def test_v107_core_typography_migrates_without_touching_custom_presets(
    database: Database,
) -> None:
    styles = _style_manager(database)
    repository = PresetRepository(database)
    old_core = next(value for value in core_presets() if value.id == CORE_RANKING_ID)
    old_core.style_profiles = PresetStyleProfiles()
    old_core.ranking.inactive_opacity = 0.45
    next(
        layer for layer in old_core.layers if layer.id == "ranking_numbers"
    ).rich_text.default_style = TextStyle(font_size=58, bold=True)
    next(
        layer for layer in old_core.layers if layer.id == "dynamic_caption"
    ).rich_text.default_style = TextStyle(
        font_size=48,
        minimum_font_size=24,
        bold=True,
        alignment="left",
    )
    next(
        layer for layer in old_core.layers if layer.id == "header"
    ).rich_text.default_style = TextStyle(font_size=72, bold=True)
    repository.save(old_core)
    custom = old_core.model_copy(deep=True)
    custom.id = "custom-v107-ranking"
    custom.name = "Custom v1.0.7 Ranking"
    custom.core = False
    repository.save(custom)

    manager = PresetManager(repository, styles)
    manager.ensure_core_presets()
    manager.ensure_core_presets()

    migrated = repository.get(CORE_RANKING_ID)
    preserved = repository.get(custom.id)
    assert migrated is not None and preserved is not None
    assert (
        next(
            layer for layer in migrated.layers if layer.id == "ranking_numbers"
        ).rich_text.default_style.font_size
        == 88
    )
    assert (
        next(
            layer for layer in migrated.layers if layer.id == "dynamic_caption"
        ).rich_text.default_style.font_size
        == 60
    )
    assert migrated.style_profiles.ranking_numbers == RANKING_CLASSIC_ID
    assert migrated.style_profiles.captions == CAPTION_CLEAN_ID
    assert migrated.style_profiles.header == HEADER_CLEAN_ID
    assert (
        next(
            layer for layer in preserved.layers if layer.id == "ranking_numbers"
        ).rich_text.default_style.font_size
        == 58
    )
    assert preserved.style_profiles.ranking_numbers is None


def test_ranking_countdown_plays_n_to_one_while_rows_remain_one_to_n(
    tmp_path: Path,
) -> None:
    preset, plan = _plan(tmp_path)
    number_layer = next(layer for layer in preset.layers if layer.id == "ranking_numbers")
    rows = LayoutEngine.ranking_item_rects(
        preset,
        number_layer,
        5,
        font_size=number_layer.rich_text.default_style.font_size,
    )

    assert [clip.rank for clip in plan.clips] == [5, 4, 3, 2, 1]
    assert [segment.rank for segment in plan.timeline] == [5, 4, 3, 2, 1]
    assert [item.rank for item in plan.ranking_items] == [1, 2, 3, 4, 5]
    assert [item.clip_start_seconds for item in plan.ranking_items] == [8, 6, 4, 2, 0]
    assert [caption.rank for caption in plan.captions] == [1, 2, 3, 4, 5]
    assert [caption.start_seconds for caption in plan.captions] == [8, 6, 4, 2, 0]
    assert [row.y for row in rows] == sorted(row.y for row in rows)


def test_existing_plain_ranking_plan_upgrades_to_countdown(tmp_path: Path) -> None:
    preset, plan = _plan(tmp_path, count=3)
    legacy_order = sorted(plan.clips, key=lambda clip: clip.rank)
    plan.clips = legacy_order
    cursor = 0.0
    for segment, clip in zip(plan.timeline, legacy_order, strict=True):
        segment.clip_id = clip.clip_id
        segment.rank = clip.rank
        segment.path = clip.media_path
        segment.start_seconds = cursor
        segment.end_seconds = cursor + clip.duration_seconds
        cursor = segment.end_seconds

    RenderPlanBuilder.apply_current_ranking_playback(plan, preset)

    assert [clip.rank for clip in plan.clips] == [3, 2, 1]
    assert [segment.rank for segment in plan.timeline] == [3, 2, 1]
    assert [item.clip_start_seconds for item in plan.ranking_items] == [4, 2, 0]


def test_responsive_text_and_style_metadata_are_render_contracts(
    tmp_path: Path,
) -> None:
    preset, plan = _plan(tmp_path, count=1)
    number_layer = next(layer for layer in preset.layers if layer.id == "ranking_numbers")
    preset.height = 640
    preset.width = 360
    resolved = LayoutEngine.resolved_text_style(
        preset,
        number_layer.rich_text.default_style,
    )
    metadata = RenderPlanBuilder.style_selection_metadata(preset)

    assert resolved.font_size == pytest.approx(88 / 3)
    assert resolved.outline_width == pytest.approx(5 / 3)
    assert metadata["mode"] == "preset"
    assert metadata["profile_ids"]["ranking_numbers"] == RANKING_CLASSIC_ID
    assert len(metadata["fingerprints"]["ranking_numbers"]) == 64
    assert plan.metadata["ranking_playback_order"] == "worst_to_best"


def test_glow_profile_writes_separate_ass_glow_event(
    database: Database,
    tmp_path: Path,
) -> None:
    styles = _style_manager(database)
    preset, plan = _plan(tmp_path, count=1)
    preset = styles.apply(preset, RANKING_GOLD_ID)
    ass = OverlayRenderer().create_ass(plan, preset, tmp_path / "gold.ass")
    rank_events = [
        line for line in ass.read_text(encoding="utf-8-sig").splitlines() if ",Rank," in line
    ]

    assert len(rank_events) == 2
    assert any(r"\1a&HFF&" in line and r"\blur" in line for line in rank_events)


def test_style_profile_ui_and_countdown_setting_are_exposed() -> None:
    root = Path(__file__).resolve().parents[1]
    dialog_source = (root / "app/ui/style_profiles_dialog.py").read_text(encoding="utf-8")
    editor_source = (root / "app/ui/widgets/preset_editor.py").read_text(encoding="utf-8")
    contract_source = (root / "app/ui/preset_contract_dialog.py").read_text(encoding="utf-8")
    ast.parse(dialog_source)
    ast.parse(editor_source)
    ast.parse(contract_source)

    assert "Apply to Current Preset" in dialog_source
    assert "Save Current Style as New" in dialog_source
    assert "Update Profile from Current Style" in dialog_source
    assert "Reset Built-in" in dialog_source
    assert "Style Profiles…" in editor_source
    assert "Best last (N → 1 countdown)" in contract_source
    assert "playback_order" in contract_source
