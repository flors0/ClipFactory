from __future__ import annotations

import subprocess
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path

import httpx

from app.core.config import SourceSettings
from app.download.download_cache import DownloadCache
from app.download.media_downloader import MediaDownloader
from app.media.media_probe import MediaProbe
from app.models.source_models import MediaType, SourceCandidate
from app.sources.reddit_archive.provider import ArcticShiftSourceProvider
from app.sources.source_profile_factory import SourceProfileFactory


class _MemorySourceCache:
    def __init__(self):
        self.values: dict[str, object] = {}

    def get(self, key: str) -> object | None:
        return self.values.get(key)

    def put(self, key: str, value: object, _ttl_seconds: int) -> None:
        self.values[key] = value


def _archive_post(
    identifier: str,
    *,
    age_hours: float,
    score: int,
    has_audio: bool = True,
    width: int = 1080,
    height: int = 1920,
    removed: bool = False,
) -> dict[str, object]:
    asset_id = f"asset{identifier}"
    return {
        "id": identifier,
        "title": f"Cat moment {identifier}",
        "author": "cat_creator",
        "subreddit": "SillyCats",
        "permalink": f"/r/SillyCats/comments/{identifier}/cat_moment/",
        "created_utc": (datetime.now(UTC) - timedelta(hours=age_hours)).timestamp(),
        "retrieved_on": datetime.now(UTC).timestamp(),
        "score": score,
        "num_comments": score // 2,
        "over_18": False,
        "removed_by_category": "moderator" if removed else None,
        "is_video": True,
        "url": f"https://v.redd.it/{asset_id}",
        "secure_media": {
            "reddit_video": {
                "fallback_url": f"https://v.redd.it/{asset_id}/CMAF_1080.mp4?source=fallback",
                "dash_url": f"https://v.redd.it/{asset_id}/DASHPlaylist.mpd",
                "hls_url": f"https://v.redd.it/{asset_id}/HLSPlaylist.m3u8",
                "has_audio": has_audio,
                "width": width,
                "height": height,
                "duration": 12.5,
                "is_gif": False,
                "transcoding_status": "completed",
            }
        },
    }


def test_archive_provider_filters_and_ranks_production_ready_reddit_video() -> None:
    payload = {
        "data": [
            _archive_post("fresh", age_hours=2, score=1),
            _archive_post("mature", age_hours=48, score=900),
            _archive_post("silent", age_hours=50, score=1200, has_audio=False),
            _archive_post("small", age_hours=55, score=1100, width=480, height=854),
            _archive_post("removed", age_hours=60, score=1000, removed=True),
        ]
    }

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/posts/search"
        assert request.url.params["subreddit"] == "SillyCats"
        return httpx.Response(200, json=payload, request=request)

    settings = SourceSettings(
        retry_count=0,
        archive_max_pages=1,
        archive_min_short_edge=720,
        archive_require_audio=True,
        archive_score_maturity_hours=36,
    )
    provider = ArcticShiftSourceProvider(
        settings,
        _MemorySourceCache(),
        httpx.Client(transport=httpx.MockTransport(handler)),
    )
    profile = SourceProfileFactory().create("SillyCats", candidate_limit=10)

    result = provider.discover(profile)

    assert [candidate.post_id for candidate in result.candidates] == ["mature", "fresh"]
    assert result.health.provider == "reddit_archive_arctic_shift"
    assert result.candidates[0].media_type == MediaType.VIDEO
    assert result.candidates[0].raw_metadata["source"] == "arctic_shift"
    reddit_media = result.candidates[0].raw_metadata["reddit_media"]
    assert isinstance(reddit_media, dict)
    assert reddit_media["has_audio"] is True
    assert reddit_media["cache_key"] == "https://v.redd.it/assetmature"
    assert any("provisional" in warning for warning in result.warnings)

    cached = provider.discover(profile)
    assert cached.health.cache_hit


def test_reddit_direct_downloader_muxes_high_quality_video_and_original_audio(
    media_factory: Callable[..., Path],
    database,
    tmp_path: Path,
) -> None:
    source = media_factory("reddit-source.mp4", duration=2.0, width=320, height=240)
    video = tmp_path / "video-only.mp4"
    audio = tmp_path / "audio-only.m4a"
    subprocess.run(
        [
            "ffmpeg",
            "-v",
            "error",
            "-y",
            "-i",
            str(source),
            "-an",
            "-c:v",
            "copy",
            str(video),
        ],
        check=True,
    )
    subprocess.run(
        [
            "ffmpeg",
            "-v",
            "error",
            "-y",
            "-i",
            str(source),
            "-vn",
            "-c:a",
            "copy",
            str(audio),
        ],
        check=True,
    )
    manifest = b"""<?xml version="1.0"?>
    <MPD xmlns="urn:mpeg:dash:schema:mpd:2011">
      <Period>
        <AdaptationSet contentType="video">
          <Representation bandwidth="2000000" width="720" height="1280" mimeType="video/mp4">
            <BaseURL>CMAF_720.mp4</BaseURL>
          </Representation>
        </AdaptationSet>
        <AdaptationSet contentType="audio">
          <Representation bandwidth="64000" mimeType="audio/mp4">
            <BaseURL>CMAF_AUDIO_64.mp4</BaseURL>
          </Representation>
          <Representation bandwidth="128000" mimeType="audio/mp4">
            <BaseURL>CMAF_AUDIO_128.mp4</BaseURL>
          </Representation>
        </AdaptationSet>
      </Period>
    </MPD>"""
    requests: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request.url.path)
        content_by_path = {
            "/asset/DASHPlaylist.mpd": manifest,
            "/asset/CMAF_1080.mp4": video.read_bytes(),
            "/asset/CMAF_AUDIO_128.mp4": audio.read_bytes(),
        }
        content = content_by_path.get(request.url.path)
        if content is None:
            return httpx.Response(404, request=request)
        return httpx.Response(
            200,
            content=content,
            headers={"Content-Length": str(len(content))},
            request=request,
        )

    candidate = SourceCandidate(
        post_id="post1",
        title="Reddit cat clip",
        post_url="https://www.reddit.com/r/SillyCats/comments/post1/test/",
        community="SillyCats",
        published_at=datetime.now(UTC),
        media_type=MediaType.VIDEO,
        media_url="https://v.redd.it/asset/CMAF_1080.mp4?source=fallback",
        source_fingerprint="archive-media-asset",
        raw_metadata={
            "source": "arctic_shift",
            "reddit_media": {
                "asset_id": "asset",
                "cache_key": "https://v.redd.it/asset",
                "fallback_url": "https://v.redd.it/asset/CMAF_1080.mp4?source=fallback",
                "dash_url": "https://v.redd.it/asset/DASHPlaylist.mpd",
                "hls_url": "https://v.redd.it/asset/HLSPlaylist.m3u8",
                "has_audio": True,
                "width": 1080,
                "height": 1920,
            },
        },
    )
    downloader = MediaDownloader(
        DownloadCache(database),
        tmp_path / "downloads",
        tmp_path / "temp",
        retry_count=0,
        max_height=1080,
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    downloaded = downloader.download(candidate)

    info = MediaProbe().probe(downloaded.file_path)
    assert downloaded.extractor == "arctic_shift_direct"
    assert downloaded.source_url == "https://v.redd.it/asset"
    assert info.has_audio
    assert info.audio_codec == "aac"
    assert "/asset/CMAF_1080.mp4" in requests
    assert "/asset/CMAF_AUDIO_128.mp4" in requests

    request_count = len(requests)
    cached = downloader.download(candidate)
    assert cached.from_cache
    assert len(requests) == request_count
