from __future__ import annotations

import ast
import json
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path

import pytest

from app.core.config import AppSettings, SettingsStore, SourceSettings
from app.core.paths import AppPaths
from app.media.media_probe import MediaProbe
from app.models.ai_models import ClipAnalysisResult, ProjectCreativeResult
from app.models.media_models import MediaInfo
from app.models.preset_models import DurationEnforcement, DurationRule
from app.models.project_models import QualityThresholds
from app.models.source_models import MediaType, SourceCandidate
from app.planning.clip_selection_planner import (
    AnalyzedCandidate,
    ClipSelectionPlanner,
    UsedMediaHistory,
)
from app.presets.preset_manager import core_presets
from app.presets.style_profile_manager import StyleProfileManager
from app.render.ffmpeg_renderer import FFmpegRenderer
from app.render.render_plan import RenderPlanBuilder
from app.storage.database import Database
from app.storage.repositories.style_profile_repository import StyleProfileRepository


def _analyzed(
    identifier: str,
    *,
    usable: bool = False,
    topic: float = 55,
    quality: float = 58,
    hook: float = 45,
    sensitive: bool = False,
    watermark: bool = False,
    trim_start: float = 0,
    trim_end: float | None = None,
    caption: str = "same first-pass caption",
    title: str | None = None,
) -> AnalyzedCandidate:
    source = SourceCandidate(
        post_id=identifier,
        title=title or f"{identifier} clip",
        post_url=f"https://reddit.com/{identifier}",
        community="sillycats",
        published_at=datetime.now(UTC),
        media_type=MediaType.VIDEO,
        media_url=f"https://v.redd.it/{identifier}/DASH_720.mp4",
        rights_status="unknown",
        source_fingerprint=f"source-{identifier}",
    )
    media = MediaInfo(
        file_path=f"/tmp/{identifier}.mp4",
        file_fingerprint=f"media-{identifier}",
        duration_seconds=4,
        width=720,
        height=1280,
        aspect_ratio=720 / 1280,
        fps=30,
        video_codec="h264",
        audio_codec="aac",
        has_audio=True,
        file_size_bytes=100,
        container="mp4",
    )
    analysis = ClipAnalysisResult(
        clip_id=identifier,
        summary=f"Summary {identifier}",
        detected_theme="silly cats",
        usable=usable,
        topic_match_score=topic,
        quality_score=quality,
        hook_score=hook,
        ranking_caption=caption,
        suggested_trim_start_seconds=trim_start,
        suggested_trim_end_seconds=trim_end,
        contains_sensitive_content=sensitive,
        contains_watermark=watermark,
    )
    return AnalyzedCandidate(source, media, analysis)


def test_quality_fallback_fills_ranking_without_relaxing_hard_content_filters(
    database: Database,
) -> None:
    candidates = [
        _analyzed("one", trim_start=3.8, trim_end=3.9),
        _analyzed("two"),
        _analyzed("three"),
        _analyzed("four"),
        _analyzed("five"),
        _analyzed("blocked", sensitive=True, topic=95, quality=95, hook=95),
    ]
    thresholds = QualityThresholds(
        minimum_clip_count=5,
        maximum_clip_count=5,
        minimum_individual_clip_seconds=2,
        maximum_individual_clip_seconds=4,
        allow_quality_fallback=True,
        minimum_fallback_score=35,
    )

    result = ClipSelectionPlanner(UsedMediaHistory(database)).select(
        candidates,
        target_duration=20,
        thresholds=thresholds,
    )

    assert [clip.clip_id for clip in result.selected] == [
        "one",
        "two",
        "three",
        "four",
        "five",
    ]
    assert [clip.rank for clip in result.selected] == [1, 2, 3, 4, 5]
    assert result.target_met
    assert result.fallback_clip_ids == ["one", "two", "three", "four", "five"]
    assert result.repaired_trim_clip_ids == ["one"]
    assert result.selected[0].start_seconds == 0
    assert result.selected[0].end_seconds == 4
    assert result.rejected_clip_ids == ["blocked"]
    assert result.rejection_reasons["blocked"] == ["sensitive content"]
    assert any("similar" in warning for warning in result.warnings)


def test_quality_fallback_can_be_disabled_and_failure_summary_is_actionable(
    database: Database,
) -> None:
    planner = ClipSelectionPlanner(UsedMediaHistory(database))
    result = planner.select(
        [_analyzed("one"), _analyzed("two")],
        target_duration=8,
        thresholds=QualityThresholds(
            minimum_clip_count=2,
            maximum_clip_count=2,
            allow_quality_fallback=False,
        ),
    )

    assert result.selected == []
    summary = planner.rejection_summary(result)
    assert "AI marked clip unusable: 2" in summary
    assert "topic score below 60: 2" in summary
    assert "quality score below 60: 2" in summary
    assert "hook score below 50: 2" in summary


def test_quality_fallback_never_overrides_watermark_filter(database: Database) -> None:
    planner = ClipSelectionPlanner(UsedMediaHistory(database))
    result = planner.select(
        [
            _analyzed(
                "one",
                usable=True,
                topic=90,
                quality=90,
                hook=90,
                watermark=True,
            )
        ],
        target_duration=4,
        thresholds=QualityThresholds(
            minimum_clip_count=1,
            maximum_clip_count=1,
            allow_quality_fallback=True,
            reject_watermark=True,
        ),
    )

    assert result.selected == []
    assert planner.rejection_summary(result) == "watermark: 1"


def test_style_profile_windows_qvariant_and_direct_layer_dropdown_regressions() -> None:
    root = Path(__file__).resolve().parents[1]
    dialog_path = root / "app/ui/style_profiles_dialog.py"
    editor_path = root / "app/ui/widgets/preset_editor.py"
    dialog_source = dialog_path.read_text(encoding="utf-8")
    editor_source = editor_path.read_text(encoding="utf-8")

    ast.parse(dialog_source)
    ast.parse(editor_source)
    assert "self.kind.addItem(label, kind.value)" in dialog_source
    assert "StyleProfileKind(str(value))" in dialog_source
    assert 'form.addRow("Style profile", self.style_profile_row)' in editor_source
    assert "self.style_profile_combo" in editor_source
    assert "Save as New…" in editor_source
    assert "_apply_selected_style_profile" in editor_source


def test_core_style_seeding_and_asset_library_tree_are_present(
    database: Database,
) -> None:
    manager = StyleProfileManager(StyleProfileRepository(database))
    manager.ensure_core_profiles()
    assert len(manager.list()) == 18

    root = Path(__file__).resolve().parents[1]
    expected = {
        "transitions",
        "interstitials",
        "sounds",
        "music",
        "fonts",
        "images",
        "memes",
        "backgrounds",
        "subtitles",
    }
    assert {path.name for path in (root / "assets").iterdir() if path.is_dir()} == expected
    assert all((root / "assets" / name / ".gitkeep").is_file() for name in expected)


def test_v108_user_agent_migrates_without_touching_other_settings(
    database: Database,
    tmp_path: Path,
) -> None:
    paths = AppPaths.build(tmp_path)
    paths.ensure()
    settings = AppSettings(
        language="de",
        source=SourceSettings(
            user_agent="ClipFactory/1.0.8 (+desktop content planning; contact: local-user)"
        ),
    )
    database.execute(
        "INSERT INTO app_settings(key, value_json, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)",
        ("settings", json.dumps(settings.model_dump(mode="json"))),
    )

    loaded = SettingsStore(paths, database).load()

    assert loaded.language == "de"
    assert loaded.source.user_agent.startswith("ClipFactory/1.1.0")


def test_quality_fallback_selection_reaches_real_ffmpeg_render(
    database: Database,
    media_factory: Callable[..., Path],
    tmp_path: Path,
) -> None:
    probe = MediaProbe()
    candidates: list[AnalyzedCandidate] = []
    titles = [
        "Cat launches from the sofa",
        "Tiny kitten argues with mirror",
        "Orange cat steals the blanket",
        "Sleepy cat misses the jump",
        "Black cat attacks cardboard",
    ]
    for index in range(1, 6):
        path = media_factory(
            f"fallback-{index}.mp4",
            duration=1.2,
            width=360,
            height=640,
            frequency=300 + index * 80,
        )
        template = _analyzed(
            f"fallback-{index}",
            caption=f"Fallback caption {index}",
            title=titles[index - 1],
        )
        candidates.append(
            AnalyzedCandidate(
                template.source,
                probe.probe(path),
                template.analysis,
            )
        )

    selection = ClipSelectionPlanner(UsedMediaHistory(database)).select(
        candidates,
        target_duration=5,
        thresholds=QualityThresholds(
            minimum_clip_count=5,
            maximum_clip_count=5,
            minimum_individual_clip_seconds=1,
            maximum_individual_clip_seconds=1,
            allow_quality_fallback=True,
            minimum_fallback_score=35,
        ),
    )
    assert len(selection.selected) == 5
    assert len(selection.fallback_clip_ids) == 5

    preset = core_presets()[0].model_copy(deep=True)
    preset.id = "fallback-render"
    preset.core = False
    preset.width = 360
    preset.height = 640
    preset.duration = DurationRule(
        minimum_seconds=4.8,
        target_seconds=5,
        maximum_seconds=5.2,
        enforcement=DurationEnforcement.BLOCK,
    )
    for layer in preset.layers:
        if layer.rich_text:
            layer.rich_text.default_style.font_size = min(
                layer.rich_text.default_style.font_size,
                28,
            )
            layer.rich_text.default_style.minimum_font_size = 18
    creative = ProjectCreativeResult(
        header_text="Fallback Render",
        ranking_captions=[clip.caption for clip in selection.selected],
        recommended_clip_order=[clip.clip_id for clip in selection.selected],
        overall_theme="fallback",
    )
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="fallback-render",
        preset=preset,
        selection=selection,
        creative=creative,
        output_path=tmp_path / "fallback-render.mp4",
    )
    output = FFmpegRenderer(tmp_path / "fallback-staging").render(plan, preset)
    info = probe.probe(output)

    assert output.is_file() and output.stat().st_size > 0
    assert [clip.rank for clip in plan.clips] == [5, 4, 3, 2, 1]
    assert (info.width, info.height) == (360, 640)
    assert info.has_audio
    assert info.duration_seconds == pytest.approx(5, abs=0.08)
