from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path
from threading import Event

import httpx
import pytest

from app.core.config import SourceSettings
from app.models.source_models import MediaType, SourceCandidate
from app.sources.reddit_public.parser import parse_listing_html, parse_rss
from app.sources.reddit_public.provider import PublicRedditSourceProvider
from app.sources.source_profile_factory import SourceProfileFactory, normalize_subreddit
from app.sources.source_provider import CandidateFilter

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("SillyCats", "SillyCats"),
        ("r/SillyCats", "SillyCats"),
        ("/r/SillyCats/", "SillyCats"),
        ("https://www.reddit.com/r/SillyCats/top/?t=week", "SillyCats"),
        ("https://old.reddit.com/r/SillyCats/", "SillyCats"),
    ],
)
def test_subreddit_normalization(raw: str, expected: str) -> None:
    assert normalize_subreddit(raw) == expected


@pytest.mark.parametrize(
    "raw", ["", "https://example.com/r/cats", "r/not-valid!", "https://reddit.com/user/test"]
)
def test_subreddit_normalization_rejects_unsafe_input(raw: str) -> None:
    with pytest.raises(ValueError):
        normalize_subreddit(raw)


def test_source_profile_factory_builds_canonical_public_url() -> None:
    profile = SourceProfileFactory().create("https://reddit.com/r/SillyCats/")
    assert profile.community == "SillyCats"
    assert profile.source_url == "https://www.reddit.com/r/SillyCats/"


def test_rss_parser_creates_video_candidate() -> None:
    candidates, description = parse_rss(
        FIXTURES.joinpath("reddit_feed.xml").read_bytes(), "SillyCats"
    )
    assert description == "Funny and surprising cat videos"
    assert len(candidates) == 1
    candidate = candidates[0]
    assert candidate.post_id == "abc123"
    assert candidate.media_type == MediaType.VIDEO
    assert candidate.media_url == "https://v.redd.it/abc123/DASH_720.mp4"
    assert candidate.flair == "Humor"
    assert len(candidate.source_fingerprint) == 64


def test_html_parser_creates_candidate_and_pagination() -> None:
    payload = FIXTURES.joinpath("reddit_listing.html").read_text(encoding="utf-8")
    candidates, description, next_url = parse_listing_html(
        payload,
        "SillyCats",
        "https://www.reddit.com/r/SillyCats/",
    )
    assert description == "Funny and surprising cat videos"
    assert next_url == "https://www.reddit.com/r/SillyCats/?after=t3_xyz789"
    assert len(candidates) == 1
    assert candidates[0].score == 1200
    assert candidates[0].comment_count == 42
    assert candidates[0].media_type == MediaType.VIDEO


def test_html_parser_follows_shreddit_shell_and_fragment_pagination() -> None:
    shell = """
    <html><head><meta name="description" content="Silly cats"></head><body>
      <shreddit-feed reload-url="/svc/shreddit/community-more-posts/top/?t=WEEK&amp;name=SillyCats">
      </shreddit-feed>
    </body></html>
    """
    candidates, description, next_url = parse_listing_html(
        shell,
        "SillyCats",
        "https://www.reddit.com/r/SillyCats/top/?t=week",
    )
    assert candidates == []
    assert description == "Silly cats"
    assert next_url == (
        "https://www.reddit.com/svc/shreddit/community-more-posts/top/?t=WEEK&name=SillyCats"
    )

    fragment = """
    <faceplate-batch>
      <article data-post-id="t3_live123">
        <shreddit-post id="t3_live123"
          permalink="/r/SillyCats/comments/live123/server_rendered_post/"
          content-href="https://v.redd.it/live123"
          post-title="Server-rendered post"
          post-type="video"
          score="321"
          comment-count="12"
          author="cat_author">
        </shreddit-post>
      </article>
      <faceplate-partial
        src="/svc/shreddit/community-more-posts/top/?t=WEEK&amp;name=SillyCats&amp;after=cursor123">
      </faceplate-partial>
    </faceplate-batch>
    """
    candidates, _, next_url = parse_listing_html(
        fragment,
        "SillyCats",
        "https://www.reddit.com/svc/shreddit/community-more-posts/top/?t=WEEK&name=SillyCats",
    )
    assert len(candidates) == 1
    assert candidates[0].post_id == "live123"
    assert candidates[0].media_type == MediaType.VIDEO
    assert next_url == (
        "https://www.reddit.com/svc/shreddit/community-more-posts/top/"
        "?t=WEEK&name=SillyCats&after=cursor123"
    )


class _MemorySourceCache:
    def get(self, _key: str) -> None:
        return None

    def put(self, _key: str, _value: object, _ttl_seconds: int) -> None:
        return None


class _NoDelayEvent(Event):
    def wait(self, _timeout: float | None = None) -> bool:
        return self.is_set()


def test_public_provider_uses_server_feed_after_empty_200_page() -> None:
    requested_paths: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requested_paths.append(request.url.path)
        if request.url.path.endswith("/.rss"):
            return httpx.Response(403, request=request)
        if request.url.path == "/r/SillyCats/top/":
            return httpx.Response(200, text="<html><main></main></html>", request=request)
        if request.url.path == "/svc/shreddit/community-more-posts/top/":
            return httpx.Response(
                200,
                text="""
                <shreddit-post id="t3_fallback1"
                  permalink="/r/SillyCats/comments/fallback1/public_fallback/"
                  content-href="https://v.redd.it/fallback1"
                  post-title="Public fallback"
                  post-type="video"
                  score="500"
                  comment-count="20"
                  author="cat_author">
                </shreddit-post>
                """,
                request=request,
            )
        raise AssertionError(f"Unexpected request: {request.url}")

    settings = SourceSettings(retry_count=0, request_interval_seconds=0.5)
    client = httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True)
    provider = PublicRedditSourceProvider(settings, _MemorySourceCache(), client=client)
    profile = SourceProfileFactory().create("SillyCats", candidate_limit=1)

    result = provider.discover(profile, cancel_event=_NoDelayEvent())

    assert [candidate.post_id for candidate in result.candidates] == ["fallback1"]
    assert result.health.provider == "public_reddit"
    assert "/svc/shreddit/community-more-posts/top/" in requested_paths
    assert any("public HTML feed" in warning for warning in result.warnings)


def _candidate(identifier: str, **updates: object) -> SourceCandidate:
    values: dict[str, object] = {
        "post_id": identifier,
        "title": f"Candidate {identifier}",
        "post_url": f"https://reddit.com/r/SillyCats/comments/{identifier}/test/",
        "community": "SillyCats",
        "published_at": datetime.now(UTC) - timedelta(hours=1),
        "score": 50,
        "comment_count": 10,
        "flair": "Video",
        "media_type": MediaType.VIDEO,
        "media_url": f"https://v.redd.it/{identifier}/video.mp4",
        "source_fingerprint": f"fingerprint-{identifier}",
    }
    values.update(updates)
    return SourceCandidate.model_validate(values)


def test_candidate_filter_applies_policy_and_deduplicates() -> None:
    profile = SourceProfileFactory().create(
        "SillyCats",
        candidate_limit=2,
        min_score=25,
        max_post_age_hours=24,
        allow_nsfw=False,
    )
    profile.allowed_flairs = ["video"]
    values = [
        _candidate("good"),
        _candidate("low", score=1),
        _candidate("old", published_at=datetime.now(UTC) - timedelta(days=2)),
        _candidate("nsfw", nsfw=True),
        _candidate("image", media_type=MediaType.IMAGE),
        _candidate("duplicate", source_fingerprint="fingerprint-good"),
        _candidate("second"),
        _candidate("third"),
    ]
    accepted = CandidateFilter().apply(profile, values)
    assert [value.post_id for value in accepted] == ["good", "second"]
