from __future__ import annotations

import re
import shutil
import subprocess
from collections.abc import Callable
from pathlib import Path

import pytest

from app.media.media_probe import MediaProbe, parse_fraction
from app.media.technical_validator import TechnicalValidator
from app.models.ai_models import ProjectCreativeResult
from app.models.preset_models import DurationEnforcement, DurationRule, Preset
from app.models.project_models import ClipSelectionResult, SelectedClip
from app.presets.preset_manager import core_presets
from app.render.ffmpeg_renderer import FFmpegRenderer
from app.render.render_plan import RenderPlanBuilder


def test_fraction_parser() -> None:
    assert parse_fraction("30000/1001") == pytest.approx(29.97002997)
    assert parse_fraction("0/0") == 0


def test_media_probe_reads_video_audio_and_dimensions(media_factory: Callable[..., Path]) -> None:
    media = media_factory("probe.mp4", duration=2.0, width=320, height=240)
    info = MediaProbe().probe(media)
    assert info.duration_seconds == pytest.approx(2.0, abs=0.08)
    assert (info.width, info.height) == (320, 240)
    assert info.fps == pytest.approx(30, abs=0.01)
    assert info.has_audio
    assert info.video_codec == "h264"
    assert info.audio_codec == "aac"
    assert len(info.file_fingerprint) == 64


def _render_preset() -> Preset:
    preset = core_presets()[0].model_copy(deep=True)
    preset.id = "test-small-render"
    preset.core = False
    preset.width = 360
    preset.height = 640
    preset.duration = DurationRule(
        minimum_seconds=2.8,
        target_seconds=3.0,
        maximum_seconds=3.2,
        enforcement=DurationEnforcement.BLOCK,
    )
    for layer in preset.layers:
        if layer.rich_text:
            layer.rich_text.default_style.font_size = min(
                layer.rich_text.default_style.font_size, 28
            )
            layer.rich_text.default_style.minimum_font_size = 18
    return preset


def test_ffmpeg_renderer_creates_valid_vertical_output(
    media_factory: Callable[..., Path],
    tmp_path: Path,
) -> None:
    if not shutil.which("ffprobe"):
        pytest.skip("ffprobe is required for the render integration test.")
    first = media_factory("first.mp4", duration=1.7, frequency=440)
    second = media_factory("second.mp4", duration=1.7, frequency=660)
    probe = MediaProbe()
    first_info = probe.probe(first)
    second_info = probe.probe(second)
    selection = ClipSelectionResult(
        selected=[
            SelectedClip(
                clip_id="first",
                candidate_id="post-first",
                media_path=str(first),
                media_fingerprint=first_info.file_fingerprint,
                source_url="https://reddit.com/first",
                start_seconds=0,
                end_seconds=1.5,
                caption="First test moment",
                rank=1,
                analysis_score=90,
            ),
            SelectedClip(
                clip_id="second",
                candidate_id="post-second",
                media_path=str(second),
                media_fingerprint=second_info.file_fingerprint,
                source_url="https://reddit.com/second",
                start_seconds=0,
                end_seconds=1.5,
                caption="Second test moment",
                rank=2,
                analysis_score=89,
            ),
        ],
        total_duration_seconds=3,
        target_met=True,
    )
    creative = ProjectCreativeResult(
        header_text="Two Test Moments",
        ranking_captions=["First test moment", "Second test moment"],
        recommended_clip_order=["first", "second"],
        overall_theme="test patterns",
    )
    preset = _render_preset()
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="render-test",
        preset=preset,
        selection=selection,
        creative=creative,
        output_path=tmp_path / "rendered.mp4",
    )
    progress: list[int] = []
    output = FFmpegRenderer(tmp_path / "staging").render(
        plan,
        preset,
        progress_callback=lambda value, _message: progress.append(value),
    )
    assert output.is_file() and output.stat().st_size > 0
    assert progress[-1] == 100
    rendered_info = probe.probe(output)
    assert (rendered_info.width, rendered_info.height) == (360, 640)
    validation = TechnicalValidator(probe).validate(
        output,
        expected_width=360,
        expected_height=640,
        expected_fps=30,
        minimum_duration=2.8,
        maximum_duration=3.2,
        deep_scan=False,
    )
    assert validation.passed, [check.model_dump() for check in validation.checks]


def _band_mean_volume(
    media: Path,
    *,
    start: float,
    duration: float,
    filters: str,
) -> float:
    completed = subprocess.run(
        [
            "ffmpeg",
            "-v",
            "info",
            "-ss",
            f"{start:.3f}",
            "-t",
            f"{duration:.3f}",
            "-i",
            str(media),
            "-vn",
            "-af",
            f"{filters},volumedetect",
            "-f",
            "null",
            "-",
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    match = re.search(r"mean_volume:\s*(-?(?:\d+(?:\.\d+)?|inf)) dB", completed.stderr)
    assert completed.returncode == 0 and match, completed.stderr[-1000:]
    return float(match.group(1))


def test_compilation_renderer_keeps_original_audio_and_transition_sound(
    media_factory: Callable[..., Path],
    tmp_path: Path,
) -> None:
    clips = [
        media_factory("clip-a.mp4", duration=1.2, width=360, height=640, frequency=300),
        media_factory("clip-b.mp4", duration=1.2, width=360, height=640, frequency=400),
        media_factory("clip-c.mp4", duration=1.2, width=360, height=640, frequency=500),
    ]
    transition = media_factory(
        "transition.mp4",
        duration=0.25,
        width=360,
        height=640,
        frequency=200,
    )
    sound = tmp_path / "transition.wav"
    completed = subprocess.run(
        [
            "ffmpeg",
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            "sine=frequency=1200:sample_rate=48000:duration=0.20",
            "-c:a",
            "pcm_s16le",
            "-y",
            str(sound),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    assert completed.returncode == 0, completed.stderr

    probe = MediaProbe()
    selection = ClipSelectionResult(
        selected=[
            SelectedClip(
                clip_id=f"clip-{index}",
                candidate_id=f"post-{index}",
                media_path=str(path),
                media_fingerprint=probe.probe(path).file_fingerprint,
                source_url=f"https://reddit.com/{index}",
                start_seconds=0,
                end_seconds=1,
                caption="",
                rank=index,
                analysis_score=90,
            )
            for index, path in enumerate(clips, start=1)
        ],
        total_duration_seconds=3,
        target_met=True,
    )
    creative = ProjectCreativeResult(
        header_text="",
        ranking_captions=["", "", ""],
        recommended_clip_order=["clip-1", "clip-2", "clip-3"],
        overall_theme="test",
    )
    preset = core_presets()[1].model_copy(deep=True)
    preset.id = "test-compilation"
    preset.core = False
    preset.width = 360
    preset.height = 640
    preset.duration = DurationRule(
        minimum_seconds=3.4,
        target_seconds=3.5,
        maximum_seconds=3.7,
        enforcement=DurationEnforcement.BLOCK,
    )
    preset.transition.enabled = True
    preset.transition.type = "fixed_asset"
    preset.transition.fixed_asset_id = "transition"
    preset.transition.sound_asset_id = "sound"
    preset.transition.duration_seconds = 0.25
    preset.transition.sound_duration_seconds = 0.20
    preset.transition.use_asset_audio = False
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="compilation-audio",
        preset=preset,
        selection=selection,
        creative=creative,
        output_path=tmp_path / "compilation.mp4",
        asset_paths={"transition": transition, "sound": sound},
    )

    output = FFmpegRenderer(tmp_path / "staging").render(plan, preset)
    info = probe.probe(output)

    assert plan.transition_count == 2
    assert info.has_audio
    assert info.duration_seconds == pytest.approx(3.5, abs=0.12)
    assert (
        _band_mean_volume(
            output,
            start=0.25,
            duration=0.30,
            filters="lowpass=f=700",
        )
        > -45
    )
    assert (
        _band_mean_volume(
            output,
            start=1.02,
            duration=0.16,
            filters="highpass=f=900,lowpass=f=1600",
        )
        > -45
    )
