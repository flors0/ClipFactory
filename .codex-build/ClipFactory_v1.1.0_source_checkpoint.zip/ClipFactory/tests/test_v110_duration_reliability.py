from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path

import pytest

from app.ai.prompt_builder import PromptBuilder
from app.media.media_probe import MediaProbe
from app.media.technical_validator import TechnicalValidator
from app.models.ai_models import ClipAnalysisResult, ProjectCreativeResult
from app.models.media_models import MediaInfo
from app.models.preset_models import DurationEnforcement, DurationRule
from app.models.project_models import (
    ClipSelectionResult,
    QualityThresholds,
    SelectedClip,
)
from app.models.source_models import MediaType, SourceCandidate
from app.planning.clip_selection_planner import (
    AnalyzedCandidate,
    ClipSelectionPlanner,
    UsedMediaHistory,
)
from app.presets.preset_manager import core_presets
from app.render.ffmpeg_renderer import FFmpegRenderer
from app.render.render_plan import RenderPlanBuilder
from app.review.final_review_service import FinalReviewService
from app.storage.database import Database


def _candidate(identifier: str) -> AnalyzedCandidate:
    titles = {
        "1": "Cat launches from sofa",
        "2": "Kitten argues with mirror",
        "3": "Orange thief steals blanket",
        "4": "Sleepy jumper misses landing",
        "5": "Cardboard box ambush",
    }
    return AnalyzedCandidate(
        source=SourceCandidate(
            post_id=identifier,
            title=titles[identifier],
            post_url=f"https://reddit.com/{identifier}",
            community="sillycats",
            published_at=datetime.now(UTC),
            media_type=MediaType.VIDEO,
            media_url=f"https://v.redd.it/{identifier}/DASH_720.mp4",
            rights_status="unknown",
            source_fingerprint=f"source-{identifier}",
        ),
        media=MediaInfo(
            file_path=f"/tmp/{identifier}.mp4",
            file_fingerprint=f"media-{identifier}",
            duration_seconds=20,
            width=720,
            height=1280,
            aspect_ratio=720 / 1280,
            fps=30,
            video_codec="h264",
            audio_codec="aac",
            has_audio=True,
            file_size_bytes=100,
            container="mp4",
        ),
        analysis=ClipAnalysisResult(
            clip_id=identifier,
            summary=f"Cat moment {identifier}",
            detected_theme="silly cats",
            usable=True,
            topic_match_score=90,
            quality_score=90,
            hook_score=90,
            ranking_caption=f"Reaction {identifier}",
            suggested_trim_start_seconds=4,
            suggested_trim_end_seconds=10,
        ),
    )


def test_short_ai_trim_windows_expand_to_the_preset_target(database: Database) -> None:
    result = ClipSelectionPlanner(UsedMediaHistory(database)).select(
        [_candidate(str(index)) for index in range(1, 6)],
        target_duration=65,
        thresholds=QualityThresholds(
            minimum_clip_count=5,
            maximum_clip_count=5,
            minimum_individual_clip_seconds=2,
            maximum_individual_clip_seconds=20,
        ),
    )

    assert result.target_met
    assert result.total_duration_seconds == pytest.approx(65)
    assert [clip.duration_seconds for clip in result.selected] == pytest.approx([13] * 5)
    assert result.extended_trim_clip_ids == ["1", "2", "3", "4", "5"]
    assert all(clip.start_seconds <= 4 and clip.end_seconds >= 10 for clip in result.selected)
    assert any("without looping footage" in warning for warning in result.warnings)


@pytest.mark.parametrize(
    ("enforcement", "expected_pass", "expected_blocking"),
    [
        (DurationEnforcement.WARN, True, False),
        (DurationEnforcement.BLOCK, False, True),
        (DurationEnforcement.AUTO_EXTEND, False, True),
    ],
)
def test_final_review_uses_the_preset_duration_enforcement(
    enforcement: DurationEnforcement,
    expected_pass: bool,
    expected_blocking: bool,
    media_factory: Callable[..., Path],
    tmp_path: Path,
) -> None:
    media = media_factory(
        f"duration-{enforcement.value}.mp4",
        duration=3,
        width=360,
        height=640,
    )
    preset = core_presets()[0].model_copy(deep=True)
    preset.width = 360
    preset.height = 640
    preset.duration = DurationRule(
        minimum_seconds=5,
        target_seconds=7,
        maximum_seconds=9,
        enforcement=enforcement,
    )
    probe = MediaProbe()
    review = FinalReviewService(
        probe,
        TechnicalValidator(probe),
        None,
        PromptBuilder("clip-test", "creative-test", "review-test"),
        ai_enabled=False,
    )

    technical, ai_review, _warnings = review.review(
        media,
        preset,
        theme="cats",
        platform="youtube",
        job_id="duration-review",
        deep_scan=False,
    )

    duration_check = next(check for check in technical.checks if check.name == "Duration")
    assert technical.passed is expected_pass
    assert not duration_check.passed
    assert duration_check.blocking is expected_blocking
    assert ai_review is None
    if enforcement == DurationEnforcement.WARN:
        assert any("non-blocking" in warning for warning in technical.warnings)
    else:
        assert technical.warnings == []


def test_warn_duration_render_reaches_non_blocking_review(
    media_factory: Callable[..., Path],
    tmp_path: Path,
) -> None:
    source = media_factory(
        "short-warn-source.mp4",
        duration=3.2,
        width=360,
        height=640,
    )
    probe = MediaProbe()
    info = probe.probe(source)
    selection = ClipSelectionResult(
        selected=[
            SelectedClip(
                clip_id="short",
                candidate_id="post-short",
                media_path=str(source),
                media_fingerprint=info.file_fingerprint,
                source_url="https://reddit.com/short",
                start_seconds=0,
                end_seconds=3,
                caption="Still rendered",
                rank=1,
                analysis_score=80,
            )
        ],
        total_duration_seconds=3,
        target_met=False,
    )
    creative = ProjectCreativeResult(
        header_text="Short safe selection",
        ranking_captions=["Still rendered"],
        recommended_clip_order=["short"],
        overall_theme="cats",
    )
    preset = core_presets()[0].model_copy(deep=True)
    preset.width = 360
    preset.height = 640
    preset.ranking.count = 1
    preset.duration = DurationRule(
        minimum_seconds=5,
        target_seconds=7,
        maximum_seconds=9,
        enforcement=DurationEnforcement.WARN,
    )
    for layer in preset.layers:
        if layer.rich_text:
            layer.rich_text.default_style.font_size = min(
                layer.rich_text.default_style.font_size,
                28,
            )
            layer.rich_text.default_style.minimum_font_size = 18
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="short-warn",
        preset=preset,
        selection=selection,
        creative=creative,
        output_path=tmp_path / "short-warn.mp4",
    )

    output = FFmpegRenderer(tmp_path / "staging").render(plan, preset)
    technical, _ai_review, _warnings = FinalReviewService(
        probe,
        TechnicalValidator(probe),
        None,
        PromptBuilder("clip-test", "creative-test", "review-test"),
        ai_enabled=False,
    ).review(
        output,
        preset,
        theme="cats",
        platform="youtube",
        job_id="short-warn",
        deep_scan=False,
    )

    duration_check = next(check for check in technical.checks if check.name == "Duration")
    assert output.is_file() and output.stat().st_size > 0
    assert probe.probe(output).duration_seconds == pytest.approx(3, abs=0.08)
    assert technical.passed
    assert not duration_check.passed
    assert not duration_check.blocking


def test_extended_five_clip_ranking_reaches_real_render(
    database: Database,
    media_factory: Callable[..., Path],
    tmp_path: Path,
) -> None:
    probe = MediaProbe()
    candidates: list[AnalyzedCandidate] = []
    for index in range(1, 6):
        path = media_factory(
            f"extended-{index}.mp4",
            duration=2,
            width=360,
            height=640,
            frequency=280 + index * 90,
        )
        template = _candidate(str(index))
        candidates.append(
            AnalyzedCandidate(
                source=template.source,
                media=probe.probe(path),
                analysis=template.analysis.model_copy(
                    update={
                        "suggested_trim_start_seconds": 0.2,
                        "suggested_trim_end_seconds": 0.8,
                    }
                ),
            )
        )
    selection = ClipSelectionPlanner(UsedMediaHistory(database)).select(
        candidates,
        target_duration=6.5,
        thresholds=QualityThresholds(
            minimum_clip_count=5,
            maximum_clip_count=5,
            minimum_individual_clip_seconds=0.5,
            maximum_individual_clip_seconds=2,
        ),
    )
    preset = core_presets()[0].model_copy(deep=True)
    preset.width = 360
    preset.height = 640
    preset.duration = DurationRule(
        minimum_seconds=6.4,
        target_seconds=6.5,
        maximum_seconds=6.6,
        enforcement=DurationEnforcement.BLOCK,
    )
    for layer in preset.layers:
        if layer.rich_text:
            layer.rich_text.default_style.font_size = min(
                layer.rich_text.default_style.font_size,
                28,
            )
            layer.rich_text.default_style.minimum_font_size = 18
    creative = ProjectCreativeResult(
        header_text="Extended Trim Acceptance",
        ranking_captions=[f"Moment {index}" for index in range(1, 6)],
        recommended_clip_order=[str(index) for index in range(1, 6)],
        overall_theme="cats",
    )
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="extended-five",
        preset=preset,
        selection=selection,
        creative=creative,
        output_path=tmp_path / "extended-five.mp4",
    )

    output = FFmpegRenderer(tmp_path / "staging").render(plan, preset)
    info = probe.probe(output)

    assert selection.target_met
    assert [clip.duration_seconds for clip in selection.selected] == pytest.approx([1.3] * 5)
    assert [clip.rank for clip in plan.clips] == [5, 4, 3, 2, 1]
    assert (info.width, info.height, round(info.fps)) == (360, 640, 30)
    assert info.video_codec == "h264"
    assert info.audio_codec == "aac"
    assert info.has_audio
    assert info.duration_seconds == pytest.approx(6.5, abs=0.08)
