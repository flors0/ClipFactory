from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path
from threading import Event
from urllib.parse import parse_qs, urlparse

import pytest

from app.core.exceptions import OAuthError, UploadError
from app.models.channel_models import ChannelProfile
from app.models.media_models import TechnicalCheck, TechnicalValidationResult
from app.models.render_models import ProductionJob, ProductionStatus
from app.models.review_models import ReviewItem, ReviewStatus
from app.models.upload_models import (
    TikTokMetadata,
    UploadJob,
    UploadResult,
    UploadStatus,
    YouTubeMetadata,
)
from app.review.review_queue import ReviewQueue
from app.scheduling.job_store import PersistentJobStore
from app.scheduling.scheduler import PersistentUploadScheduler
from app.storage.database import Database
from app.storage.repositories.channel_repository import ChannelRepository
from app.storage.repositories.job_repository import (
    ProductionJobRepository,
    ReviewRepository,
    UploadJobRepository,
)
from app.uploads.metadata_mapping import tiktok_post_info, youtube_insert_body
from app.uploads.oauth_manager import InMemoryCredentialStore, OAuthManager, TikTokToken
from app.uploads.tiktok_uploader import TikTokUploader
from app.uploads.upload_queue import UploadQueue
from app.uploads.uploader import Uploader
from app.uploads.youtube_uploader import YouTubeUploader


def test_youtube_metadata_mapping_uses_official_resource_fields() -> None:
    metadata = YouTubeMetadata(
        title="A verified title",
        description="Observed moments from the rendered clips.",
        tags=["cats", "shorts"],
        hashtags=["Shorts", "Cats"],
        category_id="15",
        privacy_status="unlisted",
        made_for_kids=False,
        recording_date="2026-07-20T00:00:00Z",
    )
    body = youtube_insert_body(metadata)
    assert body["snippet"]["title"] == metadata.title
    assert body["snippet"]["categoryId"] == "15"
    assert body["snippet"]["description"].endswith("#Shorts #Cats")
    assert body["status"]["privacyStatus"] == "unlisted"
    assert body["status"]["selfDeclaredMadeForKids"] is False
    assert body["recordingDetails"]["recordingDate"] == metadata.recording_date

    scheduled_at = datetime.now(UTC) + timedelta(days=1)
    scheduled = youtube_insert_body(metadata, scheduled_at)
    assert scheduled["status"]["privacyStatus"] == "private"
    assert scheduled["status"]["publishAt"].endswith("Z")
    with pytest.raises(ValueError, match="timezone"):
        youtube_insert_body(metadata, datetime.now().replace(tzinfo=None) + timedelta(days=1))


def test_tiktok_metadata_mapping_uses_capability_flags() -> None:
    metadata = TikTokMetadata(
        caption="Which moment wins?",
        hashtags=["Cats", "Ranking"],
        privacy_level="SELF_ONLY",
        comments_enabled=True,
        duet_enabled=False,
        stitch_enabled=True,
        cover_timestamp_ms=500,
    )
    body = tiktok_post_info(metadata)
    assert body == {
        "title": "Which moment wins? #Cats #Ranking",
        "privacy_level": "SELF_ONLY",
        "disable_comment": False,
        "disable_duet": True,
        "disable_stitch": False,
        "video_cover_timestamp_ms": 500,
    }


def _review_item(job: ProductionJob, path: Path, channel: ChannelProfile) -> ReviewItem:
    return ReviewItem(
        production_job_id=job.id,
        project_id=job.project_id,
        video_path=str(path),
        filename=path.name,
        duration_seconds=65,
        platform=channel.platform,
        channel_id=channel.id,
        preset_id=job.preset_id,
        header="Reviewed header",
        clip_ids=["clip-1"],
        ranking_captions=["Observed caption"],
        upload_metadata=YouTubeMetadata(title="Reviewed title").model_dump(mode="json"),
        scheduled_at=datetime.now(UTC) + timedelta(hours=2),
        technical_validation=TechnicalValidationResult(
            passed=True,
            checks=[TechnicalCheck(name="Valid MP4", passed=True)],
        ),
    )


def test_review_and_upload_are_separate_approval_gates(database: Database, tmp_path: Path) -> None:
    production_repository = ProductionJobRepository(database)
    review_repository = ReviewRepository(database)
    upload_repository = UploadJobRepository(database)
    job = ProductionJob(
        project_id="project",
        preset_id="preset",
        channel_id="channel",
        status=ProductionStatus.VALIDATING,
    )
    production_repository.save(job, validate_transition=False)
    channel = ChannelProfile(id="channel", display_name="YouTube", platform="youtube")
    video = tmp_path / "video.mp4"
    video.write_bytes(b"non-empty-test-video")
    reviews = ReviewQueue(review_repository, production_repository)
    item = reviews.add(_review_item(job, video, channel))
    assert item.status == ReviewStatus.PENDING
    assert production_repository.get(job.id).status == ProductionStatus.AWAITING_REVIEW

    queue = UploadQueue(upload_repository, production_repository)
    with pytest.raises(ValueError, match="approved"):
        queue.create_from_review(item, channel)
    item = reviews.approve(item.id)
    upload = queue.create_from_review(item, channel)
    assert upload.status == UploadStatus.BLOCKED_APPROVAL
    assert not upload.batch_approved
    assert upload.execution_at == item.scheduled_at
    approved = queue.approve_upload_batch([upload.id])[0]
    assert approved.batch_approved
    assert approved.status == UploadStatus.SCHEDULED
    assert production_repository.get(job.id).status == ProductionStatus.QUEUED_FOR_UPLOAD


def test_public_youtube_job_uses_native_publish_schedule(
    database: Database, tmp_path: Path
) -> None:
    production_repository = ProductionJobRepository(database)
    review_repository = ReviewRepository(database)
    upload_repository = UploadJobRepository(database)
    job = ProductionJob(
        project_id="project",
        preset_id="preset",
        channel_id="channel",
        status=ProductionStatus.VALIDATING,
    )
    production_repository.save(job, validate_transition=False)
    channel = ChannelProfile(
        id="channel",
        display_name="Public YouTube",
        platform="youtube",
        default_privacy="public",
    )
    video = tmp_path / "public-video.mp4"
    video.write_bytes(b"non-empty-test-video")
    reviews = ReviewQueue(review_repository, production_repository)
    item = _review_item(job, video, channel)
    item.upload_metadata = YouTubeMetadata(
        title="Scheduled public title",
        privacy_status="public",
    ).model_dump(mode="json")
    item = reviews.add(item)
    item = reviews.approve(item.id)

    upload = UploadQueue(upload_repository, production_repository).create_from_review(item, channel)

    assert upload.execution_at <= datetime.now(UTC)


class SuccessfulUploader(Uploader):
    platform = "youtube"

    def upload(
        self,
        job: UploadJob,
        channel: ChannelProfile,
        *,
        cancel_event: Event | None = None,
        progress_callback=None,
        state_callback=None,
    ) -> UploadResult:
        assert job.batch_approved
        assert channel.id == job.channel_id
        (progress_callback or (lambda _value, _message: None))(60, "Mock transfer")
        return UploadResult(
            remote_id="youtube-video-id",
            status=UploadStatus.PUBLISHED,
            published_at=datetime.now(UTC),
        )


def test_persistent_scheduler_executes_one_due_approved_job(
    database: Database, tmp_path: Path
) -> None:
    production_repository = ProductionJobRepository(database)
    upload_repository = UploadJobRepository(database)
    channel_repository = ChannelRepository(database)
    production = ProductionJob(
        project_id="project",
        preset_id="preset",
        channel_id="channel",
        status=ProductionStatus.QUEUED_FOR_UPLOAD,
    )
    production_repository.save(production, validate_transition=False)
    channel = ChannelProfile(id="channel", display_name="YouTube", platform="youtube")
    channel_repository.save(channel)
    video = tmp_path / "video.mp4"
    video.write_bytes(b"test")
    job = UploadJob(
        production_job_id=production.id,
        review_item_id="review",
        channel_id=channel.id,
        platform="youtube",
        file_path=str(video),
        scheduled_at=datetime.now(UTC) - timedelta(minutes=1),
        execution_at=datetime.now(UTC) - timedelta(minutes=1),
        status=UploadStatus.QUEUED,
        batch_approved=True,
        metadata=YouTubeMetadata(title="Test").model_dump(mode="json"),
    )
    upload_repository.save(job)
    scheduler = PersistentUploadScheduler(
        PersistentJobStore(upload_repository),
        upload_repository,
        channel_repository,
        production_repository,
        {"youtube": SuccessfulUploader()},
    )
    completed = scheduler.run_due_once(datetime.now(UTC))
    assert completed is not None
    assert completed.status == UploadStatus.PUBLISHED
    assert completed.remote_id == "youtube-video-id"
    persisted_production = production_repository.get(production.id)
    assert persisted_production.status == ProductionStatus.PUBLISHED
    assert "youtube-video-id" in persisted_production.current_step


def test_interrupted_upload_is_recoverable(database: Database) -> None:
    repository = UploadJobRepository(database)
    now = datetime.now(UTC)
    job = UploadJob(
        production_job_id="production",
        review_item_id="review",
        channel_id="channel",
        platform="youtube",
        file_path="video.mp4",
        scheduled_at=now,
        execution_at=now,
        status=UploadStatus.UPLOADING,
        batch_approved=True,
        resumable_uri_reference="persisted-session",
    )
    repository.save(job)
    recovered = PersistentJobStore(repository).recover_interrupted(stale_after=timedelta(0))
    assert recovered[0].status == UploadStatus.FAILED
    assert recovered[0].resumable_uri_reference == "persisted-session"
    assert "stopped during upload" in recovered[0].last_error.lower()


def test_due_upload_job_is_claimed_only_once(database: Database) -> None:
    repository = UploadJobRepository(database)
    now = datetime.now(UTC)
    job = UploadJob(
        production_job_id="production",
        review_item_id="review",
        channel_id="channel",
        platform="youtube",
        file_path="video.mp4",
        scheduled_at=now,
        execution_at=now,
        status=UploadStatus.QUEUED,
        batch_approved=True,
        metadata=YouTubeMetadata(title="Test").model_dump(mode="json"),
    )
    repository.save(job)

    first = repository.claim_due(now + timedelta(seconds=1))
    second = UploadJobRepository(database).claim_due(now + timedelta(seconds=1))

    assert [value.id for value in first] == [job.id]
    assert second == []
    assert repository.get(job.id).status == UploadStatus.UPLOADING


@pytest.mark.parametrize(
    ("size", "expected_count"),
    [
        (4 * 1_000_000, 1),
        (64 * 1_000_000, 1),
        (65 * 1_000_000, 2),
        (96 * 1_000_000, 3),
    ],
)
def test_tiktok_chunk_plan_uses_official_remainder_rule(size: int, expected_count: int) -> None:
    chunk_size, count = TikTokUploader._chunk_plan(size)
    final_size = size - chunk_size * (count - 1)
    assert count == expected_count
    assert count <= 1000
    assert chunk_size <= 64 * 1_000_000
    assert final_size <= 128 * 1_000_000


class _DraftOAuth:
    def tiktok_token(self, _channel_id, _client):
        return TikTokToken(
            access_token="test-access",
            refresh_token="test-refresh",
            open_id="draft-user",
            scope="video.upload",
            expires_at=datetime.now(UTC) + timedelta(hours=1),
        )


class _NoNetworkClient:
    def post(self, *_args, **_kwargs):
        raise AssertionError("Draft-only capability detection must not query creator_info.")


def test_tiktok_draft_only_capability_does_not_require_publish_scope() -> None:
    uploader = TikTokUploader(_DraftOAuth(), probe=None, client=_NoNetworkClient())
    capabilities = uploader.capabilities("channel")
    assert capabilities.draft_upload_available
    assert not capabilities.direct_post_available
    assert capabilities.creator_username == "draft-user"


def test_tiktok_oauth_scopes_are_configurable_and_validated(
    database: Database, monkeypatch
) -> None:
    manager = OAuthManager(database, InMemoryCredentialStore())
    monkeypatch.setenv("TIKTOK_CLIENT_KEY", "client-key")
    monkeypatch.setenv("TIKTOK_REDIRECT_URI", "http://127.0.0.1:8765/oauth/tiktok/callback")
    monkeypatch.setenv("TIKTOK_SCOPES", "video.upload")
    url, _state = manager.tiktok_authorization_url("channel")
    assert parse_qs(urlparse(url).query)["scope"] == ["video.upload"]
    monkeypatch.setenv("TIKTOK_SCOPES", "unsupported.scope")
    with pytest.raises(OAuthError, match="TIKTOK_SCOPES"):
        manager.tiktok_authorization_url("channel")


class _ExecuteRequest:
    def __init__(self, payload):
        self.payload = payload

    def execute(self):
        return self.payload


class _FakeVideos:
    def __init__(self, payload):
        self.payload = payload

    def list(self, **_kwargs):
        return _ExecuteRequest(self.payload)


class _FakeYouTubeService:
    def __init__(self, payload):
        self.payload = payload

    def videos(self):
        return _FakeVideos(self.payload)


def _remote_youtube_job(status: UploadStatus = UploadStatus.PROCESSING) -> UploadJob:
    now = datetime.now(UTC)
    return UploadJob(
        production_job_id="production",
        review_item_id="review",
        channel_id="channel",
        platform="youtube",
        file_path="already-transferred.mp4",
        scheduled_at=now + timedelta(hours=1),
        status=status,
        batch_approved=True,
        remote_id="video-id",
        metadata=YouTubeMetadata(title="Test", privacy_status="public").model_dump(mode="json"),
    )


def test_youtube_remote_status_distinguishes_processing_scheduled_and_rejected() -> None:
    job = _remote_youtube_job()
    metadata = YouTubeMetadata.model_validate(job.metadata)
    processing = YouTubeUploader._remote_result(
        _FakeYouTubeService(
            {
                "items": [
                    {
                        "status": {"uploadStatus": "uploaded", "privacyStatus": "private"},
                        "processingDetails": {"processingStatus": "processing"},
                    }
                ]
            }
        ),
        job,
        metadata,
    )
    assert processing.status == UploadStatus.PROCESSING

    scheduled = YouTubeUploader._remote_result(
        _FakeYouTubeService(
            {
                "items": [
                    {
                        "status": {
                            "uploadStatus": "processed",
                            "privacyStatus": "private",
                            "publishAt": job.scheduled_at.isoformat(),
                        },
                        "processingDetails": {"processingStatus": "succeeded"},
                    }
                ]
            }
        ),
        job,
        metadata,
    )
    assert scheduled.status == UploadStatus.SCHEDULED

    with pytest.raises(UploadError, match="did not succeed"):
        YouTubeUploader._remote_result(
            _FakeYouTubeService(
                {
                    "items": [
                        {
                            "status": {
                                "uploadStatus": "rejected",
                                "rejectionReason": "duplicate",
                            }
                        }
                    ]
                }
            ),
            job,
            metadata,
        )
