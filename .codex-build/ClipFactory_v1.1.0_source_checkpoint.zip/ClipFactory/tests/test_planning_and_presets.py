from __future__ import annotations

from datetime import UTC, datetime, time, timedelta

import pytest

from app.models.ai_models import ClipAnalysisResult, ProjectCreativeResult
from app.models.channel_models import ChannelProfile
from app.models.media_models import MediaInfo
from app.models.preset_models import (
    Color,
    DurationEnforcement,
    DurationRule,
    Preset,
    RichTextDocument,
)
from app.models.project_models import ClipSelectionResult, QualityThresholds, SelectedClip
from app.models.schedule_models import MissedJobPolicy, ScheduleRequest, ScheduleTemplate
from app.models.source_models import MediaType, SourceCandidate
from app.planning.batch_planner import BatchPlanner
from app.planning.clip_selection_planner import (
    AnalyzedCandidate,
    ClipSelectionPlanner,
    UsedMediaHistory,
)
from app.planning.duration_rules import evaluate_duration
from app.planning.schedule_planner import SchedulePlanner
from app.presets.preset_manager import PresetManager, core_presets, legacy_core_presets
from app.presets.preset_validator import PresetValidator
from app.presets.rich_text import RichTextEditor, expand_placeholders
from app.render.render_plan import RenderPlanBuilder
from app.sources.source_profile_factory import SourceProfileFactory
from app.storage.database import Database
from app.storage.repositories.preset_repository import PresetRepository


def test_core_presets_are_valid_serializable_and_protected(database: Database) -> None:
    repository = PresetRepository(database)
    manager = PresetManager(repository)
    assert len(manager.ensure_core_presets()) == 2
    assert manager.ensure_core_presets() == []
    assert len(repository.list()) == 2
    assert {preset.name for preset in repository.list()} == {
        "Ranking",
        "TikTok Core Compilation",
    }
    for preset in repository.list():
        assert not preset.transition.enabled
        assert preset.transition.fixed_asset_id is None
        assert preset.transition.sound_asset_id is None
        assert Preset.model_validate_json(preset.model_dump_json()) == preset
        assert PresetValidator().validate(preset) == []
    with pytest.raises(ValueError, match="Core presets"):
        repository.delete("core-ranking")
    ranking = repository.get("core-ranking")
    assert ranking is not None
    ranking.ranking.spacing = 0.025
    manager.save(ranking)
    assert repository.get("core-ranking").ranking.spacing == 0.025
    assert manager.reset_core("core-ranking").ranking.spacing == 0.012
    duplicate = manager.duplicate("core-ranking", "My Ranking")
    assert not duplicate.core
    assert manager.rename(duplicate.id, "Renamed Ranking").name == "Renamed Ranking"
    assert manager.delete(duplicate.id)


def test_v105_preset_migration_keeps_custom_presets(database: Database) -> None:
    repository = PresetRepository(database)
    for preset in legacy_core_presets():
        repository.save(preset)
    custom = legacy_core_presets()[0].model_copy(deep=True)
    custom.id = "my-custom-ranking"
    custom.name = "My Custom Ranking"
    custom.core = False
    custom.ranking.spacing = 0.027
    repository.save(custom)

    manager = PresetManager(repository)
    manager.ensure_core_presets()
    manager.ensure_core_presets()

    values = repository.list()
    assert {preset.id for preset in values if preset.core} == {
        "core-ranking",
        "core-tiktok-core-compilation",
    }
    migrated_custom = repository.get("my-custom-ranking")
    assert migrated_custom is not None
    assert migrated_custom.ranking.spacing == 0.027
    assert not any(preset.id in {value.id for value in legacy_core_presets()} for preset in values)


def test_rich_text_range_styling_and_replacement() -> None:
    document = RichTextDocument(text="Top cat moment")
    red = document.default_style.model_copy(
        update={
            "foreground": Color(red=255, green=20, blue=20),
            "italic": True,
        }
    )
    styled = RichTextEditor.apply_style(document, 4, 7, red)
    assert RichTextEditor.style_at(styled, 5).foreground.red == 255
    assert RichTextEditor.style_at(styled, 5).italic
    assert RichTextEditor.style_at(styled, 1) == document.default_style

    replaced = RichTextEditor.replace_text(styled, 4, 7, "kitten")
    assert replaced.text == "Top kitten moment"
    assert RichTextEditor.style_at(replaced, 6).foreground == red.foreground
    assert all(span.end <= len(replaced.text) for span in replaced.spans)


def test_rich_text_placeholder_expansion_preserves_fixed_and_dynamic_styles() -> None:
    document = RichTextDocument(text="Top 5 {theme}")
    fixed_style = document.default_style.model_copy(
        update={"foreground": Color(red=255, green=30, blue=30), "bold": True}
    )
    placeholder_style = document.default_style.model_copy(
        update={"foreground": Color(red=240, green=240, blue=255), "italic": True}
    )
    document = RichTextEditor.apply_style(document, 0, 5, fixed_style)
    document = RichTextEditor.apply_style(document, 6, 13, placeholder_style)

    expanded = expand_placeholders(document, {"theme": "funny cats"})

    assert expanded.text == "Top 5 funny cats"
    assert RichTextEditor.style_at(expanded, 1) == fixed_style
    assert RichTextEditor.style_at(expanded, 8) == placeholder_style


def test_render_plan_expands_preset_header_placeholders(tmp_path) -> None:
    preset = core_presets()[0]
    selection = ClipSelectionResult(
        selected=[_selected("first", 0, 5)],
        total_duration_seconds=5,
        target_met=True,
    )
    creative = ProjectCreativeResult(
        header_text="AI header",
        ranking_captions=["Observed caption"],
        recommended_clip_order=["first"],
        overall_theme="funny cats",
    )

    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="job",
        preset=preset,
        selection=selection,
        creative=creative,
        output_path=tmp_path / "output.mp4",
    )

    assert plan.header_text == "AI header"
    assert plan.metadata["header_document"]["text"] == plan.header_text


@pytest.mark.parametrize(
    ("enforcement", "duration", "allowed"),
    [
        (DurationEnforcement.WARN, 3, True),
        (DurationEnforcement.BLOCK, 3, False),
        (DurationEnforcement.AUTO_EXTEND, 3, False),
        (DurationEnforcement.BLOCK, 7, True),
    ],
)
def test_duration_rules(enforcement: DurationEnforcement, duration: float, allowed: bool) -> None:
    rule = DurationRule(
        minimum_seconds=5,
        target_seconds=7,
        maximum_seconds=9,
        enforcement=enforcement,
    )
    result, _warnings = evaluate_duration(duration, rule, additional_clips_available=False)
    assert result is allowed


def _selected(identifier: str, start: float, end: float) -> SelectedClip:
    return SelectedClip(
        clip_id=identifier,
        candidate_id=f"post-{identifier}",
        media_path=f"/tmp/{identifier}.mp4",
        media_fingerprint=f"fingerprint-{identifier}",
        source_url=f"https://reddit.com/{identifier}",
        start_seconds=start,
        end_seconds=end,
        caption=f"Caption {identifier}",
        rank=1,
        analysis_score=90,
    )


def test_render_plan_maps_order_copy_and_timing(tmp_path) -> None:
    preset = core_presets()[0]
    selection = ClipSelectionResult(
        selected=[_selected("first", 0, 3), _selected("second", 1, 5)],
        total_duration_seconds=7,
        target_met=True,
    )
    creative = ProjectCreativeResult(
        header_text="Original header",
        ranking_captions=["Second caption", "First caption"],
        recommended_clip_order=["second", "first"],
        overall_theme="cats",
    )
    plan = RenderPlanBuilder().build(
        project_id="project",
        job_id="job",
        preset=preset,
        selection=selection,
        creative=creative,
        output_path=tmp_path / "output.mp4",
        project_overrides={"header_text": "Edited header"},
    )
    assert [clip.clip_id for clip in plan.clips] == ["first", "second"]
    assert plan.header_text == "Edited header"
    assert plan.captions[0].start_seconds == 3
    assert plan.captions[0].end_seconds == 7
    assert plan.captions[1].start_seconds == 0
    assert plan.captions[1].end_seconds == 7
    assert plan.target_duration_seconds == 7


def _analyzed(
    identifier: str,
    *,
    fingerprint: str | None = None,
    title: str | None = None,
    rights: str = "unknown",
) -> AnalyzedCandidate:
    candidate = SourceCandidate(
        post_id=identifier,
        title=title or f"Unique clip {identifier}",
        post_url=f"https://reddit.com/r/test/comments/{identifier}/clip/",
        community="test",
        published_at=datetime.now(UTC),
        media_type=MediaType.VIDEO,
        media_url=f"https://v.redd.it/{identifier}/video.mp4",
        rights_status=rights,
        source_fingerprint=f"source-{identifier}",
    )
    media = MediaInfo(
        file_path=f"/tmp/{identifier}.mp4",
        file_fingerprint=fingerprint or f"media-{identifier}",
        duration_seconds=5,
        width=720,
        height=1280,
        aspect_ratio=0.5625,
        fps=30,
        video_codec="h264",
        audio_codec="aac",
        has_audio=True,
        file_size_bytes=100,
        container="mp4",
    )
    analysis = ClipAnalysisResult(
        clip_id=identifier,
        summary=f"Summary {identifier}",
        detected_theme="cats",
        usable=True,
        topic_match_score=90,
        quality_score=90,
        hook_score=90,
        ranking_caption=f"Caption {identifier}",
    )
    return AnalyzedCandidate(candidate, media, analysis)


def test_clip_selection_prevents_duplicates_and_used_media(database: Database) -> None:
    history = UsedMediaHistory(database)
    history.reserve("media-used", "used", channel_id="channel", batch_id="previous")
    planner = ClipSelectionPlanner(history)
    thresholds = QualityThresholds(
        minimum_clip_count=2,
        maximum_clip_count=5,
        minimum_individual_clip_seconds=1,
        maximum_individual_clip_seconds=5,
    )
    result = planner.select(
        [
            _analyzed("one"),
            _analyzed("duplicate-media", fingerprint="media-one"),
            _analyzed("similar-title", title="Unique clip one!"),
            _analyzed("used", fingerprint="media-used"),
            _analyzed("two"),
        ],
        target_duration=10,
        thresholds=thresholds,
        channel_id="channel",
    )
    assert [value.clip_id for value in result.selected] == ["one", "two"]
    assert result.target_met
    assert set(result.rejected_clip_ids) == {"duplicate-media", "similar-title", "used"}


def test_strict_rights_policy_blocks_unknown_media(database: Database) -> None:
    thresholds = QualityThresholds(
        minimum_clip_count=1,
        allow_unknown_rights=False,
        minimum_individual_clip_seconds=1,
    )
    result = ClipSelectionPlanner(UsedMediaHistory(database)).select(
        [_analyzed("unknown"), _analyzed("cleared", rights="cleared")],
        target_duration=5,
        thresholds=thresholds,
    )
    assert [value.clip_id for value in result.selected] == ["cleared"]


def test_batch_planning_and_timezone_schedule() -> None:
    source = SourceProfileFactory().create("SillyCats")
    preset = core_presets()[0]
    channel = ChannelProfile(display_name="YouTube test", platform="youtube")
    start = datetime.now(UTC) + timedelta(hours=1)
    schedule = SchedulePlanner().build(
        ScheduleRequest(timezone="Europe/Berlin", count=2, start_at=start, interval_hours=3)
    )
    batch = BatchPlanner().build(
        sources=[source],
        presets=[preset],
        channels=[channel],
        video_count=2,
        schedule=schedule,
        analyses_per_video=4,
    )
    assert len(batch.items) == 2
    assert batch.estimated_downloads == 8
    assert batch.estimated_ai_requests == 12
    assert all(item.job.scheduled_at and item.job.scheduled_at.tzinfo for item in batch.items)


def test_batch_planner_supports_an_exact_video_count_per_channel() -> None:
    source = SourceProfileFactory().create("SillyCats")
    presets = core_presets()[:2]
    channels = [
        ChannelProfile(id="youtube-a", display_name="YouTube A", platform="youtube"),
        ChannelProfile(id="youtube-b", display_name="YouTube B", platform="youtube"),
        ChannelProfile(id="tiktok-a", display_name="TikTok A", platform="tiktok"),
    ]
    start = datetime.now(UTC) + timedelta(hours=1)
    schedule = [start + timedelta(hours=index) for index in range(6)]

    batch = BatchPlanner().build(
        sources=[source],
        presets=presets,
        channels=channels,
        video_count=6,
        videos_per_channel=2,
        schedule=schedule,
    )

    counts = {
        channel.id: sum(item.channel and item.channel.id == channel.id for item in batch.items)
        for channel in channels
    }
    assert counts == {"youtube-a": 2, "youtube-b": 2, "tiktok-a": 2}
    assert all(item.target_platform == item.channel.platform for item in batch.items)


def test_schedule_template_and_missed_job_policies() -> None:
    planner = SchedulePlanner()
    now = datetime.now(UTC)
    schedule = [now - timedelta(hours=2), now + timedelta(hours=2)]
    skipped, missed = planner.apply_missed_policy(schedule, now=now, policy=MissedJobPolicy.SKIP)
    assert missed == [schedule[0]]
    assert skipped == [schedule[1]]
    immediate, _ = planner.apply_missed_policy(
        schedule,
        now=now,
        policy=MissedJobPolicy.UPLOAD_IMMEDIATELY,
    )
    assert immediate[0] == now

    template = ScheduleTemplate(
        name="Weekday mornings",
        timezone="UTC",
        weekdays=list(range(7)),
        daily_times=[time(9, 0), time(18, 0)],
    )
    upcoming = planner.next_from_template(template, count=3, after=now)
    assert len(upcoming) == 3
    assert upcoming == sorted(upcoming)
    assert all(value > now for value in upcoming)
